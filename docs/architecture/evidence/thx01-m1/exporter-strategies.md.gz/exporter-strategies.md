# PyTorch ONNX Conversion Report

```
❌ Obtain model graph with `torch.export.export(..., strict=False)`
❌ Obtain model graph with `torch.export.export(..., strict=True)`
✅ Obtain model graph with `torch.export._draft_export.draft_export`
✅ Decompose operators for ONNX compatibility
✅ Translate the graph into ONNX
⚪ Run `onnx.checker` on the ONNX model
⚪ Execute the model with ONNX Runtime
⚪ Validate model output accuracy
```

## Error messages

```pytb
# ⚠️ Errors from strategy 'TorchExportNonStrictStrategy': -----------------------

Traceback (most recent call last):

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 118, in __call__
    exported_program = self._capture(model, args, kwargs, dynamic_shapes)
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 225, in _capture
    raise exc from None

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 210, in _capture
    return torch.export.export(
           ^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 319, in export
    raise e

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 286, in export
    return _export(
           ^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2176, in _export
    ep = _export_for_training(
         ^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2037, in _export_for_training
    export_artifact = export_func(
                      ^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1979, in _non_strict_export
    aten_export_artifact = _to_aten_func(  # type: ignore[operator]
                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1800, in _export_to_aten_ir_make_fx
    raise UserError(UserErrorType.CONSTRAINT_VIOLATION, str(e))  # noqa: B904
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

torch._dynamo.exc.UserError: Constraints violated (sequence)! For more information, run with TORCH_LOGS="+dynamic".
  - Not all values of sequence = L['input_ids'].size()[1] in the specified range sequence <= 1024 satisfy the generated guard 1 != L['input_ids'].size()[1].

The error above occurred when calling torch.export.export. If you would like to view some more information about this error, and get a list of all other errors that may occur in your export call, you can replace your `export()` call with `draft_export()`.


# ⚠️ Errors from strategy 'TorchExportStrictStrategy': -----------------------

Traceback (most recent call last):

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 118, in __call__
    exported_program = self._capture(model, args, kwargs, dynamic_shapes)
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 176, in _capture
    raise exc from None

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 161, in _capture
    return torch.export.export(
           ^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 319, in export
    raise e

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 286, in export
    return _export(
           ^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2176, in _export
    ep = _export_for_training(
         ^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2037, in _export_for_training
    export_artifact = export_func(
                      ^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1411, in _strict_export
    gm_torch_level = _export_to_torch_ir(
                     ^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 815, in _export_to_torch_ir
    raise UserError(UserErrorType.CONSTRAINT_VIOLATION, str(e))  # noqa: B904
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

torch._dynamo.exc.UserError: Constraints violated (sequence)! For more information, run with TORCH_LOGS="+dynamic".
  - Not all values of sequence = L['input_ids'].size()[1] in the specified range sequence <= 1024 satisfy the generated guard 1 != L['input_ids'].size()[1].


The error above occurred when calling torch.export.export. If you would like to view some more information about this error, and get a list of all other errors that may occur in your export call, you can replace your `export()` call with `draft_export()`.


# ⚠️ Errors from strategy 'TorchExportDraftExportStrategy': -----------------------

RuntimeError: [93m
###################################################################################################
WARNING: 2 issue(s) found during export, and it was not able to soundly produce a graph.
Please follow the instructions to fix the errors.
###################################################################################################

1. Guard Added.
    A guard was added during tracing, which might've resulted in some incorrect
    tracing or constraint violation error.
    Specifically, this guard was added: Eq(s53, s70), where {'s70': "L['input_ids'].size()[1]", 's53': "L['attention_mask'].size()[1]"}.
    This occurred at the following stacktrace: 
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/module.py, lineno 1784, in _call_impl
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py, lineno 550, in forward
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py, lineno 465, in sdpa_attention_forward
            F.scaled_dot_product_attention(:
        
        Locals:
            query: ['Tensor(shape: torch.Size([1, 12, s70, 64]), stride: (768*s70, 64, 768, 1), storage_offset: 0)']
            key: ['Tensor(shape: torch.Size([1, 12, s70, 64]), stride: (768*s70, 64, 768, 1), storage_offset: 0)']
            value: ['Tensor(shape: torch.Size([1, 12, s70, 64]), stride: (2304*s70, 64, 2304, 1), storage_offset: 1536)']
            module: [None]
            attention_mask: ['Tensor(shape: torch.Size([1, 1, s53, s53]), stride: (s53**2, s53**2, s53, 1), storage_offset: 0)']

        Symbols:
           s70: L['input_ids'].size()[1]
           s53: L['attention_mask'].size()[1]

    And the following framework stacktrace: 
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/fx/experimental/proxy_tensor.py, lineno 1462, in __torch_dispatch__
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/fx/experimental/proxy_tensor.py, lineno 914, in proxy_call
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/_ops.py, lineno 829, in __call__
            return self._op(*args, **kwargs)

    Because of this, we have modified the dynamic shapes structure to be the
    following. You can also use torch.export.Dim.AUTO instead to specify your
    dynamic shapes, and we will automatically infer the dynamism for you.
    ```
    dynamic_shapes = ({1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, {1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, None, None, None)
    ```

2. Guard Added.
    A guard was added during tracing, which might've resulted in some incorrect
    tracing or constraint violation error.
    Specifically, this guard was added: Eq(768*s53, 74496), where {'s53': "L['attention_mask'].size()[1]"}.
    This occurred at the following stacktrace: 
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/module.py, lineno 1773, in _wrapped_call_impl
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/module.py, lineno 1784, in _call_impl
        File /workspace/scratch/thx01-m1/snapshot/thx01/common.py, lineno 113, in forward
            h = layer(h, src_key_padding_mask=pad):
        
        Locals:
            layer: [None]
            h: ['Tensor(shape: torch.Size([1, s53, 768]), stride: (768*s53, 768, 1), storage_offset: 0)']
            pad: ['Tensor(shape: torch.Size([1, s53]), stride: (s53, 1), storage_offset: 0)']

        Symbols:
           s53: L['attention_mask'].size()[1]

    And the following framework stacktrace: 
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/_ops.py, lineno 829, in __call__
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/utils/_stats.py, lineno 28, in wrapper
        File /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/_subclasses/fake_utils.py, lineno 193, in _check_fake_real_tensors
            if r_offset != f_offset:

    Because of this, we have modified the dynamic shapes structure to be the
    following. You can also use torch.export.Dim.AUTO instead to specify your
    dynamic shapes, and we will automatically infer the dynamism for you.
    ```
    dynamic_shapes = ({1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, {1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, None, None, None)
    ```

[0m


```

## Exported program

```python
ExportedProgram:
    class GraphModule(torch.nn.Module):
        def forward(self, p_encoder_embeddings_tok_embeddings_weight: "f32[256000, 768]", p_encoder_embeddings_norm_weight: "f32[768]", p_encoder_layers_0_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_0_attn_wo_weight: "f32[768, 768]", p_encoder_layers_0_mlp_norm_weight: "f32[768]", p_encoder_layers_0_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_0_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_1_attn_norm_weight: "f32[768]", p_encoder_layers_1_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_1_attn_wo_weight: "f32[768, 768]", p_encoder_layers_1_mlp_norm_weight: "f32[768]", p_encoder_layers_1_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_1_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_2_attn_norm_weight: "f32[768]", p_encoder_layers_2_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_2_attn_wo_weight: "f32[768, 768]", p_encoder_layers_2_mlp_norm_weight: "f32[768]", p_encoder_layers_2_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_2_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_3_attn_norm_weight: "f32[768]", p_encoder_layers_3_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_3_attn_wo_weight: "f32[768, 768]", p_encoder_layers_3_mlp_norm_weight: "f32[768]", p_encoder_layers_3_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_3_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_4_attn_norm_weight: "f32[768]", p_encoder_layers_4_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_4_attn_wo_weight: "f32[768, 768]", p_encoder_layers_4_mlp_norm_weight: "f32[768]", p_encoder_layers_4_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_4_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_5_attn_norm_weight: "f32[768]", p_encoder_layers_5_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_5_attn_wo_weight: "f32[768, 768]", p_encoder_layers_5_mlp_norm_weight: "f32[768]", p_encoder_layers_5_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_5_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_6_attn_norm_weight: "f32[768]", p_encoder_layers_6_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_6_attn_wo_weight: "f32[768, 768]", p_encoder_layers_6_mlp_norm_weight: "f32[768]", p_encoder_layers_6_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_6_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_7_attn_norm_weight: "f32[768]", p_encoder_layers_7_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_7_attn_wo_weight: "f32[768, 768]", p_encoder_layers_7_mlp_norm_weight: "f32[768]", p_encoder_layers_7_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_7_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_8_attn_norm_weight: "f32[768]", p_encoder_layers_8_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_8_attn_wo_weight: "f32[768, 768]", p_encoder_layers_8_mlp_norm_weight: "f32[768]", p_encoder_layers_8_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_8_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_9_attn_norm_weight: "f32[768]", p_encoder_layers_9_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_9_attn_wo_weight: "f32[768, 768]", p_encoder_layers_9_mlp_norm_weight: "f32[768]", p_encoder_layers_9_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_9_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_10_attn_norm_weight: "f32[768]", p_encoder_layers_10_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_10_attn_wo_weight: "f32[768, 768]", p_encoder_layers_10_mlp_norm_weight: "f32[768]", p_encoder_layers_10_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_10_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_11_attn_norm_weight: "f32[768]", p_encoder_layers_11_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_11_attn_wo_weight: "f32[768, 768]", p_encoder_layers_11_mlp_norm_weight: "f32[768]", p_encoder_layers_11_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_11_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_12_attn_norm_weight: "f32[768]", p_encoder_layers_12_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_12_attn_wo_weight: "f32[768, 768]", p_encoder_layers_12_mlp_norm_weight: "f32[768]", p_encoder_layers_12_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_12_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_13_attn_norm_weight: "f32[768]", p_encoder_layers_13_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_13_attn_wo_weight: "f32[768, 768]", p_encoder_layers_13_mlp_norm_weight: "f32[768]", p_encoder_layers_13_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_13_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_14_attn_norm_weight: "f32[768]", p_encoder_layers_14_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_14_attn_wo_weight: "f32[768, 768]", p_encoder_layers_14_mlp_norm_weight: "f32[768]", p_encoder_layers_14_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_14_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_15_attn_norm_weight: "f32[768]", p_encoder_layers_15_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_15_attn_wo_weight: "f32[768, 768]", p_encoder_layers_15_mlp_norm_weight: "f32[768]", p_encoder_layers_15_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_15_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_16_attn_norm_weight: "f32[768]", p_encoder_layers_16_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_16_attn_wo_weight: "f32[768, 768]", p_encoder_layers_16_mlp_norm_weight: "f32[768]", p_encoder_layers_16_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_16_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_17_attn_norm_weight: "f32[768]", p_encoder_layers_17_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_17_attn_wo_weight: "f32[768, 768]", p_encoder_layers_17_mlp_norm_weight: "f32[768]", p_encoder_layers_17_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_17_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_18_attn_norm_weight: "f32[768]", p_encoder_layers_18_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_18_attn_wo_weight: "f32[768, 768]", p_encoder_layers_18_mlp_norm_weight: "f32[768]", p_encoder_layers_18_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_18_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_19_attn_norm_weight: "f32[768]", p_encoder_layers_19_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_19_attn_wo_weight: "f32[768, 768]", p_encoder_layers_19_mlp_norm_weight: "f32[768]", p_encoder_layers_19_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_19_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_20_attn_norm_weight: "f32[768]", p_encoder_layers_20_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_20_attn_wo_weight: "f32[768, 768]", p_encoder_layers_20_mlp_norm_weight: "f32[768]", p_encoder_layers_20_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_20_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_21_attn_norm_weight: "f32[768]", p_encoder_layers_21_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_21_attn_wo_weight: "f32[768, 768]", p_encoder_layers_21_mlp_norm_weight: "f32[768]", p_encoder_layers_21_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_21_mlp_wo_weight: "f32[768, 1152]", p_encoder_final_norm_weight: "f32[768]", p_head_layers_0_self_attn_in_proj_weight: "f32[2304, 768]", p_head_layers_0_self_attn_in_proj_bias: "f32[2304]", p_head_layers_0_self_attn_out_proj_weight: "f32[768, 768]", p_head_layers_0_self_attn_out_proj_bias: "f32[768]", p_head_layers_0_linear1_weight: "f32[3072, 768]", p_head_layers_0_linear1_bias: "f32[3072]", p_head_layers_0_linear2_weight: "f32[768, 3072]", p_head_layers_0_linear2_bias: "f32[768]", p_head_layers_0_norm1_weight: "f32[768]", p_head_layers_0_norm1_bias: "f32[768]", p_head_layers_0_norm2_weight: "f32[768]", p_head_layers_0_norm2_bias: "f32[768]", p_head_layers_1_self_attn_in_proj_weight: "f32[2304, 768]", p_head_layers_1_self_attn_in_proj_bias: "f32[2304]", p_head_layers_1_self_attn_out_proj_weight: "f32[768, 768]", p_head_layers_1_self_attn_out_proj_bias: "f32[768]", p_head_layers_1_linear1_weight: "f32[3072, 768]", p_head_layers_1_linear1_bias: "f32[3072]", p_head_layers_1_linear2_weight: "f32[768, 3072]", p_head_layers_1_linear2_bias: "f32[768]", p_head_layers_1_norm1_weight: "f32[768]", p_head_layers_1_norm1_bias: "f32[768]", p_head_layers_1_norm2_weight: "f32[768]", p_head_layers_1_norm2_bias: "f32[768]", p_type_emb_weight: "f32[3, 768]", p_scorer_0_weight: "f32[768]", p_scorer_0_bias: "f32[768]", p_scorer_1_weight: "f32[768, 768]", p_scorer_1_bias: "f32[768]", p_scorer_3_weight: "f32[1, 768]", p_scorer_3_bias: "f32[1]", p_act_head_0_weight: "f32[256, 772]", p_act_head_0_bias: "f32[256]", p_act_head_2_weight: "f32[2, 256]", p_act_head_2_bias: "f32[2]", b_temperature: "f32[3]", c_encoder_lifted_tensor_0: "f32[]", b_encoder_rotary_emb_sliding_attention_inv_freq: "f32[32]", b_encoder_rotary_emb_sliding_attention_original_inv_freq: "f32[32]", b_encoder_rotary_emb_full_attention_inv_freq: "f32[32]", b_encoder_rotary_emb_full_attention_original_inv_freq: "f32[32]", input_ids: "i64[1, 97]", attention_mask: "i64[1, 97]", marker_pos: "i64[1, 3]", marker_mask: "b8[1, 3]", qtype: "i64[1]"):
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:927 in forward, code: position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
            arange: "i64[97]" = torch.ops.aten.arange.default(97, device = device(type='cpu'), pin_memory = False)
            unsqueeze: "i64[1, 97]" = torch.ops.aten.unsqueeze.default(arange, 0);  arange = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:929 in forward, code: attention_mask, sliding_window_mask = self._update_attention_mask(
            slice_1: "i64[1, 97]" = torch.ops.aten.slice.Tensor(attention_mask, 0, 0, 9223372036854775807)
            unsqueeze_1: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_1, 1);  slice_1 = None
            unsqueeze_2: "i64[1, 1, 1, 97]" = torch.ops.aten.unsqueeze.default(unsqueeze_1, 2);  unsqueeze_1 = None
            slice_2: "i64[1, 1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_2, 3, 0, 9223372036854775807);  unsqueeze_2 = None
            expand: "i64[1, 1, 97, 97]" = torch.ops.aten.expand.default(slice_2, [1, 1, 97, 97]);  slice_2 = None
            _to_copy: "f32[1, 1, 97, 97]" = torch.ops.aten._to_copy.default(expand, dtype = torch.float32);  expand = None
            clone: "f32[]" = torch.ops.aten.clone.default(c_encoder_lifted_tensor_0);  c_encoder_lifted_tensor_0 = None
            sub: "f32[1, 1, 97, 97]" = torch.ops.aten.sub.Tensor(clone, _to_copy);  clone = _to_copy = None
            _to_copy_1: "b8[1, 1, 97, 97]" = torch.ops.aten._to_copy.default(sub, dtype = torch.bool)
            masked_fill: "f32[1, 1, 97, 97]" = torch.ops.aten.masked_fill.Scalar(sub, _to_copy_1, -3.4028234663852886e+38);  sub = _to_copy_1 = None
            arange_1: "i64[97]" = torch.ops.aten.arange.default(97, device = device(type='cpu'), pin_memory = False)
            unsqueeze_3: "i64[1, 97]" = torch.ops.aten.unsqueeze.default(arange_1, 0);  arange_1 = None
            permute: "i64[97, 1]" = torch.ops.aten.permute.default(unsqueeze_3, [1, 0])
            sub_1: "i64[97, 97]" = torch.ops.aten.sub.Tensor(unsqueeze_3, permute);  unsqueeze_3 = permute = None
            abs_1: "i64[97, 97]" = torch.ops.aten.abs.default(sub_1);  sub_1 = None
            le: "b8[97, 97]" = torch.ops.aten.le.Scalar(abs_1, 64);  abs_1 = None
            unsqueeze_4: "b8[1, 97, 97]" = torch.ops.aten.unsqueeze.default(le, 0);  le = None
            unsqueeze_5: "b8[1, 1, 97, 97]" = torch.ops.aten.unsqueeze.default(unsqueeze_4, 0);  unsqueeze_4 = None
            logical_not: "b8[1, 1, 97, 97]" = torch.ops.aten.logical_not.default(unsqueeze_5);  unsqueeze_5 = None
            masked_fill_1: "f32[1, 1, 97, 97]" = torch.ops.aten.masked_fill.Scalar(masked_fill, logical_not, -3.4028234663852886e+38);  logical_not = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/sparse.py:192 in forward, code: return F.embedding(
            embedding: "f32[1, 97, 768]" = torch.ops.aten.embedding.default(p_encoder_embeddings_tok_embeddings_weight, input_ids, 0);  p_encoder_embeddings_tok_embeddings_weight = input_ids = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(embedding, [768], p_encoder_embeddings_norm_weight);  embedding = p_encoder_embeddings_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_1: "f32[1, 97, 768]" = torch.ops.aten.clone.default(layer_norm);  layer_norm = None
            
             # File: <eval_with_key>.121:5 in forward, code: unsqueeze_6 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_6: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.121:6 in forward, code: slice_3 = torch.ops.aten.slice.Tensor(unsqueeze_6, 1, 0, 9223372036854775807);  unsqueeze_6 = None
            slice_3: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_6, 1, 0, 9223372036854775807);  unsqueeze_6 = None
            
             # File: <eval_with_key>.121:7 in forward, code: unsqueeze_7 = torch.ops.aten.unsqueeze.default(slice_3, 2);  slice_3 = None
            unsqueeze_7: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_3, 2);  slice_3 = None
            
             # File: <eval_with_key>.121:10 in forward, code: expand_1 = torch.ops.aten.expand.default(to_3, [1, -1, 1]);  to_3 = None
            expand_1: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_7, [1, -1, 1]);  unsqueeze_7 = None
            
             # File: <eval_with_key>.121:13 in forward, code: slice_4 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_4: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.121:14 in forward, code: unsqueeze_8 = torch.ops.aten.unsqueeze.default(slice_4, 1);  slice_4 = None
            unsqueeze_8: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_4, 1);  slice_4 = None
            
             # File: <eval_with_key>.121:15 in forward, code: slice_5 = torch.ops.aten.slice.Tensor(unsqueeze_8, 2, 0, 9223372036854775807);  unsqueeze_8 = None
            slice_5: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_8, 2, 0, 9223372036854775807);  unsqueeze_8 = None
            
             # File: <eval_with_key>.121:17 in forward, code: to_5 = torch.ops.aten.to.dtype(slice_5, torch.float32);  slice_5 = None
            _to_copy_2: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_5, dtype = torch.float32);  slice_5 = None
            
             # File: <eval_with_key>.121:22 in forward, code: matmul = torch.ops.aten.matmul.default(to_6, to_7);  to_6 = to_7 = None
            matmul: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_1, _to_copy_2);  expand_1 = _to_copy_2 = None
            
             # File: <eval_with_key>.121:23 in forward, code: transpose = torch.ops.aten.transpose.int(matmul, 1, 2);  matmul = None
            transpose: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul, 1, 2);  matmul = None
            
             # File: <eval_with_key>.121:24 in forward, code: cat = torch.ops.aten.cat.default([transpose, transpose], -1);  transpose = None
            cat: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose, transpose], -1);  transpose = None
            
             # File: <eval_with_key>.121:25 in forward, code: cos = torch.ops.aten.cos.default(cat)
            cos: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat)
            
             # File: <eval_with_key>.121:26 in forward, code: mul = torch.ops.aten.mul.Tensor(cos, 1.0);  cos = None
            mul: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos, 1.0);  cos = mul = None
            
             # File: <eval_with_key>.121:27 in forward, code: sin = torch.ops.aten.sin.default(cat);  cat = None
            sin: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat);  cat = None
            
             # File: <eval_with_key>.121:28 in forward, code: mul_1 = torch.ops.aten.mul.Tensor(sin, 1.0);  sin = None
            mul_1: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin, 1.0);  sin = mul_1 = None
            
             # File: <eval_with_key>.122:5 in forward, code: unsqueeze_9 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_9: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.122:6 in forward, code: slice_6 = torch.ops.aten.slice.Tensor(unsqueeze_9, 1, 0, 9223372036854775807);  unsqueeze_9 = None
            slice_6: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_9, 1, 0, 9223372036854775807);  unsqueeze_9 = None
            
             # File: <eval_with_key>.122:7 in forward, code: unsqueeze_10 = torch.ops.aten.unsqueeze.default(slice_6, 2);  slice_6 = None
            unsqueeze_10: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_6, 2);  slice_6 = None
            
             # File: <eval_with_key>.122:10 in forward, code: expand_2 = torch.ops.aten.expand.default(to_10, [1, -1, 1]);  to_10 = None
            expand_2: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_10, [1, -1, 1]);  unsqueeze_10 = None
            
             # File: <eval_with_key>.122:13 in forward, code: slice_7 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_7: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.122:14 in forward, code: unsqueeze_11 = torch.ops.aten.unsqueeze.default(slice_7, 1);  slice_7 = None
            unsqueeze_11: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_7, 1);  slice_7 = None
            
             # File: <eval_with_key>.122:15 in forward, code: slice_8 = torch.ops.aten.slice.Tensor(unsqueeze_11, 2, 0, 9223372036854775807);  unsqueeze_11 = None
            slice_8: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_11, 2, 0, 9223372036854775807);  unsqueeze_11 = None
            
             # File: <eval_with_key>.122:17 in forward, code: to_12 = torch.ops.aten.to.dtype(slice_8, torch.float32);  slice_8 = None
            _to_copy_3: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_8, dtype = torch.float32);  slice_8 = None
            
             # File: <eval_with_key>.122:22 in forward, code: matmul_1 = torch.ops.aten.matmul.default(to_13, to_14);  to_13 = to_14 = None
            matmul_1: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_2, _to_copy_3);  expand_2 = _to_copy_3 = None
            
             # File: <eval_with_key>.122:23 in forward, code: transpose_1 = torch.ops.aten.transpose.int(matmul_1, 1, 2);  matmul_1 = None
            transpose_1: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_1, 1, 2);  matmul_1 = None
            
             # File: <eval_with_key>.122:24 in forward, code: cat_1 = torch.ops.aten.cat.default([transpose_1, transpose_1], -1);  transpose_1 = None
            cat_1: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_1, transpose_1], -1);  transpose_1 = None
            
             # File: <eval_with_key>.122:25 in forward, code: cos_1 = torch.ops.aten.cos.default(cat_1)
            cos_1: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_1)
            
             # File: <eval_with_key>.122:26 in forward, code: mul_2 = torch.ops.aten.mul.Tensor(cos_1, 1.0);  cos_1 = None
            mul_2: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_1, 1.0);  cos_1 = mul_2 = None
            
             # File: <eval_with_key>.122:27 in forward, code: sin_1 = torch.ops.aten.sin.default(cat_1);  cat_1 = None
            sin_1: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_1);  cat_1 = None
            
             # File: <eval_with_key>.122:28 in forward, code: mul_3 = torch.ops.aten.mul.Tensor(sin_1, 1.0);  sin_1 = None
            mul_3: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_1, 1.0);  sin_1 = mul_3 = None
            
             # File: <eval_with_key>.123:5 in forward, code: unsqueeze_12 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_12: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.123:6 in forward, code: slice_9 = torch.ops.aten.slice.Tensor(unsqueeze_12, 1, 0, 9223372036854775807);  unsqueeze_12 = None
            slice_9: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_12, 1, 0, 9223372036854775807);  unsqueeze_12 = None
            
             # File: <eval_with_key>.123:7 in forward, code: unsqueeze_13 = torch.ops.aten.unsqueeze.default(slice_9, 2);  slice_9 = None
            unsqueeze_13: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_9, 2);  slice_9 = None
            
             # File: <eval_with_key>.123:10 in forward, code: expand_3 = torch.ops.aten.expand.default(to_17, [1, -1, 1]);  to_17 = None
            expand_3: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_13, [1, -1, 1]);  unsqueeze_13 = None
            
             # File: <eval_with_key>.123:13 in forward, code: slice_10 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_10: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.123:14 in forward, code: unsqueeze_14 = torch.ops.aten.unsqueeze.default(slice_10, 1);  slice_10 = None
            unsqueeze_14: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_10, 1);  slice_10 = None
            
             # File: <eval_with_key>.123:15 in forward, code: slice_11 = torch.ops.aten.slice.Tensor(unsqueeze_14, 2, 0, 9223372036854775807);  unsqueeze_14 = None
            slice_11: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_14, 2, 0, 9223372036854775807);  unsqueeze_14 = None
            
             # File: <eval_with_key>.123:17 in forward, code: to_19 = torch.ops.aten.to.dtype(slice_11, torch.float32);  slice_11 = None
            _to_copy_4: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_11, dtype = torch.float32);  slice_11 = None
            
             # File: <eval_with_key>.123:22 in forward, code: matmul_2 = torch.ops.aten.matmul.default(to_20, to_21);  to_20 = to_21 = None
            matmul_2: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_3, _to_copy_4);  expand_3 = _to_copy_4 = None
            
             # File: <eval_with_key>.123:23 in forward, code: transpose_2 = torch.ops.aten.transpose.int(matmul_2, 1, 2);  matmul_2 = None
            transpose_2: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_2, 1, 2);  matmul_2 = None
            
             # File: <eval_with_key>.123:24 in forward, code: cat_2 = torch.ops.aten.cat.default([transpose_2, transpose_2], -1);  transpose_2 = None
            cat_2: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_2, transpose_2], -1);  transpose_2 = None
            
             # File: <eval_with_key>.123:25 in forward, code: cos_2 = torch.ops.aten.cos.default(cat_2)
            cos_2: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_2)
            
             # File: <eval_with_key>.123:26 in forward, code: mul_4 = torch.ops.aten.mul.Tensor(cos_2, 1.0);  cos_2 = None
            mul_4: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_2, 1.0);  cos_2 = mul_4 = None
            
             # File: <eval_with_key>.123:27 in forward, code: sin_2 = torch.ops.aten.sin.default(cat_2);  cat_2 = None
            sin_2: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_2);  cat_2 = None
            
             # File: <eval_with_key>.123:28 in forward, code: mul_5 = torch.ops.aten.mul.Tensor(sin_2, 1.0);  sin_2 = None
            mul_5: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_2, 1.0);  sin_2 = mul_5 = None
            
             # File: <eval_with_key>.124:5 in forward, code: unsqueeze_15 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_15: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.124:6 in forward, code: slice_12 = torch.ops.aten.slice.Tensor(unsqueeze_15, 1, 0, 9223372036854775807);  unsqueeze_15 = None
            slice_12: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_15, 1, 0, 9223372036854775807);  unsqueeze_15 = None
            
             # File: <eval_with_key>.124:7 in forward, code: unsqueeze_16 = torch.ops.aten.unsqueeze.default(slice_12, 2);  slice_12 = None
            unsqueeze_16: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_12, 2);  slice_12 = None
            
             # File: <eval_with_key>.124:10 in forward, code: expand_4 = torch.ops.aten.expand.default(to_24, [1, -1, 1]);  to_24 = None
            expand_4: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_16, [1, -1, 1]);  unsqueeze_16 = None
            
             # File: <eval_with_key>.124:13 in forward, code: slice_13 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_13: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.124:14 in forward, code: unsqueeze_17 = torch.ops.aten.unsqueeze.default(slice_13, 1);  slice_13 = None
            unsqueeze_17: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_13, 1);  slice_13 = None
            
             # File: <eval_with_key>.124:15 in forward, code: slice_14 = torch.ops.aten.slice.Tensor(unsqueeze_17, 2, 0, 9223372036854775807);  unsqueeze_17 = None
            slice_14: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_17, 2, 0, 9223372036854775807);  unsqueeze_17 = None
            
             # File: <eval_with_key>.124:17 in forward, code: to_26 = torch.ops.aten.to.dtype(slice_14, torch.float32);  slice_14 = None
            _to_copy_5: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_14, dtype = torch.float32);  slice_14 = None
            
             # File: <eval_with_key>.124:22 in forward, code: matmul_3 = torch.ops.aten.matmul.default(to_27, to_28);  to_27 = to_28 = None
            matmul_3: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_4, _to_copy_5);  expand_4 = _to_copy_5 = None
            
             # File: <eval_with_key>.124:23 in forward, code: transpose_3 = torch.ops.aten.transpose.int(matmul_3, 1, 2);  matmul_3 = None
            transpose_3: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_3, 1, 2);  matmul_3 = None
            
             # File: <eval_with_key>.124:24 in forward, code: cat_3 = torch.ops.aten.cat.default([transpose_3, transpose_3], -1);  transpose_3 = None
            cat_3: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_3, transpose_3], -1);  transpose_3 = None
            
             # File: <eval_with_key>.124:25 in forward, code: cos_3 = torch.ops.aten.cos.default(cat_3)
            cos_3: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_3)
            
             # File: <eval_with_key>.124:26 in forward, code: mul_6 = torch.ops.aten.mul.Tensor(cos_3, 1.0);  cos_3 = None
            mul_6: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_3, 1.0);  cos_3 = mul_6 = None
            
             # File: <eval_with_key>.124:27 in forward, code: sin_3 = torch.ops.aten.sin.default(cat_3);  cat_3 = None
            sin_3: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_3);  cat_3 = None
            
             # File: <eval_with_key>.124:28 in forward, code: mul_7 = torch.ops.aten.mul.Tensor(sin_3, 1.0);  sin_3 = None
            mul_7: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_3, 1.0);  sin_3 = mul_7 = None
            
             # File: <eval_with_key>.125:5 in forward, code: unsqueeze_18 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_18: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.125:6 in forward, code: slice_15 = torch.ops.aten.slice.Tensor(unsqueeze_18, 1, 0, 9223372036854775807);  unsqueeze_18 = None
            slice_15: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_18, 1, 0, 9223372036854775807);  unsqueeze_18 = None
            
             # File: <eval_with_key>.125:7 in forward, code: unsqueeze_19 = torch.ops.aten.unsqueeze.default(slice_15, 2);  slice_15 = None
            unsqueeze_19: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_15, 2);  slice_15 = None
            
             # File: <eval_with_key>.125:10 in forward, code: expand_5 = torch.ops.aten.expand.default(to_31, [1, -1, 1]);  to_31 = None
            expand_5: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_19, [1, -1, 1]);  unsqueeze_19 = None
            
             # File: <eval_with_key>.125:13 in forward, code: slice_16 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_16: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.125:14 in forward, code: unsqueeze_20 = torch.ops.aten.unsqueeze.default(slice_16, 1);  slice_16 = None
            unsqueeze_20: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_16, 1);  slice_16 = None
            
             # File: <eval_with_key>.125:15 in forward, code: slice_17 = torch.ops.aten.slice.Tensor(unsqueeze_20, 2, 0, 9223372036854775807);  unsqueeze_20 = None
            slice_17: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_20, 2, 0, 9223372036854775807);  unsqueeze_20 = None
            
             # File: <eval_with_key>.125:17 in forward, code: to_33 = torch.ops.aten.to.dtype(slice_17, torch.float32);  slice_17 = None
            _to_copy_6: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_17, dtype = torch.float32);  slice_17 = None
            
             # File: <eval_with_key>.125:22 in forward, code: matmul_4 = torch.ops.aten.matmul.default(to_34, to_35);  to_34 = to_35 = None
            matmul_4: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_5, _to_copy_6);  expand_5 = _to_copy_6 = None
            
             # File: <eval_with_key>.125:23 in forward, code: transpose_4 = torch.ops.aten.transpose.int(matmul_4, 1, 2);  matmul_4 = None
            transpose_4: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_4, 1, 2);  matmul_4 = None
            
             # File: <eval_with_key>.125:24 in forward, code: cat_4 = torch.ops.aten.cat.default([transpose_4, transpose_4], -1);  transpose_4 = None
            cat_4: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_4, transpose_4], -1);  transpose_4 = None
            
             # File: <eval_with_key>.125:25 in forward, code: cos_4 = torch.ops.aten.cos.default(cat_4)
            cos_4: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_4)
            
             # File: <eval_with_key>.125:26 in forward, code: mul_8 = torch.ops.aten.mul.Tensor(cos_4, 1.0);  cos_4 = None
            mul_8: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_4, 1.0);  cos_4 = mul_8 = None
            
             # File: <eval_with_key>.125:27 in forward, code: sin_4 = torch.ops.aten.sin.default(cat_4);  cat_4 = None
            sin_4: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_4);  cat_4 = None
            
             # File: <eval_with_key>.125:28 in forward, code: mul_9 = torch.ops.aten.mul.Tensor(sin_4, 1.0);  sin_4 = None
            mul_9: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_4, 1.0);  sin_4 = mul_9 = None
            
             # File: <eval_with_key>.126:5 in forward, code: unsqueeze_21 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_21: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.126:6 in forward, code: slice_18 = torch.ops.aten.slice.Tensor(unsqueeze_21, 1, 0, 9223372036854775807);  unsqueeze_21 = None
            slice_18: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_21, 1, 0, 9223372036854775807);  unsqueeze_21 = None
            
             # File: <eval_with_key>.126:7 in forward, code: unsqueeze_22 = torch.ops.aten.unsqueeze.default(slice_18, 2);  slice_18 = None
            unsqueeze_22: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_18, 2);  slice_18 = None
            
             # File: <eval_with_key>.126:10 in forward, code: expand_6 = torch.ops.aten.expand.default(to_38, [1, -1, 1]);  to_38 = None
            expand_6: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_22, [1, -1, 1]);  unsqueeze_22 = None
            
             # File: <eval_with_key>.126:13 in forward, code: slice_19 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_19: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.126:14 in forward, code: unsqueeze_23 = torch.ops.aten.unsqueeze.default(slice_19, 1);  slice_19 = None
            unsqueeze_23: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_19, 1);  slice_19 = None
            
             # File: <eval_with_key>.126:15 in forward, code: slice_20 = torch.ops.aten.slice.Tensor(unsqueeze_23, 2, 0, 9223372036854775807);  unsqueeze_23 = None
            slice_20: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_23, 2, 0, 9223372036854775807);  unsqueeze_23 = None
            
             # File: <eval_with_key>.126:17 in forward, code: to_40 = torch.ops.aten.to.dtype(slice_20, torch.float32);  slice_20 = None
            _to_copy_7: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_20, dtype = torch.float32);  slice_20 = None
            
             # File: <eval_with_key>.126:22 in forward, code: matmul_5 = torch.ops.aten.matmul.default(to_41, to_42);  to_41 = to_42 = None
            matmul_5: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_6, _to_copy_7);  expand_6 = _to_copy_7 = None
            
             # File: <eval_with_key>.126:23 in forward, code: transpose_5 = torch.ops.aten.transpose.int(matmul_5, 1, 2);  matmul_5 = None
            transpose_5: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_5, 1, 2);  matmul_5 = None
            
             # File: <eval_with_key>.126:24 in forward, code: cat_5 = torch.ops.aten.cat.default([transpose_5, transpose_5], -1);  transpose_5 = None
            cat_5: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_5, transpose_5], -1);  transpose_5 = None
            
             # File: <eval_with_key>.126:25 in forward, code: cos_5 = torch.ops.aten.cos.default(cat_5)
            cos_5: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_5)
            
             # File: <eval_with_key>.126:26 in forward, code: mul_10 = torch.ops.aten.mul.Tensor(cos_5, 1.0);  cos_5 = None
            mul_10: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_5, 1.0);  cos_5 = mul_10 = None
            
             # File: <eval_with_key>.126:27 in forward, code: sin_5 = torch.ops.aten.sin.default(cat_5);  cat_5 = None
            sin_5: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_5);  cat_5 = None
            
             # File: <eval_with_key>.126:28 in forward, code: mul_11 = torch.ops.aten.mul.Tensor(sin_5, 1.0);  sin_5 = None
            mul_11: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_5, 1.0);  sin_5 = mul_11 = None
            
             # File: <eval_with_key>.127:5 in forward, code: unsqueeze_24 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_24: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.127:6 in forward, code: slice_21 = torch.ops.aten.slice.Tensor(unsqueeze_24, 1, 0, 9223372036854775807);  unsqueeze_24 = None
            slice_21: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_24, 1, 0, 9223372036854775807);  unsqueeze_24 = None
            
             # File: <eval_with_key>.127:7 in forward, code: unsqueeze_25 = torch.ops.aten.unsqueeze.default(slice_21, 2);  slice_21 = None
            unsqueeze_25: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_21, 2);  slice_21 = None
            
             # File: <eval_with_key>.127:10 in forward, code: expand_7 = torch.ops.aten.expand.default(to_45, [1, -1, 1]);  to_45 = None
            expand_7: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_25, [1, -1, 1]);  unsqueeze_25 = None
            
             # File: <eval_with_key>.127:13 in forward, code: slice_22 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_22: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.127:14 in forward, code: unsqueeze_26 = torch.ops.aten.unsqueeze.default(slice_22, 1);  slice_22 = None
            unsqueeze_26: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_22, 1);  slice_22 = None
            
             # File: <eval_with_key>.127:15 in forward, code: slice_23 = torch.ops.aten.slice.Tensor(unsqueeze_26, 2, 0, 9223372036854775807);  unsqueeze_26 = None
            slice_23: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_26, 2, 0, 9223372036854775807);  unsqueeze_26 = None
            
             # File: <eval_with_key>.127:17 in forward, code: to_47 = torch.ops.aten.to.dtype(slice_23, torch.float32);  slice_23 = None
            _to_copy_8: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_23, dtype = torch.float32);  slice_23 = None
            
             # File: <eval_with_key>.127:22 in forward, code: matmul_6 = torch.ops.aten.matmul.default(to_48, to_49);  to_48 = to_49 = None
            matmul_6: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_7, _to_copy_8);  expand_7 = _to_copy_8 = None
            
             # File: <eval_with_key>.127:23 in forward, code: transpose_6 = torch.ops.aten.transpose.int(matmul_6, 1, 2);  matmul_6 = None
            transpose_6: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_6, 1, 2);  matmul_6 = None
            
             # File: <eval_with_key>.127:24 in forward, code: cat_6 = torch.ops.aten.cat.default([transpose_6, transpose_6], -1);  transpose_6 = None
            cat_6: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_6, transpose_6], -1);  transpose_6 = None
            
             # File: <eval_with_key>.127:25 in forward, code: cos_6 = torch.ops.aten.cos.default(cat_6)
            cos_6: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_6)
            
             # File: <eval_with_key>.127:26 in forward, code: mul_12 = torch.ops.aten.mul.Tensor(cos_6, 1.0);  cos_6 = None
            mul_12: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_6, 1.0);  cos_6 = mul_12 = None
            
             # File: <eval_with_key>.127:27 in forward, code: sin_6 = torch.ops.aten.sin.default(cat_6);  cat_6 = None
            sin_6: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_6);  cat_6 = None
            
             # File: <eval_with_key>.127:28 in forward, code: mul_13 = torch.ops.aten.mul.Tensor(sin_6, 1.0);  sin_6 = None
            mul_13: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_6, 1.0);  sin_6 = mul_13 = None
            
             # File: <eval_with_key>.128:5 in forward, code: unsqueeze_27 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_27: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.128:6 in forward, code: slice_24 = torch.ops.aten.slice.Tensor(unsqueeze_27, 1, 0, 9223372036854775807);  unsqueeze_27 = None
            slice_24: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_27, 1, 0, 9223372036854775807);  unsqueeze_27 = None
            
             # File: <eval_with_key>.128:7 in forward, code: unsqueeze_28 = torch.ops.aten.unsqueeze.default(slice_24, 2);  slice_24 = None
            unsqueeze_28: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_24, 2);  slice_24 = None
            
             # File: <eval_with_key>.128:10 in forward, code: expand_8 = torch.ops.aten.expand.default(to_52, [1, -1, 1]);  to_52 = None
            expand_8: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_28, [1, -1, 1]);  unsqueeze_28 = None
            
             # File: <eval_with_key>.128:13 in forward, code: slice_25 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_25: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.128:14 in forward, code: unsqueeze_29 = torch.ops.aten.unsqueeze.default(slice_25, 1);  slice_25 = None
            unsqueeze_29: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_25, 1);  slice_25 = None
            
             # File: <eval_with_key>.128:15 in forward, code: slice_26 = torch.ops.aten.slice.Tensor(unsqueeze_29, 2, 0, 9223372036854775807);  unsqueeze_29 = None
            slice_26: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_29, 2, 0, 9223372036854775807);  unsqueeze_29 = None
            
             # File: <eval_with_key>.128:17 in forward, code: to_54 = torch.ops.aten.to.dtype(slice_26, torch.float32);  slice_26 = None
            _to_copy_9: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_26, dtype = torch.float32);  slice_26 = None
            
             # File: <eval_with_key>.128:22 in forward, code: matmul_7 = torch.ops.aten.matmul.default(to_55, to_56);  to_55 = to_56 = None
            matmul_7: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_8, _to_copy_9);  expand_8 = _to_copy_9 = None
            
             # File: <eval_with_key>.128:23 in forward, code: transpose_7 = torch.ops.aten.transpose.int(matmul_7, 1, 2);  matmul_7 = None
            transpose_7: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_7, 1, 2);  matmul_7 = None
            
             # File: <eval_with_key>.128:24 in forward, code: cat_7 = torch.ops.aten.cat.default([transpose_7, transpose_7], -1);  transpose_7 = None
            cat_7: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_7, transpose_7], -1);  transpose_7 = None
            
             # File: <eval_with_key>.128:25 in forward, code: cos_7 = torch.ops.aten.cos.default(cat_7)
            cos_7: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_7)
            
             # File: <eval_with_key>.128:26 in forward, code: mul_14 = torch.ops.aten.mul.Tensor(cos_7, 1.0);  cos_7 = None
            mul_14: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_7, 1.0);  cos_7 = mul_14 = None
            
             # File: <eval_with_key>.128:27 in forward, code: sin_7 = torch.ops.aten.sin.default(cat_7);  cat_7 = None
            sin_7: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_7);  cat_7 = None
            
             # File: <eval_with_key>.128:28 in forward, code: mul_15 = torch.ops.aten.mul.Tensor(sin_7, 1.0);  sin_7 = None
            mul_15: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_7, 1.0);  sin_7 = mul_15 = None
            
             # File: <eval_with_key>.129:5 in forward, code: unsqueeze_30 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_30: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.129:6 in forward, code: slice_27 = torch.ops.aten.slice.Tensor(unsqueeze_30, 1, 0, 9223372036854775807);  unsqueeze_30 = None
            slice_27: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_30, 1, 0, 9223372036854775807);  unsqueeze_30 = None
            
             # File: <eval_with_key>.129:7 in forward, code: unsqueeze_31 = torch.ops.aten.unsqueeze.default(slice_27, 2);  slice_27 = None
            unsqueeze_31: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_27, 2);  slice_27 = None
            
             # File: <eval_with_key>.129:10 in forward, code: expand_9 = torch.ops.aten.expand.default(to_59, [1, -1, 1]);  to_59 = None
            expand_9: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_31, [1, -1, 1]);  unsqueeze_31 = None
            
             # File: <eval_with_key>.129:13 in forward, code: slice_28 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_28: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.129:14 in forward, code: unsqueeze_32 = torch.ops.aten.unsqueeze.default(slice_28, 1);  slice_28 = None
            unsqueeze_32: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_28, 1);  slice_28 = None
            
             # File: <eval_with_key>.129:15 in forward, code: slice_29 = torch.ops.aten.slice.Tensor(unsqueeze_32, 2, 0, 9223372036854775807);  unsqueeze_32 = None
            slice_29: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_32, 2, 0, 9223372036854775807);  unsqueeze_32 = None
            
             # File: <eval_with_key>.129:17 in forward, code: to_61 = torch.ops.aten.to.dtype(slice_29, torch.float32);  slice_29 = None
            _to_copy_10: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_29, dtype = torch.float32);  slice_29 = None
            
             # File: <eval_with_key>.129:22 in forward, code: matmul_8 = torch.ops.aten.matmul.default(to_62, to_63);  to_62 = to_63 = None
            matmul_8: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_9, _to_copy_10);  expand_9 = _to_copy_10 = None
            
             # File: <eval_with_key>.129:23 in forward, code: transpose_8 = torch.ops.aten.transpose.int(matmul_8, 1, 2);  matmul_8 = None
            transpose_8: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_8, 1, 2);  matmul_8 = None
            
             # File: <eval_with_key>.129:24 in forward, code: cat_8 = torch.ops.aten.cat.default([transpose_8, transpose_8], -1);  transpose_8 = None
            cat_8: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_8, transpose_8], -1);  transpose_8 = None
            
             # File: <eval_with_key>.129:25 in forward, code: cos_8 = torch.ops.aten.cos.default(cat_8)
            cos_8: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_8)
            
             # File: <eval_with_key>.129:26 in forward, code: mul_16 = torch.ops.aten.mul.Tensor(cos_8, 1.0);  cos_8 = None
            mul_16: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_8, 1.0);  cos_8 = mul_16 = None
            
             # File: <eval_with_key>.129:27 in forward, code: sin_8 = torch.ops.aten.sin.default(cat_8);  cat_8 = None
            sin_8: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_8);  cat_8 = None
            
             # File: <eval_with_key>.129:28 in forward, code: mul_17 = torch.ops.aten.mul.Tensor(sin_8, 1.0);  sin_8 = None
            mul_17: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_8, 1.0);  sin_8 = mul_17 = None
            
             # File: <eval_with_key>.130:5 in forward, code: unsqueeze_33 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_33: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.130:6 in forward, code: slice_30 = torch.ops.aten.slice.Tensor(unsqueeze_33, 1, 0, 9223372036854775807);  unsqueeze_33 = None
            slice_30: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_33, 1, 0, 9223372036854775807);  unsqueeze_33 = None
            
             # File: <eval_with_key>.130:7 in forward, code: unsqueeze_34 = torch.ops.aten.unsqueeze.default(slice_30, 2);  slice_30 = None
            unsqueeze_34: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_30, 2);  slice_30 = None
            
             # File: <eval_with_key>.130:10 in forward, code: expand_10 = torch.ops.aten.expand.default(to_66, [1, -1, 1]);  to_66 = None
            expand_10: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_34, [1, -1, 1]);  unsqueeze_34 = None
            
             # File: <eval_with_key>.130:13 in forward, code: slice_31 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_31: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.130:14 in forward, code: unsqueeze_35 = torch.ops.aten.unsqueeze.default(slice_31, 1);  slice_31 = None
            unsqueeze_35: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_31, 1);  slice_31 = None
            
             # File: <eval_with_key>.130:15 in forward, code: slice_32 = torch.ops.aten.slice.Tensor(unsqueeze_35, 2, 0, 9223372036854775807);  unsqueeze_35 = None
            slice_32: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_35, 2, 0, 9223372036854775807);  unsqueeze_35 = None
            
             # File: <eval_with_key>.130:17 in forward, code: to_68 = torch.ops.aten.to.dtype(slice_32, torch.float32);  slice_32 = None
            _to_copy_11: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_32, dtype = torch.float32);  slice_32 = None
            
             # File: <eval_with_key>.130:22 in forward, code: matmul_9 = torch.ops.aten.matmul.default(to_69, to_70);  to_69 = to_70 = None
            matmul_9: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_10, _to_copy_11);  expand_10 = _to_copy_11 = None
            
             # File: <eval_with_key>.130:23 in forward, code: transpose_9 = torch.ops.aten.transpose.int(matmul_9, 1, 2);  matmul_9 = None
            transpose_9: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_9, 1, 2);  matmul_9 = None
            
             # File: <eval_with_key>.130:24 in forward, code: cat_9 = torch.ops.aten.cat.default([transpose_9, transpose_9], -1);  transpose_9 = None
            cat_9: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_9, transpose_9], -1);  transpose_9 = None
            
             # File: <eval_with_key>.130:25 in forward, code: cos_9 = torch.ops.aten.cos.default(cat_9)
            cos_9: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_9)
            
             # File: <eval_with_key>.130:26 in forward, code: mul_18 = torch.ops.aten.mul.Tensor(cos_9, 1.0);  cos_9 = None
            mul_18: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_9, 1.0);  cos_9 = mul_18 = None
            
             # File: <eval_with_key>.130:27 in forward, code: sin_9 = torch.ops.aten.sin.default(cat_9);  cat_9 = None
            sin_9: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_9);  cat_9 = None
            
             # File: <eval_with_key>.130:28 in forward, code: mul_19 = torch.ops.aten.mul.Tensor(sin_9, 1.0);  sin_9 = None
            mul_19: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_9, 1.0);  sin_9 = mul_19 = None
            
             # File: <eval_with_key>.131:5 in forward, code: unsqueeze_36 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_36: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.131:6 in forward, code: slice_33 = torch.ops.aten.slice.Tensor(unsqueeze_36, 1, 0, 9223372036854775807);  unsqueeze_36 = None
            slice_33: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_36, 1, 0, 9223372036854775807);  unsqueeze_36 = None
            
             # File: <eval_with_key>.131:7 in forward, code: unsqueeze_37 = torch.ops.aten.unsqueeze.default(slice_33, 2);  slice_33 = None
            unsqueeze_37: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_33, 2);  slice_33 = None
            
             # File: <eval_with_key>.131:10 in forward, code: expand_11 = torch.ops.aten.expand.default(to_73, [1, -1, 1]);  to_73 = None
            expand_11: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_37, [1, -1, 1]);  unsqueeze_37 = None
            
             # File: <eval_with_key>.131:13 in forward, code: slice_34 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_34: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.131:14 in forward, code: unsqueeze_38 = torch.ops.aten.unsqueeze.default(slice_34, 1);  slice_34 = None
            unsqueeze_38: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_34, 1);  slice_34 = None
            
             # File: <eval_with_key>.131:15 in forward, code: slice_35 = torch.ops.aten.slice.Tensor(unsqueeze_38, 2, 0, 9223372036854775807);  unsqueeze_38 = None
            slice_35: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_38, 2, 0, 9223372036854775807);  unsqueeze_38 = None
            
             # File: <eval_with_key>.131:17 in forward, code: to_75 = torch.ops.aten.to.dtype(slice_35, torch.float32);  slice_35 = None
            _to_copy_12: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_35, dtype = torch.float32);  slice_35 = None
            
             # File: <eval_with_key>.131:22 in forward, code: matmul_10 = torch.ops.aten.matmul.default(to_76, to_77);  to_76 = to_77 = None
            matmul_10: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_11, _to_copy_12);  expand_11 = _to_copy_12 = None
            
             # File: <eval_with_key>.131:23 in forward, code: transpose_10 = torch.ops.aten.transpose.int(matmul_10, 1, 2);  matmul_10 = None
            transpose_10: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_10, 1, 2);  matmul_10 = None
            
             # File: <eval_with_key>.131:24 in forward, code: cat_10 = torch.ops.aten.cat.default([transpose_10, transpose_10], -1);  transpose_10 = None
            cat_10: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_10, transpose_10], -1);  transpose_10 = None
            
             # File: <eval_with_key>.131:25 in forward, code: cos_10 = torch.ops.aten.cos.default(cat_10)
            cos_10: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_10)
            
             # File: <eval_with_key>.131:26 in forward, code: mul_20 = torch.ops.aten.mul.Tensor(cos_10, 1.0);  cos_10 = None
            mul_20: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_10, 1.0);  cos_10 = mul_20 = None
            
             # File: <eval_with_key>.131:27 in forward, code: sin_10 = torch.ops.aten.sin.default(cat_10);  cat_10 = None
            sin_10: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_10);  cat_10 = None
            
             # File: <eval_with_key>.131:28 in forward, code: mul_21 = torch.ops.aten.mul.Tensor(sin_10, 1.0);  sin_10 = None
            mul_21: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_10, 1.0);  sin_10 = mul_21 = None
            
             # File: <eval_with_key>.132:5 in forward, code: unsqueeze_39 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_39: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.132:6 in forward, code: slice_36 = torch.ops.aten.slice.Tensor(unsqueeze_39, 1, 0, 9223372036854775807);  unsqueeze_39 = None
            slice_36: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_39, 1, 0, 9223372036854775807);  unsqueeze_39 = None
            
             # File: <eval_with_key>.132:7 in forward, code: unsqueeze_40 = torch.ops.aten.unsqueeze.default(slice_36, 2);  slice_36 = None
            unsqueeze_40: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_36, 2);  slice_36 = None
            
             # File: <eval_with_key>.132:10 in forward, code: expand_12 = torch.ops.aten.expand.default(to_80, [1, -1, 1]);  to_80 = None
            expand_12: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_40, [1, -1, 1]);  unsqueeze_40 = None
            
             # File: <eval_with_key>.132:13 in forward, code: slice_37 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_37: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.132:14 in forward, code: unsqueeze_41 = torch.ops.aten.unsqueeze.default(slice_37, 1);  slice_37 = None
            unsqueeze_41: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_37, 1);  slice_37 = None
            
             # File: <eval_with_key>.132:15 in forward, code: slice_38 = torch.ops.aten.slice.Tensor(unsqueeze_41, 2, 0, 9223372036854775807);  unsqueeze_41 = None
            slice_38: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_41, 2, 0, 9223372036854775807);  unsqueeze_41 = None
            
             # File: <eval_with_key>.132:17 in forward, code: to_82 = torch.ops.aten.to.dtype(slice_38, torch.float32);  slice_38 = None
            _to_copy_13: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_38, dtype = torch.float32);  slice_38 = None
            
             # File: <eval_with_key>.132:22 in forward, code: matmul_11 = torch.ops.aten.matmul.default(to_83, to_84);  to_83 = to_84 = None
            matmul_11: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_12, _to_copy_13);  expand_12 = _to_copy_13 = None
            
             # File: <eval_with_key>.132:23 in forward, code: transpose_11 = torch.ops.aten.transpose.int(matmul_11, 1, 2);  matmul_11 = None
            transpose_11: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_11, 1, 2);  matmul_11 = None
            
             # File: <eval_with_key>.132:24 in forward, code: cat_11 = torch.ops.aten.cat.default([transpose_11, transpose_11], -1);  transpose_11 = None
            cat_11: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_11, transpose_11], -1);  transpose_11 = None
            
             # File: <eval_with_key>.132:25 in forward, code: cos_11 = torch.ops.aten.cos.default(cat_11)
            cos_11: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_11)
            
             # File: <eval_with_key>.132:26 in forward, code: mul_22 = torch.ops.aten.mul.Tensor(cos_11, 1.0);  cos_11 = None
            mul_22: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_11, 1.0);  cos_11 = mul_22 = None
            
             # File: <eval_with_key>.132:27 in forward, code: sin_11 = torch.ops.aten.sin.default(cat_11);  cat_11 = None
            sin_11: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_11);  cat_11 = None
            
             # File: <eval_with_key>.132:28 in forward, code: mul_23 = torch.ops.aten.mul.Tensor(sin_11, 1.0);  sin_11 = None
            mul_23: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_11, 1.0);  sin_11 = mul_23 = None
            
             # File: <eval_with_key>.133:5 in forward, code: unsqueeze_42 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_42: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.133:6 in forward, code: slice_39 = torch.ops.aten.slice.Tensor(unsqueeze_42, 1, 0, 9223372036854775807);  unsqueeze_42 = None
            slice_39: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_42, 1, 0, 9223372036854775807);  unsqueeze_42 = None
            
             # File: <eval_with_key>.133:7 in forward, code: unsqueeze_43 = torch.ops.aten.unsqueeze.default(slice_39, 2);  slice_39 = None
            unsqueeze_43: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_39, 2);  slice_39 = None
            
             # File: <eval_with_key>.133:10 in forward, code: expand_13 = torch.ops.aten.expand.default(to_87, [1, -1, 1]);  to_87 = None
            expand_13: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_43, [1, -1, 1]);  unsqueeze_43 = None
            
             # File: <eval_with_key>.133:13 in forward, code: slice_40 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_40: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.133:14 in forward, code: unsqueeze_44 = torch.ops.aten.unsqueeze.default(slice_40, 1);  slice_40 = None
            unsqueeze_44: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_40, 1);  slice_40 = None
            
             # File: <eval_with_key>.133:15 in forward, code: slice_41 = torch.ops.aten.slice.Tensor(unsqueeze_44, 2, 0, 9223372036854775807);  unsqueeze_44 = None
            slice_41: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_44, 2, 0, 9223372036854775807);  unsqueeze_44 = None
            
             # File: <eval_with_key>.133:17 in forward, code: to_89 = torch.ops.aten.to.dtype(slice_41, torch.float32);  slice_41 = None
            _to_copy_14: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_41, dtype = torch.float32);  slice_41 = None
            
             # File: <eval_with_key>.133:22 in forward, code: matmul_12 = torch.ops.aten.matmul.default(to_90, to_91);  to_90 = to_91 = None
            matmul_12: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_13, _to_copy_14);  expand_13 = _to_copy_14 = None
            
             # File: <eval_with_key>.133:23 in forward, code: transpose_12 = torch.ops.aten.transpose.int(matmul_12, 1, 2);  matmul_12 = None
            transpose_12: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_12, 1, 2);  matmul_12 = None
            
             # File: <eval_with_key>.133:24 in forward, code: cat_12 = torch.ops.aten.cat.default([transpose_12, transpose_12], -1);  transpose_12 = None
            cat_12: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_12, transpose_12], -1);  transpose_12 = None
            
             # File: <eval_with_key>.133:25 in forward, code: cos_12 = torch.ops.aten.cos.default(cat_12)
            cos_12: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_12)
            
             # File: <eval_with_key>.133:26 in forward, code: mul_24 = torch.ops.aten.mul.Tensor(cos_12, 1.0);  cos_12 = None
            mul_24: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_12, 1.0);  cos_12 = mul_24 = None
            
             # File: <eval_with_key>.133:27 in forward, code: sin_12 = torch.ops.aten.sin.default(cat_12);  cat_12 = None
            sin_12: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_12);  cat_12 = None
            
             # File: <eval_with_key>.133:28 in forward, code: mul_25 = torch.ops.aten.mul.Tensor(sin_12, 1.0);  sin_12 = None
            mul_25: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_12, 1.0);  sin_12 = mul_25 = None
            
             # File: <eval_with_key>.134:5 in forward, code: unsqueeze_45 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_45: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.134:6 in forward, code: slice_42 = torch.ops.aten.slice.Tensor(unsqueeze_45, 1, 0, 9223372036854775807);  unsqueeze_45 = None
            slice_42: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_45, 1, 0, 9223372036854775807);  unsqueeze_45 = None
            
             # File: <eval_with_key>.134:7 in forward, code: unsqueeze_46 = torch.ops.aten.unsqueeze.default(slice_42, 2);  slice_42 = None
            unsqueeze_46: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_42, 2);  slice_42 = None
            
             # File: <eval_with_key>.134:10 in forward, code: expand_14 = torch.ops.aten.expand.default(to_94, [1, -1, 1]);  to_94 = None
            expand_14: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_46, [1, -1, 1]);  unsqueeze_46 = None
            
             # File: <eval_with_key>.134:13 in forward, code: slice_43 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_43: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.134:14 in forward, code: unsqueeze_47 = torch.ops.aten.unsqueeze.default(slice_43, 1);  slice_43 = None
            unsqueeze_47: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_43, 1);  slice_43 = None
            
             # File: <eval_with_key>.134:15 in forward, code: slice_44 = torch.ops.aten.slice.Tensor(unsqueeze_47, 2, 0, 9223372036854775807);  unsqueeze_47 = None
            slice_44: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_47, 2, 0, 9223372036854775807);  unsqueeze_47 = None
            
             # File: <eval_with_key>.134:17 in forward, code: to_96 = torch.ops.aten.to.dtype(slice_44, torch.float32);  slice_44 = None
            _to_copy_15: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_44, dtype = torch.float32);  slice_44 = None
            
             # File: <eval_with_key>.134:22 in forward, code: matmul_13 = torch.ops.aten.matmul.default(to_97, to_98);  to_97 = to_98 = None
            matmul_13: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_14, _to_copy_15);  expand_14 = _to_copy_15 = None
            
             # File: <eval_with_key>.134:23 in forward, code: transpose_13 = torch.ops.aten.transpose.int(matmul_13, 1, 2);  matmul_13 = None
            transpose_13: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_13, 1, 2);  matmul_13 = None
            
             # File: <eval_with_key>.134:24 in forward, code: cat_13 = torch.ops.aten.cat.default([transpose_13, transpose_13], -1);  transpose_13 = None
            cat_13: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_13, transpose_13], -1);  transpose_13 = None
            
             # File: <eval_with_key>.134:25 in forward, code: cos_13 = torch.ops.aten.cos.default(cat_13)
            cos_13: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_13)
            
             # File: <eval_with_key>.134:26 in forward, code: mul_26 = torch.ops.aten.mul.Tensor(cos_13, 1.0);  cos_13 = None
            mul_26: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_13, 1.0);  cos_13 = mul_26 = None
            
             # File: <eval_with_key>.134:27 in forward, code: sin_13 = torch.ops.aten.sin.default(cat_13);  cat_13 = None
            sin_13: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_13);  cat_13 = None
            
             # File: <eval_with_key>.134:28 in forward, code: mul_27 = torch.ops.aten.mul.Tensor(sin_13, 1.0);  sin_13 = None
            mul_27: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_13, 1.0);  sin_13 = mul_27 = None
            
             # File: <eval_with_key>.135:5 in forward, code: unsqueeze_48 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_48: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.135:6 in forward, code: slice_45 = torch.ops.aten.slice.Tensor(unsqueeze_48, 1, 0, 9223372036854775807);  unsqueeze_48 = None
            slice_45: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_48, 1, 0, 9223372036854775807);  unsqueeze_48 = None
            
             # File: <eval_with_key>.135:7 in forward, code: unsqueeze_49 = torch.ops.aten.unsqueeze.default(slice_45, 2);  slice_45 = None
            unsqueeze_49: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_45, 2);  slice_45 = None
            
             # File: <eval_with_key>.135:10 in forward, code: expand_15 = torch.ops.aten.expand.default(to_101, [1, -1, 1]);  to_101 = None
            expand_15: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_49, [1, -1, 1]);  unsqueeze_49 = None
            
             # File: <eval_with_key>.135:13 in forward, code: slice_46 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_46: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.135:14 in forward, code: unsqueeze_50 = torch.ops.aten.unsqueeze.default(slice_46, 1);  slice_46 = None
            unsqueeze_50: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_46, 1);  slice_46 = None
            
             # File: <eval_with_key>.135:15 in forward, code: slice_47 = torch.ops.aten.slice.Tensor(unsqueeze_50, 2, 0, 9223372036854775807);  unsqueeze_50 = None
            slice_47: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_50, 2, 0, 9223372036854775807);  unsqueeze_50 = None
            
             # File: <eval_with_key>.135:17 in forward, code: to_103 = torch.ops.aten.to.dtype(slice_47, torch.float32);  slice_47 = None
            _to_copy_16: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_47, dtype = torch.float32);  slice_47 = None
            
             # File: <eval_with_key>.135:22 in forward, code: matmul_14 = torch.ops.aten.matmul.default(to_104, to_105);  to_104 = to_105 = None
            matmul_14: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_15, _to_copy_16);  expand_15 = _to_copy_16 = None
            
             # File: <eval_with_key>.135:23 in forward, code: transpose_14 = torch.ops.aten.transpose.int(matmul_14, 1, 2);  matmul_14 = None
            transpose_14: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_14, 1, 2);  matmul_14 = None
            
             # File: <eval_with_key>.135:24 in forward, code: cat_14 = torch.ops.aten.cat.default([transpose_14, transpose_14], -1);  transpose_14 = None
            cat_14: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_14, transpose_14], -1);  transpose_14 = None
            
             # File: <eval_with_key>.135:25 in forward, code: cos_14 = torch.ops.aten.cos.default(cat_14)
            cos_14: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_14)
            
             # File: <eval_with_key>.135:26 in forward, code: mul_28 = torch.ops.aten.mul.Tensor(cos_14, 1.0);  cos_14 = None
            mul_28: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_14, 1.0);  cos_14 = mul_28 = None
            
             # File: <eval_with_key>.135:27 in forward, code: sin_14 = torch.ops.aten.sin.default(cat_14);  cat_14 = None
            sin_14: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_14);  cat_14 = None
            
             # File: <eval_with_key>.135:28 in forward, code: mul_29 = torch.ops.aten.mul.Tensor(sin_14, 1.0);  sin_14 = None
            mul_29: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_14, 1.0);  sin_14 = mul_29 = None
            
             # File: <eval_with_key>.136:5 in forward, code: unsqueeze_51 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_51: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.136:6 in forward, code: slice_48 = torch.ops.aten.slice.Tensor(unsqueeze_51, 1, 0, 9223372036854775807);  unsqueeze_51 = None
            slice_48: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_51, 1, 0, 9223372036854775807);  unsqueeze_51 = None
            
             # File: <eval_with_key>.136:7 in forward, code: unsqueeze_52 = torch.ops.aten.unsqueeze.default(slice_48, 2);  slice_48 = None
            unsqueeze_52: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_48, 2);  slice_48 = None
            
             # File: <eval_with_key>.136:10 in forward, code: expand_16 = torch.ops.aten.expand.default(to_108, [1, -1, 1]);  to_108 = None
            expand_16: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_52, [1, -1, 1]);  unsqueeze_52 = None
            
             # File: <eval_with_key>.136:13 in forward, code: slice_49 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_49: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.136:14 in forward, code: unsqueeze_53 = torch.ops.aten.unsqueeze.default(slice_49, 1);  slice_49 = None
            unsqueeze_53: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_49, 1);  slice_49 = None
            
             # File: <eval_with_key>.136:15 in forward, code: slice_50 = torch.ops.aten.slice.Tensor(unsqueeze_53, 2, 0, 9223372036854775807);  unsqueeze_53 = None
            slice_50: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_53, 2, 0, 9223372036854775807);  unsqueeze_53 = None
            
             # File: <eval_with_key>.136:17 in forward, code: to_110 = torch.ops.aten.to.dtype(slice_50, torch.float32);  slice_50 = None
            _to_copy_17: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_50, dtype = torch.float32);  slice_50 = None
            
             # File: <eval_with_key>.136:22 in forward, code: matmul_15 = torch.ops.aten.matmul.default(to_111, to_112);  to_111 = to_112 = None
            matmul_15: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_16, _to_copy_17);  expand_16 = _to_copy_17 = None
            
             # File: <eval_with_key>.136:23 in forward, code: transpose_15 = torch.ops.aten.transpose.int(matmul_15, 1, 2);  matmul_15 = None
            transpose_15: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_15, 1, 2);  matmul_15 = None
            
             # File: <eval_with_key>.136:24 in forward, code: cat_15 = torch.ops.aten.cat.default([transpose_15, transpose_15], -1);  transpose_15 = None
            cat_15: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_15, transpose_15], -1);  transpose_15 = None
            
             # File: <eval_with_key>.136:25 in forward, code: cos_15 = torch.ops.aten.cos.default(cat_15)
            cos_15: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_15)
            
             # File: <eval_with_key>.136:26 in forward, code: mul_30 = torch.ops.aten.mul.Tensor(cos_15, 1.0);  cos_15 = None
            mul_30: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_15, 1.0);  cos_15 = mul_30 = None
            
             # File: <eval_with_key>.136:27 in forward, code: sin_15 = torch.ops.aten.sin.default(cat_15);  cat_15 = None
            sin_15: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_15);  cat_15 = None
            
             # File: <eval_with_key>.136:28 in forward, code: mul_31 = torch.ops.aten.mul.Tensor(sin_15, 1.0);  sin_15 = None
            mul_31: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_15, 1.0);  sin_15 = mul_31 = None
            
             # File: <eval_with_key>.137:5 in forward, code: unsqueeze_54 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_54: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.137:6 in forward, code: slice_51 = torch.ops.aten.slice.Tensor(unsqueeze_54, 1, 0, 9223372036854775807);  unsqueeze_54 = None
            slice_51: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_54, 1, 0, 9223372036854775807);  unsqueeze_54 = None
            
             # File: <eval_with_key>.137:7 in forward, code: unsqueeze_55 = torch.ops.aten.unsqueeze.default(slice_51, 2);  slice_51 = None
            unsqueeze_55: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_51, 2);  slice_51 = None
            
             # File: <eval_with_key>.137:10 in forward, code: expand_17 = torch.ops.aten.expand.default(to_115, [1, -1, 1]);  to_115 = None
            expand_17: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_55, [1, -1, 1]);  unsqueeze_55 = None
            
             # File: <eval_with_key>.137:13 in forward, code: slice_52 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_52: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.137:14 in forward, code: unsqueeze_56 = torch.ops.aten.unsqueeze.default(slice_52, 1);  slice_52 = None
            unsqueeze_56: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_52, 1);  slice_52 = None
            
             # File: <eval_with_key>.137:15 in forward, code: slice_53 = torch.ops.aten.slice.Tensor(unsqueeze_56, 2, 0, 9223372036854775807);  unsqueeze_56 = None
            slice_53: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_56, 2, 0, 9223372036854775807);  unsqueeze_56 = None
            
             # File: <eval_with_key>.137:17 in forward, code: to_117 = torch.ops.aten.to.dtype(slice_53, torch.float32);  slice_53 = None
            _to_copy_18: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_53, dtype = torch.float32);  slice_53 = None
            
             # File: <eval_with_key>.137:22 in forward, code: matmul_16 = torch.ops.aten.matmul.default(to_118, to_119);  to_118 = to_119 = None
            matmul_16: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_17, _to_copy_18);  expand_17 = _to_copy_18 = None
            
             # File: <eval_with_key>.137:23 in forward, code: transpose_16 = torch.ops.aten.transpose.int(matmul_16, 1, 2);  matmul_16 = None
            transpose_16: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_16, 1, 2);  matmul_16 = None
            
             # File: <eval_with_key>.137:24 in forward, code: cat_16 = torch.ops.aten.cat.default([transpose_16, transpose_16], -1);  transpose_16 = None
            cat_16: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_16, transpose_16], -1);  transpose_16 = None
            
             # File: <eval_with_key>.137:25 in forward, code: cos_16 = torch.ops.aten.cos.default(cat_16)
            cos_16: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_16)
            
             # File: <eval_with_key>.137:26 in forward, code: mul_32 = torch.ops.aten.mul.Tensor(cos_16, 1.0);  cos_16 = None
            mul_32: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_16, 1.0);  cos_16 = mul_32 = None
            
             # File: <eval_with_key>.137:27 in forward, code: sin_16 = torch.ops.aten.sin.default(cat_16);  cat_16 = None
            sin_16: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_16);  cat_16 = None
            
             # File: <eval_with_key>.137:28 in forward, code: mul_33 = torch.ops.aten.mul.Tensor(sin_16, 1.0);  sin_16 = None
            mul_33: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_16, 1.0);  sin_16 = mul_33 = None
            
             # File: <eval_with_key>.138:5 in forward, code: unsqueeze_57 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_57: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.138:6 in forward, code: slice_54 = torch.ops.aten.slice.Tensor(unsqueeze_57, 1, 0, 9223372036854775807);  unsqueeze_57 = None
            slice_54: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_57, 1, 0, 9223372036854775807);  unsqueeze_57 = None
            
             # File: <eval_with_key>.138:7 in forward, code: unsqueeze_58 = torch.ops.aten.unsqueeze.default(slice_54, 2);  slice_54 = None
            unsqueeze_58: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_54, 2);  slice_54 = None
            
             # File: <eval_with_key>.138:10 in forward, code: expand_18 = torch.ops.aten.expand.default(to_122, [1, -1, 1]);  to_122 = None
            expand_18: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_58, [1, -1, 1]);  unsqueeze_58 = None
            
             # File: <eval_with_key>.138:13 in forward, code: slice_55 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_55: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.138:14 in forward, code: unsqueeze_59 = torch.ops.aten.unsqueeze.default(slice_55, 1);  slice_55 = None
            unsqueeze_59: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_55, 1);  slice_55 = None
            
             # File: <eval_with_key>.138:15 in forward, code: slice_56 = torch.ops.aten.slice.Tensor(unsqueeze_59, 2, 0, 9223372036854775807);  unsqueeze_59 = None
            slice_56: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_59, 2, 0, 9223372036854775807);  unsqueeze_59 = None
            
             # File: <eval_with_key>.138:17 in forward, code: to_124 = torch.ops.aten.to.dtype(slice_56, torch.float32);  slice_56 = None
            _to_copy_19: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_56, dtype = torch.float32);  slice_56 = None
            
             # File: <eval_with_key>.138:22 in forward, code: matmul_17 = torch.ops.aten.matmul.default(to_125, to_126);  to_125 = to_126 = None
            matmul_17: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_18, _to_copy_19);  expand_18 = _to_copy_19 = None
            
             # File: <eval_with_key>.138:23 in forward, code: transpose_17 = torch.ops.aten.transpose.int(matmul_17, 1, 2);  matmul_17 = None
            transpose_17: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_17, 1, 2);  matmul_17 = None
            
             # File: <eval_with_key>.138:24 in forward, code: cat_17 = torch.ops.aten.cat.default([transpose_17, transpose_17], -1);  transpose_17 = None
            cat_17: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_17, transpose_17], -1);  transpose_17 = None
            
             # File: <eval_with_key>.138:25 in forward, code: cos_17 = torch.ops.aten.cos.default(cat_17)
            cos_17: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_17)
            
             # File: <eval_with_key>.138:26 in forward, code: mul_34 = torch.ops.aten.mul.Tensor(cos_17, 1.0);  cos_17 = None
            mul_34: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_17, 1.0);  cos_17 = mul_34 = None
            
             # File: <eval_with_key>.138:27 in forward, code: sin_17 = torch.ops.aten.sin.default(cat_17);  cat_17 = None
            sin_17: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_17);  cat_17 = None
            
             # File: <eval_with_key>.138:28 in forward, code: mul_35 = torch.ops.aten.mul.Tensor(sin_17, 1.0);  sin_17 = None
            mul_35: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_17, 1.0);  sin_17 = mul_35 = None
            
             # File: <eval_with_key>.139:5 in forward, code: unsqueeze_60 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_60: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.139:6 in forward, code: slice_57 = torch.ops.aten.slice.Tensor(unsqueeze_60, 1, 0, 9223372036854775807);  unsqueeze_60 = None
            slice_57: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_60, 1, 0, 9223372036854775807);  unsqueeze_60 = None
            
             # File: <eval_with_key>.139:7 in forward, code: unsqueeze_61 = torch.ops.aten.unsqueeze.default(slice_57, 2);  slice_57 = None
            unsqueeze_61: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_57, 2);  slice_57 = None
            
             # File: <eval_with_key>.139:10 in forward, code: expand_19 = torch.ops.aten.expand.default(to_129, [1, -1, 1]);  to_129 = None
            expand_19: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_61, [1, -1, 1]);  unsqueeze_61 = None
            
             # File: <eval_with_key>.139:13 in forward, code: slice_58 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_58: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.139:14 in forward, code: unsqueeze_62 = torch.ops.aten.unsqueeze.default(slice_58, 1);  slice_58 = None
            unsqueeze_62: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_58, 1);  slice_58 = None
            
             # File: <eval_with_key>.139:15 in forward, code: slice_59 = torch.ops.aten.slice.Tensor(unsqueeze_62, 2, 0, 9223372036854775807);  unsqueeze_62 = None
            slice_59: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_62, 2, 0, 9223372036854775807);  unsqueeze_62 = None
            
             # File: <eval_with_key>.139:17 in forward, code: to_131 = torch.ops.aten.to.dtype(slice_59, torch.float32);  slice_59 = None
            _to_copy_20: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_59, dtype = torch.float32);  slice_59 = None
            
             # File: <eval_with_key>.139:22 in forward, code: matmul_18 = torch.ops.aten.matmul.default(to_132, to_133);  to_132 = to_133 = None
            matmul_18: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_19, _to_copy_20);  expand_19 = _to_copy_20 = None
            
             # File: <eval_with_key>.139:23 in forward, code: transpose_18 = torch.ops.aten.transpose.int(matmul_18, 1, 2);  matmul_18 = None
            transpose_18: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_18, 1, 2);  matmul_18 = None
            
             # File: <eval_with_key>.139:24 in forward, code: cat_18 = torch.ops.aten.cat.default([transpose_18, transpose_18], -1);  transpose_18 = None
            cat_18: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_18, transpose_18], -1);  transpose_18 = None
            
             # File: <eval_with_key>.139:25 in forward, code: cos_18 = torch.ops.aten.cos.default(cat_18)
            cos_18: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_18)
            
             # File: <eval_with_key>.139:26 in forward, code: mul_36 = torch.ops.aten.mul.Tensor(cos_18, 1.0);  cos_18 = None
            mul_36: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_18, 1.0);  cos_18 = mul_36 = None
            
             # File: <eval_with_key>.139:27 in forward, code: sin_18 = torch.ops.aten.sin.default(cat_18);  cat_18 = None
            sin_18: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_18);  cat_18 = None
            
             # File: <eval_with_key>.139:28 in forward, code: mul_37 = torch.ops.aten.mul.Tensor(sin_18, 1.0);  sin_18 = None
            mul_37: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_18, 1.0);  sin_18 = mul_37 = None
            
             # File: <eval_with_key>.140:5 in forward, code: unsqueeze_63 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_63: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.140:6 in forward, code: slice_60 = torch.ops.aten.slice.Tensor(unsqueeze_63, 1, 0, 9223372036854775807);  unsqueeze_63 = None
            slice_60: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_63, 1, 0, 9223372036854775807);  unsqueeze_63 = None
            
             # File: <eval_with_key>.140:7 in forward, code: unsqueeze_64 = torch.ops.aten.unsqueeze.default(slice_60, 2);  slice_60 = None
            unsqueeze_64: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_60, 2);  slice_60 = None
            
             # File: <eval_with_key>.140:10 in forward, code: expand_20 = torch.ops.aten.expand.default(to_136, [1, -1, 1]);  to_136 = None
            expand_20: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_64, [1, -1, 1]);  unsqueeze_64 = None
            
             # File: <eval_with_key>.140:13 in forward, code: slice_61 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_61: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.140:14 in forward, code: unsqueeze_65 = torch.ops.aten.unsqueeze.default(slice_61, 1);  slice_61 = None
            unsqueeze_65: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_61, 1);  slice_61 = None
            
             # File: <eval_with_key>.140:15 in forward, code: slice_62 = torch.ops.aten.slice.Tensor(unsqueeze_65, 2, 0, 9223372036854775807);  unsqueeze_65 = None
            slice_62: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_65, 2, 0, 9223372036854775807);  unsqueeze_65 = None
            
             # File: <eval_with_key>.140:17 in forward, code: to_138 = torch.ops.aten.to.dtype(slice_62, torch.float32);  slice_62 = None
            _to_copy_21: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_62, dtype = torch.float32);  slice_62 = None
            
             # File: <eval_with_key>.140:22 in forward, code: matmul_19 = torch.ops.aten.matmul.default(to_139, to_140);  to_139 = to_140 = None
            matmul_19: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_20, _to_copy_21);  expand_20 = _to_copy_21 = None
            
             # File: <eval_with_key>.140:23 in forward, code: transpose_19 = torch.ops.aten.transpose.int(matmul_19, 1, 2);  matmul_19 = None
            transpose_19: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_19, 1, 2);  matmul_19 = None
            
             # File: <eval_with_key>.140:24 in forward, code: cat_19 = torch.ops.aten.cat.default([transpose_19, transpose_19], -1);  transpose_19 = None
            cat_19: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_19, transpose_19], -1);  transpose_19 = None
            
             # File: <eval_with_key>.140:25 in forward, code: cos_19 = torch.ops.aten.cos.default(cat_19)
            cos_19: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_19)
            
             # File: <eval_with_key>.140:26 in forward, code: mul_38 = torch.ops.aten.mul.Tensor(cos_19, 1.0);  cos_19 = None
            mul_38: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_19, 1.0);  cos_19 = mul_38 = None
            
             # File: <eval_with_key>.140:27 in forward, code: sin_19 = torch.ops.aten.sin.default(cat_19);  cat_19 = None
            sin_19: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_19);  cat_19 = None
            
             # File: <eval_with_key>.140:28 in forward, code: mul_39 = torch.ops.aten.mul.Tensor(sin_19, 1.0);  sin_19 = None
            mul_39: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_19, 1.0);  sin_19 = mul_39 = None
            
             # File: <eval_with_key>.141:5 in forward, code: unsqueeze_66 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_66: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            
             # File: <eval_with_key>.141:6 in forward, code: slice_63 = torch.ops.aten.slice.Tensor(unsqueeze_66, 1, 0, 9223372036854775807);  unsqueeze_66 = None
            slice_63: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_66, 1, 0, 9223372036854775807);  unsqueeze_66 = None
            
             # File: <eval_with_key>.141:7 in forward, code: unsqueeze_67 = torch.ops.aten.unsqueeze.default(slice_63, 2);  slice_63 = None
            unsqueeze_67: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_63, 2);  slice_63 = None
            
             # File: <eval_with_key>.141:10 in forward, code: expand_21 = torch.ops.aten.expand.default(to_143, [1, -1, 1]);  to_143 = None
            expand_21: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_67, [1, -1, 1]);  unsqueeze_67 = None
            
             # File: <eval_with_key>.141:13 in forward, code: slice_64 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_64: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.141:14 in forward, code: unsqueeze_68 = torch.ops.aten.unsqueeze.default(slice_64, 1);  slice_64 = None
            unsqueeze_68: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_64, 1);  slice_64 = None
            
             # File: <eval_with_key>.141:15 in forward, code: slice_65 = torch.ops.aten.slice.Tensor(unsqueeze_68, 2, 0, 9223372036854775807);  unsqueeze_68 = None
            slice_65: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_68, 2, 0, 9223372036854775807);  unsqueeze_68 = None
            
             # File: <eval_with_key>.141:17 in forward, code: to_145 = torch.ops.aten.to.dtype(slice_65, torch.float32);  slice_65 = None
            _to_copy_22: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_65, dtype = torch.float32);  slice_65 = None
            
             # File: <eval_with_key>.141:22 in forward, code: matmul_20 = torch.ops.aten.matmul.default(to_146, to_147);  to_146 = to_147 = None
            matmul_20: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_21, _to_copy_22);  expand_21 = _to_copy_22 = None
            
             # File: <eval_with_key>.141:23 in forward, code: transpose_20 = torch.ops.aten.transpose.int(matmul_20, 1, 2);  matmul_20 = None
            transpose_20: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_20, 1, 2);  matmul_20 = None
            
             # File: <eval_with_key>.141:24 in forward, code: cat_20 = torch.ops.aten.cat.default([transpose_20, transpose_20], -1);  transpose_20 = None
            cat_20: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_20, transpose_20], -1);  transpose_20 = None
            
             # File: <eval_with_key>.141:25 in forward, code: cos_20 = torch.ops.aten.cos.default(cat_20)
            cos_20: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_20)
            
             # File: <eval_with_key>.141:26 in forward, code: mul_40 = torch.ops.aten.mul.Tensor(cos_20, 1.0);  cos_20 = None
            mul_40: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_20, 1.0);  cos_20 = None
            
             # File: <eval_with_key>.141:27 in forward, code: sin_20 = torch.ops.aten.sin.default(cat_20);  cat_20 = None
            sin_20: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_20);  cat_20 = None
            
             # File: <eval_with_key>.141:28 in forward, code: mul_41 = torch.ops.aten.mul.Tensor(sin_20, 1.0);  sin_20 = None
            mul_41: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_20, 1.0);  sin_20 = None
            
             # File: <eval_with_key>.142:5 in forward, code: unsqueeze_69 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_69: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            
             # File: <eval_with_key>.142:6 in forward, code: slice_66 = torch.ops.aten.slice.Tensor(unsqueeze_69, 1, 0, 9223372036854775807);  unsqueeze_69 = None
            slice_66: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_69, 1, 0, 9223372036854775807);  unsqueeze_69 = None
            
             # File: <eval_with_key>.142:7 in forward, code: unsqueeze_70 = torch.ops.aten.unsqueeze.default(slice_66, 2);  slice_66 = None
            unsqueeze_70: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_66, 2);  slice_66 = None
            
             # File: <eval_with_key>.142:10 in forward, code: expand_22 = torch.ops.aten.expand.default(to_150, [1, -1, 1]);  to_150 = None
            expand_22: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_70, [1, -1, 1]);  unsqueeze_70 = None
            
             # File: <eval_with_key>.142:13 in forward, code: slice_67 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_67: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            
             # File: <eval_with_key>.142:14 in forward, code: unsqueeze_71 = torch.ops.aten.unsqueeze.default(slice_67, 1);  slice_67 = None
            unsqueeze_71: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_67, 1);  slice_67 = None
            
             # File: <eval_with_key>.142:15 in forward, code: slice_68 = torch.ops.aten.slice.Tensor(unsqueeze_71, 2, 0, 9223372036854775807);  unsqueeze_71 = None
            slice_68: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_71, 2, 0, 9223372036854775807);  unsqueeze_71 = None
            
             # File: <eval_with_key>.142:17 in forward, code: to_152 = torch.ops.aten.to.dtype(slice_68, torch.float32);  slice_68 = None
            _to_copy_23: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_68, dtype = torch.float32);  slice_68 = None
            
             # File: <eval_with_key>.142:22 in forward, code: matmul_21 = torch.ops.aten.matmul.default(to_153, to_154);  to_153 = to_154 = None
            matmul_21: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_22, _to_copy_23);  expand_22 = _to_copy_23 = None
            
             # File: <eval_with_key>.142:23 in forward, code: transpose_21 = torch.ops.aten.transpose.int(matmul_21, 1, 2);  matmul_21 = None
            transpose_21: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_21, 1, 2);  matmul_21 = None
            
             # File: <eval_with_key>.142:24 in forward, code: cat_21 = torch.ops.aten.cat.default([transpose_21, transpose_21], -1);  transpose_21 = None
            cat_21: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_21, transpose_21], -1);  transpose_21 = None
            
             # File: <eval_with_key>.142:25 in forward, code: cos_21 = torch.ops.aten.cos.default(cat_21)
            cos_21: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_21)
            
             # File: <eval_with_key>.142:26 in forward, code: mul_42 = torch.ops.aten.mul.Tensor(cos_21, 1.0);  cos_21 = None
            mul_42: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_21, 1.0);  cos_21 = None
            
             # File: <eval_with_key>.142:27 in forward, code: sin_21 = torch.ops.aten.sin.default(cat_21);  cat_21 = None
            sin_21: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_21);  cat_21 = None
            
             # File: <eval_with_key>.142:28 in forward, code: mul_43 = torch.ops.aten.mul.Tensor(sin_21, 1.0);  sin_21 = None
            mul_43: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_21, 1.0);  sin_21 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(clone_1, p_encoder_layers_0_attn_wqkv_weight);  p_encoder_layers_0_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear, [1, -1, 3, 12, 64]);  linear = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_22: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view, 3, 1);  view = None
            unbind = torch.ops.aten.unbind.int(transpose_22, 2);  transpose_22 = None
            getitem: "f32[1, 12, 97, 64]" = unbind[0]
            getitem_1: "f32[1, 12, 97, 64]" = unbind[1]
            getitem_2: "f32[1, 12, 97, 64]" = unbind[2];  unbind = None
            unsqueeze_72: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_73: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_44: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem, unsqueeze_72)
            slice_69: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem, 3, 0, 32)
            slice_70: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem, 3, 32, 9223372036854775807);  getitem = None
            neg: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_70);  slice_70 = None
            cat_22: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg, slice_69], -1);  neg = slice_69 = None
            mul_45: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_22, unsqueeze_73);  cat_22 = None
            add: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_44, mul_45);  mul_44 = mul_45 = None
            mul_46: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_1, unsqueeze_72);  unsqueeze_72 = None
            slice_71: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_1, 3, 0, 32)
            slice_72: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_1, 3, 32, 9223372036854775807);  getitem_1 = None
            neg_1: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_72);  slice_72 = None
            cat_23: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_1, slice_71], -1);  neg_1 = slice_71 = None
            mul_47: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_23, unsqueeze_73);  cat_23 = unsqueeze_73 = None
            add_1: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_46, mul_47);  mul_46 = mul_47 = None
            scaled_dot_product_attention: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add, add_1, getitem_2, masked_fill);  add = add_1 = getitem_2 = None
            transpose_23: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention, 1, 2);  scaled_dot_product_attention = None
            view_1: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_23, [1, -1, 768]);  transpose_23 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_1: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_1, p_encoder_layers_0_attn_wo_weight);  view_1 = p_encoder_layers_0_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_2: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(clone_1, linear_1);  clone_1 = linear_1 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_1: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_2, [768], p_encoder_layers_0_mlp_norm_weight);  p_encoder_layers_0_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_2: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_1, p_encoder_layers_0_mlp_wi_weight);  layer_norm_1 = p_encoder_layers_0_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split = torch.ops.aten.split.Tensor(linear_2, 1152, -1);  linear_2 = None
            getitem_3: "f32[1, 97, 1152]" = split[0]
            getitem_4: "f32[1, 97, 1152]" = split[1];  split = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_3);  getitem_3 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_48: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu, getitem_4);  gelu = getitem_4 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_2: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_48);  mul_48 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_3: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_2, p_encoder_layers_0_mlp_wo_weight);  clone_2 = p_encoder_layers_0_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_3: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_2, linear_3);  add_2 = linear_3 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_2: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_3, [768], p_encoder_layers_1_attn_norm_weight);  p_encoder_layers_1_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_4: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_2, p_encoder_layers_1_attn_wqkv_weight);  layer_norm_2 = p_encoder_layers_1_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_2: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_4, [1, -1, 3, 12, 64]);  linear_4 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_24: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_2, 3, 1);  view_2 = None
            unbind_1 = torch.ops.aten.unbind.int(transpose_24, 2);  transpose_24 = None
            getitem_5: "f32[1, 12, 97, 64]" = unbind_1[0]
            getitem_6: "f32[1, 12, 97, 64]" = unbind_1[1]
            getitem_7: "f32[1, 12, 97, 64]" = unbind_1[2];  unbind_1 = None
            unsqueeze_74: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_75: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_49: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_5, unsqueeze_74)
            slice_73: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_5, 3, 0, 32)
            slice_74: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_5, 3, 32, 9223372036854775807);  getitem_5 = None
            neg_2: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_74);  slice_74 = None
            cat_24: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_2, slice_73], -1);  neg_2 = slice_73 = None
            mul_50: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_24, unsqueeze_75);  cat_24 = None
            add_4: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_49, mul_50);  mul_49 = mul_50 = None
            mul_51: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_6, unsqueeze_74);  unsqueeze_74 = None
            slice_75: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_6, 3, 0, 32)
            slice_76: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_6, 3, 32, 9223372036854775807);  getitem_6 = None
            neg_3: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_76);  slice_76 = None
            cat_25: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_3, slice_75], -1);  neg_3 = slice_75 = None
            mul_52: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_25, unsqueeze_75);  cat_25 = unsqueeze_75 = None
            add_5: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_51, mul_52);  mul_51 = mul_52 = None
            scaled_dot_product_attention_1: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_4, add_5, getitem_7, masked_fill_1);  add_4 = add_5 = getitem_7 = None
            transpose_25: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_1, 1, 2);  scaled_dot_product_attention_1 = None
            view_3: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_25, [1, -1, 768]);  transpose_25 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_5: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_3, p_encoder_layers_1_attn_wo_weight);  view_3 = p_encoder_layers_1_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_6: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_3, linear_5);  add_3 = linear_5 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_3: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_6, [768], p_encoder_layers_1_mlp_norm_weight);  p_encoder_layers_1_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_6: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_3, p_encoder_layers_1_mlp_wi_weight);  layer_norm_3 = p_encoder_layers_1_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_1 = torch.ops.aten.split.Tensor(linear_6, 1152, -1);  linear_6 = None
            getitem_8: "f32[1, 97, 1152]" = split_1[0]
            getitem_9: "f32[1, 97, 1152]" = split_1[1];  split_1 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_1: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_8);  getitem_8 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_53: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_1, getitem_9);  gelu_1 = getitem_9 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_3: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_53);  mul_53 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_7: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_3, p_encoder_layers_1_mlp_wo_weight);  clone_3 = p_encoder_layers_1_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_7: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_6, linear_7);  add_6 = linear_7 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_4: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_7, [768], p_encoder_layers_2_attn_norm_weight);  p_encoder_layers_2_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_8: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_4, p_encoder_layers_2_attn_wqkv_weight);  layer_norm_4 = p_encoder_layers_2_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_4: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_8, [1, -1, 3, 12, 64]);  linear_8 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_26: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_4, 3, 1);  view_4 = None
            unbind_2 = torch.ops.aten.unbind.int(transpose_26, 2);  transpose_26 = None
            getitem_10: "f32[1, 12, 97, 64]" = unbind_2[0]
            getitem_11: "f32[1, 12, 97, 64]" = unbind_2[1]
            getitem_12: "f32[1, 12, 97, 64]" = unbind_2[2];  unbind_2 = None
            unsqueeze_76: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_77: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_54: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_10, unsqueeze_76)
            slice_77: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_10, 3, 0, 32)
            slice_78: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_10, 3, 32, 9223372036854775807);  getitem_10 = None
            neg_4: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_78);  slice_78 = None
            cat_26: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_4, slice_77], -1);  neg_4 = slice_77 = None
            mul_55: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_26, unsqueeze_77);  cat_26 = None
            add_8: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_54, mul_55);  mul_54 = mul_55 = None
            mul_56: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_11, unsqueeze_76);  unsqueeze_76 = None
            slice_79: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_11, 3, 0, 32)
            slice_80: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_11, 3, 32, 9223372036854775807);  getitem_11 = None
            neg_5: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_80);  slice_80 = None
            cat_27: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_5, slice_79], -1);  neg_5 = slice_79 = None
            mul_57: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_27, unsqueeze_77);  cat_27 = unsqueeze_77 = None
            add_9: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_56, mul_57);  mul_56 = mul_57 = None
            scaled_dot_product_attention_2: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_8, add_9, getitem_12, masked_fill_1);  add_8 = add_9 = getitem_12 = None
            transpose_27: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_2, 1, 2);  scaled_dot_product_attention_2 = None
            view_5: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_27, [1, -1, 768]);  transpose_27 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_9: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_5, p_encoder_layers_2_attn_wo_weight);  view_5 = p_encoder_layers_2_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_10: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_7, linear_9);  add_7 = linear_9 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_5: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_10, [768], p_encoder_layers_2_mlp_norm_weight);  p_encoder_layers_2_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_10: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_5, p_encoder_layers_2_mlp_wi_weight);  layer_norm_5 = p_encoder_layers_2_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_2 = torch.ops.aten.split.Tensor(linear_10, 1152, -1);  linear_10 = None
            getitem_13: "f32[1, 97, 1152]" = split_2[0]
            getitem_14: "f32[1, 97, 1152]" = split_2[1];  split_2 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_2: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_13);  getitem_13 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_58: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_2, getitem_14);  gelu_2 = getitem_14 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_4: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_58);  mul_58 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_11: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_4, p_encoder_layers_2_mlp_wo_weight);  clone_4 = p_encoder_layers_2_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_11: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_10, linear_11);  add_10 = linear_11 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_6: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_11, [768], p_encoder_layers_3_attn_norm_weight);  p_encoder_layers_3_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_12: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_6, p_encoder_layers_3_attn_wqkv_weight);  layer_norm_6 = p_encoder_layers_3_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_6: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_12, [1, -1, 3, 12, 64]);  linear_12 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_28: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_6, 3, 1);  view_6 = None
            unbind_3 = torch.ops.aten.unbind.int(transpose_28, 2);  transpose_28 = None
            getitem_15: "f32[1, 12, 97, 64]" = unbind_3[0]
            getitem_16: "f32[1, 12, 97, 64]" = unbind_3[1]
            getitem_17: "f32[1, 12, 97, 64]" = unbind_3[2];  unbind_3 = None
            unsqueeze_78: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_79: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_59: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_15, unsqueeze_78)
            slice_81: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_15, 3, 0, 32)
            slice_82: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_15, 3, 32, 9223372036854775807);  getitem_15 = None
            neg_6: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_82);  slice_82 = None
            cat_28: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_6, slice_81], -1);  neg_6 = slice_81 = None
            mul_60: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_28, unsqueeze_79);  cat_28 = None
            add_12: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_59, mul_60);  mul_59 = mul_60 = None
            mul_61: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_16, unsqueeze_78);  unsqueeze_78 = None
            slice_83: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_16, 3, 0, 32)
            slice_84: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_16, 3, 32, 9223372036854775807);  getitem_16 = None
            neg_7: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_84);  slice_84 = None
            cat_29: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_7, slice_83], -1);  neg_7 = slice_83 = None
            mul_62: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_29, unsqueeze_79);  cat_29 = unsqueeze_79 = None
            add_13: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_61, mul_62);  mul_61 = mul_62 = None
            scaled_dot_product_attention_3: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_12, add_13, getitem_17, masked_fill);  add_12 = add_13 = getitem_17 = None
            transpose_29: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_3, 1, 2);  scaled_dot_product_attention_3 = None
            view_7: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_29, [1, -1, 768]);  transpose_29 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_13: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_7, p_encoder_layers_3_attn_wo_weight);  view_7 = p_encoder_layers_3_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_14: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_11, linear_13);  add_11 = linear_13 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_7: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_14, [768], p_encoder_layers_3_mlp_norm_weight);  p_encoder_layers_3_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_14: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_7, p_encoder_layers_3_mlp_wi_weight);  layer_norm_7 = p_encoder_layers_3_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_3 = torch.ops.aten.split.Tensor(linear_14, 1152, -1);  linear_14 = None
            getitem_18: "f32[1, 97, 1152]" = split_3[0]
            getitem_19: "f32[1, 97, 1152]" = split_3[1];  split_3 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_3: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_18);  getitem_18 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_63: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_3, getitem_19);  gelu_3 = getitem_19 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_5: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_63);  mul_63 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_15: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_5, p_encoder_layers_3_mlp_wo_weight);  clone_5 = p_encoder_layers_3_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_15: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_14, linear_15);  add_14 = linear_15 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_8: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_15, [768], p_encoder_layers_4_attn_norm_weight);  p_encoder_layers_4_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_16: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_8, p_encoder_layers_4_attn_wqkv_weight);  layer_norm_8 = p_encoder_layers_4_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_8: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_16, [1, -1, 3, 12, 64]);  linear_16 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_30: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_8, 3, 1);  view_8 = None
            unbind_4 = torch.ops.aten.unbind.int(transpose_30, 2);  transpose_30 = None
            getitem_20: "f32[1, 12, 97, 64]" = unbind_4[0]
            getitem_21: "f32[1, 12, 97, 64]" = unbind_4[1]
            getitem_22: "f32[1, 12, 97, 64]" = unbind_4[2];  unbind_4 = None
            unsqueeze_80: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_81: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_64: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_20, unsqueeze_80)
            slice_85: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_20, 3, 0, 32)
            slice_86: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_20, 3, 32, 9223372036854775807);  getitem_20 = None
            neg_8: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_86);  slice_86 = None
            cat_30: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_8, slice_85], -1);  neg_8 = slice_85 = None
            mul_65: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_30, unsqueeze_81);  cat_30 = None
            add_16: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_64, mul_65);  mul_64 = mul_65 = None
            mul_66: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_21, unsqueeze_80);  unsqueeze_80 = None
            slice_87: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_21, 3, 0, 32)
            slice_88: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_21, 3, 32, 9223372036854775807);  getitem_21 = None
            neg_9: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_88);  slice_88 = None
            cat_31: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_9, slice_87], -1);  neg_9 = slice_87 = None
            mul_67: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_31, unsqueeze_81);  cat_31 = unsqueeze_81 = None
            add_17: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_66, mul_67);  mul_66 = mul_67 = None
            scaled_dot_product_attention_4: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_16, add_17, getitem_22, masked_fill_1);  add_16 = add_17 = getitem_22 = None
            transpose_31: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_4, 1, 2);  scaled_dot_product_attention_4 = None
            view_9: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_31, [1, -1, 768]);  transpose_31 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_17: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_9, p_encoder_layers_4_attn_wo_weight);  view_9 = p_encoder_layers_4_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_18: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_15, linear_17);  add_15 = linear_17 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_9: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_18, [768], p_encoder_layers_4_mlp_norm_weight);  p_encoder_layers_4_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_18: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_9, p_encoder_layers_4_mlp_wi_weight);  layer_norm_9 = p_encoder_layers_4_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_4 = torch.ops.aten.split.Tensor(linear_18, 1152, -1);  linear_18 = None
            getitem_23: "f32[1, 97, 1152]" = split_4[0]
            getitem_24: "f32[1, 97, 1152]" = split_4[1];  split_4 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_4: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_23);  getitem_23 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_68: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_4, getitem_24);  gelu_4 = getitem_24 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_6: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_68);  mul_68 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_19: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_6, p_encoder_layers_4_mlp_wo_weight);  clone_6 = p_encoder_layers_4_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_19: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_18, linear_19);  add_18 = linear_19 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_10: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_19, [768], p_encoder_layers_5_attn_norm_weight);  p_encoder_layers_5_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_20: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_10, p_encoder_layers_5_attn_wqkv_weight);  layer_norm_10 = p_encoder_layers_5_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_10: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_20, [1, -1, 3, 12, 64]);  linear_20 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_32: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_10, 3, 1);  view_10 = None
            unbind_5 = torch.ops.aten.unbind.int(transpose_32, 2);  transpose_32 = None
            getitem_25: "f32[1, 12, 97, 64]" = unbind_5[0]
            getitem_26: "f32[1, 12, 97, 64]" = unbind_5[1]
            getitem_27: "f32[1, 12, 97, 64]" = unbind_5[2];  unbind_5 = None
            unsqueeze_82: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_83: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_69: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_25, unsqueeze_82)
            slice_89: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_25, 3, 0, 32)
            slice_90: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_25, 3, 32, 9223372036854775807);  getitem_25 = None
            neg_10: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_90);  slice_90 = None
            cat_32: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_10, slice_89], -1);  neg_10 = slice_89 = None
            mul_70: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_32, unsqueeze_83);  cat_32 = None
            add_20: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_69, mul_70);  mul_69 = mul_70 = None
            mul_71: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_26, unsqueeze_82);  unsqueeze_82 = None
            slice_91: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_26, 3, 0, 32)
            slice_92: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_26, 3, 32, 9223372036854775807);  getitem_26 = None
            neg_11: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_92);  slice_92 = None
            cat_33: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_11, slice_91], -1);  neg_11 = slice_91 = None
            mul_72: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_33, unsqueeze_83);  cat_33 = unsqueeze_83 = None
            add_21: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_71, mul_72);  mul_71 = mul_72 = None
            scaled_dot_product_attention_5: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_20, add_21, getitem_27, masked_fill_1);  add_20 = add_21 = getitem_27 = None
            transpose_33: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_5, 1, 2);  scaled_dot_product_attention_5 = None
            view_11: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_33, [1, -1, 768]);  transpose_33 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_21: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_11, p_encoder_layers_5_attn_wo_weight);  view_11 = p_encoder_layers_5_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_22: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_19, linear_21);  add_19 = linear_21 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_11: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_22, [768], p_encoder_layers_5_mlp_norm_weight);  p_encoder_layers_5_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_22: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_11, p_encoder_layers_5_mlp_wi_weight);  layer_norm_11 = p_encoder_layers_5_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_5 = torch.ops.aten.split.Tensor(linear_22, 1152, -1);  linear_22 = None
            getitem_28: "f32[1, 97, 1152]" = split_5[0]
            getitem_29: "f32[1, 97, 1152]" = split_5[1];  split_5 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_5: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_28);  getitem_28 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_73: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_5, getitem_29);  gelu_5 = getitem_29 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_7: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_73);  mul_73 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_23: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_7, p_encoder_layers_5_mlp_wo_weight);  clone_7 = p_encoder_layers_5_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_23: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_22, linear_23);  add_22 = linear_23 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_12: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_23, [768], p_encoder_layers_6_attn_norm_weight);  p_encoder_layers_6_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_24: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_12, p_encoder_layers_6_attn_wqkv_weight);  layer_norm_12 = p_encoder_layers_6_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_12: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_24, [1, -1, 3, 12, 64]);  linear_24 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_34: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_12, 3, 1);  view_12 = None
            unbind_6 = torch.ops.aten.unbind.int(transpose_34, 2);  transpose_34 = None
            getitem_30: "f32[1, 12, 97, 64]" = unbind_6[0]
            getitem_31: "f32[1, 12, 97, 64]" = unbind_6[1]
            getitem_32: "f32[1, 12, 97, 64]" = unbind_6[2];  unbind_6 = None
            unsqueeze_84: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_85: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_74: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_30, unsqueeze_84)
            slice_93: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_30, 3, 0, 32)
            slice_94: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_30, 3, 32, 9223372036854775807);  getitem_30 = None
            neg_12: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_94);  slice_94 = None
            cat_34: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_12, slice_93], -1);  neg_12 = slice_93 = None
            mul_75: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_34, unsqueeze_85);  cat_34 = None
            add_24: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_74, mul_75);  mul_74 = mul_75 = None
            mul_76: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_31, unsqueeze_84);  unsqueeze_84 = None
            slice_95: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_31, 3, 0, 32)
            slice_96: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_31, 3, 32, 9223372036854775807);  getitem_31 = None
            neg_13: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_96);  slice_96 = None
            cat_35: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_13, slice_95], -1);  neg_13 = slice_95 = None
            mul_77: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_35, unsqueeze_85);  cat_35 = unsqueeze_85 = None
            add_25: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_76, mul_77);  mul_76 = mul_77 = None
            scaled_dot_product_attention_6: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_24, add_25, getitem_32, masked_fill);  add_24 = add_25 = getitem_32 = None
            transpose_35: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_6, 1, 2);  scaled_dot_product_attention_6 = None
            view_13: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_35, [1, -1, 768]);  transpose_35 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_25: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_13, p_encoder_layers_6_attn_wo_weight);  view_13 = p_encoder_layers_6_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_26: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_23, linear_25);  add_23 = linear_25 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_13: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_26, [768], p_encoder_layers_6_mlp_norm_weight);  p_encoder_layers_6_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_26: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_13, p_encoder_layers_6_mlp_wi_weight);  layer_norm_13 = p_encoder_layers_6_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_6 = torch.ops.aten.split.Tensor(linear_26, 1152, -1);  linear_26 = None
            getitem_33: "f32[1, 97, 1152]" = split_6[0]
            getitem_34: "f32[1, 97, 1152]" = split_6[1];  split_6 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_6: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_33);  getitem_33 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_78: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_6, getitem_34);  gelu_6 = getitem_34 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_8: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_78);  mul_78 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_27: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_8, p_encoder_layers_6_mlp_wo_weight);  clone_8 = p_encoder_layers_6_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_27: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_26, linear_27);  add_26 = linear_27 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_14: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_27, [768], p_encoder_layers_7_attn_norm_weight);  p_encoder_layers_7_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_28: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_14, p_encoder_layers_7_attn_wqkv_weight);  layer_norm_14 = p_encoder_layers_7_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_14: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_28, [1, -1, 3, 12, 64]);  linear_28 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_36: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_14, 3, 1);  view_14 = None
            unbind_7 = torch.ops.aten.unbind.int(transpose_36, 2);  transpose_36 = None
            getitem_35: "f32[1, 12, 97, 64]" = unbind_7[0]
            getitem_36: "f32[1, 12, 97, 64]" = unbind_7[1]
            getitem_37: "f32[1, 12, 97, 64]" = unbind_7[2];  unbind_7 = None
            unsqueeze_86: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_87: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_79: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_35, unsqueeze_86)
            slice_97: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_35, 3, 0, 32)
            slice_98: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_35, 3, 32, 9223372036854775807);  getitem_35 = None
            neg_14: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_98);  slice_98 = None
            cat_36: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_14, slice_97], -1);  neg_14 = slice_97 = None
            mul_80: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_36, unsqueeze_87);  cat_36 = None
            add_28: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_79, mul_80);  mul_79 = mul_80 = None
            mul_81: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_36, unsqueeze_86);  unsqueeze_86 = None
            slice_99: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_36, 3, 0, 32)
            slice_100: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_36, 3, 32, 9223372036854775807);  getitem_36 = None
            neg_15: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_100);  slice_100 = None
            cat_37: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_15, slice_99], -1);  neg_15 = slice_99 = None
            mul_82: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_37, unsqueeze_87);  cat_37 = unsqueeze_87 = None
            add_29: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_81, mul_82);  mul_81 = mul_82 = None
            scaled_dot_product_attention_7: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_28, add_29, getitem_37, masked_fill_1);  add_28 = add_29 = getitem_37 = None
            transpose_37: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_7, 1, 2);  scaled_dot_product_attention_7 = None
            view_15: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_37, [1, -1, 768]);  transpose_37 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_29: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_15, p_encoder_layers_7_attn_wo_weight);  view_15 = p_encoder_layers_7_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_30: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_27, linear_29);  add_27 = linear_29 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_15: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_30, [768], p_encoder_layers_7_mlp_norm_weight);  p_encoder_layers_7_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_30: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_15, p_encoder_layers_7_mlp_wi_weight);  layer_norm_15 = p_encoder_layers_7_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_7 = torch.ops.aten.split.Tensor(linear_30, 1152, -1);  linear_30 = None
            getitem_38: "f32[1, 97, 1152]" = split_7[0]
            getitem_39: "f32[1, 97, 1152]" = split_7[1];  split_7 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_7: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_38);  getitem_38 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_83: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_7, getitem_39);  gelu_7 = getitem_39 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_9: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_83);  mul_83 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_31: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_9, p_encoder_layers_7_mlp_wo_weight);  clone_9 = p_encoder_layers_7_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_31: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_30, linear_31);  add_30 = linear_31 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_16: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_31, [768], p_encoder_layers_8_attn_norm_weight);  p_encoder_layers_8_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_32: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_16, p_encoder_layers_8_attn_wqkv_weight);  layer_norm_16 = p_encoder_layers_8_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_16: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_32, [1, -1, 3, 12, 64]);  linear_32 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_38: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_16, 3, 1);  view_16 = None
            unbind_8 = torch.ops.aten.unbind.int(transpose_38, 2);  transpose_38 = None
            getitem_40: "f32[1, 12, 97, 64]" = unbind_8[0]
            getitem_41: "f32[1, 12, 97, 64]" = unbind_8[1]
            getitem_42: "f32[1, 12, 97, 64]" = unbind_8[2];  unbind_8 = None
            unsqueeze_88: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_89: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_84: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_40, unsqueeze_88)
            slice_101: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_40, 3, 0, 32)
            slice_102: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_40, 3, 32, 9223372036854775807);  getitem_40 = None
            neg_16: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_102);  slice_102 = None
            cat_38: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_16, slice_101], -1);  neg_16 = slice_101 = None
            mul_85: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_38, unsqueeze_89);  cat_38 = None
            add_32: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_84, mul_85);  mul_84 = mul_85 = None
            mul_86: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_41, unsqueeze_88);  unsqueeze_88 = None
            slice_103: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_41, 3, 0, 32)
            slice_104: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_41, 3, 32, 9223372036854775807);  getitem_41 = None
            neg_17: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_104);  slice_104 = None
            cat_39: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_17, slice_103], -1);  neg_17 = slice_103 = None
            mul_87: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_39, unsqueeze_89);  cat_39 = unsqueeze_89 = None
            add_33: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_86, mul_87);  mul_86 = mul_87 = None
            scaled_dot_product_attention_8: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_32, add_33, getitem_42, masked_fill_1);  add_32 = add_33 = getitem_42 = None
            transpose_39: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_8, 1, 2);  scaled_dot_product_attention_8 = None
            view_17: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_39, [1, -1, 768]);  transpose_39 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_33: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_17, p_encoder_layers_8_attn_wo_weight);  view_17 = p_encoder_layers_8_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_34: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_31, linear_33);  add_31 = linear_33 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_17: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_34, [768], p_encoder_layers_8_mlp_norm_weight);  p_encoder_layers_8_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_34: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_17, p_encoder_layers_8_mlp_wi_weight);  layer_norm_17 = p_encoder_layers_8_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_8 = torch.ops.aten.split.Tensor(linear_34, 1152, -1);  linear_34 = None
            getitem_43: "f32[1, 97, 1152]" = split_8[0]
            getitem_44: "f32[1, 97, 1152]" = split_8[1];  split_8 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_8: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_43);  getitem_43 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_88: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_8, getitem_44);  gelu_8 = getitem_44 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_10: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_88);  mul_88 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_35: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_10, p_encoder_layers_8_mlp_wo_weight);  clone_10 = p_encoder_layers_8_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_35: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_34, linear_35);  add_34 = linear_35 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_18: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_35, [768], p_encoder_layers_9_attn_norm_weight);  p_encoder_layers_9_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_36: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_18, p_encoder_layers_9_attn_wqkv_weight);  layer_norm_18 = p_encoder_layers_9_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_18: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_36, [1, -1, 3, 12, 64]);  linear_36 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_40: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_18, 3, 1);  view_18 = None
            unbind_9 = torch.ops.aten.unbind.int(transpose_40, 2);  transpose_40 = None
            getitem_45: "f32[1, 12, 97, 64]" = unbind_9[0]
            getitem_46: "f32[1, 12, 97, 64]" = unbind_9[1]
            getitem_47: "f32[1, 12, 97, 64]" = unbind_9[2];  unbind_9 = None
            unsqueeze_90: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_91: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_89: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_45, unsqueeze_90)
            slice_105: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_45, 3, 0, 32)
            slice_106: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_45, 3, 32, 9223372036854775807);  getitem_45 = None
            neg_18: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_106);  slice_106 = None
            cat_40: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_18, slice_105], -1);  neg_18 = slice_105 = None
            mul_90: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_40, unsqueeze_91);  cat_40 = None
            add_36: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_89, mul_90);  mul_89 = mul_90 = None
            mul_91: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_46, unsqueeze_90);  unsqueeze_90 = None
            slice_107: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_46, 3, 0, 32)
            slice_108: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_46, 3, 32, 9223372036854775807);  getitem_46 = None
            neg_19: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_108);  slice_108 = None
            cat_41: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_19, slice_107], -1);  neg_19 = slice_107 = None
            mul_92: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_41, unsqueeze_91);  cat_41 = unsqueeze_91 = None
            add_37: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_91, mul_92);  mul_91 = mul_92 = None
            scaled_dot_product_attention_9: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_36, add_37, getitem_47, masked_fill);  add_36 = add_37 = getitem_47 = None
            transpose_41: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_9, 1, 2);  scaled_dot_product_attention_9 = None
            view_19: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_41, [1, -1, 768]);  transpose_41 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_37: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_19, p_encoder_layers_9_attn_wo_weight);  view_19 = p_encoder_layers_9_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_38: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_35, linear_37);  add_35 = linear_37 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_19: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_38, [768], p_encoder_layers_9_mlp_norm_weight);  p_encoder_layers_9_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_38: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_19, p_encoder_layers_9_mlp_wi_weight);  layer_norm_19 = p_encoder_layers_9_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_9 = torch.ops.aten.split.Tensor(linear_38, 1152, -1);  linear_38 = None
            getitem_48: "f32[1, 97, 1152]" = split_9[0]
            getitem_49: "f32[1, 97, 1152]" = split_9[1];  split_9 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_9: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_48);  getitem_48 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_93: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_9, getitem_49);  gelu_9 = getitem_49 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_11: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_93);  mul_93 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_39: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_11, p_encoder_layers_9_mlp_wo_weight);  clone_11 = p_encoder_layers_9_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_39: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_38, linear_39);  add_38 = linear_39 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_20: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_39, [768], p_encoder_layers_10_attn_norm_weight);  p_encoder_layers_10_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_40: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_20, p_encoder_layers_10_attn_wqkv_weight);  layer_norm_20 = p_encoder_layers_10_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_20: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_40, [1, -1, 3, 12, 64]);  linear_40 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_42: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_20, 3, 1);  view_20 = None
            unbind_10 = torch.ops.aten.unbind.int(transpose_42, 2);  transpose_42 = None
            getitem_50: "f32[1, 12, 97, 64]" = unbind_10[0]
            getitem_51: "f32[1, 12, 97, 64]" = unbind_10[1]
            getitem_52: "f32[1, 12, 97, 64]" = unbind_10[2];  unbind_10 = None
            unsqueeze_92: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_93: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_94: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_50, unsqueeze_92)
            slice_109: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_50, 3, 0, 32)
            slice_110: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_50, 3, 32, 9223372036854775807);  getitem_50 = None
            neg_20: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_110);  slice_110 = None
            cat_42: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_20, slice_109], -1);  neg_20 = slice_109 = None
            mul_95: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_42, unsqueeze_93);  cat_42 = None
            add_40: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_94, mul_95);  mul_94 = mul_95 = None
            mul_96: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_51, unsqueeze_92);  unsqueeze_92 = None
            slice_111: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_51, 3, 0, 32)
            slice_112: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_51, 3, 32, 9223372036854775807);  getitem_51 = None
            neg_21: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_112);  slice_112 = None
            cat_43: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_21, slice_111], -1);  neg_21 = slice_111 = None
            mul_97: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_43, unsqueeze_93);  cat_43 = unsqueeze_93 = None
            add_41: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_96, mul_97);  mul_96 = mul_97 = None
            scaled_dot_product_attention_10: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_40, add_41, getitem_52, masked_fill_1);  add_40 = add_41 = getitem_52 = None
            transpose_43: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_10, 1, 2);  scaled_dot_product_attention_10 = None
            view_21: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_43, [1, -1, 768]);  transpose_43 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_41: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_21, p_encoder_layers_10_attn_wo_weight);  view_21 = p_encoder_layers_10_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_42: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_39, linear_41);  add_39 = linear_41 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_21: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_42, [768], p_encoder_layers_10_mlp_norm_weight);  p_encoder_layers_10_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_42: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_21, p_encoder_layers_10_mlp_wi_weight);  layer_norm_21 = p_encoder_layers_10_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_10 = torch.ops.aten.split.Tensor(linear_42, 1152, -1);  linear_42 = None
            getitem_53: "f32[1, 97, 1152]" = split_10[0]
            getitem_54: "f32[1, 97, 1152]" = split_10[1];  split_10 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_10: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_53);  getitem_53 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_98: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_10, getitem_54);  gelu_10 = getitem_54 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_12: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_98);  mul_98 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_43: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_12, p_encoder_layers_10_mlp_wo_weight);  clone_12 = p_encoder_layers_10_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_43: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_42, linear_43);  add_42 = linear_43 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_22: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_43, [768], p_encoder_layers_11_attn_norm_weight);  p_encoder_layers_11_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_44: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_22, p_encoder_layers_11_attn_wqkv_weight);  layer_norm_22 = p_encoder_layers_11_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_22: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_44, [1, -1, 3, 12, 64]);  linear_44 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_44: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_22, 3, 1);  view_22 = None
            unbind_11 = torch.ops.aten.unbind.int(transpose_44, 2);  transpose_44 = None
            getitem_55: "f32[1, 12, 97, 64]" = unbind_11[0]
            getitem_56: "f32[1, 12, 97, 64]" = unbind_11[1]
            getitem_57: "f32[1, 12, 97, 64]" = unbind_11[2];  unbind_11 = None
            unsqueeze_94: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_95: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_99: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_55, unsqueeze_94)
            slice_113: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_55, 3, 0, 32)
            slice_114: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_55, 3, 32, 9223372036854775807);  getitem_55 = None
            neg_22: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_114);  slice_114 = None
            cat_44: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_22, slice_113], -1);  neg_22 = slice_113 = None
            mul_100: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_44, unsqueeze_95);  cat_44 = None
            add_44: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_99, mul_100);  mul_99 = mul_100 = None
            mul_101: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_56, unsqueeze_94);  unsqueeze_94 = None
            slice_115: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_56, 3, 0, 32)
            slice_116: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_56, 3, 32, 9223372036854775807);  getitem_56 = None
            neg_23: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_116);  slice_116 = None
            cat_45: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_23, slice_115], -1);  neg_23 = slice_115 = None
            mul_102: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_45, unsqueeze_95);  cat_45 = unsqueeze_95 = None
            add_45: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_101, mul_102);  mul_101 = mul_102 = None
            scaled_dot_product_attention_11: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_44, add_45, getitem_57, masked_fill_1);  add_44 = add_45 = getitem_57 = None
            transpose_45: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_11, 1, 2);  scaled_dot_product_attention_11 = None
            view_23: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_45, [1, -1, 768]);  transpose_45 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_45: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_23, p_encoder_layers_11_attn_wo_weight);  view_23 = p_encoder_layers_11_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_46: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_43, linear_45);  add_43 = linear_45 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_23: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_46, [768], p_encoder_layers_11_mlp_norm_weight);  p_encoder_layers_11_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_46: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_23, p_encoder_layers_11_mlp_wi_weight);  layer_norm_23 = p_encoder_layers_11_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_11 = torch.ops.aten.split.Tensor(linear_46, 1152, -1);  linear_46 = None
            getitem_58: "f32[1, 97, 1152]" = split_11[0]
            getitem_59: "f32[1, 97, 1152]" = split_11[1];  split_11 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_11: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_58);  getitem_58 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_103: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_11, getitem_59);  gelu_11 = getitem_59 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_13: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_103);  mul_103 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_47: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_13, p_encoder_layers_11_mlp_wo_weight);  clone_13 = p_encoder_layers_11_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_47: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_46, linear_47);  add_46 = linear_47 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_24: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_47, [768], p_encoder_layers_12_attn_norm_weight);  p_encoder_layers_12_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_48: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_24, p_encoder_layers_12_attn_wqkv_weight);  layer_norm_24 = p_encoder_layers_12_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_24: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_48, [1, -1, 3, 12, 64]);  linear_48 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_46: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_24, 3, 1);  view_24 = None
            unbind_12 = torch.ops.aten.unbind.int(transpose_46, 2);  transpose_46 = None
            getitem_60: "f32[1, 12, 97, 64]" = unbind_12[0]
            getitem_61: "f32[1, 12, 97, 64]" = unbind_12[1]
            getitem_62: "f32[1, 12, 97, 64]" = unbind_12[2];  unbind_12 = None
            unsqueeze_96: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_97: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_104: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_60, unsqueeze_96)
            slice_117: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_60, 3, 0, 32)
            slice_118: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_60, 3, 32, 9223372036854775807);  getitem_60 = None
            neg_24: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_118);  slice_118 = None
            cat_46: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_24, slice_117], -1);  neg_24 = slice_117 = None
            mul_105: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_46, unsqueeze_97);  cat_46 = None
            add_48: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_104, mul_105);  mul_104 = mul_105 = None
            mul_106: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_61, unsqueeze_96);  unsqueeze_96 = None
            slice_119: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_61, 3, 0, 32)
            slice_120: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_61, 3, 32, 9223372036854775807);  getitem_61 = None
            neg_25: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_120);  slice_120 = None
            cat_47: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_25, slice_119], -1);  neg_25 = slice_119 = None
            mul_107: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_47, unsqueeze_97);  cat_47 = unsqueeze_97 = None
            add_49: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_106, mul_107);  mul_106 = mul_107 = None
            scaled_dot_product_attention_12: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_48, add_49, getitem_62, masked_fill);  add_48 = add_49 = getitem_62 = None
            transpose_47: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_12, 1, 2);  scaled_dot_product_attention_12 = None
            view_25: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_47, [1, -1, 768]);  transpose_47 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_49: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_25, p_encoder_layers_12_attn_wo_weight);  view_25 = p_encoder_layers_12_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_50: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_47, linear_49);  add_47 = linear_49 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_25: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_50, [768], p_encoder_layers_12_mlp_norm_weight);  p_encoder_layers_12_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_50: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_25, p_encoder_layers_12_mlp_wi_weight);  layer_norm_25 = p_encoder_layers_12_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_12 = torch.ops.aten.split.Tensor(linear_50, 1152, -1);  linear_50 = None
            getitem_63: "f32[1, 97, 1152]" = split_12[0]
            getitem_64: "f32[1, 97, 1152]" = split_12[1];  split_12 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_12: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_63);  getitem_63 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_108: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_12, getitem_64);  gelu_12 = getitem_64 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_14: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_108);  mul_108 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_51: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_14, p_encoder_layers_12_mlp_wo_weight);  clone_14 = p_encoder_layers_12_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_51: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_50, linear_51);  add_50 = linear_51 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_26: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_51, [768], p_encoder_layers_13_attn_norm_weight);  p_encoder_layers_13_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_52: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_26, p_encoder_layers_13_attn_wqkv_weight);  layer_norm_26 = p_encoder_layers_13_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_26: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_52, [1, -1, 3, 12, 64]);  linear_52 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_48: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_26, 3, 1);  view_26 = None
            unbind_13 = torch.ops.aten.unbind.int(transpose_48, 2);  transpose_48 = None
            getitem_65: "f32[1, 12, 97, 64]" = unbind_13[0]
            getitem_66: "f32[1, 12, 97, 64]" = unbind_13[1]
            getitem_67: "f32[1, 12, 97, 64]" = unbind_13[2];  unbind_13 = None
            unsqueeze_98: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_99: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_109: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_65, unsqueeze_98)
            slice_121: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_65, 3, 0, 32)
            slice_122: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_65, 3, 32, 9223372036854775807);  getitem_65 = None
            neg_26: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_122);  slice_122 = None
            cat_48: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_26, slice_121], -1);  neg_26 = slice_121 = None
            mul_110: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_48, unsqueeze_99);  cat_48 = None
            add_52: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_109, mul_110);  mul_109 = mul_110 = None
            mul_111: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_66, unsqueeze_98);  unsqueeze_98 = None
            slice_123: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_66, 3, 0, 32)
            slice_124: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_66, 3, 32, 9223372036854775807);  getitem_66 = None
            neg_27: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_124);  slice_124 = None
            cat_49: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_27, slice_123], -1);  neg_27 = slice_123 = None
            mul_112: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_49, unsqueeze_99);  cat_49 = unsqueeze_99 = None
            add_53: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_111, mul_112);  mul_111 = mul_112 = None
            scaled_dot_product_attention_13: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_52, add_53, getitem_67, masked_fill_1);  add_52 = add_53 = getitem_67 = None
            transpose_49: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_13, 1, 2);  scaled_dot_product_attention_13 = None
            view_27: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_49, [1, -1, 768]);  transpose_49 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_53: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_27, p_encoder_layers_13_attn_wo_weight);  view_27 = p_encoder_layers_13_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_54: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_51, linear_53);  add_51 = linear_53 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_27: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_54, [768], p_encoder_layers_13_mlp_norm_weight);  p_encoder_layers_13_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_54: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_27, p_encoder_layers_13_mlp_wi_weight);  layer_norm_27 = p_encoder_layers_13_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_13 = torch.ops.aten.split.Tensor(linear_54, 1152, -1);  linear_54 = None
            getitem_68: "f32[1, 97, 1152]" = split_13[0]
            getitem_69: "f32[1, 97, 1152]" = split_13[1];  split_13 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_13: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_68);  getitem_68 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_113: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_13, getitem_69);  gelu_13 = getitem_69 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_15: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_113);  mul_113 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_55: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_15, p_encoder_layers_13_mlp_wo_weight);  clone_15 = p_encoder_layers_13_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_55: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_54, linear_55);  add_54 = linear_55 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_28: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_55, [768], p_encoder_layers_14_attn_norm_weight);  p_encoder_layers_14_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_56: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_28, p_encoder_layers_14_attn_wqkv_weight);  layer_norm_28 = p_encoder_layers_14_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_28: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_56, [1, -1, 3, 12, 64]);  linear_56 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_50: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_28, 3, 1);  view_28 = None
            unbind_14 = torch.ops.aten.unbind.int(transpose_50, 2);  transpose_50 = None
            getitem_70: "f32[1, 12, 97, 64]" = unbind_14[0]
            getitem_71: "f32[1, 12, 97, 64]" = unbind_14[1]
            getitem_72: "f32[1, 12, 97, 64]" = unbind_14[2];  unbind_14 = None
            unsqueeze_100: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_101: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_114: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_70, unsqueeze_100)
            slice_125: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_70, 3, 0, 32)
            slice_126: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_70, 3, 32, 9223372036854775807);  getitem_70 = None
            neg_28: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_126);  slice_126 = None
            cat_50: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_28, slice_125], -1);  neg_28 = slice_125 = None
            mul_115: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_50, unsqueeze_101);  cat_50 = None
            add_56: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_114, mul_115);  mul_114 = mul_115 = None
            mul_116: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_71, unsqueeze_100);  unsqueeze_100 = None
            slice_127: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_71, 3, 0, 32)
            slice_128: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_71, 3, 32, 9223372036854775807);  getitem_71 = None
            neg_29: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_128);  slice_128 = None
            cat_51: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_29, slice_127], -1);  neg_29 = slice_127 = None
            mul_117: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_51, unsqueeze_101);  cat_51 = unsqueeze_101 = None
            add_57: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_116, mul_117);  mul_116 = mul_117 = None
            scaled_dot_product_attention_14: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_56, add_57, getitem_72, masked_fill_1);  add_56 = add_57 = getitem_72 = None
            transpose_51: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_14, 1, 2);  scaled_dot_product_attention_14 = None
            view_29: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_51, [1, -1, 768]);  transpose_51 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_57: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_29, p_encoder_layers_14_attn_wo_weight);  view_29 = p_encoder_layers_14_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_58: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_55, linear_57);  add_55 = linear_57 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_29: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_58, [768], p_encoder_layers_14_mlp_norm_weight);  p_encoder_layers_14_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_58: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_29, p_encoder_layers_14_mlp_wi_weight);  layer_norm_29 = p_encoder_layers_14_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_14 = torch.ops.aten.split.Tensor(linear_58, 1152, -1);  linear_58 = None
            getitem_73: "f32[1, 97, 1152]" = split_14[0]
            getitem_74: "f32[1, 97, 1152]" = split_14[1];  split_14 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_14: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_73);  getitem_73 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_118: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_14, getitem_74);  gelu_14 = getitem_74 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_16: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_118);  mul_118 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_59: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_16, p_encoder_layers_14_mlp_wo_weight);  clone_16 = p_encoder_layers_14_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_59: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_58, linear_59);  add_58 = linear_59 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_30: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_59, [768], p_encoder_layers_15_attn_norm_weight);  p_encoder_layers_15_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_60: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_30, p_encoder_layers_15_attn_wqkv_weight);  layer_norm_30 = p_encoder_layers_15_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_30: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_60, [1, -1, 3, 12, 64]);  linear_60 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_52: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_30, 3, 1);  view_30 = None
            unbind_15 = torch.ops.aten.unbind.int(transpose_52, 2);  transpose_52 = None
            getitem_75: "f32[1, 12, 97, 64]" = unbind_15[0]
            getitem_76: "f32[1, 12, 97, 64]" = unbind_15[1]
            getitem_77: "f32[1, 12, 97, 64]" = unbind_15[2];  unbind_15 = None
            unsqueeze_102: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_103: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_119: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_75, unsqueeze_102)
            slice_129: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_75, 3, 0, 32)
            slice_130: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_75, 3, 32, 9223372036854775807);  getitem_75 = None
            neg_30: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_130);  slice_130 = None
            cat_52: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_30, slice_129], -1);  neg_30 = slice_129 = None
            mul_120: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_52, unsqueeze_103);  cat_52 = None
            add_60: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_119, mul_120);  mul_119 = mul_120 = None
            mul_121: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_76, unsqueeze_102);  unsqueeze_102 = None
            slice_131: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_76, 3, 0, 32)
            slice_132: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_76, 3, 32, 9223372036854775807);  getitem_76 = None
            neg_31: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_132);  slice_132 = None
            cat_53: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_31, slice_131], -1);  neg_31 = slice_131 = None
            mul_122: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_53, unsqueeze_103);  cat_53 = unsqueeze_103 = None
            add_61: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_121, mul_122);  mul_121 = mul_122 = None
            scaled_dot_product_attention_15: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_60, add_61, getitem_77, masked_fill);  add_60 = add_61 = getitem_77 = None
            transpose_53: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_15, 1, 2);  scaled_dot_product_attention_15 = None
            view_31: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_53, [1, -1, 768]);  transpose_53 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_61: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_31, p_encoder_layers_15_attn_wo_weight);  view_31 = p_encoder_layers_15_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_62: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_59, linear_61);  add_59 = linear_61 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_31: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_62, [768], p_encoder_layers_15_mlp_norm_weight);  p_encoder_layers_15_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_62: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_31, p_encoder_layers_15_mlp_wi_weight);  layer_norm_31 = p_encoder_layers_15_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_15 = torch.ops.aten.split.Tensor(linear_62, 1152, -1);  linear_62 = None
            getitem_78: "f32[1, 97, 1152]" = split_15[0]
            getitem_79: "f32[1, 97, 1152]" = split_15[1];  split_15 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_15: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_78);  getitem_78 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_123: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_15, getitem_79);  gelu_15 = getitem_79 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_17: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_123);  mul_123 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_63: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_17, p_encoder_layers_15_mlp_wo_weight);  clone_17 = p_encoder_layers_15_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_63: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_62, linear_63);  add_62 = linear_63 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_32: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_63, [768], p_encoder_layers_16_attn_norm_weight);  p_encoder_layers_16_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_64: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_32, p_encoder_layers_16_attn_wqkv_weight);  layer_norm_32 = p_encoder_layers_16_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_32: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_64, [1, -1, 3, 12, 64]);  linear_64 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_54: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_32, 3, 1);  view_32 = None
            unbind_16 = torch.ops.aten.unbind.int(transpose_54, 2);  transpose_54 = None
            getitem_80: "f32[1, 12, 97, 64]" = unbind_16[0]
            getitem_81: "f32[1, 12, 97, 64]" = unbind_16[1]
            getitem_82: "f32[1, 12, 97, 64]" = unbind_16[2];  unbind_16 = None
            unsqueeze_104: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_105: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_124: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_80, unsqueeze_104)
            slice_133: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_80, 3, 0, 32)
            slice_134: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_80, 3, 32, 9223372036854775807);  getitem_80 = None
            neg_32: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_134);  slice_134 = None
            cat_54: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_32, slice_133], -1);  neg_32 = slice_133 = None
            mul_125: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_54, unsqueeze_105);  cat_54 = None
            add_64: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_124, mul_125);  mul_124 = mul_125 = None
            mul_126: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_81, unsqueeze_104);  unsqueeze_104 = None
            slice_135: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_81, 3, 0, 32)
            slice_136: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_81, 3, 32, 9223372036854775807);  getitem_81 = None
            neg_33: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_136);  slice_136 = None
            cat_55: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_33, slice_135], -1);  neg_33 = slice_135 = None
            mul_127: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_55, unsqueeze_105);  cat_55 = unsqueeze_105 = None
            add_65: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_126, mul_127);  mul_126 = mul_127 = None
            scaled_dot_product_attention_16: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_64, add_65, getitem_82, masked_fill_1);  add_64 = add_65 = getitem_82 = None
            transpose_55: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_16, 1, 2);  scaled_dot_product_attention_16 = None
            view_33: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_55, [1, -1, 768]);  transpose_55 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_65: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_33, p_encoder_layers_16_attn_wo_weight);  view_33 = p_encoder_layers_16_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_66: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_63, linear_65);  add_63 = linear_65 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_33: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_66, [768], p_encoder_layers_16_mlp_norm_weight);  p_encoder_layers_16_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_66: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_33, p_encoder_layers_16_mlp_wi_weight);  layer_norm_33 = p_encoder_layers_16_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_16 = torch.ops.aten.split.Tensor(linear_66, 1152, -1);  linear_66 = None
            getitem_83: "f32[1, 97, 1152]" = split_16[0]
            getitem_84: "f32[1, 97, 1152]" = split_16[1];  split_16 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_16: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_83);  getitem_83 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_128: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_16, getitem_84);  gelu_16 = getitem_84 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_18: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_128);  mul_128 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_67: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_18, p_encoder_layers_16_mlp_wo_weight);  clone_18 = p_encoder_layers_16_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_67: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_66, linear_67);  add_66 = linear_67 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_34: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_67, [768], p_encoder_layers_17_attn_norm_weight);  p_encoder_layers_17_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_68: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_34, p_encoder_layers_17_attn_wqkv_weight);  layer_norm_34 = p_encoder_layers_17_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_34: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_68, [1, -1, 3, 12, 64]);  linear_68 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_56: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_34, 3, 1);  view_34 = None
            unbind_17 = torch.ops.aten.unbind.int(transpose_56, 2);  transpose_56 = None
            getitem_85: "f32[1, 12, 97, 64]" = unbind_17[0]
            getitem_86: "f32[1, 12, 97, 64]" = unbind_17[1]
            getitem_87: "f32[1, 12, 97, 64]" = unbind_17[2];  unbind_17 = None
            unsqueeze_106: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_107: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_129: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_85, unsqueeze_106)
            slice_137: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_85, 3, 0, 32)
            slice_138: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_85, 3, 32, 9223372036854775807);  getitem_85 = None
            neg_34: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_138);  slice_138 = None
            cat_56: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_34, slice_137], -1);  neg_34 = slice_137 = None
            mul_130: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_56, unsqueeze_107);  cat_56 = None
            add_68: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_129, mul_130);  mul_129 = mul_130 = None
            mul_131: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_86, unsqueeze_106);  unsqueeze_106 = None
            slice_139: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_86, 3, 0, 32)
            slice_140: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_86, 3, 32, 9223372036854775807);  getitem_86 = None
            neg_35: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_140);  slice_140 = None
            cat_57: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_35, slice_139], -1);  neg_35 = slice_139 = None
            mul_132: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_57, unsqueeze_107);  cat_57 = unsqueeze_107 = None
            add_69: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_131, mul_132);  mul_131 = mul_132 = None
            scaled_dot_product_attention_17: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_68, add_69, getitem_87, masked_fill_1);  add_68 = add_69 = getitem_87 = None
            transpose_57: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_17, 1, 2);  scaled_dot_product_attention_17 = None
            view_35: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_57, [1, -1, 768]);  transpose_57 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_69: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_35, p_encoder_layers_17_attn_wo_weight);  view_35 = p_encoder_layers_17_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_70: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_67, linear_69);  add_67 = linear_69 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_35: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_70, [768], p_encoder_layers_17_mlp_norm_weight);  p_encoder_layers_17_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_70: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_35, p_encoder_layers_17_mlp_wi_weight);  layer_norm_35 = p_encoder_layers_17_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_17 = torch.ops.aten.split.Tensor(linear_70, 1152, -1);  linear_70 = None
            getitem_88: "f32[1, 97, 1152]" = split_17[0]
            getitem_89: "f32[1, 97, 1152]" = split_17[1];  split_17 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_17: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_88);  getitem_88 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_133: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_17, getitem_89);  gelu_17 = getitem_89 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_19: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_133);  mul_133 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_71: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_19, p_encoder_layers_17_mlp_wo_weight);  clone_19 = p_encoder_layers_17_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_71: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_70, linear_71);  add_70 = linear_71 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_36: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_71, [768], p_encoder_layers_18_attn_norm_weight);  p_encoder_layers_18_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_72: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_36, p_encoder_layers_18_attn_wqkv_weight);  layer_norm_36 = p_encoder_layers_18_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_36: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_72, [1, -1, 3, 12, 64]);  linear_72 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_58: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_36, 3, 1);  view_36 = None
            unbind_18 = torch.ops.aten.unbind.int(transpose_58, 2);  transpose_58 = None
            getitem_90: "f32[1, 12, 97, 64]" = unbind_18[0]
            getitem_91: "f32[1, 12, 97, 64]" = unbind_18[1]
            getitem_92: "f32[1, 12, 97, 64]" = unbind_18[2];  unbind_18 = None
            unsqueeze_108: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_109: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_134: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_90, unsqueeze_108)
            slice_141: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_90, 3, 0, 32)
            slice_142: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_90, 3, 32, 9223372036854775807);  getitem_90 = None
            neg_36: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_142);  slice_142 = None
            cat_58: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_36, slice_141], -1);  neg_36 = slice_141 = None
            mul_135: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_58, unsqueeze_109);  cat_58 = None
            add_72: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_134, mul_135);  mul_134 = mul_135 = None
            mul_136: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_91, unsqueeze_108);  unsqueeze_108 = None
            slice_143: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_91, 3, 0, 32)
            slice_144: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_91, 3, 32, 9223372036854775807);  getitem_91 = None
            neg_37: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_144);  slice_144 = None
            cat_59: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_37, slice_143], -1);  neg_37 = slice_143 = None
            mul_137: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_59, unsqueeze_109);  cat_59 = unsqueeze_109 = None
            add_73: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_136, mul_137);  mul_136 = mul_137 = None
            scaled_dot_product_attention_18: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_72, add_73, getitem_92, masked_fill);  add_72 = add_73 = getitem_92 = None
            transpose_59: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_18, 1, 2);  scaled_dot_product_attention_18 = None
            view_37: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_59, [1, -1, 768]);  transpose_59 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_73: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_37, p_encoder_layers_18_attn_wo_weight);  view_37 = p_encoder_layers_18_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_74: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_71, linear_73);  add_71 = linear_73 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_37: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_74, [768], p_encoder_layers_18_mlp_norm_weight);  p_encoder_layers_18_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_74: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_37, p_encoder_layers_18_mlp_wi_weight);  layer_norm_37 = p_encoder_layers_18_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_18 = torch.ops.aten.split.Tensor(linear_74, 1152, -1);  linear_74 = None
            getitem_93: "f32[1, 97, 1152]" = split_18[0]
            getitem_94: "f32[1, 97, 1152]" = split_18[1];  split_18 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_18: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_93);  getitem_93 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_138: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_18, getitem_94);  gelu_18 = getitem_94 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_20: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_138);  mul_138 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_75: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_20, p_encoder_layers_18_mlp_wo_weight);  clone_20 = p_encoder_layers_18_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_75: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_74, linear_75);  add_74 = linear_75 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_38: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_75, [768], p_encoder_layers_19_attn_norm_weight);  p_encoder_layers_19_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_76: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_38, p_encoder_layers_19_attn_wqkv_weight);  layer_norm_38 = p_encoder_layers_19_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_38: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_76, [1, -1, 3, 12, 64]);  linear_76 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_60: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_38, 3, 1);  view_38 = None
            unbind_19 = torch.ops.aten.unbind.int(transpose_60, 2);  transpose_60 = None
            getitem_95: "f32[1, 12, 97, 64]" = unbind_19[0]
            getitem_96: "f32[1, 12, 97, 64]" = unbind_19[1]
            getitem_97: "f32[1, 12, 97, 64]" = unbind_19[2];  unbind_19 = None
            unsqueeze_110: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_111: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_139: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_95, unsqueeze_110)
            slice_145: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_95, 3, 0, 32)
            slice_146: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_95, 3, 32, 9223372036854775807);  getitem_95 = None
            neg_38: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_146);  slice_146 = None
            cat_60: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_38, slice_145], -1);  neg_38 = slice_145 = None
            mul_140: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_60, unsqueeze_111);  cat_60 = None
            add_76: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_139, mul_140);  mul_139 = mul_140 = None
            mul_141: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_96, unsqueeze_110);  unsqueeze_110 = None
            slice_147: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_96, 3, 0, 32)
            slice_148: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_96, 3, 32, 9223372036854775807);  getitem_96 = None
            neg_39: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_148);  slice_148 = None
            cat_61: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_39, slice_147], -1);  neg_39 = slice_147 = None
            mul_142: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_61, unsqueeze_111);  cat_61 = unsqueeze_111 = None
            add_77: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_141, mul_142);  mul_141 = mul_142 = None
            scaled_dot_product_attention_19: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_76, add_77, getitem_97, masked_fill_1);  add_76 = add_77 = getitem_97 = None
            transpose_61: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_19, 1, 2);  scaled_dot_product_attention_19 = None
            view_39: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_61, [1, -1, 768]);  transpose_61 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_77: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_39, p_encoder_layers_19_attn_wo_weight);  view_39 = p_encoder_layers_19_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_78: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_75, linear_77);  add_75 = linear_77 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_39: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_78, [768], p_encoder_layers_19_mlp_norm_weight);  p_encoder_layers_19_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_78: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_39, p_encoder_layers_19_mlp_wi_weight);  layer_norm_39 = p_encoder_layers_19_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_19 = torch.ops.aten.split.Tensor(linear_78, 1152, -1);  linear_78 = None
            getitem_98: "f32[1, 97, 1152]" = split_19[0]
            getitem_99: "f32[1, 97, 1152]" = split_19[1];  split_19 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_19: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_98);  getitem_98 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_143: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_19, getitem_99);  gelu_19 = getitem_99 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_21: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_143);  mul_143 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_79: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_21, p_encoder_layers_19_mlp_wo_weight);  clone_21 = p_encoder_layers_19_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_79: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_78, linear_79);  add_78 = linear_79 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_40: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_79, [768], p_encoder_layers_20_attn_norm_weight);  p_encoder_layers_20_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_80: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_40, p_encoder_layers_20_attn_wqkv_weight);  layer_norm_40 = p_encoder_layers_20_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_40: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_80, [1, -1, 3, 12, 64]);  linear_80 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_62: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_40, 3, 1);  view_40 = None
            unbind_20 = torch.ops.aten.unbind.int(transpose_62, 2);  transpose_62 = None
            getitem_100: "f32[1, 12, 97, 64]" = unbind_20[0]
            getitem_101: "f32[1, 12, 97, 64]" = unbind_20[1]
            getitem_102: "f32[1, 12, 97, 64]" = unbind_20[2];  unbind_20 = None
            unsqueeze_112: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1);  mul_40 = None
            unsqueeze_113: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1);  mul_41 = None
            mul_144: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_100, unsqueeze_112)
            slice_149: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_100, 3, 0, 32)
            slice_150: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_100, 3, 32, 9223372036854775807);  getitem_100 = None
            neg_40: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_150);  slice_150 = None
            cat_62: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_40, slice_149], -1);  neg_40 = slice_149 = None
            mul_145: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_62, unsqueeze_113);  cat_62 = None
            add_80: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_144, mul_145);  mul_144 = mul_145 = None
            mul_146: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_101, unsqueeze_112);  unsqueeze_112 = None
            slice_151: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_101, 3, 0, 32)
            slice_152: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_101, 3, 32, 9223372036854775807);  getitem_101 = None
            neg_41: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_152);  slice_152 = None
            cat_63: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_41, slice_151], -1);  neg_41 = slice_151 = None
            mul_147: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_63, unsqueeze_113);  cat_63 = unsqueeze_113 = None
            add_81: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_146, mul_147);  mul_146 = mul_147 = None
            scaled_dot_product_attention_20: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_80, add_81, getitem_102, masked_fill_1);  add_80 = add_81 = getitem_102 = masked_fill_1 = None
            transpose_63: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_20, 1, 2);  scaled_dot_product_attention_20 = None
            view_41: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_63, [1, -1, 768]);  transpose_63 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_81: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_41, p_encoder_layers_20_attn_wo_weight);  view_41 = p_encoder_layers_20_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_82: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_79, linear_81);  add_79 = linear_81 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_41: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_82, [768], p_encoder_layers_20_mlp_norm_weight);  p_encoder_layers_20_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_82: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_41, p_encoder_layers_20_mlp_wi_weight);  layer_norm_41 = p_encoder_layers_20_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_20 = torch.ops.aten.split.Tensor(linear_82, 1152, -1);  linear_82 = None
            getitem_103: "f32[1, 97, 1152]" = split_20[0]
            getitem_104: "f32[1, 97, 1152]" = split_20[1];  split_20 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_20: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_103);  getitem_103 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_148: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_20, getitem_104);  gelu_20 = getitem_104 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_22: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_148);  mul_148 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_83: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_22, p_encoder_layers_20_mlp_wo_weight);  clone_22 = p_encoder_layers_20_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_83: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_82, linear_83);  add_82 = linear_83 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_42: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_83, [768], p_encoder_layers_21_attn_norm_weight);  p_encoder_layers_21_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_84: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_42, p_encoder_layers_21_attn_wqkv_weight);  layer_norm_42 = p_encoder_layers_21_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_42: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_84, [1, -1, 3, 12, 64]);  linear_84 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_64: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_42, 3, 1);  view_42 = None
            unbind_21 = torch.ops.aten.unbind.int(transpose_64, 2);  transpose_64 = None
            getitem_105: "f32[1, 12, 97, 64]" = unbind_21[0]
            getitem_106: "f32[1, 12, 97, 64]" = unbind_21[1]
            getitem_107: "f32[1, 12, 97, 64]" = unbind_21[2];  unbind_21 = None
            unsqueeze_114: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1);  mul_42 = None
            unsqueeze_115: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1);  mul_43 = None
            mul_149: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_105, unsqueeze_114)
            slice_153: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_105, 3, 0, 32)
            slice_154: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_105, 3, 32, 9223372036854775807);  getitem_105 = None
            neg_42: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_154);  slice_154 = None
            cat_64: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_42, slice_153], -1);  neg_42 = slice_153 = None
            mul_150: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_64, unsqueeze_115);  cat_64 = None
            add_84: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_149, mul_150);  mul_149 = mul_150 = None
            mul_151: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_106, unsqueeze_114);  unsqueeze_114 = None
            slice_155: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_106, 3, 0, 32)
            slice_156: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_106, 3, 32, 9223372036854775807);  getitem_106 = None
            neg_43: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_156);  slice_156 = None
            cat_65: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_43, slice_155], -1);  neg_43 = slice_155 = None
            mul_152: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_65, unsqueeze_115);  cat_65 = unsqueeze_115 = None
            add_85: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_151, mul_152);  mul_151 = mul_152 = None
            scaled_dot_product_attention_21: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_84, add_85, getitem_107, masked_fill);  add_84 = add_85 = getitem_107 = masked_fill = None
            transpose_65: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_21, 1, 2);  scaled_dot_product_attention_21 = None
            view_43: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_65, [1, -1, 768]);  transpose_65 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_85: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_43, p_encoder_layers_21_attn_wo_weight);  view_43 = p_encoder_layers_21_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_86: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_83, linear_85);  add_83 = linear_85 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_43: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_86, [768], p_encoder_layers_21_mlp_norm_weight);  p_encoder_layers_21_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_86: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_43, p_encoder_layers_21_mlp_wi_weight);  layer_norm_43 = p_encoder_layers_21_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_21 = torch.ops.aten.split.Tensor(linear_86, 1152, -1);  linear_86 = None
            getitem_108: "f32[1, 97, 1152]" = split_21[0]
            getitem_109: "f32[1, 97, 1152]" = split_21[1];  split_21 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_21: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_108);  getitem_108 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_153: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_21, getitem_109);  gelu_21 = getitem_109 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_23: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_153);  mul_153 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_87: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_23, p_encoder_layers_21_mlp_wo_weight);  clone_23 = p_encoder_layers_21_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_87: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_86, linear_87);  add_86 = linear_87 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_44: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_87, [768], p_encoder_final_norm_weight);  add_87 = p_encoder_final_norm_weight = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/sparse.py:192 in forward, code: return F.embedding(
            embedding_1: "f32[1, 768]" = torch.ops.aten.embedding.default(p_type_emb_weight, qtype);  p_type_emb_weight = qtype = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:109 in forward, code: h = h + self.type_emb(qtype)[:, None, :]
            slice_157: "f32[1, 768]" = torch.ops.aten.slice.Tensor(embedding_1, 0, 0, 9223372036854775807);  embedding_1 = None
            unsqueeze_116: "f32[1, 1, 768]" = torch.ops.aten.unsqueeze.default(slice_157, 1);  slice_157 = None
            slice_158: "f32[1, 1, 768]" = torch.ops.aten.slice.Tensor(unsqueeze_116, 2, 0, 9223372036854775807);  unsqueeze_116 = None
            add_88: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(layer_norm_44, slice_158);  layer_norm_44 = slice_158 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:111 in forward, code: pad = ~attention_mask.bool()
            _to_copy_24: "b8[1, 97]" = torch.ops.aten._to_copy.default(attention_mask, dtype = torch.bool);  attention_mask = None
            bitwise_not: "b8[1, 97]" = torch.ops.aten.bitwise_not.default(_to_copy_24);  _to_copy_24 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:805 in forward, code: src_key_padding_mask = F._canonical_mask(
            zeros_like: "f32[1, 97]" = torch.ops.aten.zeros_like.default(bitwise_not, dtype = torch.float32, pin_memory = False)
            masked_fill_2: "f32[1, 97]" = torch.ops.aten.masked_fill.Scalar(zeros_like, bitwise_not, -inf);  zeros_like = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_45: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_88, [768], p_head_layers_0_norm1_weight, p_head_layers_0_norm1_bias);  p_head_layers_0_norm1_weight = p_head_layers_0_norm1_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1346 in forward, code: query = key = value = query.transpose(1, 0)
            transpose_66: "f32[97, 1, 768]" = torch.ops.aten.transpose.int(layer_norm_45, 1, 0);  layer_norm_45 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1380 in forward, code: attn_output, attn_output_weights = F.multi_head_attention_forward(
            linear_88: "f32[97, 1, 2304]" = torch.ops.aten.linear.default(transpose_66, p_head_layers_0_self_attn_in_proj_weight, p_head_layers_0_self_attn_in_proj_bias);  transpose_66 = p_head_layers_0_self_attn_in_proj_weight = p_head_layers_0_self_attn_in_proj_bias = None
            view_44: "f32[97, 1, 3, 768]" = torch.ops.aten.view.default(linear_88, [97, 1, 3, 768]);  linear_88 = None
            unsqueeze_117: "f32[1, 97, 1, 3, 768]" = torch.ops.aten.unsqueeze.default(view_44, 0);  view_44 = None
            transpose_67: "f32[3, 97, 1, 1, 768]" = torch.ops.aten.transpose.int(unsqueeze_117, 0, -2);  unsqueeze_117 = None
            squeeze: "f32[3, 97, 1, 768]" = torch.ops.aten.squeeze.dim(transpose_67, -2);  transpose_67 = None
            clone_24: "f32[3, 97, 1, 768]" = torch.ops.aten.clone.default(squeeze, memory_format = torch.contiguous_format);  squeeze = None
            select: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_24, 0, 0)
            select_1: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_24, 0, 1)
            select_2: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_24, 0, 2);  clone_24 = None
            view_45: "f32[97, 12, 64]" = torch.ops.aten.view.default(select, [97, 12, 64]);  select = None
            transpose_68: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_45, 0, 1);  view_45 = None
            view_46: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_1, [97, 12, 64]);  select_1 = None
            transpose_69: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_46, 0, 1);  view_46 = None
            view_47: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_2, [97, 12, 64]);  select_2 = None
            transpose_70: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_47, 0, 1);  view_47 = None
            view_51: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_68, [1, 12, 97, 64]);  transpose_68 = None
            view_52: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_69, [1, 12, 97, 64]);  transpose_69 = None
            view_53: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_70, [1, 12, 97, 64]);  transpose_70 = None
            view_54: "f32[1, 1, 1, 97]" = torch.ops.aten.view.default(masked_fill_2, [1, 1, 1, 97]);  masked_fill_2 = None
            expand_24: "f32[1, 12, 1, 97]" = torch.ops.aten.expand.default(view_54, [-1, 12, -1, -1]);  view_54 = None
            view_55: "f32[12, 1, 97]" = torch.ops.aten.view.default(expand_24, [12, 1, 97]);  expand_24 = None
            view_56: "f32[1, 12, 1, 97]" = torch.ops.aten.view.default(view_55, [1, 12, -1, 97]);  view_55 = None
            scaled_dot_product_attention_22: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(view_51, view_52, view_53, view_56);  view_51 = view_52 = view_53 = view_56 = None
            permute_1: "f32[97, 1, 12, 64]" = torch.ops.aten.permute.default(scaled_dot_product_attention_22, [2, 0, 1, 3]);  scaled_dot_product_attention_22 = None
            view_57: "f32[97, 768]" = torch.ops.aten.view.default(permute_1, [97, 768]);  permute_1 = None
            linear_89: "f32[97, 768]" = torch.ops.aten.linear.default(view_57, p_head_layers_0_self_attn_out_proj_weight, p_head_layers_0_self_attn_out_proj_bias);  view_57 = p_head_layers_0_self_attn_out_proj_weight = p_head_layers_0_self_attn_out_proj_bias = None
            view_58: "f32[97, 1, 768]" = torch.ops.aten.view.default(linear_89, [97, 1, 768]);  linear_89 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1402 in forward, code: return attn_output.transpose(1, 0), attn_output_weights
            transpose_71: "f32[1, 97, 768]" = torch.ops.aten.transpose.int(view_58, 1, 0);  view_58 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_25: "f32[1, 97, 768]" = torch.ops.aten.clone.default(transpose_71);  transpose_71 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:928 in forward, code: x = x + self._sa_block(
            add_89: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_88, clone_25);  add_88 = clone_25 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_46: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_89, [768], p_head_layers_0_norm2_weight, p_head_layers_0_norm2_bias);  p_head_layers_0_norm2_weight = p_head_layers_0_norm2_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_90: "f32[1, 97, 3072]" = torch.ops.aten.linear.default(layer_norm_46, p_head_layers_0_linear1_weight, p_head_layers_0_linear1_bias);  layer_norm_46 = p_head_layers_0_linear1_weight = p_head_layers_0_linear1_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            relu: "f32[1, 97, 3072]" = torch.ops.aten.relu.default(linear_90);  linear_90 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_26: "f32[1, 97, 3072]" = torch.ops.aten.clone.default(relu);  relu = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_91: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_26, p_head_layers_0_linear2_weight, p_head_layers_0_linear2_bias);  clone_26 = p_head_layers_0_linear2_weight = p_head_layers_0_linear2_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_27: "f32[1, 97, 768]" = torch.ops.aten.clone.default(linear_91);  linear_91 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            add_90: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_89, clone_27);  add_89 = clone_27 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:805 in forward, code: src_key_padding_mask = F._canonical_mask(
            zeros_like_1: "f32[1, 97]" = torch.ops.aten.zeros_like.default(bitwise_not, dtype = torch.float32, pin_memory = False)
            masked_fill_3: "f32[1, 97]" = torch.ops.aten.masked_fill.Scalar(zeros_like_1, bitwise_not, -inf);  zeros_like_1 = bitwise_not = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_47: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_90, [768], p_head_layers_1_norm1_weight, p_head_layers_1_norm1_bias);  p_head_layers_1_norm1_weight = p_head_layers_1_norm1_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1346 in forward, code: query = key = value = query.transpose(1, 0)
            transpose_72: "f32[97, 1, 768]" = torch.ops.aten.transpose.int(layer_norm_47, 1, 0);  layer_norm_47 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1380 in forward, code: attn_output, attn_output_weights = F.multi_head_attention_forward(
            linear_92: "f32[97, 1, 2304]" = torch.ops.aten.linear.default(transpose_72, p_head_layers_1_self_attn_in_proj_weight, p_head_layers_1_self_attn_in_proj_bias);  transpose_72 = p_head_layers_1_self_attn_in_proj_weight = p_head_layers_1_self_attn_in_proj_bias = None
            view_59: "f32[97, 1, 3, 768]" = torch.ops.aten.view.default(linear_92, [97, 1, 3, 768]);  linear_92 = None
            unsqueeze_118: "f32[1, 97, 1, 3, 768]" = torch.ops.aten.unsqueeze.default(view_59, 0);  view_59 = None
            transpose_73: "f32[3, 97, 1, 1, 768]" = torch.ops.aten.transpose.int(unsqueeze_118, 0, -2);  unsqueeze_118 = None
            squeeze_1: "f32[3, 97, 1, 768]" = torch.ops.aten.squeeze.dim(transpose_73, -2);  transpose_73 = None
            clone_28: "f32[3, 97, 1, 768]" = torch.ops.aten.clone.default(squeeze_1, memory_format = torch.contiguous_format);  squeeze_1 = None
            select_3: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_28, 0, 0)
            select_4: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_28, 0, 1)
            select_5: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_28, 0, 2);  clone_28 = None
            view_60: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_3, [97, 12, 64]);  select_3 = None
            transpose_74: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_60, 0, 1);  view_60 = None
            view_61: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_4, [97, 12, 64]);  select_4 = None
            transpose_75: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_61, 0, 1);  view_61 = None
            view_62: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_5, [97, 12, 64]);  select_5 = None
            transpose_76: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_62, 0, 1);  view_62 = None
            view_66: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_74, [1, 12, 97, 64]);  transpose_74 = None
            view_67: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_75, [1, 12, 97, 64]);  transpose_75 = None
            view_68: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_76, [1, 12, 97, 64]);  transpose_76 = None
            view_69: "f32[1, 1, 1, 97]" = torch.ops.aten.view.default(masked_fill_3, [1, 1, 1, 97]);  masked_fill_3 = None
            expand_26: "f32[1, 12, 1, 97]" = torch.ops.aten.expand.default(view_69, [-1, 12, -1, -1]);  view_69 = None
            view_70: "f32[12, 1, 97]" = torch.ops.aten.view.default(expand_26, [12, 1, 97]);  expand_26 = None
            view_71: "f32[1, 12, 1, 97]" = torch.ops.aten.view.default(view_70, [1, 12, -1, 97]);  view_70 = None
            scaled_dot_product_attention_23: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(view_66, view_67, view_68, view_71);  view_66 = view_67 = view_68 = view_71 = None
            permute_2: "f32[97, 1, 12, 64]" = torch.ops.aten.permute.default(scaled_dot_product_attention_23, [2, 0, 1, 3]);  scaled_dot_product_attention_23 = None
            view_72: "f32[97, 768]" = torch.ops.aten.view.default(permute_2, [97, 768]);  permute_2 = None
            linear_93: "f32[97, 768]" = torch.ops.aten.linear.default(view_72, p_head_layers_1_self_attn_out_proj_weight, p_head_layers_1_self_attn_out_proj_bias);  view_72 = p_head_layers_1_self_attn_out_proj_weight = p_head_layers_1_self_attn_out_proj_bias = None
            view_73: "f32[97, 1, 768]" = torch.ops.aten.view.default(linear_93, [97, 1, 768]);  linear_93 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1402 in forward, code: return attn_output.transpose(1, 0), attn_output_weights
            transpose_77: "f32[1, 97, 768]" = torch.ops.aten.transpose.int(view_73, 1, 0);  view_73 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_29: "f32[1, 97, 768]" = torch.ops.aten.clone.default(transpose_77);  transpose_77 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:928 in forward, code: x = x + self._sa_block(
            add_91: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_90, clone_29);  add_90 = clone_29 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_48: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_91, [768], p_head_layers_1_norm2_weight, p_head_layers_1_norm2_bias);  p_head_layers_1_norm2_weight = p_head_layers_1_norm2_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_94: "f32[1, 97, 3072]" = torch.ops.aten.linear.default(layer_norm_48, p_head_layers_1_linear1_weight, p_head_layers_1_linear1_bias);  layer_norm_48 = p_head_layers_1_linear1_weight = p_head_layers_1_linear1_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            relu_1: "f32[1, 97, 3072]" = torch.ops.aten.relu.default(linear_94);  linear_94 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_30: "f32[1, 97, 3072]" = torch.ops.aten.clone.default(relu_1);  relu_1 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_95: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_30, p_head_layers_1_linear2_weight, p_head_layers_1_linear2_bias);  clone_30 = p_head_layers_1_linear2_weight = p_head_layers_1_linear2_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_31: "f32[1, 97, 768]" = torch.ops.aten.clone.default(linear_95);  linear_95 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            add_92: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_91, clone_31);  add_91 = clone_31 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:114 in forward, code: idx = marker_pos.clamp(min=0)[:, :, None].expand(-1, -1, h.size(-1))
            clamp: "i64[1, 3]" = torch.ops.aten.clamp.default(marker_pos, 0);  marker_pos = None
            slice_159: "i64[1, 3]" = torch.ops.aten.slice.Tensor(clamp, 0, 0, 9223372036854775807);  clamp = None
            slice_160: "i64[1, 3]" = torch.ops.aten.slice.Tensor(slice_159, 1, 0, 9223372036854775807);  slice_159 = None
            unsqueeze_119: "i64[1, 3, 1]" = torch.ops.aten.unsqueeze.default(slice_160, 2);  slice_160 = None
            expand_27: "i64[1, 3, 768]" = torch.ops.aten.expand.default(unsqueeze_119, [-1, -1, 768]);  unsqueeze_119 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:115 in forward, code: m = torch.gather(h, 1, idx)
            gather: "f32[1, 3, 768]" = torch.ops.aten.gather.default(add_92, 1, expand_27);  expand_27 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_49: "f32[1, 3, 768]" = torch.ops.aten.layer_norm.default(gather, [768], p_scorer_0_weight, p_scorer_0_bias);  gather = p_scorer_0_weight = p_scorer_0_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_96: "f32[1, 3, 768]" = torch.ops.aten.linear.default(layer_norm_49, p_scorer_1_weight, p_scorer_1_bias);  layer_norm_49 = p_scorer_1_weight = p_scorer_1_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:738 in forward, code: return F.gelu(input, approximate=self.approximate)
            gelu_22: "f32[1, 3, 768]" = torch.ops.aten.gelu.default(linear_96);  linear_96 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_97: "f32[1, 3, 1]" = torch.ops.aten.linear.default(gelu_22, p_scorer_3_weight, p_scorer_3_bias);  gelu_22 = p_scorer_3_weight = p_scorer_3_bias = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:116 in forward, code: logits = self.scorer(m).squeeze(-1).float()
            squeeze_2: "f32[1, 3]" = torch.ops.aten.squeeze.dim(linear_97, -1);  linear_97 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:117 in forward, code: logits = logits.masked_fill(~marker_mask, -1e4)
            bitwise_not_1: "b8[1, 3]" = torch.ops.aten.bitwise_not.default(marker_mask)
            masked_fill_4: "f32[1, 3]" = torch.ops.aten.masked_fill.Scalar(squeeze_2, bitwise_not_1, -10000.0);  squeeze_2 = bitwise_not_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:119 in forward, code: p = torch.softmax(logits.detach(), -1)
            detach: "f32[1, 3]" = torch.ops.aten.detach.default(masked_fill_4)
            detach_1: "f32[1, 3]" = torch.ops.aten.detach.default(detach);  detach = None
            detach_2: "f32[1, 3]" = torch.ops.aten.detach.default(detach_1);  detach_1 = None
            softmax: "f32[1, 3]" = torch.ops.aten.softmax.int(detach_2, -1);  detach_2 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:120 in forward, code: k = marker_mask.sum(-1).clamp(min=2).float()
            convert_element_type_default: "i64[1, 3]" = torch.ops.prims.convert_element_type.default(marker_mask, dtype = torch.int64);  marker_mask = None
            sum_1: "i64[1]" = torch.ops.aten.sum.dim_IntList(convert_element_type_default, [-1]);  convert_element_type_default = None
            clamp_1: "i64[1]" = torch.ops.aten.clamp.default(sum_1, 2);  sum_1 = None
            _to_copy_25: "f32[1]" = torch.ops.aten._to_copy.default(clamp_1, dtype = torch.float32);  clamp_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:121 in forward, code: ent = -(p * torch.log(p.clamp_min(1e-9))).sum(-1) / torch.log(k)
            clamp_min: "f32[1, 3]" = torch.ops.aten.clamp_min.default(softmax, 1e-09)
            log: "f32[1, 3]" = torch.ops.aten.log.default(clamp_min);  clamp_min = None
            mul_154: "f32[1, 3]" = torch.ops.aten.mul.Tensor(softmax, log);  log = None
            sum_2: "f32[1]" = torch.ops.aten.sum.dim_IntList(mul_154, [-1]);  mul_154 = None
            neg_44: "f32[1]" = torch.ops.aten.neg.default(sum_2);  sum_2 = None
            log_1: "f32[1]" = torch.ops.aten.log.default(_to_copy_25)
            div: "f32[1]" = torch.ops.aten.div.Tensor(neg_44, log_1);  neg_44 = log_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:123 in forward, code: top2 = p.topk(2, -1).values
            topk = torch.ops.aten.topk.default(softmax, 2);  softmax = None
            getitem_110: "f32[1, 2]" = topk[0];  topk = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:133 in forward, code: feats = torch.stack([top2[:, 0], top2[:, 0] - top2[:, 1], ent, k / 255.0], -1)
            slice_161: "f32[1, 2]" = torch.ops.aten.slice.Tensor(getitem_110)
            select_6: "f32[1]" = torch.ops.aten.select.int(slice_161, 1, 0);  slice_161 = None
            slice_162: "f32[1, 2]" = torch.ops.aten.slice.Tensor(getitem_110)
            select_7: "f32[1]" = torch.ops.aten.select.int(slice_162, 1, 0);  slice_162 = None
            slice_163: "f32[1, 2]" = torch.ops.aten.slice.Tensor(getitem_110);  getitem_110 = None
            select_8: "f32[1]" = torch.ops.aten.select.int(slice_163, 1, 1);  slice_163 = None
            sub_2: "f32[1]" = torch.ops.aten.sub.Tensor(select_7, select_8);  select_7 = select_8 = None
            div_1: "f32[1]" = torch.ops.aten.div.Tensor(_to_copy_25, 255.0);  _to_copy_25 = None
            stack: "f32[1, 4]" = torch.ops.aten.stack.default([select_6, sub_2, div, div_1], -1);  select_6 = sub_2 = div = div_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:134 in forward, code: pooled = h[:, 0].float()
            slice_164: "f32[1, 97, 768]" = torch.ops.aten.slice.Tensor(add_92);  add_92 = None
            select_9: "f32[1, 768]" = torch.ops.aten.select.int(slice_164, 1, 0);  slice_164 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:135 in forward, code: act_logits = self.act_head(torch.cat([pooled, feats], -1))
            cat_66: "f32[1, 772]" = torch.ops.aten.cat.default([select_9, stack], -1);  select_9 = stack = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_98: "f32[1, 256]" = torch.ops.aten.linear.default(cat_66, p_act_head_0_weight, p_act_head_0_bias);  cat_66 = p_act_head_0_weight = p_act_head_0_bias = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:738 in forward, code: return F.gelu(input, approximate=self.approximate)
            gelu_23: "f32[1, 256]" = torch.ops.aten.gelu.default(linear_98);  linear_98 = None
            
             # File: /workspace/scratch/thx01-m1/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_99: "f32[1, 2]" = torch.ops.aten.linear.default(gelu_23, p_act_head_2_weight, p_act_head_2_bias);  gelu_23 = p_act_head_2_weight = p_act_head_2_bias = None
            return (masked_fill_4, linear_99)
            
Graph signature: 
    # inputs
    p_encoder_embeddings_tok_embeddings_weight: PARAMETER target='encoder.embeddings.tok_embeddings.weight'
    p_encoder_embeddings_norm_weight: PARAMETER target='encoder.embeddings.norm.weight'
    p_encoder_layers_0_attn_wqkv_weight: PARAMETER target='encoder.layers.0.attn.Wqkv.weight'
    p_encoder_layers_0_attn_wo_weight: PARAMETER target='encoder.layers.0.attn.Wo.weight'
    p_encoder_layers_0_mlp_norm_weight: PARAMETER target='encoder.layers.0.mlp_norm.weight'
    p_encoder_layers_0_mlp_wi_weight: PARAMETER target='encoder.layers.0.mlp.Wi.weight'
    p_encoder_layers_0_mlp_wo_weight: PARAMETER target='encoder.layers.0.mlp.Wo.weight'
    p_encoder_layers_1_attn_norm_weight: PARAMETER target='encoder.layers.1.attn_norm.weight'
    p_encoder_layers_1_attn_wqkv_weight: PARAMETER target='encoder.layers.1.attn.Wqkv.weight'
    p_encoder_layers_1_attn_wo_weight: PARAMETER target='encoder.layers.1.attn.Wo.weight'
    p_encoder_layers_1_mlp_norm_weight: PARAMETER target='encoder.layers.1.mlp_norm.weight'
    p_encoder_layers_1_mlp_wi_weight: PARAMETER target='encoder.layers.1.mlp.Wi.weight'
    p_encoder_layers_1_mlp_wo_weight: PARAMETER target='encoder.layers.1.mlp.Wo.weight'
    p_encoder_layers_2_attn_norm_weight: PARAMETER target='encoder.layers.2.attn_norm.weight'
    p_encoder_layers_2_attn_wqkv_weight: PARAMETER target='encoder.layers.2.attn.Wqkv.weight'
    p_encoder_layers_2_attn_wo_weight: PARAMETER target='encoder.layers.2.attn.Wo.weight'
    p_encoder_layers_2_mlp_norm_weight: PARAMETER target='encoder.layers.2.mlp_norm.weight'
    p_encoder_layers_2_mlp_wi_weight: PARAMETER target='encoder.layers.2.mlp.Wi.weight'
    p_encoder_layers_2_mlp_wo_weight: PARAMETER target='encoder.layers.2.mlp.Wo.weight'
    p_encoder_layers_3_attn_norm_weight: PARAMETER target='encoder.layers.3.attn_norm.weight'
    p_encoder_layers_3_attn_wqkv_weight: PARAMETER target='encoder.layers.3.attn.Wqkv.weight'
    p_encoder_layers_3_attn_wo_weight: PARAMETER target='encoder.layers.3.attn.Wo.weight'
    p_encoder_layers_3_mlp_norm_weight: PARAMETER target='encoder.layers.3.mlp_norm.weight'
    p_encoder_layers_3_mlp_wi_weight: PARAMETER target='encoder.layers.3.mlp.Wi.weight'
    p_encoder_layers_3_mlp_wo_weight: PARAMETER target='encoder.layers.3.mlp.Wo.weight'
    p_encoder_layers_4_attn_norm_weight: PARAMETER target='encoder.layers.4.attn_norm.weight'
    p_encoder_layers_4_attn_wqkv_weight: PARAMETER target='encoder.layers.4.attn.Wqkv.weight'
    p_encoder_layers_4_attn_wo_weight: PARAMETER target='encoder.layers.4.attn.Wo.weight'
    p_encoder_layers_4_mlp_norm_weight: PARAMETER target='encoder.layers.4.mlp_norm.weight'
    p_encoder_layers_4_mlp_wi_weight: PARAMETER target='encoder.layers.4.mlp.Wi.weight'
    p_encoder_layers_4_mlp_wo_weight: PARAMETER target='encoder.layers.4.mlp.Wo.weight'
    p_encoder_layers_5_attn_norm_weight: PARAMETER target='encoder.layers.5.attn_norm.weight'
    p_encoder_layers_5_attn_wqkv_weight: PARAMETER target='encoder.layers.5.attn.Wqkv.weight'
    p_encoder_layers_5_attn_wo_weight: PARAMETER target='encoder.layers.5.attn.Wo.weight'
    p_encoder_layers_5_mlp_norm_weight: PARAMETER target='encoder.layers.5.mlp_norm.weight'
    p_encoder_layers_5_mlp_wi_weight: PARAMETER target='encoder.layers.5.mlp.Wi.weight'
    p_encoder_layers_5_mlp_wo_weight: PARAMETER target='encoder.layers.5.mlp.Wo.weight'
    p_encoder_layers_6_attn_norm_weight: PARAMETER target='encoder.layers.6.attn_norm.weight'
    p_encoder_layers_6_attn_wqkv_weight: PARAMETER target='encoder.layers.6.attn.Wqkv.weight'
    p_encoder_layers_6_attn_wo_weight: PARAMETER target='encoder.layers.6.attn.Wo.weight'
    p_encoder_layers_6_mlp_norm_weight: PARAMETER target='encoder.layers.6.mlp_norm.weight'
    p_encoder_layers_6_mlp_wi_weight: PARAMETER target='encoder.layers.6.mlp.Wi.weight'
    p_encoder_layers_6_mlp_wo_weight: PARAMETER target='encoder.layers.6.mlp.Wo.weight'
    p_encoder_layers_7_attn_norm_weight: PARAMETER target='encoder.layers.7.attn_norm.weight'
    p_encoder_layers_7_attn_wqkv_weight: PARAMETER target='encoder.layers.7.attn.Wqkv.weight'
    p_encoder_layers_7_attn_wo_weight: PARAMETER target='encoder.layers.7.attn.Wo.weight'
    p_encoder_layers_7_mlp_norm_weight: PARAMETER target='encoder.layers.7.mlp_norm.weight'
    p_encoder_layers_7_mlp_wi_weight: PARAMETER target='encoder.layers.7.mlp.Wi.weight'
    p_encoder_layers_7_mlp_wo_weight: PARAMETER target='encoder.layers.7.mlp.Wo.weight'
    p_encoder_layers_8_attn_norm_weight: PARAMETER target='encoder.layers.8.attn_norm.weight'
    p_encoder_layers_8_attn_wqkv_weight: PARAMETER target='encoder.layers.8.attn.Wqkv.weight'
    p_encoder_layers_8_attn_wo_weight: PARAMETER target='encoder.layers.8.attn.Wo.weight'
    p_encoder_layers_8_mlp_norm_weight: PARAMETER target='encoder.layers.8.mlp_norm.weight'
    p_encoder_layers_8_mlp_wi_weight: PARAMETER target='encoder.layers.8.mlp.Wi.weight'
    p_encoder_layers_8_mlp_wo_weight: PARAMETER target='encoder.layers.8.mlp.Wo.weight'
    p_encoder_layers_9_attn_norm_weight: PARAMETER target='encoder.layers.9.attn_norm.weight'
    p_encoder_layers_9_attn_wqkv_weight: PARAMETER target='encoder.layers.9.attn.Wqkv.weight'
    p_encoder_layers_9_attn_wo_weight: PARAMETER target='encoder.layers.9.attn.Wo.weight'
    p_encoder_layers_9_mlp_norm_weight: PARAMETER target='encoder.layers.9.mlp_norm.weight'
    p_encoder_layers_9_mlp_wi_weight: PARAMETER target='encoder.layers.9.mlp.Wi.weight'
    p_encoder_layers_9_mlp_wo_weight: PARAMETER target='encoder.layers.9.mlp.Wo.weight'
    p_encoder_layers_10_attn_norm_weight: PARAMETER target='encoder.layers.10.attn_norm.weight'
    p_encoder_layers_10_attn_wqkv_weight: PARAMETER target='encoder.layers.10.attn.Wqkv.weight'
    p_encoder_layers_10_attn_wo_weight: PARAMETER target='encoder.layers.10.attn.Wo.weight'
    p_encoder_layers_10_mlp_norm_weight: PARAMETER target='encoder.layers.10.mlp_norm.weight'
    p_encoder_layers_10_mlp_wi_weight: PARAMETER target='encoder.layers.10.mlp.Wi.weight'
    p_encoder_layers_10_mlp_wo_weight: PARAMETER target='encoder.layers.10.mlp.Wo.weight'
    p_encoder_layers_11_attn_norm_weight: PARAMETER target='encoder.layers.11.attn_norm.weight'
    p_encoder_layers_11_attn_wqkv_weight: PARAMETER target='encoder.layers.11.attn.Wqkv.weight'
    p_encoder_layers_11_attn_wo_weight: PARAMETER target='encoder.layers.11.attn.Wo.weight'
    p_encoder_layers_11_mlp_norm_weight: PARAMETER target='encoder.layers.11.mlp_norm.weight'
    p_encoder_layers_11_mlp_wi_weight: PARAMETER target='encoder.layers.11.mlp.Wi.weight'
    p_encoder_layers_11_mlp_wo_weight: PARAMETER target='encoder.layers.11.mlp.Wo.weight'
    p_encoder_layers_12_attn_norm_weight: PARAMETER target='encoder.layers.12.attn_norm.weight'
    p_encoder_layers_12_attn_wqkv_weight: PARAMETER target='encoder.layers.12.attn.Wqkv.weight'
    p_encoder_layers_12_attn_wo_weight: PARAMETER target='encoder.layers.12.attn.Wo.weight'
    p_encoder_layers_12_mlp_norm_weight: PARAMETER target='encoder.layers.12.mlp_norm.weight'
    p_encoder_layers_12_mlp_wi_weight: PARAMETER target='encoder.layers.12.mlp.Wi.weight'
    p_encoder_layers_12_mlp_wo_weight: PARAMETER target='encoder.layers.12.mlp.Wo.weight'
    p_encoder_layers_13_attn_norm_weight: PARAMETER target='encoder.layers.13.attn_norm.weight'
    p_encoder_layers_13_attn_wqkv_weight: PARAMETER target='encoder.layers.13.attn.Wqkv.weight'
    p_encoder_layers_13_attn_wo_weight: PARAMETER target='encoder.layers.13.attn.Wo.weight'
    p_encoder_layers_13_mlp_norm_weight: PARAMETER target='encoder.layers.13.mlp_norm.weight'
    p_encoder_layers_13_mlp_wi_weight: PARAMETER target='encoder.layers.13.mlp.Wi.weight'
    p_encoder_layers_13_mlp_wo_weight: PARAMETER target='encoder.layers.13.mlp.Wo.weight'
    p_encoder_layers_14_attn_norm_weight: PARAMETER target='encoder.layers.14.attn_norm.weight'
    p_encoder_layers_14_attn_wqkv_weight: PARAMETER target='encoder.layers.14.attn.Wqkv.weight'
    p_encoder_layers_14_attn_wo_weight: PARAMETER target='encoder.layers.14.attn.Wo.weight'
    p_encoder_layers_14_mlp_norm_weight: PARAMETER target='encoder.layers.14.mlp_norm.weight'
    p_encoder_layers_14_mlp_wi_weight: PARAMETER target='encoder.layers.14.mlp.Wi.weight'
    p_encoder_layers_14_mlp_wo_weight: PARAMETER target='encoder.layers.14.mlp.Wo.weight'
    p_encoder_layers_15_attn_norm_weight: PARAMETER target='encoder.layers.15.attn_norm.weight'
    p_encoder_layers_15_attn_wqkv_weight: PARAMETER target='encoder.layers.15.attn.Wqkv.weight'
    p_encoder_layers_15_attn_wo_weight: PARAMETER target='encoder.layers.15.attn.Wo.weight'
    p_encoder_layers_15_mlp_norm_weight: PARAMETER target='encoder.layers.15.mlp_norm.weight'
    p_encoder_layers_15_mlp_wi_weight: PARAMETER target='encoder.layers.15.mlp.Wi.weight'
    p_encoder_layers_15_mlp_wo_weight: PARAMETER target='encoder.layers.15.mlp.Wo.weight'
    p_encoder_layers_16_attn_norm_weight: PARAMETER target='encoder.layers.16.attn_norm.weight'
    p_encoder_layers_16_attn_wqkv_weight: PARAMETER target='encoder.layers.16.attn.Wqkv.weight'
    p_encoder_layers_16_attn_wo_weight: PARAMETER target='encoder.layers.16.attn.Wo.weight'
    p_encoder_layers_16_mlp_norm_weight: PARAMETER target='encoder.layers.16.mlp_norm.weight'
    p_encoder_layers_16_mlp_wi_weight: PARAMETER target='encoder.layers.16.mlp.Wi.weight'
    p_encoder_layers_16_mlp_wo_weight: PARAMETER target='encoder.layers.16.mlp.Wo.weight'
    p_encoder_layers_17_attn_norm_weight: PARAMETER target='encoder.layers.17.attn_norm.weight'
    p_encoder_layers_17_attn_wqkv_weight: PARAMETER target='encoder.layers.17.attn.Wqkv.weight'
    p_encoder_layers_17_attn_wo_weight: PARAMETER target='encoder.layers.17.attn.Wo.weight'
    p_encoder_layers_17_mlp_norm_weight: PARAMETER target='encoder.layers.17.mlp_norm.weight'
    p_encoder_layers_17_mlp_wi_weight: PARAMETER target='encoder.layers.17.mlp.Wi.weight'
    p_encoder_layers_17_mlp_wo_weight: PARAMETER target='encoder.layers.17.mlp.Wo.weight'
    p_encoder_layers_18_attn_norm_weight: PARAMETER target='encoder.layers.18.attn_norm.weight'
    p_encoder_layers_18_attn_wqkv_weight: PARAMETER target='encoder.layers.18.attn.Wqkv.weight'
    p_encoder_layers_18_attn_wo_weight: PARAMETER target='encoder.layers.18.attn.Wo.weight'
    p_encoder_layers_18_mlp_norm_weight: PARAMETER target='encoder.layers.18.mlp_norm.weight'
    p_encoder_layers_18_mlp_wi_weight: PARAMETER target='encoder.layers.18.mlp.Wi.weight'
    p_encoder_layers_18_mlp_wo_weight: PARAMETER target='encoder.layers.18.mlp.Wo.weight'
    p_encoder_layers_19_attn_norm_weight: PARAMETER target='encoder.layers.19.attn_norm.weight'
    p_encoder_layers_19_attn_wqkv_weight: PARAMETER target='encoder.layers.19.attn.Wqkv.weight'
    p_encoder_layers_19_attn_wo_weight: PARAMETER target='encoder.layers.19.attn.Wo.weight'
    p_encoder_layers_19_mlp_norm_weight: PARAMETER target='encoder.layers.19.mlp_norm.weight'
    p_encoder_layers_19_mlp_wi_weight: PARAMETER target='encoder.layers.19.mlp.Wi.weight'
    p_encoder_layers_19_mlp_wo_weight: PARAMETER target='encoder.layers.19.mlp.Wo.weight'
    p_encoder_layers_20_attn_norm_weight: PARAMETER target='encoder.layers.20.attn_norm.weight'
    p_encoder_layers_20_attn_wqkv_weight: PARAMETER target='encoder.layers.20.attn.Wqkv.weight'
    p_encoder_layers_20_attn_wo_weight: PARAMETER target='encoder.layers.20.attn.Wo.weight'
    p_encoder_layers_20_mlp_norm_weight: PARAMETER target='encoder.layers.20.mlp_norm.weight'
    p_encoder_layers_20_mlp_wi_weight: PARAMETER target='encoder.layers.20.mlp.Wi.weight'
    p_encoder_layers_20_mlp_wo_weight: PARAMETER target='encoder.layers.20.mlp.Wo.weight'
    p_encoder_layers_21_attn_norm_weight: PARAMETER target='encoder.layers.21.attn_norm.weight'
    p_encoder_layers_21_attn_wqkv_weight: PARAMETER target='encoder.layers.21.attn.Wqkv.weight'
    p_encoder_layers_21_attn_wo_weight: PARAMETER target='encoder.layers.21.attn.Wo.weight'
    p_encoder_layers_21_mlp_norm_weight: PARAMETER target='encoder.layers.21.mlp_norm.weight'
    p_encoder_layers_21_mlp_wi_weight: PARAMETER target='encoder.layers.21.mlp.Wi.weight'
    p_encoder_layers_21_mlp_wo_weight: PARAMETER target='encoder.layers.21.mlp.Wo.weight'
    p_encoder_final_norm_weight: PARAMETER target='encoder.final_norm.weight'
    p_head_layers_0_self_attn_in_proj_weight: PARAMETER target='head.layers.0.self_attn.in_proj_weight'
    p_head_layers_0_self_attn_in_proj_bias: PARAMETER target='head.layers.0.self_attn.in_proj_bias'
    p_head_layers_0_self_attn_out_proj_weight: PARAMETER target='head.layers.0.self_attn.out_proj.weight'
    p_head_layers_0_self_attn_out_proj_bias: PARAMETER target='head.layers.0.self_attn.out_proj.bias'
    p_head_layers_0_linear1_weight: PARAMETER target='head.layers.0.linear1.weight'
    p_head_layers_0_linear1_bias: PARAMETER target='head.layers.0.linear1.bias'
    p_head_layers_0_linear2_weight: PARAMETER target='head.layers.0.linear2.weight'
    p_head_layers_0_linear2_bias: PARAMETER target='head.layers.0.linear2.bias'
    p_head_layers_0_norm1_weight: PARAMETER target='head.layers.0.norm1.weight'
    p_head_layers_0_norm1_bias: PARAMETER target='head.layers.0.norm1.bias'
    p_head_layers_0_norm2_weight: PARAMETER target='head.layers.0.norm2.weight'
    p_head_layers_0_norm2_bias: PARAMETER target='head.layers.0.norm2.bias'
    p_head_layers_1_self_attn_in_proj_weight: PARAMETER target='head.layers.1.self_attn.in_proj_weight'
    p_head_layers_1_self_attn_in_proj_bias: PARAMETER target='head.layers.1.self_attn.in_proj_bias'
    p_head_layers_1_self_attn_out_proj_weight: PARAMETER target='head.layers.1.self_attn.out_proj.weight'
    p_head_layers_1_self_attn_out_proj_bias: PARAMETER target='head.layers.1.self_attn.out_proj.bias'
    p_head_layers_1_linear1_weight: PARAMETER target='head.layers.1.linear1.weight'
    p_head_layers_1_linear1_bias: PARAMETER target='head.layers.1.linear1.bias'
    p_head_layers_1_linear2_weight: PARAMETER target='head.layers.1.linear2.weight'
    p_head_layers_1_linear2_bias: PARAMETER target='head.layers.1.linear2.bias'
    p_head_layers_1_norm1_weight: PARAMETER target='head.layers.1.norm1.weight'
    p_head_layers_1_norm1_bias: PARAMETER target='head.layers.1.norm1.bias'
    p_head_layers_1_norm2_weight: PARAMETER target='head.layers.1.norm2.weight'
    p_head_layers_1_norm2_bias: PARAMETER target='head.layers.1.norm2.bias'
    p_type_emb_weight: PARAMETER target='type_emb.weight'
    p_scorer_0_weight: PARAMETER target='scorer.0.weight'
    p_scorer_0_bias: PARAMETER target='scorer.0.bias'
    p_scorer_1_weight: PARAMETER target='scorer.1.weight'
    p_scorer_1_bias: PARAMETER target='scorer.1.bias'
    p_scorer_3_weight: PARAMETER target='scorer.3.weight'
    p_scorer_3_bias: PARAMETER target='scorer.3.bias'
    p_act_head_0_weight: PARAMETER target='act_head.0.weight'
    p_act_head_0_bias: PARAMETER target='act_head.0.bias'
    p_act_head_2_weight: PARAMETER target='act_head.2.weight'
    p_act_head_2_bias: PARAMETER target='act_head.2.bias'
    b_temperature: BUFFER target='temperature' persistent=True
    c_encoder_lifted_tensor_0: CONSTANT_TENSOR target='encoder.lifted_tensor_0'
    b_encoder_rotary_emb_sliding_attention_inv_freq: BUFFER target='encoder.rotary_emb.sliding_attention_inv_freq' persistent=False
    b_encoder_rotary_emb_sliding_attention_original_inv_freq: BUFFER target='encoder.rotary_emb.sliding_attention_original_inv_freq' persistent=False
    b_encoder_rotary_emb_full_attention_inv_freq: BUFFER target='encoder.rotary_emb.full_attention_inv_freq' persistent=False
    b_encoder_rotary_emb_full_attention_original_inv_freq: BUFFER target='encoder.rotary_emb.full_attention_original_inv_freq' persistent=False
    input_ids: USER_INPUT
    attention_mask: USER_INPUT
    marker_pos: USER_INPUT
    marker_mask: USER_INPUT
    qtype: USER_INPUT
    
    # outputs
    masked_fill_4: USER_OUTPUT
    linear_99: USER_OUTPUT
    
Range constraints: {}

```

## ONNX model

```python
<
    ir_version=10,
    opset_imports={'pkg.onnxscript.torch_lib.common': 1, '': 18, 'pkg.onnxscript.torch_lib': 1},
    producer_name='pytorch',
    producer_version='2.8.0+cpu',
    domain=None,
    model_version=None,
>
graph(
    name=main_graph,
    inputs=(
        %"input_ids"<INT64,[1,97]>,
        %"attention_mask"<INT64,[1,97]>,
        %"marker_pos"<INT64,[1,3]>,
        %"marker_mask"<BOOL,[1,3]>,
        %"qtype"<INT64,[1]>
    ),
    outputs=(
        %"logits"<FLOAT,[1,3]>,
        %"act_logits"<FLOAT,[1,2]>
    ),
    initializers=(
        %"encoder.embeddings.tok_embeddings.weight"<FLOAT,[256000,768]>{TorchTensor(...)},
        %"encoder.embeddings.norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.0.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.0.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.0.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.0.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.0.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.1.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.1.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.1.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.1.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.1.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.1.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.2.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.2.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.2.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.2.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.2.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.2.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.3.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.3.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.3.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.3.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.3.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.3.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.4.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.4.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.4.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.4.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.4.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.4.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.5.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.5.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.5.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.5.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.5.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.5.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.6.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.6.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.6.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.6.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.6.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.6.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.7.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.7.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.7.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.7.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.7.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.7.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.8.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.8.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.8.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.8.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.8.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.8.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.9.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.9.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.9.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.9.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.9.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.9.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.10.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.10.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.10.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.10.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.10.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.10.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.11.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.11.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.11.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.11.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.11.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.11.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.12.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.12.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.12.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.12.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.12.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.12.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.13.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.13.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.13.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.13.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.13.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.13.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.14.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.14.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.14.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.14.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.14.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.14.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.15.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.15.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.15.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.15.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.15.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.15.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.16.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.16.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.16.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.16.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.16.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.16.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.17.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.17.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.17.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.17.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.17.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.17.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.18.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.18.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.18.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.18.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.18.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.18.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.19.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.19.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.19.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.19.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.19.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.19.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.20.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.20.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.20.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.20.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.20.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.20.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.21.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.21.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.21.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.21.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.21.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.21.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.final_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.self_attn.in_proj_weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"head.layers.0.self_attn.in_proj_bias"<FLOAT,[2304]>{TorchTensor(...)},
        %"head.layers.0.self_attn.out_proj.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"head.layers.0.self_attn.out_proj.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.linear1.weight"<FLOAT,[3072,768]>{TorchTensor(...)},
        %"head.layers.0.linear1.bias"<FLOAT,[3072]>{TorchTensor(...)},
        %"head.layers.0.linear2.weight"<FLOAT,[768,3072]>{TorchTensor(...)},
        %"head.layers.0.linear2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm1.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm1.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm2.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.self_attn.in_proj_weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"head.layers.1.self_attn.in_proj_bias"<FLOAT,[2304]>{TorchTensor(...)},
        %"head.layers.1.self_attn.out_proj.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"head.layers.1.self_attn.out_proj.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.linear1.weight"<FLOAT,[3072,768]>{TorchTensor(...)},
        %"head.layers.1.linear1.bias"<FLOAT,[3072]>{TorchTensor(...)},
        %"head.layers.1.linear2.weight"<FLOAT,[768,3072]>{TorchTensor(...)},
        %"head.layers.1.linear2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm1.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm1.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm2.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"type_emb.weight"<FLOAT,[3,768]>{TorchTensor(...)},
        %"scorer.0.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"scorer.0.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"scorer.1.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"scorer.1.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"scorer.3.weight"<FLOAT,[1,768]>{TorchTensor(...)},
        %"scorer.3.bias"<FLOAT,[1]>{TorchTensor<FLOAT,[1]>(Parameter containing: tensor([0.0259], requires_grad=True), name='scorer.3.bias')},
        %"act_head.0.weight"<FLOAT,[256,772]>{TorchTensor(...)},
        %"act_head.0.bias"<FLOAT,[256]>{TorchTensor(...)},
        %"act_head.2.weight"<FLOAT,[2,256]>{TorchTensor(...)},
        %"act_head.2.bias"<FLOAT,[2]>{TorchTensor<FLOAT,[2]>(Parameter containing: tensor([ 0.0235, -0.0205], requires_grad=True), name='act_head.2.bias')},
        %"temperature"<FLOAT,[3]>{TorchTensor<FLOAT,[3]>(tensor([1., 1., 1.]), name='temperature')},
        %"encoder.rotary_emb.sliding_attention_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.rotary_emb.sliding_attention_original_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.rotary_emb.full_attention_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.rotary_emb.full_attention_original_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.lifted_tensor_0"<FLOAT,[]>{TorchTensor<FLOAT,[]>(tensor(1.), name='encoder.lifted_tensor_0')}
    ),
) {
       0 |  # node_Constant_0
            %"val_0"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0., dtype=float32), name=None)}
       1 |  # node_Constant_1
            %"val_1"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(97), name=None)}
       2 |  # node_CastLike_2
            %"val_2"<?,?> ⬅️ ::CastLike(%"val_0", %"val_1")
       3 |  # node_Constant_3
            %"val_3"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
       4 |  # node_CastLike_4
            %"val_4"<?,?> ⬅️ ::CastLike(%"val_3", %"val_1")
       5 |  # node_arange
            %"arange"<INT64,[97]> ⬅️ ::Range(%"val_2", %"val_1", %"val_4")
       6 |  # node_Constant_5
            %"val_5"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([0]), name=None)}
       7 |  # node_unsqueeze
            %"unsqueeze"<INT64,[1,97]> ⬅️ ::Unsqueeze(%"arange", %"val_5")
       8 |  # node_Constant_6
            %"val_6"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(0), name=None)}
       9 |  # node_Cast_7
            %"val_7"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      10 |  # node_Constant_8
            %"val_8"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      11 |  # node_Reshape_9
            %"val_9"<?,?> ⬅️ ::Reshape(%"val_7", %"val_8") {allowzero=0}
      12 |  # node_Constant_10
            %"val_10"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(9223372036854775807), name=None)}
      13 |  # node_Cast_11
            %"val_11"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      14 |  # node_Constant_12
            %"val_12"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      15 |  # node_Reshape_13
            %"val_13"<?,?> ⬅️ ::Reshape(%"val_11", %"val_12") {allowzero=0}
      16 |  # node_Cast_14
            %"val_14"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      17 |  # node_Constant_15
            %"val_15"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      18 |  # node_Reshape_16
            %"val_16"<?,?> ⬅️ ::Reshape(%"val_14", %"val_15") {allowzero=0}
      19 |  # node_Constant_17
            %"val_17"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      20 |  # node_slice_1
            %"slice_1"<INT64,[1,97]> ⬅️ ::Slice(%"attention_mask", %"val_9", %"val_13", %"val_16", %"val_17")
      21 |  # node_Constant_18
            %"val_18"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([1]), name=None)}
      22 |  # node_unsqueeze_1
            %"unsqueeze_1"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_1", %"val_18")
      23 |  # node_Constant_19
            %"val_19"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([2]), name=None)}
      24 |  # node_unsqueeze_2
            %"unsqueeze_2"<INT64,[1,1,1,97]> ⬅️ ::Unsqueeze(%"unsqueeze_1", %"val_19")
      25 |  # node_Cast_20
            %"val_20"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      26 |  # node_Constant_21
            %"val_21"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      27 |  # node_Reshape_22
            %"val_22"<?,?> ⬅️ ::Reshape(%"val_20", %"val_21") {allowzero=0}
      28 |  # node_Cast_23
            %"val_23"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      29 |  # node_Constant_24
            %"val_24"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      30 |  # node_Reshape_25
            %"val_25"<?,?> ⬅️ ::Reshape(%"val_23", %"val_24") {allowzero=0}
      31 |  # node_Constant_26
            %"val_26"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(3), name=None)}
      32 |  # node_Cast_27
            %"val_27"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
      33 |  # node_Constant_28
            %"val_28"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      34 |  # node_Reshape_29
            %"val_29"<?,?> ⬅️ ::Reshape(%"val_27", %"val_28") {allowzero=0}
      35 |  # node_Constant_30
            %"val_30"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      36 |  # node_slice_2
            %"slice_2"<INT64,[1,1,1,97]> ⬅️ ::Slice(%"unsqueeze_2", %"val_22", %"val_25", %"val_29", %"val_30")
      37 |  # node_Constant_31
            %"val_31"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[4]>(array([ 1,  1, 97, 97]), name=None)}
      38 |  # node_Cast_32
            %"val_32"<?,?> ⬅️ ::Cast(%"val_31") {to=7}
      39 |  # node_Abs_33
            %"val_33"<?,?> ⬅️ ::Abs(%"val_32")
      40 |  # node_expand
            %"expand"<INT64,[1,1,97,97]> ⬅️ ::Expand(%"slice_2", %"val_33")
      41 |  # node__to_copy
            %"_to_copy"<FLOAT,[1,1,97,97]> ⬅️ ::Cast(%"expand") {to=1}
      42 |  # node_clone
            %"clone"<FLOAT,[]> ⬅️ ::Identity(%"encoder.lifted_tensor_0"{1.0})
      43 |  # node_sub
            %"sub"<FLOAT,[1,1,97,97]> ⬅️ ::Sub(%"clone", %"_to_copy")
      44 |  # node__to_copy_1
            %"_to_copy_1"<BOOL,[1,1,97,97]> ⬅️ ::Cast(%"sub") {to=9}
      45 |  # node_Constant_34
            %"val_34"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(-3.4028235e+38, dtype=float32), name=None)}
      46 |  # node_CastLike_35
            %"val_35"<?,?> ⬅️ ::CastLike(%"val_34", %"sub")
      47 |  # node_masked_fill
            %"masked_fill"<FLOAT,[1,1,97,97]> ⬅️ ::Where(%"_to_copy_1", %"val_35", %"sub")
      48 |  # node_CastLike_36
            %"val_36"<?,?> ⬅️ ::CastLike(%"val_0", %"val_1")
      49 |  # node_CastLike_37
            %"val_37"<?,?> ⬅️ ::CastLike(%"val_3", %"val_1")
      50 |  # node_arange_1
            %"arange_1"<INT64,[97]> ⬅️ ::Range(%"val_36", %"val_1", %"val_37")
      51 |  # node_unsqueeze_3
            %"unsqueeze_3"<INT64,[1,97]> ⬅️ ::Unsqueeze(%"arange_1", %"val_5")
      52 |  # node_permute
            %"permute"<INT64,[97,1]> ⬅️ ::Transpose(%"unsqueeze_3") {perm=(1, 0)}
      53 |  # node_sub_1
            %"sub_1"<INT64,[97,97]> ⬅️ ::Sub(%"unsqueeze_3", %"permute")
      54 |  # node_abs_1
            %"abs_1"<INT64,[97,97]> ⬅️ ::Abs(%"sub_1")
      55 |  # node_Constant_38
            %"val_38"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(64), name=None)}
      56 |  # node_le
            %"le"<BOOL,[97,97]> ⬅️ ::LessOrEqual(%"abs_1", %"val_38")
      57 |  # node_unsqueeze_4
            %"unsqueeze_4"<BOOL,[1,97,97]> ⬅️ ::Unsqueeze(%"le", %"val_5")
      58 |  # node_unsqueeze_5
            %"unsqueeze_5"<BOOL,[1,1,97,97]> ⬅️ ::Unsqueeze(%"unsqueeze_4", %"val_5")
      59 |  # node_logical_not
            %"logical_not"<BOOL,[1,1,97,97]> ⬅️ ::Not(%"unsqueeze_5")
      60 |  # node_CastLike_39
            %"val_39"<?,?> ⬅️ ::CastLike(%"val_34", %"masked_fill")
      61 |  # node_masked_fill_1
            %"masked_fill_1"<FLOAT,[1,1,97,97]> ⬅️ ::Where(%"logical_not", %"val_39", %"masked_fill")
      62 |  # node_embedding
            %"embedding"<FLOAT,[1,97,768]> ⬅️ ::Gather(%"encoder.embeddings.tok_embeddings.weight"{...}, %"input_ids") {axis=0}
      63 |  # node_layer_norm
            %"layer_norm"<FLOAT,[1,97,768]>, %"val_40"<?,?>, %"val_41"<?,?> ⬅️ ::LayerNormalization(%"embedding", %"encoder.embeddings.norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
      64 |  # node_clone_1
            %"clone_1"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"layer_norm")
      65 |  # node_unsqueeze_6
            %"unsqueeze_6"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
      66 |  # node_Cast_40
            %"val_42"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      67 |  # node_Constant_41
            %"val_43"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      68 |  # node_Reshape_42
            %"val_44"<?,?> ⬅️ ::Reshape(%"val_42", %"val_43") {allowzero=0}
      69 |  # node_Cast_43
            %"val_45"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      70 |  # node_Constant_44
            %"val_46"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      71 |  # node_Reshape_45
            %"val_47"<?,?> ⬅️ ::Reshape(%"val_45", %"val_46") {allowzero=0}
      72 |  # node_Constant_46
            %"val_48"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(1), name=None)}
      73 |  # node_Cast_47
            %"val_49"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
      74 |  # node_Constant_48
            %"val_50"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      75 |  # node_Reshape_49
            %"val_51"<?,?> ⬅️ ::Reshape(%"val_49", %"val_50") {allowzero=0}
      76 |  # node_Constant_50
            %"val_52"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      77 |  # node_slice_3
            %"slice_3"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_6", %"val_44", %"val_47", %"val_51", %"val_52")
      78 |  # node_unsqueeze_7
            %"unsqueeze_7"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_3", %"val_19")
      79 |  # node_Constant_51
            %"val_53"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[3]>(array([ 1, -1,  1]), name=None)}
      80 |  # node_Cast_52
            %"val_54"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
      81 |  # node_Abs_53
            %"val_55"<?,?> ⬅️ ::Abs(%"val_54")
      82 |  # node_expand_1
            %"expand_1"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_7", %"val_55")
      83 |  # node_Cast_54
            %"val_56"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      84 |  # node_Constant_55
            %"val_57"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      85 |  # node_Reshape_56
            %"val_58"<?,?> ⬅️ ::Reshape(%"val_56", %"val_57") {allowzero=0}
      86 |  # node_Cast_57
            %"val_59"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      87 |  # node_Constant_58
            %"val_60"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      88 |  # node_Reshape_59
            %"val_61"<?,?> ⬅️ ::Reshape(%"val_59", %"val_60") {allowzero=0}
      89 |  # node_Cast_60
            %"val_62"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      90 |  # node_Constant_61
            %"val_63"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      91 |  # node_Reshape_62
            %"val_64"<?,?> ⬅️ ::Reshape(%"val_62", %"val_63") {allowzero=0}
      92 |  # node_Constant_63
            %"val_65"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      93 |  # node_slice_4
            %"slice_4"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_58", %"val_61", %"val_64", %"val_65")
      94 |  # node_unsqueeze_8
            %"unsqueeze_8"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_4", %"val_18")
      95 |  # node_Cast_64
            %"val_66"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      96 |  # node_Constant_65
            %"val_67"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      97 |  # node_Reshape_66
            %"val_68"<?,?> ⬅️ ::Reshape(%"val_66", %"val_67") {allowzero=0}
      98 |  # node_Cast_67
            %"val_69"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      99 |  # node_Constant_68
            %"val_70"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     100 |  # node_Reshape_69
            %"val_71"<?,?> ⬅️ ::Reshape(%"val_69", %"val_70") {allowzero=0}
     101 |  # node_Constant_70
            %"val_72"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(2), name=None)}
     102 |  # node_Cast_71
            %"val_73"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     103 |  # node_Constant_72
            %"val_74"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     104 |  # node_Reshape_73
            %"val_75"<?,?> ⬅️ ::Reshape(%"val_73", %"val_74") {allowzero=0}
     105 |  # node_Constant_74
            %"val_76"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     106 |  # node_slice_5
            %"slice_5"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_8", %"val_68", %"val_71", %"val_75", %"val_76")
     107 |  # node__to_copy_2
            %"_to_copy_2"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_5") {to=1}
     108 |  # node_matmul
            %"matmul"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_1", %"_to_copy_2")
     109 |  # node_transpose
            %"transpose"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul") {perm=(0, 2, 1)}
     110 |  # node_cat
            %"cat"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose", %"transpose") {axis=-1}
     111 |  # node_cos
            %"cos"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat")
     112 |  # node_mul
            %"mul"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos", %"val_3")
     113 |  # node_sin
            %"sin"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat")
     114 |  # node_mul_1
            %"mul_1"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin", %"val_3")
     115 |  # node_unsqueeze_9
            %"unsqueeze_9"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     116 |  # node_Cast_75
            %"val_77"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     117 |  # node_Constant_76
            %"val_78"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     118 |  # node_Reshape_77
            %"val_79"<?,?> ⬅️ ::Reshape(%"val_77", %"val_78") {allowzero=0}
     119 |  # node_Cast_78
            %"val_80"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     120 |  # node_Constant_79
            %"val_81"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     121 |  # node_Reshape_80
            %"val_82"<?,?> ⬅️ ::Reshape(%"val_80", %"val_81") {allowzero=0}
     122 |  # node_Cast_81
            %"val_83"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     123 |  # node_Constant_82
            %"val_84"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     124 |  # node_Reshape_83
            %"val_85"<?,?> ⬅️ ::Reshape(%"val_83", %"val_84") {allowzero=0}
     125 |  # node_Constant_84
            %"val_86"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     126 |  # node_slice_6
            %"slice_6"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_9", %"val_79", %"val_82", %"val_85", %"val_86")
     127 |  # node_unsqueeze_10
            %"unsqueeze_10"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_6", %"val_19")
     128 |  # node_Cast_85
            %"val_87"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     129 |  # node_Abs_86
            %"val_88"<?,?> ⬅️ ::Abs(%"val_87")
     130 |  # node_expand_2
            %"expand_2"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_10", %"val_88")
     131 |  # node_Cast_87
            %"val_89"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     132 |  # node_Constant_88
            %"val_90"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     133 |  # node_Reshape_89
            %"val_91"<?,?> ⬅️ ::Reshape(%"val_89", %"val_90") {allowzero=0}
     134 |  # node_Cast_90
            %"val_92"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     135 |  # node_Constant_91
            %"val_93"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     136 |  # node_Reshape_92
            %"val_94"<?,?> ⬅️ ::Reshape(%"val_92", %"val_93") {allowzero=0}
     137 |  # node_Cast_93
            %"val_95"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     138 |  # node_Constant_94
            %"val_96"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     139 |  # node_Reshape_95
            %"val_97"<?,?> ⬅️ ::Reshape(%"val_95", %"val_96") {allowzero=0}
     140 |  # node_Constant_96
            %"val_98"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     141 |  # node_slice_7
            %"slice_7"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_91", %"val_94", %"val_97", %"val_98")
     142 |  # node_unsqueeze_11
            %"unsqueeze_11"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_7", %"val_18")
     143 |  # node_Cast_97
            %"val_99"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     144 |  # node_Constant_98
            %"val_100"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     145 |  # node_Reshape_99
            %"val_101"<?,?> ⬅️ ::Reshape(%"val_99", %"val_100") {allowzero=0}
     146 |  # node_Cast_100
            %"val_102"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     147 |  # node_Constant_101
            %"val_103"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     148 |  # node_Reshape_102
            %"val_104"<?,?> ⬅️ ::Reshape(%"val_102", %"val_103") {allowzero=0}
     149 |  # node_Cast_103
            %"val_105"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     150 |  # node_Constant_104
            %"val_106"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     151 |  # node_Reshape_105
            %"val_107"<?,?> ⬅️ ::Reshape(%"val_105", %"val_106") {allowzero=0}
     152 |  # node_Constant_106
            %"val_108"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     153 |  # node_slice_8
            %"slice_8"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_11", %"val_101", %"val_104", %"val_107", %"val_108")
     154 |  # node__to_copy_3
            %"_to_copy_3"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_8") {to=1}
     155 |  # node_matmul_1
            %"matmul_1"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_2", %"_to_copy_3")
     156 |  # node_transpose_1
            %"transpose_1"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_1") {perm=(0, 2, 1)}
     157 |  # node_cat_1
            %"cat_1"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_1", %"transpose_1") {axis=-1}
     158 |  # node_cos_1
            %"cos_1"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_1")
     159 |  # node_mul_2
            %"mul_2"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_1", %"val_3")
     160 |  # node_sin_1
            %"sin_1"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_1")
     161 |  # node_mul_3
            %"mul_3"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_1", %"val_3")
     162 |  # node_unsqueeze_12
            %"unsqueeze_12"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     163 |  # node_Cast_107
            %"val_109"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     164 |  # node_Constant_108
            %"val_110"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     165 |  # node_Reshape_109
            %"val_111"<?,?> ⬅️ ::Reshape(%"val_109", %"val_110") {allowzero=0}
     166 |  # node_Cast_110
            %"val_112"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     167 |  # node_Constant_111
            %"val_113"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     168 |  # node_Reshape_112
            %"val_114"<?,?> ⬅️ ::Reshape(%"val_112", %"val_113") {allowzero=0}
     169 |  # node_Cast_113
            %"val_115"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     170 |  # node_Constant_114
            %"val_116"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     171 |  # node_Reshape_115
            %"val_117"<?,?> ⬅️ ::Reshape(%"val_115", %"val_116") {allowzero=0}
     172 |  # node_Constant_116
            %"val_118"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     173 |  # node_slice_9
            %"slice_9"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_12", %"val_111", %"val_114", %"val_117", %"val_118")
     174 |  # node_unsqueeze_13
            %"unsqueeze_13"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_9", %"val_19")
     175 |  # node_Cast_117
            %"val_119"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     176 |  # node_Abs_118
            %"val_120"<?,?> ⬅️ ::Abs(%"val_119")
     177 |  # node_expand_3
            %"expand_3"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_13", %"val_120")
     178 |  # node_Cast_119
            %"val_121"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     179 |  # node_Constant_120
            %"val_122"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     180 |  # node_Reshape_121
            %"val_123"<?,?> ⬅️ ::Reshape(%"val_121", %"val_122") {allowzero=0}
     181 |  # node_Cast_122
            %"val_124"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     182 |  # node_Constant_123
            %"val_125"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     183 |  # node_Reshape_124
            %"val_126"<?,?> ⬅️ ::Reshape(%"val_124", %"val_125") {allowzero=0}
     184 |  # node_Cast_125
            %"val_127"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     185 |  # node_Constant_126
            %"val_128"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     186 |  # node_Reshape_127
            %"val_129"<?,?> ⬅️ ::Reshape(%"val_127", %"val_128") {allowzero=0}
     187 |  # node_Constant_128
            %"val_130"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     188 |  # node_slice_10
            %"slice_10"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_123", %"val_126", %"val_129", %"val_130")
     189 |  # node_unsqueeze_14
            %"unsqueeze_14"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_10", %"val_18")
     190 |  # node_Cast_129
            %"val_131"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     191 |  # node_Constant_130
            %"val_132"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     192 |  # node_Reshape_131
            %"val_133"<?,?> ⬅️ ::Reshape(%"val_131", %"val_132") {allowzero=0}
     193 |  # node_Cast_132
            %"val_134"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     194 |  # node_Constant_133
            %"val_135"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     195 |  # node_Reshape_134
            %"val_136"<?,?> ⬅️ ::Reshape(%"val_134", %"val_135") {allowzero=0}
     196 |  # node_Cast_135
            %"val_137"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     197 |  # node_Constant_136
            %"val_138"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     198 |  # node_Reshape_137
            %"val_139"<?,?> ⬅️ ::Reshape(%"val_137", %"val_138") {allowzero=0}
     199 |  # node_Constant_138
            %"val_140"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     200 |  # node_slice_11
            %"slice_11"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_14", %"val_133", %"val_136", %"val_139", %"val_140")
     201 |  # node__to_copy_4
            %"_to_copy_4"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_11") {to=1}
     202 |  # node_matmul_2
            %"matmul_2"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_3", %"_to_copy_4")
     203 |  # node_transpose_2
            %"transpose_2"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_2") {perm=(0, 2, 1)}
     204 |  # node_cat_2
            %"cat_2"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_2", %"transpose_2") {axis=-1}
     205 |  # node_cos_2
            %"cos_2"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_2")
     206 |  # node_mul_4
            %"mul_4"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_2", %"val_3")
     207 |  # node_sin_2
            %"sin_2"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_2")
     208 |  # node_mul_5
            %"mul_5"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_2", %"val_3")
     209 |  # node_unsqueeze_15
            %"unsqueeze_15"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     210 |  # node_Cast_139
            %"val_141"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     211 |  # node_Constant_140
            %"val_142"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     212 |  # node_Reshape_141
            %"val_143"<?,?> ⬅️ ::Reshape(%"val_141", %"val_142") {allowzero=0}
     213 |  # node_Cast_142
            %"val_144"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     214 |  # node_Constant_143
            %"val_145"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     215 |  # node_Reshape_144
            %"val_146"<?,?> ⬅️ ::Reshape(%"val_144", %"val_145") {allowzero=0}
     216 |  # node_Cast_145
            %"val_147"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     217 |  # node_Constant_146
            %"val_148"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     218 |  # node_Reshape_147
            %"val_149"<?,?> ⬅️ ::Reshape(%"val_147", %"val_148") {allowzero=0}
     219 |  # node_Constant_148
            %"val_150"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     220 |  # node_slice_12
            %"slice_12"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_15", %"val_143", %"val_146", %"val_149", %"val_150")
     221 |  # node_unsqueeze_16
            %"unsqueeze_16"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_12", %"val_19")
     222 |  # node_Cast_149
            %"val_151"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     223 |  # node_Abs_150
            %"val_152"<?,?> ⬅️ ::Abs(%"val_151")
     224 |  # node_expand_4
            %"expand_4"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_16", %"val_152")
     225 |  # node_Cast_151
            %"val_153"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     226 |  # node_Constant_152
            %"val_154"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     227 |  # node_Reshape_153
            %"val_155"<?,?> ⬅️ ::Reshape(%"val_153", %"val_154") {allowzero=0}
     228 |  # node_Cast_154
            %"val_156"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     229 |  # node_Constant_155
            %"val_157"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     230 |  # node_Reshape_156
            %"val_158"<?,?> ⬅️ ::Reshape(%"val_156", %"val_157") {allowzero=0}
     231 |  # node_Cast_157
            %"val_159"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     232 |  # node_Constant_158
            %"val_160"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     233 |  # node_Reshape_159
            %"val_161"<?,?> ⬅️ ::Reshape(%"val_159", %"val_160") {allowzero=0}
     234 |  # node_Constant_160
            %"val_162"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     235 |  # node_slice_13
            %"slice_13"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_155", %"val_158", %"val_161", %"val_162")
     236 |  # node_unsqueeze_17
            %"unsqueeze_17"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_13", %"val_18")
     237 |  # node_Cast_161
            %"val_163"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     238 |  # node_Constant_162
            %"val_164"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     239 |  # node_Reshape_163
            %"val_165"<?,?> ⬅️ ::Reshape(%"val_163", %"val_164") {allowzero=0}
     240 |  # node_Cast_164
            %"val_166"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     241 |  # node_Constant_165
            %"val_167"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     242 |  # node_Reshape_166
            %"val_168"<?,?> ⬅️ ::Reshape(%"val_166", %"val_167") {allowzero=0}
     243 |  # node_Cast_167
            %"val_169"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     244 |  # node_Constant_168
            %"val_170"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     245 |  # node_Reshape_169
            %"val_171"<?,?> ⬅️ ::Reshape(%"val_169", %"val_170") {allowzero=0}
     246 |  # node_Constant_170
            %"val_172"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     247 |  # node_slice_14
            %"slice_14"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_17", %"val_165", %"val_168", %"val_171", %"val_172")
     248 |  # node__to_copy_5
            %"_to_copy_5"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_14") {to=1}
     249 |  # node_matmul_3
            %"matmul_3"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_4", %"_to_copy_5")
     250 |  # node_transpose_3
            %"transpose_3"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_3") {perm=(0, 2, 1)}
     251 |  # node_cat_3
            %"cat_3"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_3", %"transpose_3") {axis=-1}
     252 |  # node_cos_3
            %"cos_3"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_3")
     253 |  # node_mul_6
            %"mul_6"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_3", %"val_3")
     254 |  # node_sin_3
            %"sin_3"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_3")
     255 |  # node_mul_7
            %"mul_7"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_3", %"val_3")
     256 |  # node_unsqueeze_18
            %"unsqueeze_18"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     257 |  # node_Cast_171
            %"val_173"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     258 |  # node_Constant_172
            %"val_174"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     259 |  # node_Reshape_173
            %"val_175"<?,?> ⬅️ ::Reshape(%"val_173", %"val_174") {allowzero=0}
     260 |  # node_Cast_174
            %"val_176"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     261 |  # node_Constant_175
            %"val_177"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     262 |  # node_Reshape_176
            %"val_178"<?,?> ⬅️ ::Reshape(%"val_176", %"val_177") {allowzero=0}
     263 |  # node_Cast_177
            %"val_179"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     264 |  # node_Constant_178
            %"val_180"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     265 |  # node_Reshape_179
            %"val_181"<?,?> ⬅️ ::Reshape(%"val_179", %"val_180") {allowzero=0}
     266 |  # node_Constant_180
            %"val_182"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     267 |  # node_slice_15
            %"slice_15"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_18", %"val_175", %"val_178", %"val_181", %"val_182")
     268 |  # node_unsqueeze_19
            %"unsqueeze_19"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_15", %"val_19")
     269 |  # node_Cast_181
            %"val_183"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     270 |  # node_Abs_182
            %"val_184"<?,?> ⬅️ ::Abs(%"val_183")
     271 |  # node_expand_5
            %"expand_5"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_19", %"val_184")
     272 |  # node_Cast_183
            %"val_185"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     273 |  # node_Constant_184
            %"val_186"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     274 |  # node_Reshape_185
            %"val_187"<?,?> ⬅️ ::Reshape(%"val_185", %"val_186") {allowzero=0}
     275 |  # node_Cast_186
            %"val_188"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     276 |  # node_Constant_187
            %"val_189"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     277 |  # node_Reshape_188
            %"val_190"<?,?> ⬅️ ::Reshape(%"val_188", %"val_189") {allowzero=0}
     278 |  # node_Cast_189
            %"val_191"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     279 |  # node_Constant_190
            %"val_192"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     280 |  # node_Reshape_191
            %"val_193"<?,?> ⬅️ ::Reshape(%"val_191", %"val_192") {allowzero=0}
     281 |  # node_Constant_192
            %"val_194"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     282 |  # node_slice_16
            %"slice_16"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_187", %"val_190", %"val_193", %"val_194")
     283 |  # node_unsqueeze_20
            %"unsqueeze_20"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_16", %"val_18")
     284 |  # node_Cast_193
            %"val_195"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     285 |  # node_Constant_194
            %"val_196"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     286 |  # node_Reshape_195
            %"val_197"<?,?> ⬅️ ::Reshape(%"val_195", %"val_196") {allowzero=0}
     287 |  # node_Cast_196
            %"val_198"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     288 |  # node_Constant_197
            %"val_199"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     289 |  # node_Reshape_198
            %"val_200"<?,?> ⬅️ ::Reshape(%"val_198", %"val_199") {allowzero=0}
     290 |  # node_Cast_199
            %"val_201"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     291 |  # node_Constant_200
            %"val_202"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     292 |  # node_Reshape_201
            %"val_203"<?,?> ⬅️ ::Reshape(%"val_201", %"val_202") {allowzero=0}
     293 |  # node_Constant_202
            %"val_204"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     294 |  # node_slice_17
            %"slice_17"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_20", %"val_197", %"val_200", %"val_203", %"val_204")
     295 |  # node__to_copy_6
            %"_to_copy_6"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_17") {to=1}
     296 |  # node_matmul_4
            %"matmul_4"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_5", %"_to_copy_6")
     297 |  # node_transpose_4
            %"transpose_4"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_4") {perm=(0, 2, 1)}
     298 |  # node_cat_4
            %"cat_4"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_4", %"transpose_4") {axis=-1}
     299 |  # node_cos_4
            %"cos_4"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_4")
     300 |  # node_mul_8
            %"mul_8"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_4", %"val_3")
     301 |  # node_sin_4
            %"sin_4"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_4")
     302 |  # node_mul_9
            %"mul_9"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_4", %"val_3")
     303 |  # node_unsqueeze_21
            %"unsqueeze_21"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     304 |  # node_Cast_203
            %"val_205"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     305 |  # node_Constant_204
            %"val_206"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     306 |  # node_Reshape_205
            %"val_207"<?,?> ⬅️ ::Reshape(%"val_205", %"val_206") {allowzero=0}
     307 |  # node_Cast_206
            %"val_208"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     308 |  # node_Constant_207
            %"val_209"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     309 |  # node_Reshape_208
            %"val_210"<?,?> ⬅️ ::Reshape(%"val_208", %"val_209") {allowzero=0}
     310 |  # node_Cast_209
            %"val_211"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     311 |  # node_Constant_210
            %"val_212"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     312 |  # node_Reshape_211
            %"val_213"<?,?> ⬅️ ::Reshape(%"val_211", %"val_212") {allowzero=0}
     313 |  # node_Constant_212
            %"val_214"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     314 |  # node_slice_18
            %"slice_18"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_21", %"val_207", %"val_210", %"val_213", %"val_214")
     315 |  # node_unsqueeze_22
            %"unsqueeze_22"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_18", %"val_19")
     316 |  # node_Cast_213
            %"val_215"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     317 |  # node_Abs_214
            %"val_216"<?,?> ⬅️ ::Abs(%"val_215")
     318 |  # node_expand_6
            %"expand_6"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_22", %"val_216")
     319 |  # node_Cast_215
            %"val_217"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     320 |  # node_Constant_216
            %"val_218"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     321 |  # node_Reshape_217
            %"val_219"<?,?> ⬅️ ::Reshape(%"val_217", %"val_218") {allowzero=0}
     322 |  # node_Cast_218
            %"val_220"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     323 |  # node_Constant_219
            %"val_221"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     324 |  # node_Reshape_220
            %"val_222"<?,?> ⬅️ ::Reshape(%"val_220", %"val_221") {allowzero=0}
     325 |  # node_Cast_221
            %"val_223"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     326 |  # node_Constant_222
            %"val_224"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     327 |  # node_Reshape_223
            %"val_225"<?,?> ⬅️ ::Reshape(%"val_223", %"val_224") {allowzero=0}
     328 |  # node_Constant_224
            %"val_226"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     329 |  # node_slice_19
            %"slice_19"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_219", %"val_222", %"val_225", %"val_226")
     330 |  # node_unsqueeze_23
            %"unsqueeze_23"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_19", %"val_18")
     331 |  # node_Cast_225
            %"val_227"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     332 |  # node_Constant_226
            %"val_228"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     333 |  # node_Reshape_227
            %"val_229"<?,?> ⬅️ ::Reshape(%"val_227", %"val_228") {allowzero=0}
     334 |  # node_Cast_228
            %"val_230"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     335 |  # node_Constant_229
            %"val_231"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     336 |  # node_Reshape_230
            %"val_232"<?,?> ⬅️ ::Reshape(%"val_230", %"val_231") {allowzero=0}
     337 |  # node_Cast_231
            %"val_233"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     338 |  # node_Constant_232
            %"val_234"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     339 |  # node_Reshape_233
            %"val_235"<?,?> ⬅️ ::Reshape(%"val_233", %"val_234") {allowzero=0}
     340 |  # node_Constant_234
            %"val_236"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     341 |  # node_slice_20
            %"slice_20"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_23", %"val_229", %"val_232", %"val_235", %"val_236")
     342 |  # node__to_copy_7
            %"_to_copy_7"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_20") {to=1}
     343 |  # node_matmul_5
            %"matmul_5"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_6", %"_to_copy_7")
     344 |  # node_transpose_5
            %"transpose_5"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_5") {perm=(0, 2, 1)}
     345 |  # node_cat_5
            %"cat_5"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_5", %"transpose_5") {axis=-1}
     346 |  # node_cos_5
            %"cos_5"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_5")
     347 |  # node_mul_10
            %"mul_10"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_5", %"val_3")
     348 |  # node_sin_5
            %"sin_5"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_5")
     349 |  # node_mul_11
            %"mul_11"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_5", %"val_3")
     350 |  # node_unsqueeze_24
            %"unsqueeze_24"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     351 |  # node_Cast_235
            %"val_237"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     352 |  # node_Constant_236
            %"val_238"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     353 |  # node_Reshape_237
            %"val_239"<?,?> ⬅️ ::Reshape(%"val_237", %"val_238") {allowzero=0}
     354 |  # node_Cast_238
            %"val_240"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     355 |  # node_Constant_239
            %"val_241"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     356 |  # node_Reshape_240
            %"val_242"<?,?> ⬅️ ::Reshape(%"val_240", %"val_241") {allowzero=0}
     357 |  # node_Cast_241
            %"val_243"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     358 |  # node_Constant_242
            %"val_244"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     359 |  # node_Reshape_243
            %"val_245"<?,?> ⬅️ ::Reshape(%"val_243", %"val_244") {allowzero=0}
     360 |  # node_Constant_244
            %"val_246"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     361 |  # node_slice_21
            %"slice_21"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_24", %"val_239", %"val_242", %"val_245", %"val_246")
     362 |  # node_unsqueeze_25
            %"unsqueeze_25"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_21", %"val_19")
     363 |  # node_Cast_245
            %"val_247"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     364 |  # node_Abs_246
            %"val_248"<?,?> ⬅️ ::Abs(%"val_247")
     365 |  # node_expand_7
            %"expand_7"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_25", %"val_248")
     366 |  # node_Cast_247
            %"val_249"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     367 |  # node_Constant_248
            %"val_250"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     368 |  # node_Reshape_249
            %"val_251"<?,?> ⬅️ ::Reshape(%"val_249", %"val_250") {allowzero=0}
     369 |  # node_Cast_250
            %"val_252"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     370 |  # node_Constant_251
            %"val_253"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     371 |  # node_Reshape_252
            %"val_254"<?,?> ⬅️ ::Reshape(%"val_252", %"val_253") {allowzero=0}
     372 |  # node_Cast_253
            %"val_255"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     373 |  # node_Constant_254
            %"val_256"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     374 |  # node_Reshape_255
            %"val_257"<?,?> ⬅️ ::Reshape(%"val_255", %"val_256") {allowzero=0}
     375 |  # node_Constant_256
            %"val_258"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     376 |  # node_slice_22
            %"slice_22"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_251", %"val_254", %"val_257", %"val_258")
     377 |  # node_unsqueeze_26
            %"unsqueeze_26"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_22", %"val_18")
     378 |  # node_Cast_257
            %"val_259"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     379 |  # node_Constant_258
            %"val_260"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     380 |  # node_Reshape_259
            %"val_261"<?,?> ⬅️ ::Reshape(%"val_259", %"val_260") {allowzero=0}
     381 |  # node_Cast_260
            %"val_262"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     382 |  # node_Constant_261
            %"val_263"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     383 |  # node_Reshape_262
            %"val_264"<?,?> ⬅️ ::Reshape(%"val_262", %"val_263") {allowzero=0}
     384 |  # node_Cast_263
            %"val_265"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     385 |  # node_Constant_264
            %"val_266"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     386 |  # node_Reshape_265
            %"val_267"<?,?> ⬅️ ::Reshape(%"val_265", %"val_266") {allowzero=0}
     387 |  # node_Constant_266
            %"val_268"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     388 |  # node_slice_23
            %"slice_23"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_26", %"val_261", %"val_264", %"val_267", %"val_268")
     389 |  # node__to_copy_8
            %"_to_copy_8"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_23") {to=1}
     390 |  # node_matmul_6
            %"matmul_6"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_7", %"_to_copy_8")
     391 |  # node_transpose_6
            %"transpose_6"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_6") {perm=(0, 2, 1)}
     392 |  # node_cat_6
            %"cat_6"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_6", %"transpose_6") {axis=-1}
     393 |  # node_cos_6
            %"cos_6"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_6")
     394 |  # node_mul_12
            %"mul_12"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_6", %"val_3")
     395 |  # node_sin_6
            %"sin_6"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_6")
     396 |  # node_mul_13
            %"mul_13"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_6", %"val_3")
     397 |  # node_unsqueeze_27
            %"unsqueeze_27"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     398 |  # node_Cast_267
            %"val_269"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     399 |  # node_Constant_268
            %"val_270"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     400 |  # node_Reshape_269
            %"val_271"<?,?> ⬅️ ::Reshape(%"val_269", %"val_270") {allowzero=0}
     401 |  # node_Cast_270
            %"val_272"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     402 |  # node_Constant_271
            %"val_273"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     403 |  # node_Reshape_272
            %"val_274"<?,?> ⬅️ ::Reshape(%"val_272", %"val_273") {allowzero=0}
     404 |  # node_Cast_273
            %"val_275"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     405 |  # node_Constant_274
            %"val_276"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     406 |  # node_Reshape_275
            %"val_277"<?,?> ⬅️ ::Reshape(%"val_275", %"val_276") {allowzero=0}
     407 |  # node_Constant_276
            %"val_278"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     408 |  # node_slice_24
            %"slice_24"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_27", %"val_271", %"val_274", %"val_277", %"val_278")
     409 |  # node_unsqueeze_28
            %"unsqueeze_28"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_24", %"val_19")
     410 |  # node_Cast_277
            %"val_279"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     411 |  # node_Abs_278
            %"val_280"<?,?> ⬅️ ::Abs(%"val_279")
     412 |  # node_expand_8
            %"expand_8"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_28", %"val_280")
     413 |  # node_Cast_279
            %"val_281"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     414 |  # node_Constant_280
            %"val_282"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     415 |  # node_Reshape_281
            %"val_283"<?,?> ⬅️ ::Reshape(%"val_281", %"val_282") {allowzero=0}
     416 |  # node_Cast_282
            %"val_284"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     417 |  # node_Constant_283
            %"val_285"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     418 |  # node_Reshape_284
            %"val_286"<?,?> ⬅️ ::Reshape(%"val_284", %"val_285") {allowzero=0}
     419 |  # node_Cast_285
            %"val_287"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     420 |  # node_Constant_286
            %"val_288"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     421 |  # node_Reshape_287
            %"val_289"<?,?> ⬅️ ::Reshape(%"val_287", %"val_288") {allowzero=0}
     422 |  # node_Constant_288
            %"val_290"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     423 |  # node_slice_25
            %"slice_25"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_283", %"val_286", %"val_289", %"val_290")
     424 |  # node_unsqueeze_29
            %"unsqueeze_29"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_25", %"val_18")
     425 |  # node_Cast_289
            %"val_291"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     426 |  # node_Constant_290
            %"val_292"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     427 |  # node_Reshape_291
            %"val_293"<?,?> ⬅️ ::Reshape(%"val_291", %"val_292") {allowzero=0}
     428 |  # node_Cast_292
            %"val_294"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     429 |  # node_Constant_293
            %"val_295"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     430 |  # node_Reshape_294
            %"val_296"<?,?> ⬅️ ::Reshape(%"val_294", %"val_295") {allowzero=0}
     431 |  # node_Cast_295
            %"val_297"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     432 |  # node_Constant_296
            %"val_298"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     433 |  # node_Reshape_297
            %"val_299"<?,?> ⬅️ ::Reshape(%"val_297", %"val_298") {allowzero=0}
     434 |  # node_Constant_298
            %"val_300"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     435 |  # node_slice_26
            %"slice_26"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_29", %"val_293", %"val_296", %"val_299", %"val_300")
     436 |  # node__to_copy_9
            %"_to_copy_9"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_26") {to=1}
     437 |  # node_matmul_7
            %"matmul_7"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_8", %"_to_copy_9")
     438 |  # node_transpose_7
            %"transpose_7"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_7") {perm=(0, 2, 1)}
     439 |  # node_cat_7
            %"cat_7"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_7", %"transpose_7") {axis=-1}
     440 |  # node_cos_7
            %"cos_7"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_7")
     441 |  # node_mul_14
            %"mul_14"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_7", %"val_3")
     442 |  # node_sin_7
            %"sin_7"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_7")
     443 |  # node_mul_15
            %"mul_15"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_7", %"val_3")
     444 |  # node_unsqueeze_30
            %"unsqueeze_30"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     445 |  # node_Cast_299
            %"val_301"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     446 |  # node_Constant_300
            %"val_302"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     447 |  # node_Reshape_301
            %"val_303"<?,?> ⬅️ ::Reshape(%"val_301", %"val_302") {allowzero=0}
     448 |  # node_Cast_302
            %"val_304"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     449 |  # node_Constant_303
            %"val_305"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     450 |  # node_Reshape_304
            %"val_306"<?,?> ⬅️ ::Reshape(%"val_304", %"val_305") {allowzero=0}
     451 |  # node_Cast_305
            %"val_307"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     452 |  # node_Constant_306
            %"val_308"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     453 |  # node_Reshape_307
            %"val_309"<?,?> ⬅️ ::Reshape(%"val_307", %"val_308") {allowzero=0}
     454 |  # node_Constant_308
            %"val_310"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     455 |  # node_slice_27
            %"slice_27"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_30", %"val_303", %"val_306", %"val_309", %"val_310")
     456 |  # node_unsqueeze_31
            %"unsqueeze_31"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_27", %"val_19")
     457 |  # node_Cast_309
            %"val_311"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     458 |  # node_Abs_310
            %"val_312"<?,?> ⬅️ ::Abs(%"val_311")
     459 |  # node_expand_9
            %"expand_9"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_31", %"val_312")
     460 |  # node_Cast_311
            %"val_313"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     461 |  # node_Constant_312
            %"val_314"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     462 |  # node_Reshape_313
            %"val_315"<?,?> ⬅️ ::Reshape(%"val_313", %"val_314") {allowzero=0}
     463 |  # node_Cast_314
            %"val_316"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     464 |  # node_Constant_315
            %"val_317"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     465 |  # node_Reshape_316
            %"val_318"<?,?> ⬅️ ::Reshape(%"val_316", %"val_317") {allowzero=0}
     466 |  # node_Cast_317
            %"val_319"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     467 |  # node_Constant_318
            %"val_320"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     468 |  # node_Reshape_319
            %"val_321"<?,?> ⬅️ ::Reshape(%"val_319", %"val_320") {allowzero=0}
     469 |  # node_Constant_320
            %"val_322"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     470 |  # node_slice_28
            %"slice_28"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_315", %"val_318", %"val_321", %"val_322")
     471 |  # node_unsqueeze_32
            %"unsqueeze_32"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_28", %"val_18")
     472 |  # node_Cast_321
            %"val_323"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     473 |  # node_Constant_322
            %"val_324"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     474 |  # node_Reshape_323
            %"val_325"<?,?> ⬅️ ::Reshape(%"val_323", %"val_324") {allowzero=0}
     475 |  # node_Cast_324
            %"val_326"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     476 |  # node_Constant_325
            %"val_327"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     477 |  # node_Reshape_326
            %"val_328"<?,?> ⬅️ ::Reshape(%"val_326", %"val_327") {allowzero=0}
     478 |  # node_Cast_327
            %"val_329"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     479 |  # node_Constant_328
            %"val_330"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     480 |  # node_Reshape_329
            %"val_331"<?,?> ⬅️ ::Reshape(%"val_329", %"val_330") {allowzero=0}
     481 |  # node_Constant_330
            %"val_332"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     482 |  # node_slice_29
            %"slice_29"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_32", %"val_325", %"val_328", %"val_331", %"val_332")
     483 |  # node__to_copy_10
            %"_to_copy_10"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_29") {to=1}
     484 |  # node_matmul_8
            %"matmul_8"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_9", %"_to_copy_10")
     485 |  # node_transpose_8
            %"transpose_8"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_8") {perm=(0, 2, 1)}
     486 |  # node_cat_8
            %"cat_8"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_8", %"transpose_8") {axis=-1}
     487 |  # node_cos_8
            %"cos_8"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_8")
     488 |  # node_mul_16
            %"mul_16"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_8", %"val_3")
     489 |  # node_sin_8
            %"sin_8"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_8")
     490 |  # node_mul_17
            %"mul_17"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_8", %"val_3")
     491 |  # node_unsqueeze_33
            %"unsqueeze_33"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     492 |  # node_Cast_331
            %"val_333"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     493 |  # node_Constant_332
            %"val_334"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     494 |  # node_Reshape_333
            %"val_335"<?,?> ⬅️ ::Reshape(%"val_333", %"val_334") {allowzero=0}
     495 |  # node_Cast_334
            %"val_336"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     496 |  # node_Constant_335
            %"val_337"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     497 |  # node_Reshape_336
            %"val_338"<?,?> ⬅️ ::Reshape(%"val_336", %"val_337") {allowzero=0}
     498 |  # node_Cast_337
            %"val_339"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     499 |  # node_Constant_338
            %"val_340"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     500 |  # node_Reshape_339
            %"val_341"<?,?> ⬅️ ::Reshape(%"val_339", %"val_340") {allowzero=0}
     501 |  # node_Constant_340
            %"val_342"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     502 |  # node_slice_30
            %"slice_30"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_33", %"val_335", %"val_338", %"val_341", %"val_342")
     503 |  # node_unsqueeze_34
            %"unsqueeze_34"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_30", %"val_19")
     504 |  # node_Cast_341
            %"val_343"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     505 |  # node_Abs_342
            %"val_344"<?,?> ⬅️ ::Abs(%"val_343")
     506 |  # node_expand_10
            %"expand_10"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_34", %"val_344")
     507 |  # node_Cast_343
            %"val_345"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     508 |  # node_Constant_344
            %"val_346"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     509 |  # node_Reshape_345
            %"val_347"<?,?> ⬅️ ::Reshape(%"val_345", %"val_346") {allowzero=0}
     510 |  # node_Cast_346
            %"val_348"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     511 |  # node_Constant_347
            %"val_349"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     512 |  # node_Reshape_348
            %"val_350"<?,?> ⬅️ ::Reshape(%"val_348", %"val_349") {allowzero=0}
     513 |  # node_Cast_349
            %"val_351"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     514 |  # node_Constant_350
            %"val_352"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     515 |  # node_Reshape_351
            %"val_353"<?,?> ⬅️ ::Reshape(%"val_351", %"val_352") {allowzero=0}
     516 |  # node_Constant_352
            %"val_354"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     517 |  # node_slice_31
            %"slice_31"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_347", %"val_350", %"val_353", %"val_354")
     518 |  # node_unsqueeze_35
            %"unsqueeze_35"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_31", %"val_18")
     519 |  # node_Cast_353
            %"val_355"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     520 |  # node_Constant_354
            %"val_356"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     521 |  # node_Reshape_355
            %"val_357"<?,?> ⬅️ ::Reshape(%"val_355", %"val_356") {allowzero=0}
     522 |  # node_Cast_356
            %"val_358"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     523 |  # node_Constant_357
            %"val_359"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     524 |  # node_Reshape_358
            %"val_360"<?,?> ⬅️ ::Reshape(%"val_358", %"val_359") {allowzero=0}
     525 |  # node_Cast_359
            %"val_361"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     526 |  # node_Constant_360
            %"val_362"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     527 |  # node_Reshape_361
            %"val_363"<?,?> ⬅️ ::Reshape(%"val_361", %"val_362") {allowzero=0}
     528 |  # node_Constant_362
            %"val_364"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     529 |  # node_slice_32
            %"slice_32"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_35", %"val_357", %"val_360", %"val_363", %"val_364")
     530 |  # node__to_copy_11
            %"_to_copy_11"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_32") {to=1}
     531 |  # node_matmul_9
            %"matmul_9"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_10", %"_to_copy_11")
     532 |  # node_transpose_9
            %"transpose_9"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_9") {perm=(0, 2, 1)}
     533 |  # node_cat_9
            %"cat_9"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_9", %"transpose_9") {axis=-1}
     534 |  # node_cos_9
            %"cos_9"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_9")
     535 |  # node_mul_18
            %"mul_18"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_9", %"val_3")
     536 |  # node_sin_9
            %"sin_9"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_9")
     537 |  # node_mul_19
            %"mul_19"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_9", %"val_3")
     538 |  # node_unsqueeze_36
            %"unsqueeze_36"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     539 |  # node_Cast_363
            %"val_365"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     540 |  # node_Constant_364
            %"val_366"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     541 |  # node_Reshape_365
            %"val_367"<?,?> ⬅️ ::Reshape(%"val_365", %"val_366") {allowzero=0}
     542 |  # node_Cast_366
            %"val_368"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     543 |  # node_Constant_367
            %"val_369"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     544 |  # node_Reshape_368
            %"val_370"<?,?> ⬅️ ::Reshape(%"val_368", %"val_369") {allowzero=0}
     545 |  # node_Cast_369
            %"val_371"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     546 |  # node_Constant_370
            %"val_372"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     547 |  # node_Reshape_371
            %"val_373"<?,?> ⬅️ ::Reshape(%"val_371", %"val_372") {allowzero=0}
     548 |  # node_Constant_372
            %"val_374"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     549 |  # node_slice_33
            %"slice_33"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_36", %"val_367", %"val_370", %"val_373", %"val_374")
     550 |  # node_unsqueeze_37
            %"unsqueeze_37"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_33", %"val_19")
     551 |  # node_Cast_373
            %"val_375"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     552 |  # node_Abs_374
            %"val_376"<?,?> ⬅️ ::Abs(%"val_375")
     553 |  # node_expand_11
            %"expand_11"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_37", %"val_376")
     554 |  # node_Cast_375
            %"val_377"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     555 |  # node_Constant_376
            %"val_378"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     556 |  # node_Reshape_377
            %"val_379"<?,?> ⬅️ ::Reshape(%"val_377", %"val_378") {allowzero=0}
     557 |  # node_Cast_378
            %"val_380"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     558 |  # node_Constant_379
            %"val_381"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     559 |  # node_Reshape_380
            %"val_382"<?,?> ⬅️ ::Reshape(%"val_380", %"val_381") {allowzero=0}
     560 |  # node_Cast_381
            %"val_383"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     561 |  # node_Constant_382
            %"val_384"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     562 |  # node_Reshape_383
            %"val_385"<?,?> ⬅️ ::Reshape(%"val_383", %"val_384") {allowzero=0}
     563 |  # node_Constant_384
            %"val_386"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     564 |  # node_slice_34
            %"slice_34"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_379", %"val_382", %"val_385", %"val_386")
     565 |  # node_unsqueeze_38
            %"unsqueeze_38"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_34", %"val_18")
     566 |  # node_Cast_385
            %"val_387"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     567 |  # node_Constant_386
            %"val_388"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     568 |  # node_Reshape_387
            %"val_389"<?,?> ⬅️ ::Reshape(%"val_387", %"val_388") {allowzero=0}
     569 |  # node_Cast_388
            %"val_390"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     570 |  # node_Constant_389
            %"val_391"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     571 |  # node_Reshape_390
            %"val_392"<?,?> ⬅️ ::Reshape(%"val_390", %"val_391") {allowzero=0}
     572 |  # node_Cast_391
            %"val_393"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     573 |  # node_Constant_392
            %"val_394"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     574 |  # node_Reshape_393
            %"val_395"<?,?> ⬅️ ::Reshape(%"val_393", %"val_394") {allowzero=0}
     575 |  # node_Constant_394
            %"val_396"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     576 |  # node_slice_35
            %"slice_35"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_38", %"val_389", %"val_392", %"val_395", %"val_396")
     577 |  # node__to_copy_12
            %"_to_copy_12"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_35") {to=1}
     578 |  # node_matmul_10
            %"matmul_10"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_11", %"_to_copy_12")
     579 |  # node_transpose_10
            %"transpose_10"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_10") {perm=(0, 2, 1)}
     580 |  # node_cat_10
            %"cat_10"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_10", %"transpose_10") {axis=-1}
     581 |  # node_cos_10
            %"cos_10"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_10")
     582 |  # node_mul_20
            %"mul_20"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_10", %"val_3")
     583 |  # node_sin_10
            %"sin_10"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_10")
     584 |  # node_mul_21
            %"mul_21"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_10", %"val_3")
     585 |  # node_unsqueeze_39
            %"unsqueeze_39"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     586 |  # node_Cast_395
            %"val_397"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     587 |  # node_Constant_396
            %"val_398"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     588 |  # node_Reshape_397
            %"val_399"<?,?> ⬅️ ::Reshape(%"val_397", %"val_398") {allowzero=0}
     589 |  # node_Cast_398
            %"val_400"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     590 |  # node_Constant_399
            %"val_401"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     591 |  # node_Reshape_400
            %"val_402"<?,?> ⬅️ ::Reshape(%"val_400", %"val_401") {allowzero=0}
     592 |  # node_Cast_401
            %"val_403"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     593 |  # node_Constant_402
            %"val_404"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     594 |  # node_Reshape_403
            %"val_405"<?,?> ⬅️ ::Reshape(%"val_403", %"val_404") {allowzero=0}
     595 |  # node_Constant_404
            %"val_406"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     596 |  # node_slice_36
            %"slice_36"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_39", %"val_399", %"val_402", %"val_405", %"val_406")
     597 |  # node_unsqueeze_40
            %"unsqueeze_40"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_36", %"val_19")
     598 |  # node_Cast_405
            %"val_407"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     599 |  # node_Abs_406
            %"val_408"<?,?> ⬅️ ::Abs(%"val_407")
     600 |  # node_expand_12
            %"expand_12"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_40", %"val_408")
     601 |  # node_Cast_407
            %"val_409"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     602 |  # node_Constant_408
            %"val_410"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     603 |  # node_Reshape_409
            %"val_411"<?,?> ⬅️ ::Reshape(%"val_409", %"val_410") {allowzero=0}
     604 |  # node_Cast_410
            %"val_412"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     605 |  # node_Constant_411
            %"val_413"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     606 |  # node_Reshape_412
            %"val_414"<?,?> ⬅️ ::Reshape(%"val_412", %"val_413") {allowzero=0}
     607 |  # node_Cast_413
            %"val_415"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     608 |  # node_Constant_414
            %"val_416"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     609 |  # node_Reshape_415
            %"val_417"<?,?> ⬅️ ::Reshape(%"val_415", %"val_416") {allowzero=0}
     610 |  # node_Constant_416
            %"val_418"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     611 |  # node_slice_37
            %"slice_37"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_411", %"val_414", %"val_417", %"val_418")
     612 |  # node_unsqueeze_41
            %"unsqueeze_41"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_37", %"val_18")
     613 |  # node_Cast_417
            %"val_419"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     614 |  # node_Constant_418
            %"val_420"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     615 |  # node_Reshape_419
            %"val_421"<?,?> ⬅️ ::Reshape(%"val_419", %"val_420") {allowzero=0}
     616 |  # node_Cast_420
            %"val_422"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     617 |  # node_Constant_421
            %"val_423"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     618 |  # node_Reshape_422
            %"val_424"<?,?> ⬅️ ::Reshape(%"val_422", %"val_423") {allowzero=0}
     619 |  # node_Cast_423
            %"val_425"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     620 |  # node_Constant_424
            %"val_426"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     621 |  # node_Reshape_425
            %"val_427"<?,?> ⬅️ ::Reshape(%"val_425", %"val_426") {allowzero=0}
     622 |  # node_Constant_426
            %"val_428"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     623 |  # node_slice_38
            %"slice_38"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_41", %"val_421", %"val_424", %"val_427", %"val_428")
     624 |  # node__to_copy_13
            %"_to_copy_13"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_38") {to=1}
     625 |  # node_matmul_11
            %"matmul_11"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_12", %"_to_copy_13")
     626 |  # node_transpose_11
            %"transpose_11"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_11") {perm=(0, 2, 1)}
     627 |  # node_cat_11
            %"cat_11"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_11", %"transpose_11") {axis=-1}
     628 |  # node_cos_11
            %"cos_11"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_11")
     629 |  # node_mul_22
            %"mul_22"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_11", %"val_3")
     630 |  # node_sin_11
            %"sin_11"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_11")
     631 |  # node_mul_23
            %"mul_23"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_11", %"val_3")
     632 |  # node_unsqueeze_42
            %"unsqueeze_42"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     633 |  # node_Cast_427
            %"val_429"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     634 |  # node_Constant_428
            %"val_430"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     635 |  # node_Reshape_429
            %"val_431"<?,?> ⬅️ ::Reshape(%"val_429", %"val_430") {allowzero=0}
     636 |  # node_Cast_430
            %"val_432"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     637 |  # node_Constant_431
            %"val_433"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     638 |  # node_Reshape_432
            %"val_434"<?,?> ⬅️ ::Reshape(%"val_432", %"val_433") {allowzero=0}
     639 |  # node_Cast_433
            %"val_435"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     640 |  # node_Constant_434
            %"val_436"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     641 |  # node_Reshape_435
            %"val_437"<?,?> ⬅️ ::Reshape(%"val_435", %"val_436") {allowzero=0}
     642 |  # node_Constant_436
            %"val_438"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     643 |  # node_slice_39
            %"slice_39"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_42", %"val_431", %"val_434", %"val_437", %"val_438")
     644 |  # node_unsqueeze_43
            %"unsqueeze_43"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_39", %"val_19")
     645 |  # node_Cast_437
            %"val_439"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     646 |  # node_Abs_438
            %"val_440"<?,?> ⬅️ ::Abs(%"val_439")
     647 |  # node_expand_13
            %"expand_13"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_43", %"val_440")
     648 |  # node_Cast_439
            %"val_441"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     649 |  # node_Constant_440
            %"val_442"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     650 |  # node_Reshape_441
            %"val_443"<?,?> ⬅️ ::Reshape(%"val_441", %"val_442") {allowzero=0}
     651 |  # node_Cast_442
            %"val_444"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     652 |  # node_Constant_443
            %"val_445"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     653 |  # node_Reshape_444
            %"val_446"<?,?> ⬅️ ::Reshape(%"val_444", %"val_445") {allowzero=0}
     654 |  # node_Cast_445
            %"val_447"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     655 |  # node_Constant_446
            %"val_448"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     656 |  # node_Reshape_447
            %"val_449"<?,?> ⬅️ ::Reshape(%"val_447", %"val_448") {allowzero=0}
     657 |  # node_Constant_448
            %"val_450"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     658 |  # node_slice_40
            %"slice_40"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_443", %"val_446", %"val_449", %"val_450")
     659 |  # node_unsqueeze_44
            %"unsqueeze_44"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_40", %"val_18")
     660 |  # node_Cast_449
            %"val_451"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     661 |  # node_Constant_450
            %"val_452"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     662 |  # node_Reshape_451
            %"val_453"<?,?> ⬅️ ::Reshape(%"val_451", %"val_452") {allowzero=0}
     663 |  # node_Cast_452
            %"val_454"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     664 |  # node_Constant_453
            %"val_455"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     665 |  # node_Reshape_454
            %"val_456"<?,?> ⬅️ ::Reshape(%"val_454", %"val_455") {allowzero=0}
     666 |  # node_Cast_455
            %"val_457"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     667 |  # node_Constant_456
            %"val_458"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     668 |  # node_Reshape_457
            %"val_459"<?,?> ⬅️ ::Reshape(%"val_457", %"val_458") {allowzero=0}
     669 |  # node_Constant_458
            %"val_460"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     670 |  # node_slice_41
            %"slice_41"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_44", %"val_453", %"val_456", %"val_459", %"val_460")
     671 |  # node__to_copy_14
            %"_to_copy_14"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_41") {to=1}
     672 |  # node_matmul_12
            %"matmul_12"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_13", %"_to_copy_14")
     673 |  # node_transpose_12
            %"transpose_12"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_12") {perm=(0, 2, 1)}
     674 |  # node_cat_12
            %"cat_12"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_12", %"transpose_12") {axis=-1}
     675 |  # node_cos_12
            %"cos_12"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_12")
     676 |  # node_mul_24
            %"mul_24"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_12", %"val_3")
     677 |  # node_sin_12
            %"sin_12"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_12")
     678 |  # node_mul_25
            %"mul_25"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_12", %"val_3")
     679 |  # node_unsqueeze_45
            %"unsqueeze_45"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     680 |  # node_Cast_459
            %"val_461"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     681 |  # node_Constant_460
            %"val_462"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     682 |  # node_Reshape_461
            %"val_463"<?,?> ⬅️ ::Reshape(%"val_461", %"val_462") {allowzero=0}
     683 |  # node_Cast_462
            %"val_464"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     684 |  # node_Constant_463
            %"val_465"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     685 |  # node_Reshape_464
            %"val_466"<?,?> ⬅️ ::Reshape(%"val_464", %"val_465") {allowzero=0}
     686 |  # node_Cast_465
            %"val_467"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     687 |  # node_Constant_466
            %"val_468"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     688 |  # node_Reshape_467
            %"val_469"<?,?> ⬅️ ::Reshape(%"val_467", %"val_468") {allowzero=0}
     689 |  # node_Constant_468
            %"val_470"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     690 |  # node_slice_42
            %"slice_42"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_45", %"val_463", %"val_466", %"val_469", %"val_470")
     691 |  # node_unsqueeze_46
            %"unsqueeze_46"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_42", %"val_19")
     692 |  # node_Cast_469
            %"val_471"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     693 |  # node_Abs_470
            %"val_472"<?,?> ⬅️ ::Abs(%"val_471")
     694 |  # node_expand_14
            %"expand_14"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_46", %"val_472")
     695 |  # node_Cast_471
            %"val_473"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     696 |  # node_Constant_472
            %"val_474"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     697 |  # node_Reshape_473
            %"val_475"<?,?> ⬅️ ::Reshape(%"val_473", %"val_474") {allowzero=0}
     698 |  # node_Cast_474
            %"val_476"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     699 |  # node_Constant_475
            %"val_477"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     700 |  # node_Reshape_476
            %"val_478"<?,?> ⬅️ ::Reshape(%"val_476", %"val_477") {allowzero=0}
     701 |  # node_Cast_477
            %"val_479"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     702 |  # node_Constant_478
            %"val_480"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     703 |  # node_Reshape_479
            %"val_481"<?,?> ⬅️ ::Reshape(%"val_479", %"val_480") {allowzero=0}
     704 |  # node_Constant_480
            %"val_482"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     705 |  # node_slice_43
            %"slice_43"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_475", %"val_478", %"val_481", %"val_482")
     706 |  # node_unsqueeze_47
            %"unsqueeze_47"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_43", %"val_18")
     707 |  # node_Cast_481
            %"val_483"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     708 |  # node_Constant_482
            %"val_484"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     709 |  # node_Reshape_483
            %"val_485"<?,?> ⬅️ ::Reshape(%"val_483", %"val_484") {allowzero=0}
     710 |  # node_Cast_484
            %"val_486"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     711 |  # node_Constant_485
            %"val_487"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     712 |  # node_Reshape_486
            %"val_488"<?,?> ⬅️ ::Reshape(%"val_486", %"val_487") {allowzero=0}
     713 |  # node_Cast_487
            %"val_489"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     714 |  # node_Constant_488
            %"val_490"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     715 |  # node_Reshape_489
            %"val_491"<?,?> ⬅️ ::Reshape(%"val_489", %"val_490") {allowzero=0}
     716 |  # node_Constant_490
            %"val_492"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     717 |  # node_slice_44
            %"slice_44"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_47", %"val_485", %"val_488", %"val_491", %"val_492")
     718 |  # node__to_copy_15
            %"_to_copy_15"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_44") {to=1}
     719 |  # node_matmul_13
            %"matmul_13"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_14", %"_to_copy_15")
     720 |  # node_transpose_13
            %"transpose_13"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_13") {perm=(0, 2, 1)}
     721 |  # node_cat_13
            %"cat_13"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_13", %"transpose_13") {axis=-1}
     722 |  # node_cos_13
            %"cos_13"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_13")
     723 |  # node_mul_26
            %"mul_26"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_13", %"val_3")
     724 |  # node_sin_13
            %"sin_13"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_13")
     725 |  # node_mul_27
            %"mul_27"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_13", %"val_3")
     726 |  # node_unsqueeze_48
            %"unsqueeze_48"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     727 |  # node_Cast_491
            %"val_493"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     728 |  # node_Constant_492
            %"val_494"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     729 |  # node_Reshape_493
            %"val_495"<?,?> ⬅️ ::Reshape(%"val_493", %"val_494") {allowzero=0}
     730 |  # node_Cast_494
            %"val_496"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     731 |  # node_Constant_495
            %"val_497"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     732 |  # node_Reshape_496
            %"val_498"<?,?> ⬅️ ::Reshape(%"val_496", %"val_497") {allowzero=0}
     733 |  # node_Cast_497
            %"val_499"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     734 |  # node_Constant_498
            %"val_500"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     735 |  # node_Reshape_499
            %"val_501"<?,?> ⬅️ ::Reshape(%"val_499", %"val_500") {allowzero=0}
     736 |  # node_Constant_500
            %"val_502"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     737 |  # node_slice_45
            %"slice_45"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_48", %"val_495", %"val_498", %"val_501", %"val_502")
     738 |  # node_unsqueeze_49
            %"unsqueeze_49"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_45", %"val_19")
     739 |  # node_Cast_501
            %"val_503"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     740 |  # node_Abs_502
            %"val_504"<?,?> ⬅️ ::Abs(%"val_503")
     741 |  # node_expand_15
            %"expand_15"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_49", %"val_504")
     742 |  # node_Cast_503
            %"val_505"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     743 |  # node_Constant_504
            %"val_506"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     744 |  # node_Reshape_505
            %"val_507"<?,?> ⬅️ ::Reshape(%"val_505", %"val_506") {allowzero=0}
     745 |  # node_Cast_506
            %"val_508"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     746 |  # node_Constant_507
            %"val_509"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     747 |  # node_Reshape_508
            %"val_510"<?,?> ⬅️ ::Reshape(%"val_508", %"val_509") {allowzero=0}
     748 |  # node_Cast_509
            %"val_511"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     749 |  # node_Constant_510
            %"val_512"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     750 |  # node_Reshape_511
            %"val_513"<?,?> ⬅️ ::Reshape(%"val_511", %"val_512") {allowzero=0}
     751 |  # node_Constant_512
            %"val_514"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     752 |  # node_slice_46
            %"slice_46"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_507", %"val_510", %"val_513", %"val_514")
     753 |  # node_unsqueeze_50
            %"unsqueeze_50"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_46", %"val_18")
     754 |  # node_Cast_513
            %"val_515"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     755 |  # node_Constant_514
            %"val_516"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     756 |  # node_Reshape_515
            %"val_517"<?,?> ⬅️ ::Reshape(%"val_515", %"val_516") {allowzero=0}
     757 |  # node_Cast_516
            %"val_518"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     758 |  # node_Constant_517
            %"val_519"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     759 |  # node_Reshape_518
            %"val_520"<?,?> ⬅️ ::Reshape(%"val_518", %"val_519") {allowzero=0}
     760 |  # node_Cast_519
            %"val_521"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     761 |  # node_Constant_520
            %"val_522"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     762 |  # node_Reshape_521
            %"val_523"<?,?> ⬅️ ::Reshape(%"val_521", %"val_522") {allowzero=0}
     763 |  # node_Constant_522
            %"val_524"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     764 |  # node_slice_47
            %"slice_47"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_50", %"val_517", %"val_520", %"val_523", %"val_524")
     765 |  # node__to_copy_16
            %"_to_copy_16"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_47") {to=1}
     766 |  # node_matmul_14
            %"matmul_14"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_15", %"_to_copy_16")
     767 |  # node_transpose_14
            %"transpose_14"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_14") {perm=(0, 2, 1)}
     768 |  # node_cat_14
            %"cat_14"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_14", %"transpose_14") {axis=-1}
     769 |  # node_cos_14
            %"cos_14"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_14")
     770 |  # node_mul_28
            %"mul_28"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_14", %"val_3")
     771 |  # node_sin_14
            %"sin_14"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_14")
     772 |  # node_mul_29
            %"mul_29"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_14", %"val_3")
     773 |  # node_unsqueeze_51
            %"unsqueeze_51"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     774 |  # node_Cast_523
            %"val_525"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     775 |  # node_Constant_524
            %"val_526"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     776 |  # node_Reshape_525
            %"val_527"<?,?> ⬅️ ::Reshape(%"val_525", %"val_526") {allowzero=0}
     777 |  # node_Cast_526
            %"val_528"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     778 |  # node_Constant_527
            %"val_529"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     779 |  # node_Reshape_528
            %"val_530"<?,?> ⬅️ ::Reshape(%"val_528", %"val_529") {allowzero=0}
     780 |  # node_Cast_529
            %"val_531"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     781 |  # node_Constant_530
            %"val_532"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     782 |  # node_Reshape_531
            %"val_533"<?,?> ⬅️ ::Reshape(%"val_531", %"val_532") {allowzero=0}
     783 |  # node_Constant_532
            %"val_534"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     784 |  # node_slice_48
            %"slice_48"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_51", %"val_527", %"val_530", %"val_533", %"val_534")
     785 |  # node_unsqueeze_52
            %"unsqueeze_52"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_48", %"val_19")
     786 |  # node_Cast_533
            %"val_535"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     787 |  # node_Abs_534
            %"val_536"<?,?> ⬅️ ::Abs(%"val_535")
     788 |  # node_expand_16
            %"expand_16"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_52", %"val_536")
     789 |  # node_Cast_535
            %"val_537"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     790 |  # node_Constant_536
            %"val_538"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     791 |  # node_Reshape_537
            %"val_539"<?,?> ⬅️ ::Reshape(%"val_537", %"val_538") {allowzero=0}
     792 |  # node_Cast_538
            %"val_540"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     793 |  # node_Constant_539
            %"val_541"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     794 |  # node_Reshape_540
            %"val_542"<?,?> ⬅️ ::Reshape(%"val_540", %"val_541") {allowzero=0}
     795 |  # node_Cast_541
            %"val_543"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     796 |  # node_Constant_542
            %"val_544"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     797 |  # node_Reshape_543
            %"val_545"<?,?> ⬅️ ::Reshape(%"val_543", %"val_544") {allowzero=0}
     798 |  # node_Constant_544
            %"val_546"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     799 |  # node_slice_49
            %"slice_49"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_539", %"val_542", %"val_545", %"val_546")
     800 |  # node_unsqueeze_53
            %"unsqueeze_53"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_49", %"val_18")
     801 |  # node_Cast_545
            %"val_547"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     802 |  # node_Constant_546
            %"val_548"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     803 |  # node_Reshape_547
            %"val_549"<?,?> ⬅️ ::Reshape(%"val_547", %"val_548") {allowzero=0}
     804 |  # node_Cast_548
            %"val_550"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     805 |  # node_Constant_549
            %"val_551"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     806 |  # node_Reshape_550
            %"val_552"<?,?> ⬅️ ::Reshape(%"val_550", %"val_551") {allowzero=0}
     807 |  # node_Cast_551
            %"val_553"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     808 |  # node_Constant_552
            %"val_554"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     809 |  # node_Reshape_553
            %"val_555"<?,?> ⬅️ ::Reshape(%"val_553", %"val_554") {allowzero=0}
     810 |  # node_Constant_554
            %"val_556"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     811 |  # node_slice_50
            %"slice_50"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_53", %"val_549", %"val_552", %"val_555", %"val_556")
     812 |  # node__to_copy_17
            %"_to_copy_17"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_50") {to=1}
     813 |  # node_matmul_15
            %"matmul_15"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_16", %"_to_copy_17")
     814 |  # node_transpose_15
            %"transpose_15"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_15") {perm=(0, 2, 1)}
     815 |  # node_cat_15
            %"cat_15"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_15", %"transpose_15") {axis=-1}
     816 |  # node_cos_15
            %"cos_15"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_15")
     817 |  # node_mul_30
            %"mul_30"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_15", %"val_3")
     818 |  # node_sin_15
            %"sin_15"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_15")
     819 |  # node_mul_31
            %"mul_31"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_15", %"val_3")
     820 |  # node_unsqueeze_54
            %"unsqueeze_54"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     821 |  # node_Cast_555
            %"val_557"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     822 |  # node_Constant_556
            %"val_558"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     823 |  # node_Reshape_557
            %"val_559"<?,?> ⬅️ ::Reshape(%"val_557", %"val_558") {allowzero=0}
     824 |  # node_Cast_558
            %"val_560"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     825 |  # node_Constant_559
            %"val_561"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     826 |  # node_Reshape_560
            %"val_562"<?,?> ⬅️ ::Reshape(%"val_560", %"val_561") {allowzero=0}
     827 |  # node_Cast_561
            %"val_563"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     828 |  # node_Constant_562
            %"val_564"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     829 |  # node_Reshape_563
            %"val_565"<?,?> ⬅️ ::Reshape(%"val_563", %"val_564") {allowzero=0}
     830 |  # node_Constant_564
            %"val_566"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     831 |  # node_slice_51
            %"slice_51"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_54", %"val_559", %"val_562", %"val_565", %"val_566")
     832 |  # node_unsqueeze_55
            %"unsqueeze_55"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_51", %"val_19")
     833 |  # node_Cast_565
            %"val_567"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     834 |  # node_Abs_566
            %"val_568"<?,?> ⬅️ ::Abs(%"val_567")
     835 |  # node_expand_17
            %"expand_17"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_55", %"val_568")
     836 |  # node_Cast_567
            %"val_569"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     837 |  # node_Constant_568
            %"val_570"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     838 |  # node_Reshape_569
            %"val_571"<?,?> ⬅️ ::Reshape(%"val_569", %"val_570") {allowzero=0}
     839 |  # node_Cast_570
            %"val_572"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     840 |  # node_Constant_571
            %"val_573"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     841 |  # node_Reshape_572
            %"val_574"<?,?> ⬅️ ::Reshape(%"val_572", %"val_573") {allowzero=0}
     842 |  # node_Cast_573
            %"val_575"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     843 |  # node_Constant_574
            %"val_576"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     844 |  # node_Reshape_575
            %"val_577"<?,?> ⬅️ ::Reshape(%"val_575", %"val_576") {allowzero=0}
     845 |  # node_Constant_576
            %"val_578"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     846 |  # node_slice_52
            %"slice_52"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_571", %"val_574", %"val_577", %"val_578")
     847 |  # node_unsqueeze_56
            %"unsqueeze_56"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_52", %"val_18")
     848 |  # node_Cast_577
            %"val_579"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     849 |  # node_Constant_578
            %"val_580"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     850 |  # node_Reshape_579
            %"val_581"<?,?> ⬅️ ::Reshape(%"val_579", %"val_580") {allowzero=0}
     851 |  # node_Cast_580
            %"val_582"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     852 |  # node_Constant_581
            %"val_583"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     853 |  # node_Reshape_582
            %"val_584"<?,?> ⬅️ ::Reshape(%"val_582", %"val_583") {allowzero=0}
     854 |  # node_Cast_583
            %"val_585"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     855 |  # node_Constant_584
            %"val_586"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     856 |  # node_Reshape_585
            %"val_587"<?,?> ⬅️ ::Reshape(%"val_585", %"val_586") {allowzero=0}
     857 |  # node_Constant_586
            %"val_588"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     858 |  # node_slice_53
            %"slice_53"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_56", %"val_581", %"val_584", %"val_587", %"val_588")
     859 |  # node__to_copy_18
            %"_to_copy_18"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_53") {to=1}
     860 |  # node_matmul_16
            %"matmul_16"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_17", %"_to_copy_18")
     861 |  # node_transpose_16
            %"transpose_16"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_16") {perm=(0, 2, 1)}
     862 |  # node_cat_16
            %"cat_16"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_16", %"transpose_16") {axis=-1}
     863 |  # node_cos_16
            %"cos_16"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_16")
     864 |  # node_mul_32
            %"mul_32"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_16", %"val_3")
     865 |  # node_sin_16
            %"sin_16"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_16")
     866 |  # node_mul_33
            %"mul_33"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_16", %"val_3")
     867 |  # node_unsqueeze_57
            %"unsqueeze_57"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     868 |  # node_Cast_587
            %"val_589"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     869 |  # node_Constant_588
            %"val_590"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     870 |  # node_Reshape_589
            %"val_591"<?,?> ⬅️ ::Reshape(%"val_589", %"val_590") {allowzero=0}
     871 |  # node_Cast_590
            %"val_592"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     872 |  # node_Constant_591
            %"val_593"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     873 |  # node_Reshape_592
            %"val_594"<?,?> ⬅️ ::Reshape(%"val_592", %"val_593") {allowzero=0}
     874 |  # node_Cast_593
            %"val_595"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     875 |  # node_Constant_594
            %"val_596"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     876 |  # node_Reshape_595
            %"val_597"<?,?> ⬅️ ::Reshape(%"val_595", %"val_596") {allowzero=0}
     877 |  # node_Constant_596
            %"val_598"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     878 |  # node_slice_54
            %"slice_54"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_57", %"val_591", %"val_594", %"val_597", %"val_598")
     879 |  # node_unsqueeze_58
            %"unsqueeze_58"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_54", %"val_19")
     880 |  # node_Cast_597
            %"val_599"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     881 |  # node_Abs_598
            %"val_600"<?,?> ⬅️ ::Abs(%"val_599")
     882 |  # node_expand_18
            %"expand_18"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_58", %"val_600")
     883 |  # node_Cast_599
            %"val_601"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     884 |  # node_Constant_600
            %"val_602"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     885 |  # node_Reshape_601
            %"val_603"<?,?> ⬅️ ::Reshape(%"val_601", %"val_602") {allowzero=0}
     886 |  # node_Cast_602
            %"val_604"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     887 |  # node_Constant_603
            %"val_605"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     888 |  # node_Reshape_604
            %"val_606"<?,?> ⬅️ ::Reshape(%"val_604", %"val_605") {allowzero=0}
     889 |  # node_Cast_605
            %"val_607"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     890 |  # node_Constant_606
            %"val_608"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     891 |  # node_Reshape_607
            %"val_609"<?,?> ⬅️ ::Reshape(%"val_607", %"val_608") {allowzero=0}
     892 |  # node_Constant_608
            %"val_610"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     893 |  # node_slice_55
            %"slice_55"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_603", %"val_606", %"val_609", %"val_610")
     894 |  # node_unsqueeze_59
            %"unsqueeze_59"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_55", %"val_18")
     895 |  # node_Cast_609
            %"val_611"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     896 |  # node_Constant_610
            %"val_612"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     897 |  # node_Reshape_611
            %"val_613"<?,?> ⬅️ ::Reshape(%"val_611", %"val_612") {allowzero=0}
     898 |  # node_Cast_612
            %"val_614"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     899 |  # node_Constant_613
            %"val_615"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     900 |  # node_Reshape_614
            %"val_616"<?,?> ⬅️ ::Reshape(%"val_614", %"val_615") {allowzero=0}
     901 |  # node_Cast_615
            %"val_617"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     902 |  # node_Constant_616
            %"val_618"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     903 |  # node_Reshape_617
            %"val_619"<?,?> ⬅️ ::Reshape(%"val_617", %"val_618") {allowzero=0}
     904 |  # node_Constant_618
            %"val_620"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     905 |  # node_slice_56
            %"slice_56"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_59", %"val_613", %"val_616", %"val_619", %"val_620")
     906 |  # node__to_copy_19
            %"_to_copy_19"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_56") {to=1}
     907 |  # node_matmul_17
            %"matmul_17"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_18", %"_to_copy_19")
     908 |  # node_transpose_17
            %"transpose_17"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_17") {perm=(0, 2, 1)}
     909 |  # node_cat_17
            %"cat_17"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_17", %"transpose_17") {axis=-1}
     910 |  # node_cos_17
            %"cos_17"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_17")
     911 |  # node_mul_34
            %"mul_34"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_17", %"val_3")
     912 |  # node_sin_17
            %"sin_17"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_17")
     913 |  # node_mul_35
            %"mul_35"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_17", %"val_3")
     914 |  # node_unsqueeze_60
            %"unsqueeze_60"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     915 |  # node_Cast_619
            %"val_621"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     916 |  # node_Constant_620
            %"val_622"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     917 |  # node_Reshape_621
            %"val_623"<?,?> ⬅️ ::Reshape(%"val_621", %"val_622") {allowzero=0}
     918 |  # node_Cast_622
            %"val_624"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     919 |  # node_Constant_623
            %"val_625"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     920 |  # node_Reshape_624
            %"val_626"<?,?> ⬅️ ::Reshape(%"val_624", %"val_625") {allowzero=0}
     921 |  # node_Cast_625
            %"val_627"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     922 |  # node_Constant_626
            %"val_628"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     923 |  # node_Reshape_627
            %"val_629"<?,?> ⬅️ ::Reshape(%"val_627", %"val_628") {allowzero=0}
     924 |  # node_Constant_628
            %"val_630"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     925 |  # node_slice_57
            %"slice_57"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_60", %"val_623", %"val_626", %"val_629", %"val_630")
     926 |  # node_unsqueeze_61
            %"unsqueeze_61"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_57", %"val_19")
     927 |  # node_Cast_629
            %"val_631"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     928 |  # node_Abs_630
            %"val_632"<?,?> ⬅️ ::Abs(%"val_631")
     929 |  # node_expand_19
            %"expand_19"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_61", %"val_632")
     930 |  # node_Cast_631
            %"val_633"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     931 |  # node_Constant_632
            %"val_634"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     932 |  # node_Reshape_633
            %"val_635"<?,?> ⬅️ ::Reshape(%"val_633", %"val_634") {allowzero=0}
     933 |  # node_Cast_634
            %"val_636"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     934 |  # node_Constant_635
            %"val_637"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     935 |  # node_Reshape_636
            %"val_638"<?,?> ⬅️ ::Reshape(%"val_636", %"val_637") {allowzero=0}
     936 |  # node_Cast_637
            %"val_639"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     937 |  # node_Constant_638
            %"val_640"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     938 |  # node_Reshape_639
            %"val_641"<?,?> ⬅️ ::Reshape(%"val_639", %"val_640") {allowzero=0}
     939 |  # node_Constant_640
            %"val_642"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     940 |  # node_slice_58
            %"slice_58"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_635", %"val_638", %"val_641", %"val_642")
     941 |  # node_unsqueeze_62
            %"unsqueeze_62"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_58", %"val_18")
     942 |  # node_Cast_641
            %"val_643"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     943 |  # node_Constant_642
            %"val_644"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     944 |  # node_Reshape_643
            %"val_645"<?,?> ⬅️ ::Reshape(%"val_643", %"val_644") {allowzero=0}
     945 |  # node_Cast_644
            %"val_646"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     946 |  # node_Constant_645
            %"val_647"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     947 |  # node_Reshape_646
            %"val_648"<?,?> ⬅️ ::Reshape(%"val_646", %"val_647") {allowzero=0}
     948 |  # node_Cast_647
            %"val_649"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     949 |  # node_Constant_648
            %"val_650"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     950 |  # node_Reshape_649
            %"val_651"<?,?> ⬅️ ::Reshape(%"val_649", %"val_650") {allowzero=0}
     951 |  # node_Constant_650
            %"val_652"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     952 |  # node_slice_59
            %"slice_59"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_62", %"val_645", %"val_648", %"val_651", %"val_652")
     953 |  # node__to_copy_20
            %"_to_copy_20"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_59") {to=1}
     954 |  # node_matmul_18
            %"matmul_18"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_19", %"_to_copy_20")
     955 |  # node_transpose_18
            %"transpose_18"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_18") {perm=(0, 2, 1)}
     956 |  # node_cat_18
            %"cat_18"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_18", %"transpose_18") {axis=-1}
     957 |  # node_cos_18
            %"cos_18"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_18")
     958 |  # node_mul_36
            %"mul_36"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_18", %"val_3")
     959 |  # node_sin_18
            %"sin_18"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_18")
     960 |  # node_mul_37
            %"mul_37"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_18", %"val_3")
     961 |  # node_unsqueeze_63
            %"unsqueeze_63"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     962 |  # node_Cast_651
            %"val_653"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     963 |  # node_Constant_652
            %"val_654"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     964 |  # node_Reshape_653
            %"val_655"<?,?> ⬅️ ::Reshape(%"val_653", %"val_654") {allowzero=0}
     965 |  # node_Cast_654
            %"val_656"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     966 |  # node_Constant_655
            %"val_657"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     967 |  # node_Reshape_656
            %"val_658"<?,?> ⬅️ ::Reshape(%"val_656", %"val_657") {allowzero=0}
     968 |  # node_Cast_657
            %"val_659"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
     969 |  # node_Constant_658
            %"val_660"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     970 |  # node_Reshape_659
            %"val_661"<?,?> ⬅️ ::Reshape(%"val_659", %"val_660") {allowzero=0}
     971 |  # node_Constant_660
            %"val_662"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     972 |  # node_slice_60
            %"slice_60"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_63", %"val_655", %"val_658", %"val_661", %"val_662")
     973 |  # node_unsqueeze_64
            %"unsqueeze_64"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_60", %"val_19")
     974 |  # node_Cast_661
            %"val_663"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
     975 |  # node_Abs_662
            %"val_664"<?,?> ⬅️ ::Abs(%"val_663")
     976 |  # node_expand_20
            %"expand_20"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_64", %"val_664")
     977 |  # node_Cast_663
            %"val_665"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     978 |  # node_Constant_664
            %"val_666"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     979 |  # node_Reshape_665
            %"val_667"<?,?> ⬅️ ::Reshape(%"val_665", %"val_666") {allowzero=0}
     980 |  # node_Cast_666
            %"val_668"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     981 |  # node_Constant_667
            %"val_669"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     982 |  # node_Reshape_668
            %"val_670"<?,?> ⬅️ ::Reshape(%"val_668", %"val_669") {allowzero=0}
     983 |  # node_Cast_669
            %"val_671"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     984 |  # node_Constant_670
            %"val_672"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     985 |  # node_Reshape_671
            %"val_673"<?,?> ⬅️ ::Reshape(%"val_671", %"val_672") {allowzero=0}
     986 |  # node_Constant_672
            %"val_674"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     987 |  # node_slice_61
            %"slice_61"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_667", %"val_670", %"val_673", %"val_674")
     988 |  # node_unsqueeze_65
            %"unsqueeze_65"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_61", %"val_18")
     989 |  # node_Cast_673
            %"val_675"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     990 |  # node_Constant_674
            %"val_676"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     991 |  # node_Reshape_675
            %"val_677"<?,?> ⬅️ ::Reshape(%"val_675", %"val_676") {allowzero=0}
     992 |  # node_Cast_676
            %"val_678"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     993 |  # node_Constant_677
            %"val_679"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     994 |  # node_Reshape_678
            %"val_680"<?,?> ⬅️ ::Reshape(%"val_678", %"val_679") {allowzero=0}
     995 |  # node_Cast_679
            %"val_681"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
     996 |  # node_Constant_680
            %"val_682"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     997 |  # node_Reshape_681
            %"val_683"<?,?> ⬅️ ::Reshape(%"val_681", %"val_682") {allowzero=0}
     998 |  # node_Constant_682
            %"val_684"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     999 |  # node_slice_62
            %"slice_62"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_65", %"val_677", %"val_680", %"val_683", %"val_684")
    1000 |  # node__to_copy_21
            %"_to_copy_21"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_62") {to=1}
    1001 |  # node_matmul_19
            %"matmul_19"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_20", %"_to_copy_21")
    1002 |  # node_transpose_19
            %"transpose_19"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_19") {perm=(0, 2, 1)}
    1003 |  # node_cat_19
            %"cat_19"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_19", %"transpose_19") {axis=-1}
    1004 |  # node_cos_19
            %"cos_19"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_19")
    1005 |  # node_mul_38
            %"mul_38"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_19", %"val_3")
    1006 |  # node_sin_19
            %"sin_19"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_19")
    1007 |  # node_mul_39
            %"mul_39"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_19", %"val_3")
    1008 |  # node_unsqueeze_66
            %"unsqueeze_66"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
    1009 |  # node_Cast_683
            %"val_685"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1010 |  # node_Constant_684
            %"val_686"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1011 |  # node_Reshape_685
            %"val_687"<?,?> ⬅️ ::Reshape(%"val_685", %"val_686") {allowzero=0}
    1012 |  # node_Cast_686
            %"val_688"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1013 |  # node_Constant_687
            %"val_689"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1014 |  # node_Reshape_688
            %"val_690"<?,?> ⬅️ ::Reshape(%"val_688", %"val_689") {allowzero=0}
    1015 |  # node_Cast_689
            %"val_691"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
    1016 |  # node_Constant_690
            %"val_692"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1017 |  # node_Reshape_691
            %"val_693"<?,?> ⬅️ ::Reshape(%"val_691", %"val_692") {allowzero=0}
    1018 |  # node_Constant_692
            %"val_694"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1019 |  # node_slice_63
            %"slice_63"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_66", %"val_687", %"val_690", %"val_693", %"val_694")
    1020 |  # node_unsqueeze_67
            %"unsqueeze_67"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_63", %"val_19")
    1021 |  # node_Cast_693
            %"val_695"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
    1022 |  # node_Abs_694
            %"val_696"<?,?> ⬅️ ::Abs(%"val_695")
    1023 |  # node_expand_21
            %"expand_21"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_67", %"val_696")
    1024 |  # node_Cast_695
            %"val_697"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1025 |  # node_Constant_696
            %"val_698"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1026 |  # node_Reshape_697
            %"val_699"<?,?> ⬅️ ::Reshape(%"val_697", %"val_698") {allowzero=0}
    1027 |  # node_Cast_698
            %"val_700"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1028 |  # node_Constant_699
            %"val_701"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1029 |  # node_Reshape_700
            %"val_702"<?,?> ⬅️ ::Reshape(%"val_700", %"val_701") {allowzero=0}
    1030 |  # node_Cast_701
            %"val_703"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1031 |  # node_Constant_702
            %"val_704"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1032 |  # node_Reshape_703
            %"val_705"<?,?> ⬅️ ::Reshape(%"val_703", %"val_704") {allowzero=0}
    1033 |  # node_Constant_704
            %"val_706"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1034 |  # node_slice_64
            %"slice_64"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_699", %"val_702", %"val_705", %"val_706")
    1035 |  # node_unsqueeze_68
            %"unsqueeze_68"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_64", %"val_18")
    1036 |  # node_Cast_705
            %"val_707"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1037 |  # node_Constant_706
            %"val_708"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1038 |  # node_Reshape_707
            %"val_709"<?,?> ⬅️ ::Reshape(%"val_707", %"val_708") {allowzero=0}
    1039 |  # node_Cast_708
            %"val_710"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1040 |  # node_Constant_709
            %"val_711"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1041 |  # node_Reshape_710
            %"val_712"<?,?> ⬅️ ::Reshape(%"val_710", %"val_711") {allowzero=0}
    1042 |  # node_Cast_711
            %"val_713"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
    1043 |  # node_Constant_712
            %"val_714"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1044 |  # node_Reshape_713
            %"val_715"<?,?> ⬅️ ::Reshape(%"val_713", %"val_714") {allowzero=0}
    1045 |  # node_Constant_714
            %"val_716"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1046 |  # node_slice_65
            %"slice_65"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_68", %"val_709", %"val_712", %"val_715", %"val_716")
    1047 |  # node__to_copy_22
            %"_to_copy_22"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_65") {to=1}
    1048 |  # node_matmul_20
            %"matmul_20"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_21", %"_to_copy_22")
    1049 |  # node_transpose_20
            %"transpose_20"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_20") {perm=(0, 2, 1)}
    1050 |  # node_cat_20
            %"cat_20"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_20", %"transpose_20") {axis=-1}
    1051 |  # node_cos_20
            %"cos_20"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_20")
    1052 |  # node_mul_40
            %"mul_40"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_20", %"val_3")
    1053 |  # node_sin_20
            %"sin_20"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_20")
    1054 |  # node_mul_41
            %"mul_41"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_20", %"val_3")
    1055 |  # node_unsqueeze_69
            %"unsqueeze_69"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
    1056 |  # node_Cast_715
            %"val_717"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1057 |  # node_Constant_716
            %"val_718"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1058 |  # node_Reshape_717
            %"val_719"<?,?> ⬅️ ::Reshape(%"val_717", %"val_718") {allowzero=0}
    1059 |  # node_Cast_718
            %"val_720"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1060 |  # node_Constant_719
            %"val_721"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1061 |  # node_Reshape_720
            %"val_722"<?,?> ⬅️ ::Reshape(%"val_720", %"val_721") {allowzero=0}
    1062 |  # node_Cast_721
            %"val_723"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
    1063 |  # node_Constant_722
            %"val_724"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1064 |  # node_Reshape_723
            %"val_725"<?,?> ⬅️ ::Reshape(%"val_723", %"val_724") {allowzero=0}
    1065 |  # node_Constant_724
            %"val_726"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1066 |  # node_slice_66
            %"slice_66"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_69", %"val_719", %"val_722", %"val_725", %"val_726")
    1067 |  # node_unsqueeze_70
            %"unsqueeze_70"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_66", %"val_19")
    1068 |  # node_Cast_725
            %"val_727"<?,?> ⬅️ ::Cast(%"val_53") {to=7}
    1069 |  # node_Abs_726
            %"val_728"<?,?> ⬅️ ::Abs(%"val_727")
    1070 |  # node_expand_22
            %"expand_22"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_70", %"val_728")
    1071 |  # node_Cast_727
            %"val_729"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1072 |  # node_Constant_728
            %"val_730"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1073 |  # node_Reshape_729
            %"val_731"<?,?> ⬅️ ::Reshape(%"val_729", %"val_730") {allowzero=0}
    1074 |  # node_Cast_730
            %"val_732"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1075 |  # node_Constant_731
            %"val_733"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1076 |  # node_Reshape_732
            %"val_734"<?,?> ⬅️ ::Reshape(%"val_732", %"val_733") {allowzero=0}
    1077 |  # node_Cast_733
            %"val_735"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1078 |  # node_Constant_734
            %"val_736"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1079 |  # node_Reshape_735
            %"val_737"<?,?> ⬅️ ::Reshape(%"val_735", %"val_736") {allowzero=0}
    1080 |  # node_Constant_736
            %"val_738"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1081 |  # node_slice_67
            %"slice_67"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_731", %"val_734", %"val_737", %"val_738")
    1082 |  # node_unsqueeze_71
            %"unsqueeze_71"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_67", %"val_18")
    1083 |  # node_Cast_737
            %"val_739"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1084 |  # node_Constant_738
            %"val_740"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1085 |  # node_Reshape_739
            %"val_741"<?,?> ⬅️ ::Reshape(%"val_739", %"val_740") {allowzero=0}
    1086 |  # node_Cast_740
            %"val_742"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1087 |  # node_Constant_741
            %"val_743"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1088 |  # node_Reshape_742
            %"val_744"<?,?> ⬅️ ::Reshape(%"val_742", %"val_743") {allowzero=0}
    1089 |  # node_Cast_743
            %"val_745"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
    1090 |  # node_Constant_744
            %"val_746"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1091 |  # node_Reshape_745
            %"val_747"<?,?> ⬅️ ::Reshape(%"val_745", %"val_746") {allowzero=0}
    1092 |  # node_Constant_746
            %"val_748"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1093 |  # node_slice_68
            %"slice_68"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_71", %"val_741", %"val_744", %"val_747", %"val_748")
    1094 |  # node__to_copy_23
            %"_to_copy_23"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_68") {to=1}
    1095 |  # node_matmul_21
            %"matmul_21"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_22", %"_to_copy_23")
    1096 |  # node_transpose_21
            %"transpose_21"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_21") {perm=(0, 2, 1)}
    1097 |  # node_cat_21
            %"cat_21"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_21", %"transpose_21") {axis=-1}
    1098 |  # node_cos_21
            %"cos_21"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_21")
    1099 |  # node_mul_42
            %"mul_42"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_21", %"val_3")
    1100 |  # node_sin_21
            %"sin_21"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_21")
    1101 |  # node_mul_43
            %"mul_43"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_21", %"val_3")
    1102 |  # node_Transpose_747
            %"val_749"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1103 |  # node_linear
            %"linear"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"clone_1", %"val_749")
    1104 |  # node_Constant_748
            %"val_750"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[5]>(array([ 1, -1,  3, 12, 64]), name=None)}
    1105 |  # node_Cast_749
            %"val_751"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1106 |  # node_view
            %"view"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear", %"val_751") {allowzero=1}
    1107 |  # node_transpose_22
            %"transpose_22"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view") {perm=(0, 3, 2, 1, 4)}
    1108 |  # node_unbind
            %"unbind"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_22") {dim=2}
    1109 |  # node_getitem
            %"getitem"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind", %"val_6")
    1110 |  # node_getitem_1
            %"getitem_1"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind", %"val_48")
    1111 |  # node_getitem_2
            %"getitem_2"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind", %"val_72")
    1112 |  # node_unsqueeze_72
            %"unsqueeze_72"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    1113 |  # node_unsqueeze_73
            %"unsqueeze_73"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    1114 |  # node_mul_44
            %"mul_44"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem", %"unsqueeze_72")
    1115 |  # node_Cast_750
            %"val_752"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1116 |  # node_Constant_751
            %"val_753"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1117 |  # node_Reshape_752
            %"val_754"<?,?> ⬅️ ::Reshape(%"val_752", %"val_753") {allowzero=0}
    1118 |  # node_Constant_753
            %"val_755"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(32), name=None)}
    1119 |  # node_Cast_754
            %"val_756"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1120 |  # node_Constant_755
            %"val_757"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1121 |  # node_Reshape_756
            %"val_758"<?,?> ⬅️ ::Reshape(%"val_756", %"val_757") {allowzero=0}
    1122 |  # node_Cast_757
            %"val_759"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1123 |  # node_Constant_758
            %"val_760"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1124 |  # node_Reshape_759
            %"val_761"<?,?> ⬅️ ::Reshape(%"val_759", %"val_760") {allowzero=0}
    1125 |  # node_Constant_760
            %"val_762"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1126 |  # node_slice_69
            %"slice_69"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem", %"val_754", %"val_758", %"val_761", %"val_762")
    1127 |  # node_Cast_761
            %"val_763"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1128 |  # node_Constant_762
            %"val_764"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1129 |  # node_Reshape_763
            %"val_765"<?,?> ⬅️ ::Reshape(%"val_763", %"val_764") {allowzero=0}
    1130 |  # node_Cast_764
            %"val_766"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1131 |  # node_Constant_765
            %"val_767"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1132 |  # node_Reshape_766
            %"val_768"<?,?> ⬅️ ::Reshape(%"val_766", %"val_767") {allowzero=0}
    1133 |  # node_Cast_767
            %"val_769"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1134 |  # node_Constant_768
            %"val_770"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1135 |  # node_Reshape_769
            %"val_771"<?,?> ⬅️ ::Reshape(%"val_769", %"val_770") {allowzero=0}
    1136 |  # node_Constant_770
            %"val_772"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1137 |  # node_slice_70
            %"slice_70"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem", %"val_765", %"val_768", %"val_771", %"val_772")
    1138 |  # node_neg
            %"neg"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_70")
    1139 |  # node_cat_22
            %"cat_22"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg", %"slice_69") {axis=-1}
    1140 |  # node_mul_45
            %"mul_45"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_22", %"unsqueeze_73")
    1141 |  # node_add
            %"add"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_44", %"mul_45")
    1142 |  # node_mul_46
            %"mul_46"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_1", %"unsqueeze_72")
    1143 |  # node_Cast_771
            %"val_773"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1144 |  # node_Constant_772
            %"val_774"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1145 |  # node_Reshape_773
            %"val_775"<?,?> ⬅️ ::Reshape(%"val_773", %"val_774") {allowzero=0}
    1146 |  # node_Cast_774
            %"val_776"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1147 |  # node_Constant_775
            %"val_777"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1148 |  # node_Reshape_776
            %"val_778"<?,?> ⬅️ ::Reshape(%"val_776", %"val_777") {allowzero=0}
    1149 |  # node_Cast_777
            %"val_779"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1150 |  # node_Constant_778
            %"val_780"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1151 |  # node_Reshape_779
            %"val_781"<?,?> ⬅️ ::Reshape(%"val_779", %"val_780") {allowzero=0}
    1152 |  # node_Constant_780
            %"val_782"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1153 |  # node_slice_71
            %"slice_71"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_1", %"val_775", %"val_778", %"val_781", %"val_782")
    1154 |  # node_Cast_781
            %"val_783"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1155 |  # node_Constant_782
            %"val_784"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1156 |  # node_Reshape_783
            %"val_785"<?,?> ⬅️ ::Reshape(%"val_783", %"val_784") {allowzero=0}
    1157 |  # node_Cast_784
            %"val_786"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1158 |  # node_Constant_785
            %"val_787"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1159 |  # node_Reshape_786
            %"val_788"<?,?> ⬅️ ::Reshape(%"val_786", %"val_787") {allowzero=0}
    1160 |  # node_Cast_787
            %"val_789"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1161 |  # node_Constant_788
            %"val_790"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1162 |  # node_Reshape_789
            %"val_791"<?,?> ⬅️ ::Reshape(%"val_789", %"val_790") {allowzero=0}
    1163 |  # node_Constant_790
            %"val_792"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1164 |  # node_slice_72
            %"slice_72"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_1", %"val_785", %"val_788", %"val_791", %"val_792")
    1165 |  # node_neg_1
            %"neg_1"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_72")
    1166 |  # node_cat_23
            %"cat_23"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_1", %"slice_71") {axis=-1}
    1167 |  # node_mul_47
            %"mul_47"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_23", %"unsqueeze_73")
    1168 |  # node_add_1
            %"add_1"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_46", %"mul_47")
    1169 |  # node_Shape_791
            %"val_793"<?,?> ⬅️ ::Shape(%"add") {start=0}
    1170 |  # node_Constant_792
            %"val_794"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1171 |  # node_Gather_793
            %"val_795"<?,?> ⬅️ ::Gather(%"val_793", %"val_794") {axis=0}
    1172 |  # node_CastLike_794
            %"val_796"<?,?> ⬅️ ::CastLike(%"val_795", %"add")
    1173 |  # node_Constant_795
            %"val_797"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1174 |  # node_CastLike_796
            %"val_798"<?,?> ⬅️ ::CastLike(%"val_797", %"add")
    1175 |  # node_Sqrt_797
            %"val_799"<?,?> ⬅️ ::Sqrt(%"val_796")
    1176 |  # node_Div_798
            %"val_800"<?,?> ⬅️ ::Div(%"val_798", %"val_799")
    1177 |  # node_CastLike_799
            %"val_801"<?,?> ⬅️ ::CastLike(%"val_800", %"add")
    1178 |  # node_Shape_800
            %"val_802"<?,?> ⬅️ ::Shape(%"add_1") {start=0}
    1179 |  # node_Constant_801
            %"val_803"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1180 |  # node_Constant_802
            %"val_804"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([-1]), name=None)}
    1181 |  # node_Slice_803
            %"val_805"<?,?> ⬅️ ::Slice(%"val_802", %"val_804", %"val_803")
    1182 |  # node_Constant_804
            %"val_806"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([-2]), name=None)}
    1183 |  # node_Slice_805
            %"val_807"<?,?> ⬅️ ::Slice(%"val_802", %"val_806", %"val_804")
    1184 |  # node_Constant_806
            %"val_808"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1185 |  # node_Slice_807
            %"val_809"<?,?> ⬅️ ::Slice(%"val_802", %"val_808", %"val_806")
    1186 |  # node_Constant_808
            %"val_810"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1187 |  # node_Concat_809
            %"val_811"<?,?> ⬅️ ::Concat(%"val_810", %"val_807", %"val_805") {axis=0}
    1188 |  # node_Reshape_810
            %"val_812"<?,?> ⬅️ ::Reshape(%"add_1", %"val_811") {allowzero=0}
    1189 |  # node_Transpose_811
            %"val_813"<?,?> ⬅️ ::Transpose(%"val_812") {perm=(0, 2, 1)}
    1190 |  # node_Concat_812
            %"val_814"<?,?> ⬅️ ::Concat(%"val_809", %"val_805", %"val_807") {axis=0}
    1191 |  # node_Reshape_813
            %"val_815"<?,?> ⬅️ ::Reshape(%"val_813", %"val_814") {allowzero=0}
    1192 |  # node_Sqrt_814
            %"val_816"<?,?> ⬅️ ::Sqrt(%"val_801")
    1193 |  # node_Mul_815
            %"val_817"<?,?> ⬅️ ::Mul(%"add", %"val_816")
    1194 |  # node_Sqrt_816
            %"val_818"<?,?> ⬅️ ::Sqrt(%"val_801")
    1195 |  # node_Mul_817
            %"val_819"<?,?> ⬅️ ::Mul(%"val_815", %"val_818")
    1196 |  # node_MatMul_818
            %"val_820"<?,?> ⬅️ ::MatMul(%"val_817", %"val_819")
    1197 |  # node_Add_819
            %"val_821"<?,?> ⬅️ ::Add(%"val_820", %"masked_fill")
    1198 |  # node_Softmax_820
            %"val_822"<?,?> ⬅️ ::Softmax(%"val_821") {axis=-1}
    1199 |  # node_scaled_dot_product_attention
            %"scaled_dot_product_attention"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_822", %"getitem_2")
    1200 |  # node_transpose_23
            %"transpose_23"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention") {perm=(0, 2, 1, 3)}
    1201 |  # node_Constant_821
            %"val_823"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[3]>(array([  1,  -1, 768]), name=None)}
    1202 |  # node_Cast_822
            %"val_824"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1203 |  # node_view_1
            %"view_1"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_23", %"val_824") {allowzero=1}
    1204 |  # node_Transpose_823
            %"val_825"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.attn.Wo.weight"{...}) {perm=(1, 0)}
    1205 |  # node_linear_1
            %"linear_1"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_1", %"val_825")
    1206 |  # node_add_2
            %"add_2"<FLOAT,[1,97,768]> ⬅️ ::Add(%"clone_1", %"linear_1")
    1207 |  # node_layer_norm_1
            %"layer_norm_1"<FLOAT,[1,97,768]>, %"val_826"<?,?>, %"val_827"<?,?> ⬅️ ::LayerNormalization(%"add_2", %"encoder.layers.0.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1208 |  # node_Transpose_824
            %"val_828"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1209 |  # node_linear_2
            %"linear_2"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_1", %"val_828")
    1210 |  # node_Constant_825
            %"val_829"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(1152), name=None)}
    1211 |  # node_split
            %"split"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_2", %"val_829") {dim=-1}
    1212 |  # node_getitem_3
            %"getitem_3"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split", %"val_6")
    1213 |  # node_getitem_4
            %"getitem_4"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split", %"val_48")
    1214 |  # node_Constant_826
            %"val_830"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1215 |  # node_Div_827
            %"val_831"<?,?> ⬅️ ::Div(%"getitem_3", %"val_830")
    1216 |  # node_Erf_828
            %"val_832"<?,?> ⬅️ ::Erf(%"val_831")
    1217 |  # node_Constant_829
            %"val_833"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1218 |  # node_Add_830
            %"val_834"<?,?> ⬅️ ::Add(%"val_832", %"val_833")
    1219 |  # node_Constant_831
            %"val_835"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1220 |  # node_Mul_832
            %"val_836"<?,?> ⬅️ ::Mul(%"val_835", %"val_834")
    1221 |  # node_gelu
            %"gelu"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_3", %"val_836")
    1222 |  # node_mul_48
            %"mul_48"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu", %"getitem_4")
    1223 |  # node_clone_2
            %"clone_2"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_48")
    1224 |  # node_Transpose_833
            %"val_837"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1225 |  # node_linear_3
            %"linear_3"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_2", %"val_837")
    1226 |  # node_add_3
            %"add_3"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_2", %"linear_3")
    1227 |  # node_layer_norm_2
            %"layer_norm_2"<FLOAT,[1,97,768]>, %"val_838"<?,?>, %"val_839"<?,?> ⬅️ ::LayerNormalization(%"add_3", %"encoder.layers.1.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1228 |  # node_Transpose_834
            %"val_840"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1229 |  # node_linear_4
            %"linear_4"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_2", %"val_840")
    1230 |  # node_Cast_835
            %"val_841"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1231 |  # node_view_2
            %"view_2"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_4", %"val_841") {allowzero=1}
    1232 |  # node_transpose_24
            %"transpose_24"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_2") {perm=(0, 3, 2, 1, 4)}
    1233 |  # node_unbind_1
            %"unbind_1"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_24") {dim=2}
    1234 |  # node_getitem_5
            %"getitem_5"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_1", %"val_6")
    1235 |  # node_getitem_6
            %"getitem_6"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_1", %"val_48")
    1236 |  # node_getitem_7
            %"getitem_7"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_1", %"val_72")
    1237 |  # node_unsqueeze_74
            %"unsqueeze_74"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1238 |  # node_unsqueeze_75
            %"unsqueeze_75"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1239 |  # node_mul_49
            %"mul_49"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_5", %"unsqueeze_74")
    1240 |  # node_Cast_836
            %"val_842"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1241 |  # node_Constant_837
            %"val_843"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1242 |  # node_Reshape_838
            %"val_844"<?,?> ⬅️ ::Reshape(%"val_842", %"val_843") {allowzero=0}
    1243 |  # node_Cast_839
            %"val_845"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1244 |  # node_Constant_840
            %"val_846"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1245 |  # node_Reshape_841
            %"val_847"<?,?> ⬅️ ::Reshape(%"val_845", %"val_846") {allowzero=0}
    1246 |  # node_Cast_842
            %"val_848"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1247 |  # node_Constant_843
            %"val_849"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1248 |  # node_Reshape_844
            %"val_850"<?,?> ⬅️ ::Reshape(%"val_848", %"val_849") {allowzero=0}
    1249 |  # node_Constant_845
            %"val_851"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1250 |  # node_slice_73
            %"slice_73"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_5", %"val_844", %"val_847", %"val_850", %"val_851")
    1251 |  # node_Cast_846
            %"val_852"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1252 |  # node_Constant_847
            %"val_853"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1253 |  # node_Reshape_848
            %"val_854"<?,?> ⬅️ ::Reshape(%"val_852", %"val_853") {allowzero=0}
    1254 |  # node_Cast_849
            %"val_855"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1255 |  # node_Constant_850
            %"val_856"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1256 |  # node_Reshape_851
            %"val_857"<?,?> ⬅️ ::Reshape(%"val_855", %"val_856") {allowzero=0}
    1257 |  # node_Cast_852
            %"val_858"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1258 |  # node_Constant_853
            %"val_859"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1259 |  # node_Reshape_854
            %"val_860"<?,?> ⬅️ ::Reshape(%"val_858", %"val_859") {allowzero=0}
    1260 |  # node_Constant_855
            %"val_861"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1261 |  # node_slice_74
            %"slice_74"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_5", %"val_854", %"val_857", %"val_860", %"val_861")
    1262 |  # node_neg_2
            %"neg_2"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_74")
    1263 |  # node_cat_24
            %"cat_24"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_2", %"slice_73") {axis=-1}
    1264 |  # node_mul_50
            %"mul_50"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_24", %"unsqueeze_75")
    1265 |  # node_add_4
            %"add_4"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_49", %"mul_50")
    1266 |  # node_mul_51
            %"mul_51"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_6", %"unsqueeze_74")
    1267 |  # node_Cast_856
            %"val_862"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1268 |  # node_Constant_857
            %"val_863"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1269 |  # node_Reshape_858
            %"val_864"<?,?> ⬅️ ::Reshape(%"val_862", %"val_863") {allowzero=0}
    1270 |  # node_Cast_859
            %"val_865"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1271 |  # node_Constant_860
            %"val_866"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1272 |  # node_Reshape_861
            %"val_867"<?,?> ⬅️ ::Reshape(%"val_865", %"val_866") {allowzero=0}
    1273 |  # node_Cast_862
            %"val_868"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1274 |  # node_Constant_863
            %"val_869"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1275 |  # node_Reshape_864
            %"val_870"<?,?> ⬅️ ::Reshape(%"val_868", %"val_869") {allowzero=0}
    1276 |  # node_Constant_865
            %"val_871"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1277 |  # node_slice_75
            %"slice_75"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_6", %"val_864", %"val_867", %"val_870", %"val_871")
    1278 |  # node_Cast_866
            %"val_872"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1279 |  # node_Constant_867
            %"val_873"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1280 |  # node_Reshape_868
            %"val_874"<?,?> ⬅️ ::Reshape(%"val_872", %"val_873") {allowzero=0}
    1281 |  # node_Cast_869
            %"val_875"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1282 |  # node_Constant_870
            %"val_876"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1283 |  # node_Reshape_871
            %"val_877"<?,?> ⬅️ ::Reshape(%"val_875", %"val_876") {allowzero=0}
    1284 |  # node_Cast_872
            %"val_878"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1285 |  # node_Constant_873
            %"val_879"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1286 |  # node_Reshape_874
            %"val_880"<?,?> ⬅️ ::Reshape(%"val_878", %"val_879") {allowzero=0}
    1287 |  # node_Constant_875
            %"val_881"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1288 |  # node_slice_76
            %"slice_76"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_6", %"val_874", %"val_877", %"val_880", %"val_881")
    1289 |  # node_neg_3
            %"neg_3"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_76")
    1290 |  # node_cat_25
            %"cat_25"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_3", %"slice_75") {axis=-1}
    1291 |  # node_mul_52
            %"mul_52"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_25", %"unsqueeze_75")
    1292 |  # node_add_5
            %"add_5"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_51", %"mul_52")
    1293 |  # node_Shape_876
            %"val_882"<?,?> ⬅️ ::Shape(%"add_4") {start=0}
    1294 |  # node_Constant_877
            %"val_883"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1295 |  # node_Gather_878
            %"val_884"<?,?> ⬅️ ::Gather(%"val_882", %"val_883") {axis=0}
    1296 |  # node_CastLike_879
            %"val_885"<?,?> ⬅️ ::CastLike(%"val_884", %"add_4")
    1297 |  # node_Constant_880
            %"val_886"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1298 |  # node_CastLike_881
            %"val_887"<?,?> ⬅️ ::CastLike(%"val_886", %"add_4")
    1299 |  # node_Sqrt_882
            %"val_888"<?,?> ⬅️ ::Sqrt(%"val_885")
    1300 |  # node_Div_883
            %"val_889"<?,?> ⬅️ ::Div(%"val_887", %"val_888")
    1301 |  # node_CastLike_884
            %"val_890"<?,?> ⬅️ ::CastLike(%"val_889", %"add_4")
    1302 |  # node_Shape_885
            %"val_891"<?,?> ⬅️ ::Shape(%"add_5") {start=0}
    1303 |  # node_Constant_886
            %"val_892"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1304 |  # node_Slice_887
            %"val_893"<?,?> ⬅️ ::Slice(%"val_891", %"val_804", %"val_892")
    1305 |  # node_Slice_888
            %"val_894"<?,?> ⬅️ ::Slice(%"val_891", %"val_806", %"val_804")
    1306 |  # node_Constant_889
            %"val_895"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1307 |  # node_Slice_890
            %"val_896"<?,?> ⬅️ ::Slice(%"val_891", %"val_895", %"val_806")
    1308 |  # node_Constant_891
            %"val_897"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1309 |  # node_Concat_892
            %"val_898"<?,?> ⬅️ ::Concat(%"val_897", %"val_894", %"val_893") {axis=0}
    1310 |  # node_Reshape_893
            %"val_899"<?,?> ⬅️ ::Reshape(%"add_5", %"val_898") {allowzero=0}
    1311 |  # node_Transpose_894
            %"val_900"<?,?> ⬅️ ::Transpose(%"val_899") {perm=(0, 2, 1)}
    1312 |  # node_Concat_895
            %"val_901"<?,?> ⬅️ ::Concat(%"val_896", %"val_893", %"val_894") {axis=0}
    1313 |  # node_Reshape_896
            %"val_902"<?,?> ⬅️ ::Reshape(%"val_900", %"val_901") {allowzero=0}
    1314 |  # node_Sqrt_897
            %"val_903"<?,?> ⬅️ ::Sqrt(%"val_890")
    1315 |  # node_Mul_898
            %"val_904"<?,?> ⬅️ ::Mul(%"add_4", %"val_903")
    1316 |  # node_Sqrt_899
            %"val_905"<?,?> ⬅️ ::Sqrt(%"val_890")
    1317 |  # node_Mul_900
            %"val_906"<?,?> ⬅️ ::Mul(%"val_902", %"val_905")
    1318 |  # node_MatMul_901
            %"val_907"<?,?> ⬅️ ::MatMul(%"val_904", %"val_906")
    1319 |  # node_Add_902
            %"val_908"<?,?> ⬅️ ::Add(%"val_907", %"masked_fill_1")
    1320 |  # node_Softmax_903
            %"val_909"<?,?> ⬅️ ::Softmax(%"val_908") {axis=-1}
    1321 |  # node_scaled_dot_product_attention_1
            %"scaled_dot_product_attention_1"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_909", %"getitem_7")
    1322 |  # node_transpose_25
            %"transpose_25"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_1") {perm=(0, 2, 1, 3)}
    1323 |  # node_Cast_904
            %"val_910"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1324 |  # node_view_3
            %"view_3"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_25", %"val_910") {allowzero=1}
    1325 |  # node_Transpose_905
            %"val_911"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.attn.Wo.weight"{...}) {perm=(1, 0)}
    1326 |  # node_linear_5
            %"linear_5"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_3", %"val_911")
    1327 |  # node_add_6
            %"add_6"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_3", %"linear_5")
    1328 |  # node_layer_norm_3
            %"layer_norm_3"<FLOAT,[1,97,768]>, %"val_912"<?,?>, %"val_913"<?,?> ⬅️ ::LayerNormalization(%"add_6", %"encoder.layers.1.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1329 |  # node_Transpose_906
            %"val_914"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1330 |  # node_linear_6
            %"linear_6"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_3", %"val_914")
    1331 |  # node_split_1
            %"split_1"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_6", %"val_829") {dim=-1}
    1332 |  # node_getitem_8
            %"getitem_8"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_1", %"val_6")
    1333 |  # node_getitem_9
            %"getitem_9"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_1", %"val_48")
    1334 |  # node_Constant_907
            %"val_915"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1335 |  # node_Div_908
            %"val_916"<?,?> ⬅️ ::Div(%"getitem_8", %"val_915")
    1336 |  # node_Erf_909
            %"val_917"<?,?> ⬅️ ::Erf(%"val_916")
    1337 |  # node_Constant_910
            %"val_918"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1338 |  # node_Add_911
            %"val_919"<?,?> ⬅️ ::Add(%"val_917", %"val_918")
    1339 |  # node_Constant_912
            %"val_920"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1340 |  # node_Mul_913
            %"val_921"<?,?> ⬅️ ::Mul(%"val_920", %"val_919")
    1341 |  # node_gelu_1
            %"gelu_1"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_8", %"val_921")
    1342 |  # node_mul_53
            %"mul_53"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_1", %"getitem_9")
    1343 |  # node_clone_3
            %"clone_3"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_53")
    1344 |  # node_Transpose_914
            %"val_922"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1345 |  # node_linear_7
            %"linear_7"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_3", %"val_922")
    1346 |  # node_add_7
            %"add_7"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_6", %"linear_7")
    1347 |  # node_layer_norm_4
            %"layer_norm_4"<FLOAT,[1,97,768]>, %"val_923"<?,?>, %"val_924"<?,?> ⬅️ ::LayerNormalization(%"add_7", %"encoder.layers.2.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1348 |  # node_Transpose_915
            %"val_925"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1349 |  # node_linear_8
            %"linear_8"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_4", %"val_925")
    1350 |  # node_Cast_916
            %"val_926"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1351 |  # node_view_4
            %"view_4"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_8", %"val_926") {allowzero=1}
    1352 |  # node_transpose_26
            %"transpose_26"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_4") {perm=(0, 3, 2, 1, 4)}
    1353 |  # node_unbind_2
            %"unbind_2"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_26") {dim=2}
    1354 |  # node_getitem_10
            %"getitem_10"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_2", %"val_6")
    1355 |  # node_getitem_11
            %"getitem_11"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_2", %"val_48")
    1356 |  # node_getitem_12
            %"getitem_12"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_2", %"val_72")
    1357 |  # node_unsqueeze_76
            %"unsqueeze_76"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1358 |  # node_unsqueeze_77
            %"unsqueeze_77"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1359 |  # node_mul_54
            %"mul_54"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_10", %"unsqueeze_76")
    1360 |  # node_Cast_917
            %"val_927"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1361 |  # node_Constant_918
            %"val_928"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1362 |  # node_Reshape_919
            %"val_929"<?,?> ⬅️ ::Reshape(%"val_927", %"val_928") {allowzero=0}
    1363 |  # node_Cast_920
            %"val_930"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1364 |  # node_Constant_921
            %"val_931"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1365 |  # node_Reshape_922
            %"val_932"<?,?> ⬅️ ::Reshape(%"val_930", %"val_931") {allowzero=0}
    1366 |  # node_Cast_923
            %"val_933"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1367 |  # node_Constant_924
            %"val_934"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1368 |  # node_Reshape_925
            %"val_935"<?,?> ⬅️ ::Reshape(%"val_933", %"val_934") {allowzero=0}
    1369 |  # node_Constant_926
            %"val_936"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1370 |  # node_slice_77
            %"slice_77"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_10", %"val_929", %"val_932", %"val_935", %"val_936")
    1371 |  # node_Cast_927
            %"val_937"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1372 |  # node_Constant_928
            %"val_938"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1373 |  # node_Reshape_929
            %"val_939"<?,?> ⬅️ ::Reshape(%"val_937", %"val_938") {allowzero=0}
    1374 |  # node_Cast_930
            %"val_940"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1375 |  # node_Constant_931
            %"val_941"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1376 |  # node_Reshape_932
            %"val_942"<?,?> ⬅️ ::Reshape(%"val_940", %"val_941") {allowzero=0}
    1377 |  # node_Cast_933
            %"val_943"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1378 |  # node_Constant_934
            %"val_944"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1379 |  # node_Reshape_935
            %"val_945"<?,?> ⬅️ ::Reshape(%"val_943", %"val_944") {allowzero=0}
    1380 |  # node_Constant_936
            %"val_946"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1381 |  # node_slice_78
            %"slice_78"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_10", %"val_939", %"val_942", %"val_945", %"val_946")
    1382 |  # node_neg_4
            %"neg_4"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_78")
    1383 |  # node_cat_26
            %"cat_26"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_4", %"slice_77") {axis=-1}
    1384 |  # node_mul_55
            %"mul_55"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_26", %"unsqueeze_77")
    1385 |  # node_add_8
            %"add_8"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_54", %"mul_55")
    1386 |  # node_mul_56
            %"mul_56"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_11", %"unsqueeze_76")
    1387 |  # node_Cast_937
            %"val_947"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1388 |  # node_Constant_938
            %"val_948"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1389 |  # node_Reshape_939
            %"val_949"<?,?> ⬅️ ::Reshape(%"val_947", %"val_948") {allowzero=0}
    1390 |  # node_Cast_940
            %"val_950"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1391 |  # node_Constant_941
            %"val_951"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1392 |  # node_Reshape_942
            %"val_952"<?,?> ⬅️ ::Reshape(%"val_950", %"val_951") {allowzero=0}
    1393 |  # node_Cast_943
            %"val_953"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1394 |  # node_Constant_944
            %"val_954"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1395 |  # node_Reshape_945
            %"val_955"<?,?> ⬅️ ::Reshape(%"val_953", %"val_954") {allowzero=0}
    1396 |  # node_Constant_946
            %"val_956"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1397 |  # node_slice_79
            %"slice_79"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_11", %"val_949", %"val_952", %"val_955", %"val_956")
    1398 |  # node_Cast_947
            %"val_957"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1399 |  # node_Constant_948
            %"val_958"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1400 |  # node_Reshape_949
            %"val_959"<?,?> ⬅️ ::Reshape(%"val_957", %"val_958") {allowzero=0}
    1401 |  # node_Cast_950
            %"val_960"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1402 |  # node_Constant_951
            %"val_961"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1403 |  # node_Reshape_952
            %"val_962"<?,?> ⬅️ ::Reshape(%"val_960", %"val_961") {allowzero=0}
    1404 |  # node_Cast_953
            %"val_963"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1405 |  # node_Constant_954
            %"val_964"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1406 |  # node_Reshape_955
            %"val_965"<?,?> ⬅️ ::Reshape(%"val_963", %"val_964") {allowzero=0}
    1407 |  # node_Constant_956
            %"val_966"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1408 |  # node_slice_80
            %"slice_80"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_11", %"val_959", %"val_962", %"val_965", %"val_966")
    1409 |  # node_neg_5
            %"neg_5"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_80")
    1410 |  # node_cat_27
            %"cat_27"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_5", %"slice_79") {axis=-1}
    1411 |  # node_mul_57
            %"mul_57"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_27", %"unsqueeze_77")
    1412 |  # node_add_9
            %"add_9"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_56", %"mul_57")
    1413 |  # node_Shape_957
            %"val_967"<?,?> ⬅️ ::Shape(%"add_8") {start=0}
    1414 |  # node_Constant_958
            %"val_968"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1415 |  # node_Gather_959
            %"val_969"<?,?> ⬅️ ::Gather(%"val_967", %"val_968") {axis=0}
    1416 |  # node_CastLike_960
            %"val_970"<?,?> ⬅️ ::CastLike(%"val_969", %"add_8")
    1417 |  # node_Constant_961
            %"val_971"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1418 |  # node_CastLike_962
            %"val_972"<?,?> ⬅️ ::CastLike(%"val_971", %"add_8")
    1419 |  # node_Sqrt_963
            %"val_973"<?,?> ⬅️ ::Sqrt(%"val_970")
    1420 |  # node_Div_964
            %"val_974"<?,?> ⬅️ ::Div(%"val_972", %"val_973")
    1421 |  # node_CastLike_965
            %"val_975"<?,?> ⬅️ ::CastLike(%"val_974", %"add_8")
    1422 |  # node_Shape_966
            %"val_976"<?,?> ⬅️ ::Shape(%"add_9") {start=0}
    1423 |  # node_Constant_967
            %"val_977"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1424 |  # node_Slice_968
            %"val_978"<?,?> ⬅️ ::Slice(%"val_976", %"val_804", %"val_977")
    1425 |  # node_Slice_969
            %"val_979"<?,?> ⬅️ ::Slice(%"val_976", %"val_806", %"val_804")
    1426 |  # node_Constant_970
            %"val_980"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1427 |  # node_Slice_971
            %"val_981"<?,?> ⬅️ ::Slice(%"val_976", %"val_980", %"val_806")
    1428 |  # node_Constant_972
            %"val_982"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1429 |  # node_Concat_973
            %"val_983"<?,?> ⬅️ ::Concat(%"val_982", %"val_979", %"val_978") {axis=0}
    1430 |  # node_Reshape_974
            %"val_984"<?,?> ⬅️ ::Reshape(%"add_9", %"val_983") {allowzero=0}
    1431 |  # node_Transpose_975
            %"val_985"<?,?> ⬅️ ::Transpose(%"val_984") {perm=(0, 2, 1)}
    1432 |  # node_Concat_976
            %"val_986"<?,?> ⬅️ ::Concat(%"val_981", %"val_978", %"val_979") {axis=0}
    1433 |  # node_Reshape_977
            %"val_987"<?,?> ⬅️ ::Reshape(%"val_985", %"val_986") {allowzero=0}
    1434 |  # node_Sqrt_978
            %"val_988"<?,?> ⬅️ ::Sqrt(%"val_975")
    1435 |  # node_Mul_979
            %"val_989"<?,?> ⬅️ ::Mul(%"add_8", %"val_988")
    1436 |  # node_Sqrt_980
            %"val_990"<?,?> ⬅️ ::Sqrt(%"val_975")
    1437 |  # node_Mul_981
            %"val_991"<?,?> ⬅️ ::Mul(%"val_987", %"val_990")
    1438 |  # node_MatMul_982
            %"val_992"<?,?> ⬅️ ::MatMul(%"val_989", %"val_991")
    1439 |  # node_Add_983
            %"val_993"<?,?> ⬅️ ::Add(%"val_992", %"masked_fill_1")
    1440 |  # node_Softmax_984
            %"val_994"<?,?> ⬅️ ::Softmax(%"val_993") {axis=-1}
    1441 |  # node_scaled_dot_product_attention_2
            %"scaled_dot_product_attention_2"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_994", %"getitem_12")
    1442 |  # node_transpose_27
            %"transpose_27"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_2") {perm=(0, 2, 1, 3)}
    1443 |  # node_Cast_985
            %"val_995"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1444 |  # node_view_5
            %"view_5"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_27", %"val_995") {allowzero=1}
    1445 |  # node_Transpose_986
            %"val_996"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.attn.Wo.weight"{...}) {perm=(1, 0)}
    1446 |  # node_linear_9
            %"linear_9"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_5", %"val_996")
    1447 |  # node_add_10
            %"add_10"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_7", %"linear_9")
    1448 |  # node_layer_norm_5
            %"layer_norm_5"<FLOAT,[1,97,768]>, %"val_997"<?,?>, %"val_998"<?,?> ⬅️ ::LayerNormalization(%"add_10", %"encoder.layers.2.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1449 |  # node_Transpose_987
            %"val_999"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1450 |  # node_linear_10
            %"linear_10"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_5", %"val_999")
    1451 |  # node_split_2
            %"split_2"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_10", %"val_829") {dim=-1}
    1452 |  # node_getitem_13
            %"getitem_13"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_2", %"val_6")
    1453 |  # node_getitem_14
            %"getitem_14"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_2", %"val_48")
    1454 |  # node_Constant_988
            %"val_1000"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1455 |  # node_Div_989
            %"val_1001"<?,?> ⬅️ ::Div(%"getitem_13", %"val_1000")
    1456 |  # node_Erf_990
            %"val_1002"<?,?> ⬅️ ::Erf(%"val_1001")
    1457 |  # node_Constant_991
            %"val_1003"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1458 |  # node_Add_992
            %"val_1004"<?,?> ⬅️ ::Add(%"val_1002", %"val_1003")
    1459 |  # node_Constant_993
            %"val_1005"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1460 |  # node_Mul_994
            %"val_1006"<?,?> ⬅️ ::Mul(%"val_1005", %"val_1004")
    1461 |  # node_gelu_2
            %"gelu_2"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_13", %"val_1006")
    1462 |  # node_mul_58
            %"mul_58"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_2", %"getitem_14")
    1463 |  # node_clone_4
            %"clone_4"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_58")
    1464 |  # node_Transpose_995
            %"val_1007"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1465 |  # node_linear_11
            %"linear_11"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_4", %"val_1007")
    1466 |  # node_add_11
            %"add_11"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_10", %"linear_11")
    1467 |  # node_layer_norm_6
            %"layer_norm_6"<FLOAT,[1,97,768]>, %"val_1008"<?,?>, %"val_1009"<?,?> ⬅️ ::LayerNormalization(%"add_11", %"encoder.layers.3.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1468 |  # node_Transpose_996
            %"val_1010"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1469 |  # node_linear_12
            %"linear_12"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_6", %"val_1010")
    1470 |  # node_Cast_997
            %"val_1011"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1471 |  # node_view_6
            %"view_6"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_12", %"val_1011") {allowzero=1}
    1472 |  # node_transpose_28
            %"transpose_28"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_6") {perm=(0, 3, 2, 1, 4)}
    1473 |  # node_unbind_3
            %"unbind_3"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_28") {dim=2}
    1474 |  # node_getitem_15
            %"getitem_15"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_3", %"val_6")
    1475 |  # node_getitem_16
            %"getitem_16"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_3", %"val_48")
    1476 |  # node_getitem_17
            %"getitem_17"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_3", %"val_72")
    1477 |  # node_unsqueeze_78
            %"unsqueeze_78"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    1478 |  # node_unsqueeze_79
            %"unsqueeze_79"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    1479 |  # node_mul_59
            %"mul_59"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_15", %"unsqueeze_78")
    1480 |  # node_Cast_998
            %"val_1012"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1481 |  # node_Constant_999
            %"val_1013"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1482 |  # node_Reshape_1000
            %"val_1014"<?,?> ⬅️ ::Reshape(%"val_1012", %"val_1013") {allowzero=0}
    1483 |  # node_Cast_1001
            %"val_1015"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1484 |  # node_Constant_1002
            %"val_1016"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1485 |  # node_Reshape_1003
            %"val_1017"<?,?> ⬅️ ::Reshape(%"val_1015", %"val_1016") {allowzero=0}
    1486 |  # node_Cast_1004
            %"val_1018"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1487 |  # node_Constant_1005
            %"val_1019"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1488 |  # node_Reshape_1006
            %"val_1020"<?,?> ⬅️ ::Reshape(%"val_1018", %"val_1019") {allowzero=0}
    1489 |  # node_Constant_1007
            %"val_1021"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1490 |  # node_slice_81
            %"slice_81"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_15", %"val_1014", %"val_1017", %"val_1020", %"val_1021")
    1491 |  # node_Cast_1008
            %"val_1022"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1492 |  # node_Constant_1009
            %"val_1023"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1493 |  # node_Reshape_1010
            %"val_1024"<?,?> ⬅️ ::Reshape(%"val_1022", %"val_1023") {allowzero=0}
    1494 |  # node_Cast_1011
            %"val_1025"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1495 |  # node_Constant_1012
            %"val_1026"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1496 |  # node_Reshape_1013
            %"val_1027"<?,?> ⬅️ ::Reshape(%"val_1025", %"val_1026") {allowzero=0}
    1497 |  # node_Cast_1014
            %"val_1028"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1498 |  # node_Constant_1015
            %"val_1029"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1499 |  # node_Reshape_1016
            %"val_1030"<?,?> ⬅️ ::Reshape(%"val_1028", %"val_1029") {allowzero=0}
    1500 |  # node_Constant_1017
            %"val_1031"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1501 |  # node_slice_82
            %"slice_82"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_15", %"val_1024", %"val_1027", %"val_1030", %"val_1031")
    1502 |  # node_neg_6
            %"neg_6"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_82")
    1503 |  # node_cat_28
            %"cat_28"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_6", %"slice_81") {axis=-1}
    1504 |  # node_mul_60
            %"mul_60"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_28", %"unsqueeze_79")
    1505 |  # node_add_12
            %"add_12"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_59", %"mul_60")
    1506 |  # node_mul_61
            %"mul_61"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_16", %"unsqueeze_78")
    1507 |  # node_Cast_1018
            %"val_1032"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1508 |  # node_Constant_1019
            %"val_1033"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1509 |  # node_Reshape_1020
            %"val_1034"<?,?> ⬅️ ::Reshape(%"val_1032", %"val_1033") {allowzero=0}
    1510 |  # node_Cast_1021
            %"val_1035"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1511 |  # node_Constant_1022
            %"val_1036"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1512 |  # node_Reshape_1023
            %"val_1037"<?,?> ⬅️ ::Reshape(%"val_1035", %"val_1036") {allowzero=0}
    1513 |  # node_Cast_1024
            %"val_1038"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1514 |  # node_Constant_1025
            %"val_1039"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1515 |  # node_Reshape_1026
            %"val_1040"<?,?> ⬅️ ::Reshape(%"val_1038", %"val_1039") {allowzero=0}
    1516 |  # node_Constant_1027
            %"val_1041"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1517 |  # node_slice_83
            %"slice_83"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_16", %"val_1034", %"val_1037", %"val_1040", %"val_1041")
    1518 |  # node_Cast_1028
            %"val_1042"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1519 |  # node_Constant_1029
            %"val_1043"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1520 |  # node_Reshape_1030
            %"val_1044"<?,?> ⬅️ ::Reshape(%"val_1042", %"val_1043") {allowzero=0}
    1521 |  # node_Cast_1031
            %"val_1045"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1522 |  # node_Constant_1032
            %"val_1046"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1523 |  # node_Reshape_1033
            %"val_1047"<?,?> ⬅️ ::Reshape(%"val_1045", %"val_1046") {allowzero=0}
    1524 |  # node_Cast_1034
            %"val_1048"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1525 |  # node_Constant_1035
            %"val_1049"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1526 |  # node_Reshape_1036
            %"val_1050"<?,?> ⬅️ ::Reshape(%"val_1048", %"val_1049") {allowzero=0}
    1527 |  # node_Constant_1037
            %"val_1051"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1528 |  # node_slice_84
            %"slice_84"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_16", %"val_1044", %"val_1047", %"val_1050", %"val_1051")
    1529 |  # node_neg_7
            %"neg_7"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_84")
    1530 |  # node_cat_29
            %"cat_29"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_7", %"slice_83") {axis=-1}
    1531 |  # node_mul_62
            %"mul_62"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_29", %"unsqueeze_79")
    1532 |  # node_add_13
            %"add_13"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_61", %"mul_62")
    1533 |  # node_Shape_1038
            %"val_1052"<?,?> ⬅️ ::Shape(%"add_12") {start=0}
    1534 |  # node_Constant_1039
            %"val_1053"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1535 |  # node_Gather_1040
            %"val_1054"<?,?> ⬅️ ::Gather(%"val_1052", %"val_1053") {axis=0}
    1536 |  # node_CastLike_1041
            %"val_1055"<?,?> ⬅️ ::CastLike(%"val_1054", %"add_12")
    1537 |  # node_Constant_1042
            %"val_1056"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1538 |  # node_CastLike_1043
            %"val_1057"<?,?> ⬅️ ::CastLike(%"val_1056", %"add_12")
    1539 |  # node_Sqrt_1044
            %"val_1058"<?,?> ⬅️ ::Sqrt(%"val_1055")
    1540 |  # node_Div_1045
            %"val_1059"<?,?> ⬅️ ::Div(%"val_1057", %"val_1058")
    1541 |  # node_CastLike_1046
            %"val_1060"<?,?> ⬅️ ::CastLike(%"val_1059", %"add_12")
    1542 |  # node_Shape_1047
            %"val_1061"<?,?> ⬅️ ::Shape(%"add_13") {start=0}
    1543 |  # node_Constant_1048
            %"val_1062"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1544 |  # node_Slice_1049
            %"val_1063"<?,?> ⬅️ ::Slice(%"val_1061", %"val_804", %"val_1062")
    1545 |  # node_Slice_1050
            %"val_1064"<?,?> ⬅️ ::Slice(%"val_1061", %"val_806", %"val_804")
    1546 |  # node_Constant_1051
            %"val_1065"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1547 |  # node_Slice_1052
            %"val_1066"<?,?> ⬅️ ::Slice(%"val_1061", %"val_1065", %"val_806")
    1548 |  # node_Constant_1053
            %"val_1067"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1549 |  # node_Concat_1054
            %"val_1068"<?,?> ⬅️ ::Concat(%"val_1067", %"val_1064", %"val_1063") {axis=0}
    1550 |  # node_Reshape_1055
            %"val_1069"<?,?> ⬅️ ::Reshape(%"add_13", %"val_1068") {allowzero=0}
    1551 |  # node_Transpose_1056
            %"val_1070"<?,?> ⬅️ ::Transpose(%"val_1069") {perm=(0, 2, 1)}
    1552 |  # node_Concat_1057
            %"val_1071"<?,?> ⬅️ ::Concat(%"val_1066", %"val_1063", %"val_1064") {axis=0}
    1553 |  # node_Reshape_1058
            %"val_1072"<?,?> ⬅️ ::Reshape(%"val_1070", %"val_1071") {allowzero=0}
    1554 |  # node_Sqrt_1059
            %"val_1073"<?,?> ⬅️ ::Sqrt(%"val_1060")
    1555 |  # node_Mul_1060
            %"val_1074"<?,?> ⬅️ ::Mul(%"add_12", %"val_1073")
    1556 |  # node_Sqrt_1061
            %"val_1075"<?,?> ⬅️ ::Sqrt(%"val_1060")
    1557 |  # node_Mul_1062
            %"val_1076"<?,?> ⬅️ ::Mul(%"val_1072", %"val_1075")
    1558 |  # node_MatMul_1063
            %"val_1077"<?,?> ⬅️ ::MatMul(%"val_1074", %"val_1076")
    1559 |  # node_Add_1064
            %"val_1078"<?,?> ⬅️ ::Add(%"val_1077", %"masked_fill")
    1560 |  # node_Softmax_1065
            %"val_1079"<?,?> ⬅️ ::Softmax(%"val_1078") {axis=-1}
    1561 |  # node_scaled_dot_product_attention_3
            %"scaled_dot_product_attention_3"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1079", %"getitem_17")
    1562 |  # node_transpose_29
            %"transpose_29"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_3") {perm=(0, 2, 1, 3)}
    1563 |  # node_Cast_1066
            %"val_1080"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1564 |  # node_view_7
            %"view_7"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_29", %"val_1080") {allowzero=1}
    1565 |  # node_Transpose_1067
            %"val_1081"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.attn.Wo.weight"{...}) {perm=(1, 0)}
    1566 |  # node_linear_13
            %"linear_13"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_7", %"val_1081")
    1567 |  # node_add_14
            %"add_14"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_11", %"linear_13")
    1568 |  # node_layer_norm_7
            %"layer_norm_7"<FLOAT,[1,97,768]>, %"val_1082"<?,?>, %"val_1083"<?,?> ⬅️ ::LayerNormalization(%"add_14", %"encoder.layers.3.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1569 |  # node_Transpose_1068
            %"val_1084"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1570 |  # node_linear_14
            %"linear_14"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_7", %"val_1084")
    1571 |  # node_split_3
            %"split_3"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_14", %"val_829") {dim=-1}
    1572 |  # node_getitem_18
            %"getitem_18"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_3", %"val_6")
    1573 |  # node_getitem_19
            %"getitem_19"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_3", %"val_48")
    1574 |  # node_Constant_1069
            %"val_1085"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1575 |  # node_Div_1070
            %"val_1086"<?,?> ⬅️ ::Div(%"getitem_18", %"val_1085")
    1576 |  # node_Erf_1071
            %"val_1087"<?,?> ⬅️ ::Erf(%"val_1086")
    1577 |  # node_Constant_1072
            %"val_1088"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1578 |  # node_Add_1073
            %"val_1089"<?,?> ⬅️ ::Add(%"val_1087", %"val_1088")
    1579 |  # node_Constant_1074
            %"val_1090"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1580 |  # node_Mul_1075
            %"val_1091"<?,?> ⬅️ ::Mul(%"val_1090", %"val_1089")
    1581 |  # node_gelu_3
            %"gelu_3"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_18", %"val_1091")
    1582 |  # node_mul_63
            %"mul_63"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_3", %"getitem_19")
    1583 |  # node_clone_5
            %"clone_5"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_63")
    1584 |  # node_Transpose_1076
            %"val_1092"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1585 |  # node_linear_15
            %"linear_15"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_5", %"val_1092")
    1586 |  # node_add_15
            %"add_15"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_14", %"linear_15")
    1587 |  # node_layer_norm_8
            %"layer_norm_8"<FLOAT,[1,97,768]>, %"val_1093"<?,?>, %"val_1094"<?,?> ⬅️ ::LayerNormalization(%"add_15", %"encoder.layers.4.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1588 |  # node_Transpose_1077
            %"val_1095"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1589 |  # node_linear_16
            %"linear_16"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_8", %"val_1095")
    1590 |  # node_Cast_1078
            %"val_1096"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1591 |  # node_view_8
            %"view_8"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_16", %"val_1096") {allowzero=1}
    1592 |  # node_transpose_30
            %"transpose_30"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_8") {perm=(0, 3, 2, 1, 4)}
    1593 |  # node_unbind_4
            %"unbind_4"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_30") {dim=2}
    1594 |  # node_getitem_20
            %"getitem_20"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_4", %"val_6")
    1595 |  # node_getitem_21
            %"getitem_21"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_4", %"val_48")
    1596 |  # node_getitem_22
            %"getitem_22"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_4", %"val_72")
    1597 |  # node_unsqueeze_80
            %"unsqueeze_80"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1598 |  # node_unsqueeze_81
            %"unsqueeze_81"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1599 |  # node_mul_64
            %"mul_64"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_20", %"unsqueeze_80")
    1600 |  # node_Cast_1079
            %"val_1097"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1601 |  # node_Constant_1080
            %"val_1098"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1602 |  # node_Reshape_1081
            %"val_1099"<?,?> ⬅️ ::Reshape(%"val_1097", %"val_1098") {allowzero=0}
    1603 |  # node_Cast_1082
            %"val_1100"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1604 |  # node_Constant_1083
            %"val_1101"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1605 |  # node_Reshape_1084
            %"val_1102"<?,?> ⬅️ ::Reshape(%"val_1100", %"val_1101") {allowzero=0}
    1606 |  # node_Cast_1085
            %"val_1103"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1607 |  # node_Constant_1086
            %"val_1104"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1608 |  # node_Reshape_1087
            %"val_1105"<?,?> ⬅️ ::Reshape(%"val_1103", %"val_1104") {allowzero=0}
    1609 |  # node_Constant_1088
            %"val_1106"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1610 |  # node_slice_85
            %"slice_85"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_20", %"val_1099", %"val_1102", %"val_1105", %"val_1106")
    1611 |  # node_Cast_1089
            %"val_1107"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1612 |  # node_Constant_1090
            %"val_1108"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1613 |  # node_Reshape_1091
            %"val_1109"<?,?> ⬅️ ::Reshape(%"val_1107", %"val_1108") {allowzero=0}
    1614 |  # node_Cast_1092
            %"val_1110"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1615 |  # node_Constant_1093
            %"val_1111"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1616 |  # node_Reshape_1094
            %"val_1112"<?,?> ⬅️ ::Reshape(%"val_1110", %"val_1111") {allowzero=0}
    1617 |  # node_Cast_1095
            %"val_1113"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1618 |  # node_Constant_1096
            %"val_1114"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1619 |  # node_Reshape_1097
            %"val_1115"<?,?> ⬅️ ::Reshape(%"val_1113", %"val_1114") {allowzero=0}
    1620 |  # node_Constant_1098
            %"val_1116"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1621 |  # node_slice_86
            %"slice_86"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_20", %"val_1109", %"val_1112", %"val_1115", %"val_1116")
    1622 |  # node_neg_8
            %"neg_8"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_86")
    1623 |  # node_cat_30
            %"cat_30"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_8", %"slice_85") {axis=-1}
    1624 |  # node_mul_65
            %"mul_65"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_30", %"unsqueeze_81")
    1625 |  # node_add_16
            %"add_16"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_64", %"mul_65")
    1626 |  # node_mul_66
            %"mul_66"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_21", %"unsqueeze_80")
    1627 |  # node_Cast_1099
            %"val_1117"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1628 |  # node_Constant_1100
            %"val_1118"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1629 |  # node_Reshape_1101
            %"val_1119"<?,?> ⬅️ ::Reshape(%"val_1117", %"val_1118") {allowzero=0}
    1630 |  # node_Cast_1102
            %"val_1120"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1631 |  # node_Constant_1103
            %"val_1121"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1632 |  # node_Reshape_1104
            %"val_1122"<?,?> ⬅️ ::Reshape(%"val_1120", %"val_1121") {allowzero=0}
    1633 |  # node_Cast_1105
            %"val_1123"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1634 |  # node_Constant_1106
            %"val_1124"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1635 |  # node_Reshape_1107
            %"val_1125"<?,?> ⬅️ ::Reshape(%"val_1123", %"val_1124") {allowzero=0}
    1636 |  # node_Constant_1108
            %"val_1126"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1637 |  # node_slice_87
            %"slice_87"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_21", %"val_1119", %"val_1122", %"val_1125", %"val_1126")
    1638 |  # node_Cast_1109
            %"val_1127"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1639 |  # node_Constant_1110
            %"val_1128"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1640 |  # node_Reshape_1111
            %"val_1129"<?,?> ⬅️ ::Reshape(%"val_1127", %"val_1128") {allowzero=0}
    1641 |  # node_Cast_1112
            %"val_1130"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1642 |  # node_Constant_1113
            %"val_1131"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1643 |  # node_Reshape_1114
            %"val_1132"<?,?> ⬅️ ::Reshape(%"val_1130", %"val_1131") {allowzero=0}
    1644 |  # node_Cast_1115
            %"val_1133"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1645 |  # node_Constant_1116
            %"val_1134"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1646 |  # node_Reshape_1117
            %"val_1135"<?,?> ⬅️ ::Reshape(%"val_1133", %"val_1134") {allowzero=0}
    1647 |  # node_Constant_1118
            %"val_1136"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1648 |  # node_slice_88
            %"slice_88"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_21", %"val_1129", %"val_1132", %"val_1135", %"val_1136")
    1649 |  # node_neg_9
            %"neg_9"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_88")
    1650 |  # node_cat_31
            %"cat_31"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_9", %"slice_87") {axis=-1}
    1651 |  # node_mul_67
            %"mul_67"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_31", %"unsqueeze_81")
    1652 |  # node_add_17
            %"add_17"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_66", %"mul_67")
    1653 |  # node_Shape_1119
            %"val_1137"<?,?> ⬅️ ::Shape(%"add_16") {start=0}
    1654 |  # node_Constant_1120
            %"val_1138"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1655 |  # node_Gather_1121
            %"val_1139"<?,?> ⬅️ ::Gather(%"val_1137", %"val_1138") {axis=0}
    1656 |  # node_CastLike_1122
            %"val_1140"<?,?> ⬅️ ::CastLike(%"val_1139", %"add_16")
    1657 |  # node_Constant_1123
            %"val_1141"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1658 |  # node_CastLike_1124
            %"val_1142"<?,?> ⬅️ ::CastLike(%"val_1141", %"add_16")
    1659 |  # node_Sqrt_1125
            %"val_1143"<?,?> ⬅️ ::Sqrt(%"val_1140")
    1660 |  # node_Div_1126
            %"val_1144"<?,?> ⬅️ ::Div(%"val_1142", %"val_1143")
    1661 |  # node_CastLike_1127
            %"val_1145"<?,?> ⬅️ ::CastLike(%"val_1144", %"add_16")
    1662 |  # node_Shape_1128
            %"val_1146"<?,?> ⬅️ ::Shape(%"add_17") {start=0}
    1663 |  # node_Constant_1129
            %"val_1147"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1664 |  # node_Slice_1130
            %"val_1148"<?,?> ⬅️ ::Slice(%"val_1146", %"val_804", %"val_1147")
    1665 |  # node_Slice_1131
            %"val_1149"<?,?> ⬅️ ::Slice(%"val_1146", %"val_806", %"val_804")
    1666 |  # node_Constant_1132
            %"val_1150"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1667 |  # node_Slice_1133
            %"val_1151"<?,?> ⬅️ ::Slice(%"val_1146", %"val_1150", %"val_806")
    1668 |  # node_Constant_1134
            %"val_1152"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1669 |  # node_Concat_1135
            %"val_1153"<?,?> ⬅️ ::Concat(%"val_1152", %"val_1149", %"val_1148") {axis=0}
    1670 |  # node_Reshape_1136
            %"val_1154"<?,?> ⬅️ ::Reshape(%"add_17", %"val_1153") {allowzero=0}
    1671 |  # node_Transpose_1137
            %"val_1155"<?,?> ⬅️ ::Transpose(%"val_1154") {perm=(0, 2, 1)}
    1672 |  # node_Concat_1138
            %"val_1156"<?,?> ⬅️ ::Concat(%"val_1151", %"val_1148", %"val_1149") {axis=0}
    1673 |  # node_Reshape_1139
            %"val_1157"<?,?> ⬅️ ::Reshape(%"val_1155", %"val_1156") {allowzero=0}
    1674 |  # node_Sqrt_1140
            %"val_1158"<?,?> ⬅️ ::Sqrt(%"val_1145")
    1675 |  # node_Mul_1141
            %"val_1159"<?,?> ⬅️ ::Mul(%"add_16", %"val_1158")
    1676 |  # node_Sqrt_1142
            %"val_1160"<?,?> ⬅️ ::Sqrt(%"val_1145")
    1677 |  # node_Mul_1143
            %"val_1161"<?,?> ⬅️ ::Mul(%"val_1157", %"val_1160")
    1678 |  # node_MatMul_1144
            %"val_1162"<?,?> ⬅️ ::MatMul(%"val_1159", %"val_1161")
    1679 |  # node_Add_1145
            %"val_1163"<?,?> ⬅️ ::Add(%"val_1162", %"masked_fill_1")
    1680 |  # node_Softmax_1146
            %"val_1164"<?,?> ⬅️ ::Softmax(%"val_1163") {axis=-1}
    1681 |  # node_scaled_dot_product_attention_4
            %"scaled_dot_product_attention_4"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1164", %"getitem_22")
    1682 |  # node_transpose_31
            %"transpose_31"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_4") {perm=(0, 2, 1, 3)}
    1683 |  # node_Cast_1147
            %"val_1165"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1684 |  # node_view_9
            %"view_9"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_31", %"val_1165") {allowzero=1}
    1685 |  # node_Transpose_1148
            %"val_1166"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.attn.Wo.weight"{...}) {perm=(1, 0)}
    1686 |  # node_linear_17
            %"linear_17"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_9", %"val_1166")
    1687 |  # node_add_18
            %"add_18"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_15", %"linear_17")
    1688 |  # node_layer_norm_9
            %"layer_norm_9"<FLOAT,[1,97,768]>, %"val_1167"<?,?>, %"val_1168"<?,?> ⬅️ ::LayerNormalization(%"add_18", %"encoder.layers.4.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1689 |  # node_Transpose_1149
            %"val_1169"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1690 |  # node_linear_18
            %"linear_18"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_9", %"val_1169")
    1691 |  # node_split_4
            %"split_4"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_18", %"val_829") {dim=-1}
    1692 |  # node_getitem_23
            %"getitem_23"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_4", %"val_6")
    1693 |  # node_getitem_24
            %"getitem_24"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_4", %"val_48")
    1694 |  # node_Constant_1150
            %"val_1170"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1695 |  # node_Div_1151
            %"val_1171"<?,?> ⬅️ ::Div(%"getitem_23", %"val_1170")
    1696 |  # node_Erf_1152
            %"val_1172"<?,?> ⬅️ ::Erf(%"val_1171")
    1697 |  # node_Constant_1153
            %"val_1173"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1698 |  # node_Add_1154
            %"val_1174"<?,?> ⬅️ ::Add(%"val_1172", %"val_1173")
    1699 |  # node_Constant_1155
            %"val_1175"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1700 |  # node_Mul_1156
            %"val_1176"<?,?> ⬅️ ::Mul(%"val_1175", %"val_1174")
    1701 |  # node_gelu_4
            %"gelu_4"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_23", %"val_1176")
    1702 |  # node_mul_68
            %"mul_68"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_4", %"getitem_24")
    1703 |  # node_clone_6
            %"clone_6"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_68")
    1704 |  # node_Transpose_1157
            %"val_1177"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1705 |  # node_linear_19
            %"linear_19"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_6", %"val_1177")
    1706 |  # node_add_19
            %"add_19"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_18", %"linear_19")
    1707 |  # node_layer_norm_10
            %"layer_norm_10"<FLOAT,[1,97,768]>, %"val_1178"<?,?>, %"val_1179"<?,?> ⬅️ ::LayerNormalization(%"add_19", %"encoder.layers.5.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1708 |  # node_Transpose_1158
            %"val_1180"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1709 |  # node_linear_20
            %"linear_20"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_10", %"val_1180")
    1710 |  # node_Cast_1159
            %"val_1181"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1711 |  # node_view_10
            %"view_10"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_20", %"val_1181") {allowzero=1}
    1712 |  # node_transpose_32
            %"transpose_32"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_10") {perm=(0, 3, 2, 1, 4)}
    1713 |  # node_unbind_5
            %"unbind_5"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_32") {dim=2}
    1714 |  # node_getitem_25
            %"getitem_25"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_5", %"val_6")
    1715 |  # node_getitem_26
            %"getitem_26"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_5", %"val_48")
    1716 |  # node_getitem_27
            %"getitem_27"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_5", %"val_72")
    1717 |  # node_unsqueeze_82
            %"unsqueeze_82"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1718 |  # node_unsqueeze_83
            %"unsqueeze_83"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1719 |  # node_mul_69
            %"mul_69"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_25", %"unsqueeze_82")
    1720 |  # node_Cast_1160
            %"val_1182"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1721 |  # node_Constant_1161
            %"val_1183"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1722 |  # node_Reshape_1162
            %"val_1184"<?,?> ⬅️ ::Reshape(%"val_1182", %"val_1183") {allowzero=0}
    1723 |  # node_Cast_1163
            %"val_1185"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1724 |  # node_Constant_1164
            %"val_1186"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1725 |  # node_Reshape_1165
            %"val_1187"<?,?> ⬅️ ::Reshape(%"val_1185", %"val_1186") {allowzero=0}
    1726 |  # node_Cast_1166
            %"val_1188"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1727 |  # node_Constant_1167
            %"val_1189"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1728 |  # node_Reshape_1168
            %"val_1190"<?,?> ⬅️ ::Reshape(%"val_1188", %"val_1189") {allowzero=0}
    1729 |  # node_Constant_1169
            %"val_1191"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1730 |  # node_slice_89
            %"slice_89"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_25", %"val_1184", %"val_1187", %"val_1190", %"val_1191")
    1731 |  # node_Cast_1170
            %"val_1192"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1732 |  # node_Constant_1171
            %"val_1193"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1733 |  # node_Reshape_1172
            %"val_1194"<?,?> ⬅️ ::Reshape(%"val_1192", %"val_1193") {allowzero=0}
    1734 |  # node_Cast_1173
            %"val_1195"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1735 |  # node_Constant_1174
            %"val_1196"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1736 |  # node_Reshape_1175
            %"val_1197"<?,?> ⬅️ ::Reshape(%"val_1195", %"val_1196") {allowzero=0}
    1737 |  # node_Cast_1176
            %"val_1198"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1738 |  # node_Constant_1177
            %"val_1199"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1739 |  # node_Reshape_1178
            %"val_1200"<?,?> ⬅️ ::Reshape(%"val_1198", %"val_1199") {allowzero=0}
    1740 |  # node_Constant_1179
            %"val_1201"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1741 |  # node_slice_90
            %"slice_90"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_25", %"val_1194", %"val_1197", %"val_1200", %"val_1201")
    1742 |  # node_neg_10
            %"neg_10"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_90")
    1743 |  # node_cat_32
            %"cat_32"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_10", %"slice_89") {axis=-1}
    1744 |  # node_mul_70
            %"mul_70"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_32", %"unsqueeze_83")
    1745 |  # node_add_20
            %"add_20"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_69", %"mul_70")
    1746 |  # node_mul_71
            %"mul_71"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_26", %"unsqueeze_82")
    1747 |  # node_Cast_1180
            %"val_1202"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1748 |  # node_Constant_1181
            %"val_1203"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1749 |  # node_Reshape_1182
            %"val_1204"<?,?> ⬅️ ::Reshape(%"val_1202", %"val_1203") {allowzero=0}
    1750 |  # node_Cast_1183
            %"val_1205"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1751 |  # node_Constant_1184
            %"val_1206"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1752 |  # node_Reshape_1185
            %"val_1207"<?,?> ⬅️ ::Reshape(%"val_1205", %"val_1206") {allowzero=0}
    1753 |  # node_Cast_1186
            %"val_1208"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1754 |  # node_Constant_1187
            %"val_1209"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1755 |  # node_Reshape_1188
            %"val_1210"<?,?> ⬅️ ::Reshape(%"val_1208", %"val_1209") {allowzero=0}
    1756 |  # node_Constant_1189
            %"val_1211"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1757 |  # node_slice_91
            %"slice_91"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_26", %"val_1204", %"val_1207", %"val_1210", %"val_1211")
    1758 |  # node_Cast_1190
            %"val_1212"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1759 |  # node_Constant_1191
            %"val_1213"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1760 |  # node_Reshape_1192
            %"val_1214"<?,?> ⬅️ ::Reshape(%"val_1212", %"val_1213") {allowzero=0}
    1761 |  # node_Cast_1193
            %"val_1215"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1762 |  # node_Constant_1194
            %"val_1216"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1763 |  # node_Reshape_1195
            %"val_1217"<?,?> ⬅️ ::Reshape(%"val_1215", %"val_1216") {allowzero=0}
    1764 |  # node_Cast_1196
            %"val_1218"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1765 |  # node_Constant_1197
            %"val_1219"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1766 |  # node_Reshape_1198
            %"val_1220"<?,?> ⬅️ ::Reshape(%"val_1218", %"val_1219") {allowzero=0}
    1767 |  # node_Constant_1199
            %"val_1221"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1768 |  # node_slice_92
            %"slice_92"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_26", %"val_1214", %"val_1217", %"val_1220", %"val_1221")
    1769 |  # node_neg_11
            %"neg_11"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_92")
    1770 |  # node_cat_33
            %"cat_33"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_11", %"slice_91") {axis=-1}
    1771 |  # node_mul_72
            %"mul_72"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_33", %"unsqueeze_83")
    1772 |  # node_add_21
            %"add_21"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_71", %"mul_72")
    1773 |  # node_Shape_1200
            %"val_1222"<?,?> ⬅️ ::Shape(%"add_20") {start=0}
    1774 |  # node_Constant_1201
            %"val_1223"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1775 |  # node_Gather_1202
            %"val_1224"<?,?> ⬅️ ::Gather(%"val_1222", %"val_1223") {axis=0}
    1776 |  # node_CastLike_1203
            %"val_1225"<?,?> ⬅️ ::CastLike(%"val_1224", %"add_20")
    1777 |  # node_Constant_1204
            %"val_1226"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1778 |  # node_CastLike_1205
            %"val_1227"<?,?> ⬅️ ::CastLike(%"val_1226", %"add_20")
    1779 |  # node_Sqrt_1206
            %"val_1228"<?,?> ⬅️ ::Sqrt(%"val_1225")
    1780 |  # node_Div_1207
            %"val_1229"<?,?> ⬅️ ::Div(%"val_1227", %"val_1228")
    1781 |  # node_CastLike_1208
            %"val_1230"<?,?> ⬅️ ::CastLike(%"val_1229", %"add_20")
    1782 |  # node_Shape_1209
            %"val_1231"<?,?> ⬅️ ::Shape(%"add_21") {start=0}
    1783 |  # node_Constant_1210
            %"val_1232"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1784 |  # node_Slice_1211
            %"val_1233"<?,?> ⬅️ ::Slice(%"val_1231", %"val_804", %"val_1232")
    1785 |  # node_Slice_1212
            %"val_1234"<?,?> ⬅️ ::Slice(%"val_1231", %"val_806", %"val_804")
    1786 |  # node_Constant_1213
            %"val_1235"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1787 |  # node_Slice_1214
            %"val_1236"<?,?> ⬅️ ::Slice(%"val_1231", %"val_1235", %"val_806")
    1788 |  # node_Constant_1215
            %"val_1237"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1789 |  # node_Concat_1216
            %"val_1238"<?,?> ⬅️ ::Concat(%"val_1237", %"val_1234", %"val_1233") {axis=0}
    1790 |  # node_Reshape_1217
            %"val_1239"<?,?> ⬅️ ::Reshape(%"add_21", %"val_1238") {allowzero=0}
    1791 |  # node_Transpose_1218
            %"val_1240"<?,?> ⬅️ ::Transpose(%"val_1239") {perm=(0, 2, 1)}
    1792 |  # node_Concat_1219
            %"val_1241"<?,?> ⬅️ ::Concat(%"val_1236", %"val_1233", %"val_1234") {axis=0}
    1793 |  # node_Reshape_1220
            %"val_1242"<?,?> ⬅️ ::Reshape(%"val_1240", %"val_1241") {allowzero=0}
    1794 |  # node_Sqrt_1221
            %"val_1243"<?,?> ⬅️ ::Sqrt(%"val_1230")
    1795 |  # node_Mul_1222
            %"val_1244"<?,?> ⬅️ ::Mul(%"add_20", %"val_1243")
    1796 |  # node_Sqrt_1223
            %"val_1245"<?,?> ⬅️ ::Sqrt(%"val_1230")
    1797 |  # node_Mul_1224
            %"val_1246"<?,?> ⬅️ ::Mul(%"val_1242", %"val_1245")
    1798 |  # node_MatMul_1225
            %"val_1247"<?,?> ⬅️ ::MatMul(%"val_1244", %"val_1246")
    1799 |  # node_Add_1226
            %"val_1248"<?,?> ⬅️ ::Add(%"val_1247", %"masked_fill_1")
    1800 |  # node_Softmax_1227
            %"val_1249"<?,?> ⬅️ ::Softmax(%"val_1248") {axis=-1}
    1801 |  # node_scaled_dot_product_attention_5
            %"scaled_dot_product_attention_5"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1249", %"getitem_27")
    1802 |  # node_transpose_33
            %"transpose_33"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_5") {perm=(0, 2, 1, 3)}
    1803 |  # node_Cast_1228
            %"val_1250"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1804 |  # node_view_11
            %"view_11"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_33", %"val_1250") {allowzero=1}
    1805 |  # node_Transpose_1229
            %"val_1251"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.attn.Wo.weight"{...}) {perm=(1, 0)}
    1806 |  # node_linear_21
            %"linear_21"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_11", %"val_1251")
    1807 |  # node_add_22
            %"add_22"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_19", %"linear_21")
    1808 |  # node_layer_norm_11
            %"layer_norm_11"<FLOAT,[1,97,768]>, %"val_1252"<?,?>, %"val_1253"<?,?> ⬅️ ::LayerNormalization(%"add_22", %"encoder.layers.5.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1809 |  # node_Transpose_1230
            %"val_1254"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1810 |  # node_linear_22
            %"linear_22"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_11", %"val_1254")
    1811 |  # node_split_5
            %"split_5"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_22", %"val_829") {dim=-1}
    1812 |  # node_getitem_28
            %"getitem_28"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_5", %"val_6")
    1813 |  # node_getitem_29
            %"getitem_29"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_5", %"val_48")
    1814 |  # node_Constant_1231
            %"val_1255"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1815 |  # node_Div_1232
            %"val_1256"<?,?> ⬅️ ::Div(%"getitem_28", %"val_1255")
    1816 |  # node_Erf_1233
            %"val_1257"<?,?> ⬅️ ::Erf(%"val_1256")
    1817 |  # node_Constant_1234
            %"val_1258"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1818 |  # node_Add_1235
            %"val_1259"<?,?> ⬅️ ::Add(%"val_1257", %"val_1258")
    1819 |  # node_Constant_1236
            %"val_1260"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1820 |  # node_Mul_1237
            %"val_1261"<?,?> ⬅️ ::Mul(%"val_1260", %"val_1259")
    1821 |  # node_gelu_5
            %"gelu_5"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_28", %"val_1261")
    1822 |  # node_mul_73
            %"mul_73"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_5", %"getitem_29")
    1823 |  # node_clone_7
            %"clone_7"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_73")
    1824 |  # node_Transpose_1238
            %"val_1262"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1825 |  # node_linear_23
            %"linear_23"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_7", %"val_1262")
    1826 |  # node_add_23
            %"add_23"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_22", %"linear_23")
    1827 |  # node_layer_norm_12
            %"layer_norm_12"<FLOAT,[1,97,768]>, %"val_1263"<?,?>, %"val_1264"<?,?> ⬅️ ::LayerNormalization(%"add_23", %"encoder.layers.6.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1828 |  # node_Transpose_1239
            %"val_1265"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1829 |  # node_linear_24
            %"linear_24"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_12", %"val_1265")
    1830 |  # node_Cast_1240
            %"val_1266"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1831 |  # node_view_12
            %"view_12"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_24", %"val_1266") {allowzero=1}
    1832 |  # node_transpose_34
            %"transpose_34"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_12") {perm=(0, 3, 2, 1, 4)}
    1833 |  # node_unbind_6
            %"unbind_6"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_34") {dim=2}
    1834 |  # node_getitem_30
            %"getitem_30"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_6", %"val_6")
    1835 |  # node_getitem_31
            %"getitem_31"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_6", %"val_48")
    1836 |  # node_getitem_32
            %"getitem_32"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_6", %"val_72")
    1837 |  # node_unsqueeze_84
            %"unsqueeze_84"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    1838 |  # node_unsqueeze_85
            %"unsqueeze_85"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    1839 |  # node_mul_74
            %"mul_74"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_30", %"unsqueeze_84")
    1840 |  # node_Cast_1241
            %"val_1267"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1841 |  # node_Constant_1242
            %"val_1268"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1842 |  # node_Reshape_1243
            %"val_1269"<?,?> ⬅️ ::Reshape(%"val_1267", %"val_1268") {allowzero=0}
    1843 |  # node_Cast_1244
            %"val_1270"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1844 |  # node_Constant_1245
            %"val_1271"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1845 |  # node_Reshape_1246
            %"val_1272"<?,?> ⬅️ ::Reshape(%"val_1270", %"val_1271") {allowzero=0}
    1846 |  # node_Cast_1247
            %"val_1273"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1847 |  # node_Constant_1248
            %"val_1274"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1848 |  # node_Reshape_1249
            %"val_1275"<?,?> ⬅️ ::Reshape(%"val_1273", %"val_1274") {allowzero=0}
    1849 |  # node_Constant_1250
            %"val_1276"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1850 |  # node_slice_93
            %"slice_93"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_30", %"val_1269", %"val_1272", %"val_1275", %"val_1276")
    1851 |  # node_Cast_1251
            %"val_1277"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1852 |  # node_Constant_1252
            %"val_1278"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1853 |  # node_Reshape_1253
            %"val_1279"<?,?> ⬅️ ::Reshape(%"val_1277", %"val_1278") {allowzero=0}
    1854 |  # node_Cast_1254
            %"val_1280"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1855 |  # node_Constant_1255
            %"val_1281"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1856 |  # node_Reshape_1256
            %"val_1282"<?,?> ⬅️ ::Reshape(%"val_1280", %"val_1281") {allowzero=0}
    1857 |  # node_Cast_1257
            %"val_1283"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1858 |  # node_Constant_1258
            %"val_1284"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1859 |  # node_Reshape_1259
            %"val_1285"<?,?> ⬅️ ::Reshape(%"val_1283", %"val_1284") {allowzero=0}
    1860 |  # node_Constant_1260
            %"val_1286"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1861 |  # node_slice_94
            %"slice_94"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_30", %"val_1279", %"val_1282", %"val_1285", %"val_1286")
    1862 |  # node_neg_12
            %"neg_12"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_94")
    1863 |  # node_cat_34
            %"cat_34"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_12", %"slice_93") {axis=-1}
    1864 |  # node_mul_75
            %"mul_75"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_34", %"unsqueeze_85")
    1865 |  # node_add_24
            %"add_24"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_74", %"mul_75")
    1866 |  # node_mul_76
            %"mul_76"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_31", %"unsqueeze_84")
    1867 |  # node_Cast_1261
            %"val_1287"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1868 |  # node_Constant_1262
            %"val_1288"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1869 |  # node_Reshape_1263
            %"val_1289"<?,?> ⬅️ ::Reshape(%"val_1287", %"val_1288") {allowzero=0}
    1870 |  # node_Cast_1264
            %"val_1290"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1871 |  # node_Constant_1265
            %"val_1291"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1872 |  # node_Reshape_1266
            %"val_1292"<?,?> ⬅️ ::Reshape(%"val_1290", %"val_1291") {allowzero=0}
    1873 |  # node_Cast_1267
            %"val_1293"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1874 |  # node_Constant_1268
            %"val_1294"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1875 |  # node_Reshape_1269
            %"val_1295"<?,?> ⬅️ ::Reshape(%"val_1293", %"val_1294") {allowzero=0}
    1876 |  # node_Constant_1270
            %"val_1296"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1877 |  # node_slice_95
            %"slice_95"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_31", %"val_1289", %"val_1292", %"val_1295", %"val_1296")
    1878 |  # node_Cast_1271
            %"val_1297"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1879 |  # node_Constant_1272
            %"val_1298"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1880 |  # node_Reshape_1273
            %"val_1299"<?,?> ⬅️ ::Reshape(%"val_1297", %"val_1298") {allowzero=0}
    1881 |  # node_Cast_1274
            %"val_1300"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1882 |  # node_Constant_1275
            %"val_1301"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1883 |  # node_Reshape_1276
            %"val_1302"<?,?> ⬅️ ::Reshape(%"val_1300", %"val_1301") {allowzero=0}
    1884 |  # node_Cast_1277
            %"val_1303"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1885 |  # node_Constant_1278
            %"val_1304"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1886 |  # node_Reshape_1279
            %"val_1305"<?,?> ⬅️ ::Reshape(%"val_1303", %"val_1304") {allowzero=0}
    1887 |  # node_Constant_1280
            %"val_1306"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1888 |  # node_slice_96
            %"slice_96"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_31", %"val_1299", %"val_1302", %"val_1305", %"val_1306")
    1889 |  # node_neg_13
            %"neg_13"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_96")
    1890 |  # node_cat_35
            %"cat_35"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_13", %"slice_95") {axis=-1}
    1891 |  # node_mul_77
            %"mul_77"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_35", %"unsqueeze_85")
    1892 |  # node_add_25
            %"add_25"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_76", %"mul_77")
    1893 |  # node_Shape_1281
            %"val_1307"<?,?> ⬅️ ::Shape(%"add_24") {start=0}
    1894 |  # node_Constant_1282
            %"val_1308"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1895 |  # node_Gather_1283
            %"val_1309"<?,?> ⬅️ ::Gather(%"val_1307", %"val_1308") {axis=0}
    1896 |  # node_CastLike_1284
            %"val_1310"<?,?> ⬅️ ::CastLike(%"val_1309", %"add_24")
    1897 |  # node_Constant_1285
            %"val_1311"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1898 |  # node_CastLike_1286
            %"val_1312"<?,?> ⬅️ ::CastLike(%"val_1311", %"add_24")
    1899 |  # node_Sqrt_1287
            %"val_1313"<?,?> ⬅️ ::Sqrt(%"val_1310")
    1900 |  # node_Div_1288
            %"val_1314"<?,?> ⬅️ ::Div(%"val_1312", %"val_1313")
    1901 |  # node_CastLike_1289
            %"val_1315"<?,?> ⬅️ ::CastLike(%"val_1314", %"add_24")
    1902 |  # node_Shape_1290
            %"val_1316"<?,?> ⬅️ ::Shape(%"add_25") {start=0}
    1903 |  # node_Constant_1291
            %"val_1317"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1904 |  # node_Slice_1292
            %"val_1318"<?,?> ⬅️ ::Slice(%"val_1316", %"val_804", %"val_1317")
    1905 |  # node_Slice_1293
            %"val_1319"<?,?> ⬅️ ::Slice(%"val_1316", %"val_806", %"val_804")
    1906 |  # node_Constant_1294
            %"val_1320"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1907 |  # node_Slice_1295
            %"val_1321"<?,?> ⬅️ ::Slice(%"val_1316", %"val_1320", %"val_806")
    1908 |  # node_Constant_1296
            %"val_1322"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1909 |  # node_Concat_1297
            %"val_1323"<?,?> ⬅️ ::Concat(%"val_1322", %"val_1319", %"val_1318") {axis=0}
    1910 |  # node_Reshape_1298
            %"val_1324"<?,?> ⬅️ ::Reshape(%"add_25", %"val_1323") {allowzero=0}
    1911 |  # node_Transpose_1299
            %"val_1325"<?,?> ⬅️ ::Transpose(%"val_1324") {perm=(0, 2, 1)}
    1912 |  # node_Concat_1300
            %"val_1326"<?,?> ⬅️ ::Concat(%"val_1321", %"val_1318", %"val_1319") {axis=0}
    1913 |  # node_Reshape_1301
            %"val_1327"<?,?> ⬅️ ::Reshape(%"val_1325", %"val_1326") {allowzero=0}
    1914 |  # node_Sqrt_1302
            %"val_1328"<?,?> ⬅️ ::Sqrt(%"val_1315")
    1915 |  # node_Mul_1303
            %"val_1329"<?,?> ⬅️ ::Mul(%"add_24", %"val_1328")
    1916 |  # node_Sqrt_1304
            %"val_1330"<?,?> ⬅️ ::Sqrt(%"val_1315")
    1917 |  # node_Mul_1305
            %"val_1331"<?,?> ⬅️ ::Mul(%"val_1327", %"val_1330")
    1918 |  # node_MatMul_1306
            %"val_1332"<?,?> ⬅️ ::MatMul(%"val_1329", %"val_1331")
    1919 |  # node_Add_1307
            %"val_1333"<?,?> ⬅️ ::Add(%"val_1332", %"masked_fill")
    1920 |  # node_Softmax_1308
            %"val_1334"<?,?> ⬅️ ::Softmax(%"val_1333") {axis=-1}
    1921 |  # node_scaled_dot_product_attention_6
            %"scaled_dot_product_attention_6"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1334", %"getitem_32")
    1922 |  # node_transpose_35
            %"transpose_35"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_6") {perm=(0, 2, 1, 3)}
    1923 |  # node_Cast_1309
            %"val_1335"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    1924 |  # node_view_13
            %"view_13"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_35", %"val_1335") {allowzero=1}
    1925 |  # node_Transpose_1310
            %"val_1336"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.attn.Wo.weight"{...}) {perm=(1, 0)}
    1926 |  # node_linear_25
            %"linear_25"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_13", %"val_1336")
    1927 |  # node_add_26
            %"add_26"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_23", %"linear_25")
    1928 |  # node_layer_norm_13
            %"layer_norm_13"<FLOAT,[1,97,768]>, %"val_1337"<?,?>, %"val_1338"<?,?> ⬅️ ::LayerNormalization(%"add_26", %"encoder.layers.6.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1929 |  # node_Transpose_1311
            %"val_1339"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1930 |  # node_linear_26
            %"linear_26"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_13", %"val_1339")
    1931 |  # node_split_6
            %"split_6"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_26", %"val_829") {dim=-1}
    1932 |  # node_getitem_33
            %"getitem_33"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_6", %"val_6")
    1933 |  # node_getitem_34
            %"getitem_34"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_6", %"val_48")
    1934 |  # node_Constant_1312
            %"val_1340"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1935 |  # node_Div_1313
            %"val_1341"<?,?> ⬅️ ::Div(%"getitem_33", %"val_1340")
    1936 |  # node_Erf_1314
            %"val_1342"<?,?> ⬅️ ::Erf(%"val_1341")
    1937 |  # node_Constant_1315
            %"val_1343"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1938 |  # node_Add_1316
            %"val_1344"<?,?> ⬅️ ::Add(%"val_1342", %"val_1343")
    1939 |  # node_Constant_1317
            %"val_1345"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1940 |  # node_Mul_1318
            %"val_1346"<?,?> ⬅️ ::Mul(%"val_1345", %"val_1344")
    1941 |  # node_gelu_6
            %"gelu_6"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_33", %"val_1346")
    1942 |  # node_mul_78
            %"mul_78"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_6", %"getitem_34")
    1943 |  # node_clone_8
            %"clone_8"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_78")
    1944 |  # node_Transpose_1319
            %"val_1347"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1945 |  # node_linear_27
            %"linear_27"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_8", %"val_1347")
    1946 |  # node_add_27
            %"add_27"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_26", %"linear_27")
    1947 |  # node_layer_norm_14
            %"layer_norm_14"<FLOAT,[1,97,768]>, %"val_1348"<?,?>, %"val_1349"<?,?> ⬅️ ::LayerNormalization(%"add_27", %"encoder.layers.7.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1948 |  # node_Transpose_1320
            %"val_1350"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1949 |  # node_linear_28
            %"linear_28"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_14", %"val_1350")
    1950 |  # node_Cast_1321
            %"val_1351"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    1951 |  # node_view_14
            %"view_14"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_28", %"val_1351") {allowzero=1}
    1952 |  # node_transpose_36
            %"transpose_36"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_14") {perm=(0, 3, 2, 1, 4)}
    1953 |  # node_unbind_7
            %"unbind_7"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_36") {dim=2}
    1954 |  # node_getitem_35
            %"getitem_35"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_7", %"val_6")
    1955 |  # node_getitem_36
            %"getitem_36"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_7", %"val_48")
    1956 |  # node_getitem_37
            %"getitem_37"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_7", %"val_72")
    1957 |  # node_unsqueeze_86
            %"unsqueeze_86"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1958 |  # node_unsqueeze_87
            %"unsqueeze_87"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1959 |  # node_mul_79
            %"mul_79"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_35", %"unsqueeze_86")
    1960 |  # node_Cast_1322
            %"val_1352"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1961 |  # node_Constant_1323
            %"val_1353"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1962 |  # node_Reshape_1324
            %"val_1354"<?,?> ⬅️ ::Reshape(%"val_1352", %"val_1353") {allowzero=0}
    1963 |  # node_Cast_1325
            %"val_1355"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1964 |  # node_Constant_1326
            %"val_1356"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1965 |  # node_Reshape_1327
            %"val_1357"<?,?> ⬅️ ::Reshape(%"val_1355", %"val_1356") {allowzero=0}
    1966 |  # node_Cast_1328
            %"val_1358"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1967 |  # node_Constant_1329
            %"val_1359"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1968 |  # node_Reshape_1330
            %"val_1360"<?,?> ⬅️ ::Reshape(%"val_1358", %"val_1359") {allowzero=0}
    1969 |  # node_Constant_1331
            %"val_1361"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1970 |  # node_slice_97
            %"slice_97"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_35", %"val_1354", %"val_1357", %"val_1360", %"val_1361")
    1971 |  # node_Cast_1332
            %"val_1362"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1972 |  # node_Constant_1333
            %"val_1363"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1973 |  # node_Reshape_1334
            %"val_1364"<?,?> ⬅️ ::Reshape(%"val_1362", %"val_1363") {allowzero=0}
    1974 |  # node_Cast_1335
            %"val_1365"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1975 |  # node_Constant_1336
            %"val_1366"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1976 |  # node_Reshape_1337
            %"val_1367"<?,?> ⬅️ ::Reshape(%"val_1365", %"val_1366") {allowzero=0}
    1977 |  # node_Cast_1338
            %"val_1368"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1978 |  # node_Constant_1339
            %"val_1369"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1979 |  # node_Reshape_1340
            %"val_1370"<?,?> ⬅️ ::Reshape(%"val_1368", %"val_1369") {allowzero=0}
    1980 |  # node_Constant_1341
            %"val_1371"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1981 |  # node_slice_98
            %"slice_98"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_35", %"val_1364", %"val_1367", %"val_1370", %"val_1371")
    1982 |  # node_neg_14
            %"neg_14"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_98")
    1983 |  # node_cat_36
            %"cat_36"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_14", %"slice_97") {axis=-1}
    1984 |  # node_mul_80
            %"mul_80"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_36", %"unsqueeze_87")
    1985 |  # node_add_28
            %"add_28"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_79", %"mul_80")
    1986 |  # node_mul_81
            %"mul_81"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_36", %"unsqueeze_86")
    1987 |  # node_Cast_1342
            %"val_1372"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1988 |  # node_Constant_1343
            %"val_1373"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1989 |  # node_Reshape_1344
            %"val_1374"<?,?> ⬅️ ::Reshape(%"val_1372", %"val_1373") {allowzero=0}
    1990 |  # node_Cast_1345
            %"val_1375"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1991 |  # node_Constant_1346
            %"val_1376"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1992 |  # node_Reshape_1347
            %"val_1377"<?,?> ⬅️ ::Reshape(%"val_1375", %"val_1376") {allowzero=0}
    1993 |  # node_Cast_1348
            %"val_1378"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1994 |  # node_Constant_1349
            %"val_1379"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1995 |  # node_Reshape_1350
            %"val_1380"<?,?> ⬅️ ::Reshape(%"val_1378", %"val_1379") {allowzero=0}
    1996 |  # node_Constant_1351
            %"val_1381"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1997 |  # node_slice_99
            %"slice_99"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_36", %"val_1374", %"val_1377", %"val_1380", %"val_1381")
    1998 |  # node_Cast_1352
            %"val_1382"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    1999 |  # node_Constant_1353
            %"val_1383"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2000 |  # node_Reshape_1354
            %"val_1384"<?,?> ⬅️ ::Reshape(%"val_1382", %"val_1383") {allowzero=0}
    2001 |  # node_Cast_1355
            %"val_1385"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2002 |  # node_Constant_1356
            %"val_1386"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2003 |  # node_Reshape_1357
            %"val_1387"<?,?> ⬅️ ::Reshape(%"val_1385", %"val_1386") {allowzero=0}
    2004 |  # node_Cast_1358
            %"val_1388"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2005 |  # node_Constant_1359
            %"val_1389"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2006 |  # node_Reshape_1360
            %"val_1390"<?,?> ⬅️ ::Reshape(%"val_1388", %"val_1389") {allowzero=0}
    2007 |  # node_Constant_1361
            %"val_1391"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2008 |  # node_slice_100
            %"slice_100"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_36", %"val_1384", %"val_1387", %"val_1390", %"val_1391")
    2009 |  # node_neg_15
            %"neg_15"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_100")
    2010 |  # node_cat_37
            %"cat_37"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_15", %"slice_99") {axis=-1}
    2011 |  # node_mul_82
            %"mul_82"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_37", %"unsqueeze_87")
    2012 |  # node_add_29
            %"add_29"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_81", %"mul_82")
    2013 |  # node_Shape_1362
            %"val_1392"<?,?> ⬅️ ::Shape(%"add_28") {start=0}
    2014 |  # node_Constant_1363
            %"val_1393"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2015 |  # node_Gather_1364
            %"val_1394"<?,?> ⬅️ ::Gather(%"val_1392", %"val_1393") {axis=0}
    2016 |  # node_CastLike_1365
            %"val_1395"<?,?> ⬅️ ::CastLike(%"val_1394", %"add_28")
    2017 |  # node_Constant_1366
            %"val_1396"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2018 |  # node_CastLike_1367
            %"val_1397"<?,?> ⬅️ ::CastLike(%"val_1396", %"add_28")
    2019 |  # node_Sqrt_1368
            %"val_1398"<?,?> ⬅️ ::Sqrt(%"val_1395")
    2020 |  # node_Div_1369
            %"val_1399"<?,?> ⬅️ ::Div(%"val_1397", %"val_1398")
    2021 |  # node_CastLike_1370
            %"val_1400"<?,?> ⬅️ ::CastLike(%"val_1399", %"add_28")
    2022 |  # node_Shape_1371
            %"val_1401"<?,?> ⬅️ ::Shape(%"add_29") {start=0}
    2023 |  # node_Constant_1372
            %"val_1402"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2024 |  # node_Slice_1373
            %"val_1403"<?,?> ⬅️ ::Slice(%"val_1401", %"val_804", %"val_1402")
    2025 |  # node_Slice_1374
            %"val_1404"<?,?> ⬅️ ::Slice(%"val_1401", %"val_806", %"val_804")
    2026 |  # node_Constant_1375
            %"val_1405"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2027 |  # node_Slice_1376
            %"val_1406"<?,?> ⬅️ ::Slice(%"val_1401", %"val_1405", %"val_806")
    2028 |  # node_Constant_1377
            %"val_1407"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2029 |  # node_Concat_1378
            %"val_1408"<?,?> ⬅️ ::Concat(%"val_1407", %"val_1404", %"val_1403") {axis=0}
    2030 |  # node_Reshape_1379
            %"val_1409"<?,?> ⬅️ ::Reshape(%"add_29", %"val_1408") {allowzero=0}
    2031 |  # node_Transpose_1380
            %"val_1410"<?,?> ⬅️ ::Transpose(%"val_1409") {perm=(0, 2, 1)}
    2032 |  # node_Concat_1381
            %"val_1411"<?,?> ⬅️ ::Concat(%"val_1406", %"val_1403", %"val_1404") {axis=0}
    2033 |  # node_Reshape_1382
            %"val_1412"<?,?> ⬅️ ::Reshape(%"val_1410", %"val_1411") {allowzero=0}
    2034 |  # node_Sqrt_1383
            %"val_1413"<?,?> ⬅️ ::Sqrt(%"val_1400")
    2035 |  # node_Mul_1384
            %"val_1414"<?,?> ⬅️ ::Mul(%"add_28", %"val_1413")
    2036 |  # node_Sqrt_1385
            %"val_1415"<?,?> ⬅️ ::Sqrt(%"val_1400")
    2037 |  # node_Mul_1386
            %"val_1416"<?,?> ⬅️ ::Mul(%"val_1412", %"val_1415")
    2038 |  # node_MatMul_1387
            %"val_1417"<?,?> ⬅️ ::MatMul(%"val_1414", %"val_1416")
    2039 |  # node_Add_1388
            %"val_1418"<?,?> ⬅️ ::Add(%"val_1417", %"masked_fill_1")
    2040 |  # node_Softmax_1389
            %"val_1419"<?,?> ⬅️ ::Softmax(%"val_1418") {axis=-1}
    2041 |  # node_scaled_dot_product_attention_7
            %"scaled_dot_product_attention_7"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1419", %"getitem_37")
    2042 |  # node_transpose_37
            %"transpose_37"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_7") {perm=(0, 2, 1, 3)}
    2043 |  # node_Cast_1390
            %"val_1420"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2044 |  # node_view_15
            %"view_15"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_37", %"val_1420") {allowzero=1}
    2045 |  # node_Transpose_1391
            %"val_1421"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.attn.Wo.weight"{...}) {perm=(1, 0)}
    2046 |  # node_linear_29
            %"linear_29"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_15", %"val_1421")
    2047 |  # node_add_30
            %"add_30"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_27", %"linear_29")
    2048 |  # node_layer_norm_15
            %"layer_norm_15"<FLOAT,[1,97,768]>, %"val_1422"<?,?>, %"val_1423"<?,?> ⬅️ ::LayerNormalization(%"add_30", %"encoder.layers.7.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2049 |  # node_Transpose_1392
            %"val_1424"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2050 |  # node_linear_30
            %"linear_30"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_15", %"val_1424")
    2051 |  # node_split_7
            %"split_7"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_30", %"val_829") {dim=-1}
    2052 |  # node_getitem_38
            %"getitem_38"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_7", %"val_6")
    2053 |  # node_getitem_39
            %"getitem_39"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_7", %"val_48")
    2054 |  # node_Constant_1393
            %"val_1425"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2055 |  # node_Div_1394
            %"val_1426"<?,?> ⬅️ ::Div(%"getitem_38", %"val_1425")
    2056 |  # node_Erf_1395
            %"val_1427"<?,?> ⬅️ ::Erf(%"val_1426")
    2057 |  # node_Constant_1396
            %"val_1428"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2058 |  # node_Add_1397
            %"val_1429"<?,?> ⬅️ ::Add(%"val_1427", %"val_1428")
    2059 |  # node_Constant_1398
            %"val_1430"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2060 |  # node_Mul_1399
            %"val_1431"<?,?> ⬅️ ::Mul(%"val_1430", %"val_1429")
    2061 |  # node_gelu_7
            %"gelu_7"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_38", %"val_1431")
    2062 |  # node_mul_83
            %"mul_83"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_7", %"getitem_39")
    2063 |  # node_clone_9
            %"clone_9"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_83")
    2064 |  # node_Transpose_1400
            %"val_1432"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2065 |  # node_linear_31
            %"linear_31"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_9", %"val_1432")
    2066 |  # node_add_31
            %"add_31"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_30", %"linear_31")
    2067 |  # node_layer_norm_16
            %"layer_norm_16"<FLOAT,[1,97,768]>, %"val_1433"<?,?>, %"val_1434"<?,?> ⬅️ ::LayerNormalization(%"add_31", %"encoder.layers.8.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2068 |  # node_Transpose_1401
            %"val_1435"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2069 |  # node_linear_32
            %"linear_32"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_16", %"val_1435")
    2070 |  # node_Cast_1402
            %"val_1436"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2071 |  # node_view_16
            %"view_16"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_32", %"val_1436") {allowzero=1}
    2072 |  # node_transpose_38
            %"transpose_38"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_16") {perm=(0, 3, 2, 1, 4)}
    2073 |  # node_unbind_8
            %"unbind_8"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_38") {dim=2}
    2074 |  # node_getitem_40
            %"getitem_40"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_8", %"val_6")
    2075 |  # node_getitem_41
            %"getitem_41"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_8", %"val_48")
    2076 |  # node_getitem_42
            %"getitem_42"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_8", %"val_72")
    2077 |  # node_unsqueeze_88
            %"unsqueeze_88"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2078 |  # node_unsqueeze_89
            %"unsqueeze_89"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2079 |  # node_mul_84
            %"mul_84"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_40", %"unsqueeze_88")
    2080 |  # node_Cast_1403
            %"val_1437"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2081 |  # node_Constant_1404
            %"val_1438"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2082 |  # node_Reshape_1405
            %"val_1439"<?,?> ⬅️ ::Reshape(%"val_1437", %"val_1438") {allowzero=0}
    2083 |  # node_Cast_1406
            %"val_1440"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2084 |  # node_Constant_1407
            %"val_1441"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2085 |  # node_Reshape_1408
            %"val_1442"<?,?> ⬅️ ::Reshape(%"val_1440", %"val_1441") {allowzero=0}
    2086 |  # node_Cast_1409
            %"val_1443"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2087 |  # node_Constant_1410
            %"val_1444"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2088 |  # node_Reshape_1411
            %"val_1445"<?,?> ⬅️ ::Reshape(%"val_1443", %"val_1444") {allowzero=0}
    2089 |  # node_Constant_1412
            %"val_1446"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2090 |  # node_slice_101
            %"slice_101"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_40", %"val_1439", %"val_1442", %"val_1445", %"val_1446")
    2091 |  # node_Cast_1413
            %"val_1447"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2092 |  # node_Constant_1414
            %"val_1448"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2093 |  # node_Reshape_1415
            %"val_1449"<?,?> ⬅️ ::Reshape(%"val_1447", %"val_1448") {allowzero=0}
    2094 |  # node_Cast_1416
            %"val_1450"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2095 |  # node_Constant_1417
            %"val_1451"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2096 |  # node_Reshape_1418
            %"val_1452"<?,?> ⬅️ ::Reshape(%"val_1450", %"val_1451") {allowzero=0}
    2097 |  # node_Cast_1419
            %"val_1453"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2098 |  # node_Constant_1420
            %"val_1454"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2099 |  # node_Reshape_1421
            %"val_1455"<?,?> ⬅️ ::Reshape(%"val_1453", %"val_1454") {allowzero=0}
    2100 |  # node_Constant_1422
            %"val_1456"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2101 |  # node_slice_102
            %"slice_102"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_40", %"val_1449", %"val_1452", %"val_1455", %"val_1456")
    2102 |  # node_neg_16
            %"neg_16"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_102")
    2103 |  # node_cat_38
            %"cat_38"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_16", %"slice_101") {axis=-1}
    2104 |  # node_mul_85
            %"mul_85"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_38", %"unsqueeze_89")
    2105 |  # node_add_32
            %"add_32"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_84", %"mul_85")
    2106 |  # node_mul_86
            %"mul_86"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_41", %"unsqueeze_88")
    2107 |  # node_Cast_1423
            %"val_1457"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2108 |  # node_Constant_1424
            %"val_1458"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2109 |  # node_Reshape_1425
            %"val_1459"<?,?> ⬅️ ::Reshape(%"val_1457", %"val_1458") {allowzero=0}
    2110 |  # node_Cast_1426
            %"val_1460"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2111 |  # node_Constant_1427
            %"val_1461"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2112 |  # node_Reshape_1428
            %"val_1462"<?,?> ⬅️ ::Reshape(%"val_1460", %"val_1461") {allowzero=0}
    2113 |  # node_Cast_1429
            %"val_1463"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2114 |  # node_Constant_1430
            %"val_1464"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2115 |  # node_Reshape_1431
            %"val_1465"<?,?> ⬅️ ::Reshape(%"val_1463", %"val_1464") {allowzero=0}
    2116 |  # node_Constant_1432
            %"val_1466"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2117 |  # node_slice_103
            %"slice_103"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_41", %"val_1459", %"val_1462", %"val_1465", %"val_1466")
    2118 |  # node_Cast_1433
            %"val_1467"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2119 |  # node_Constant_1434
            %"val_1468"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2120 |  # node_Reshape_1435
            %"val_1469"<?,?> ⬅️ ::Reshape(%"val_1467", %"val_1468") {allowzero=0}
    2121 |  # node_Cast_1436
            %"val_1470"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2122 |  # node_Constant_1437
            %"val_1471"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2123 |  # node_Reshape_1438
            %"val_1472"<?,?> ⬅️ ::Reshape(%"val_1470", %"val_1471") {allowzero=0}
    2124 |  # node_Cast_1439
            %"val_1473"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2125 |  # node_Constant_1440
            %"val_1474"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2126 |  # node_Reshape_1441
            %"val_1475"<?,?> ⬅️ ::Reshape(%"val_1473", %"val_1474") {allowzero=0}
    2127 |  # node_Constant_1442
            %"val_1476"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2128 |  # node_slice_104
            %"slice_104"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_41", %"val_1469", %"val_1472", %"val_1475", %"val_1476")
    2129 |  # node_neg_17
            %"neg_17"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_104")
    2130 |  # node_cat_39
            %"cat_39"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_17", %"slice_103") {axis=-1}
    2131 |  # node_mul_87
            %"mul_87"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_39", %"unsqueeze_89")
    2132 |  # node_add_33
            %"add_33"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_86", %"mul_87")
    2133 |  # node_Shape_1443
            %"val_1477"<?,?> ⬅️ ::Shape(%"add_32") {start=0}
    2134 |  # node_Constant_1444
            %"val_1478"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2135 |  # node_Gather_1445
            %"val_1479"<?,?> ⬅️ ::Gather(%"val_1477", %"val_1478") {axis=0}
    2136 |  # node_CastLike_1446
            %"val_1480"<?,?> ⬅️ ::CastLike(%"val_1479", %"add_32")
    2137 |  # node_Constant_1447
            %"val_1481"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2138 |  # node_CastLike_1448
            %"val_1482"<?,?> ⬅️ ::CastLike(%"val_1481", %"add_32")
    2139 |  # node_Sqrt_1449
            %"val_1483"<?,?> ⬅️ ::Sqrt(%"val_1480")
    2140 |  # node_Div_1450
            %"val_1484"<?,?> ⬅️ ::Div(%"val_1482", %"val_1483")
    2141 |  # node_CastLike_1451
            %"val_1485"<?,?> ⬅️ ::CastLike(%"val_1484", %"add_32")
    2142 |  # node_Shape_1452
            %"val_1486"<?,?> ⬅️ ::Shape(%"add_33") {start=0}
    2143 |  # node_Constant_1453
            %"val_1487"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2144 |  # node_Slice_1454
            %"val_1488"<?,?> ⬅️ ::Slice(%"val_1486", %"val_804", %"val_1487")
    2145 |  # node_Slice_1455
            %"val_1489"<?,?> ⬅️ ::Slice(%"val_1486", %"val_806", %"val_804")
    2146 |  # node_Constant_1456
            %"val_1490"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2147 |  # node_Slice_1457
            %"val_1491"<?,?> ⬅️ ::Slice(%"val_1486", %"val_1490", %"val_806")
    2148 |  # node_Constant_1458
            %"val_1492"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2149 |  # node_Concat_1459
            %"val_1493"<?,?> ⬅️ ::Concat(%"val_1492", %"val_1489", %"val_1488") {axis=0}
    2150 |  # node_Reshape_1460
            %"val_1494"<?,?> ⬅️ ::Reshape(%"add_33", %"val_1493") {allowzero=0}
    2151 |  # node_Transpose_1461
            %"val_1495"<?,?> ⬅️ ::Transpose(%"val_1494") {perm=(0, 2, 1)}
    2152 |  # node_Concat_1462
            %"val_1496"<?,?> ⬅️ ::Concat(%"val_1491", %"val_1488", %"val_1489") {axis=0}
    2153 |  # node_Reshape_1463
            %"val_1497"<?,?> ⬅️ ::Reshape(%"val_1495", %"val_1496") {allowzero=0}
    2154 |  # node_Sqrt_1464
            %"val_1498"<?,?> ⬅️ ::Sqrt(%"val_1485")
    2155 |  # node_Mul_1465
            %"val_1499"<?,?> ⬅️ ::Mul(%"add_32", %"val_1498")
    2156 |  # node_Sqrt_1466
            %"val_1500"<?,?> ⬅️ ::Sqrt(%"val_1485")
    2157 |  # node_Mul_1467
            %"val_1501"<?,?> ⬅️ ::Mul(%"val_1497", %"val_1500")
    2158 |  # node_MatMul_1468
            %"val_1502"<?,?> ⬅️ ::MatMul(%"val_1499", %"val_1501")
    2159 |  # node_Add_1469
            %"val_1503"<?,?> ⬅️ ::Add(%"val_1502", %"masked_fill_1")
    2160 |  # node_Softmax_1470
            %"val_1504"<?,?> ⬅️ ::Softmax(%"val_1503") {axis=-1}
    2161 |  # node_scaled_dot_product_attention_8
            %"scaled_dot_product_attention_8"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1504", %"getitem_42")
    2162 |  # node_transpose_39
            %"transpose_39"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_8") {perm=(0, 2, 1, 3)}
    2163 |  # node_Cast_1471
            %"val_1505"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2164 |  # node_view_17
            %"view_17"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_39", %"val_1505") {allowzero=1}
    2165 |  # node_Transpose_1472
            %"val_1506"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.attn.Wo.weight"{...}) {perm=(1, 0)}
    2166 |  # node_linear_33
            %"linear_33"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_17", %"val_1506")
    2167 |  # node_add_34
            %"add_34"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_31", %"linear_33")
    2168 |  # node_layer_norm_17
            %"layer_norm_17"<FLOAT,[1,97,768]>, %"val_1507"<?,?>, %"val_1508"<?,?> ⬅️ ::LayerNormalization(%"add_34", %"encoder.layers.8.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2169 |  # node_Transpose_1473
            %"val_1509"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2170 |  # node_linear_34
            %"linear_34"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_17", %"val_1509")
    2171 |  # node_split_8
            %"split_8"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_34", %"val_829") {dim=-1}
    2172 |  # node_getitem_43
            %"getitem_43"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_8", %"val_6")
    2173 |  # node_getitem_44
            %"getitem_44"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_8", %"val_48")
    2174 |  # node_Constant_1474
            %"val_1510"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2175 |  # node_Div_1475
            %"val_1511"<?,?> ⬅️ ::Div(%"getitem_43", %"val_1510")
    2176 |  # node_Erf_1476
            %"val_1512"<?,?> ⬅️ ::Erf(%"val_1511")
    2177 |  # node_Constant_1477
            %"val_1513"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2178 |  # node_Add_1478
            %"val_1514"<?,?> ⬅️ ::Add(%"val_1512", %"val_1513")
    2179 |  # node_Constant_1479
            %"val_1515"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2180 |  # node_Mul_1480
            %"val_1516"<?,?> ⬅️ ::Mul(%"val_1515", %"val_1514")
    2181 |  # node_gelu_8
            %"gelu_8"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_43", %"val_1516")
    2182 |  # node_mul_88
            %"mul_88"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_8", %"getitem_44")
    2183 |  # node_clone_10
            %"clone_10"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_88")
    2184 |  # node_Transpose_1481
            %"val_1517"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2185 |  # node_linear_35
            %"linear_35"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_10", %"val_1517")
    2186 |  # node_add_35
            %"add_35"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_34", %"linear_35")
    2187 |  # node_layer_norm_18
            %"layer_norm_18"<FLOAT,[1,97,768]>, %"val_1518"<?,?>, %"val_1519"<?,?> ⬅️ ::LayerNormalization(%"add_35", %"encoder.layers.9.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2188 |  # node_Transpose_1482
            %"val_1520"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2189 |  # node_linear_36
            %"linear_36"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_18", %"val_1520")
    2190 |  # node_Cast_1483
            %"val_1521"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2191 |  # node_view_18
            %"view_18"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_36", %"val_1521") {allowzero=1}
    2192 |  # node_transpose_40
            %"transpose_40"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_18") {perm=(0, 3, 2, 1, 4)}
    2193 |  # node_unbind_9
            %"unbind_9"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_40") {dim=2}
    2194 |  # node_getitem_45
            %"getitem_45"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_9", %"val_6")
    2195 |  # node_getitem_46
            %"getitem_46"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_9", %"val_48")
    2196 |  # node_getitem_47
            %"getitem_47"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_9", %"val_72")
    2197 |  # node_unsqueeze_90
            %"unsqueeze_90"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    2198 |  # node_unsqueeze_91
            %"unsqueeze_91"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    2199 |  # node_mul_89
            %"mul_89"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_45", %"unsqueeze_90")
    2200 |  # node_Cast_1484
            %"val_1522"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2201 |  # node_Constant_1485
            %"val_1523"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2202 |  # node_Reshape_1486
            %"val_1524"<?,?> ⬅️ ::Reshape(%"val_1522", %"val_1523") {allowzero=0}
    2203 |  # node_Cast_1487
            %"val_1525"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2204 |  # node_Constant_1488
            %"val_1526"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2205 |  # node_Reshape_1489
            %"val_1527"<?,?> ⬅️ ::Reshape(%"val_1525", %"val_1526") {allowzero=0}
    2206 |  # node_Cast_1490
            %"val_1528"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2207 |  # node_Constant_1491
            %"val_1529"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2208 |  # node_Reshape_1492
            %"val_1530"<?,?> ⬅️ ::Reshape(%"val_1528", %"val_1529") {allowzero=0}
    2209 |  # node_Constant_1493
            %"val_1531"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2210 |  # node_slice_105
            %"slice_105"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_45", %"val_1524", %"val_1527", %"val_1530", %"val_1531")
    2211 |  # node_Cast_1494
            %"val_1532"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2212 |  # node_Constant_1495
            %"val_1533"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2213 |  # node_Reshape_1496
            %"val_1534"<?,?> ⬅️ ::Reshape(%"val_1532", %"val_1533") {allowzero=0}
    2214 |  # node_Cast_1497
            %"val_1535"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2215 |  # node_Constant_1498
            %"val_1536"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2216 |  # node_Reshape_1499
            %"val_1537"<?,?> ⬅️ ::Reshape(%"val_1535", %"val_1536") {allowzero=0}
    2217 |  # node_Cast_1500
            %"val_1538"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2218 |  # node_Constant_1501
            %"val_1539"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2219 |  # node_Reshape_1502
            %"val_1540"<?,?> ⬅️ ::Reshape(%"val_1538", %"val_1539") {allowzero=0}
    2220 |  # node_Constant_1503
            %"val_1541"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2221 |  # node_slice_106
            %"slice_106"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_45", %"val_1534", %"val_1537", %"val_1540", %"val_1541")
    2222 |  # node_neg_18
            %"neg_18"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_106")
    2223 |  # node_cat_40
            %"cat_40"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_18", %"slice_105") {axis=-1}
    2224 |  # node_mul_90
            %"mul_90"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_40", %"unsqueeze_91")
    2225 |  # node_add_36
            %"add_36"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_89", %"mul_90")
    2226 |  # node_mul_91
            %"mul_91"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_46", %"unsqueeze_90")
    2227 |  # node_Cast_1504
            %"val_1542"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2228 |  # node_Constant_1505
            %"val_1543"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2229 |  # node_Reshape_1506
            %"val_1544"<?,?> ⬅️ ::Reshape(%"val_1542", %"val_1543") {allowzero=0}
    2230 |  # node_Cast_1507
            %"val_1545"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2231 |  # node_Constant_1508
            %"val_1546"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2232 |  # node_Reshape_1509
            %"val_1547"<?,?> ⬅️ ::Reshape(%"val_1545", %"val_1546") {allowzero=0}
    2233 |  # node_Cast_1510
            %"val_1548"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2234 |  # node_Constant_1511
            %"val_1549"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2235 |  # node_Reshape_1512
            %"val_1550"<?,?> ⬅️ ::Reshape(%"val_1548", %"val_1549") {allowzero=0}
    2236 |  # node_Constant_1513
            %"val_1551"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2237 |  # node_slice_107
            %"slice_107"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_46", %"val_1544", %"val_1547", %"val_1550", %"val_1551")
    2238 |  # node_Cast_1514
            %"val_1552"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2239 |  # node_Constant_1515
            %"val_1553"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2240 |  # node_Reshape_1516
            %"val_1554"<?,?> ⬅️ ::Reshape(%"val_1552", %"val_1553") {allowzero=0}
    2241 |  # node_Cast_1517
            %"val_1555"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2242 |  # node_Constant_1518
            %"val_1556"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2243 |  # node_Reshape_1519
            %"val_1557"<?,?> ⬅️ ::Reshape(%"val_1555", %"val_1556") {allowzero=0}
    2244 |  # node_Cast_1520
            %"val_1558"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2245 |  # node_Constant_1521
            %"val_1559"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2246 |  # node_Reshape_1522
            %"val_1560"<?,?> ⬅️ ::Reshape(%"val_1558", %"val_1559") {allowzero=0}
    2247 |  # node_Constant_1523
            %"val_1561"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2248 |  # node_slice_108
            %"slice_108"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_46", %"val_1554", %"val_1557", %"val_1560", %"val_1561")
    2249 |  # node_neg_19
            %"neg_19"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_108")
    2250 |  # node_cat_41
            %"cat_41"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_19", %"slice_107") {axis=-1}
    2251 |  # node_mul_92
            %"mul_92"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_41", %"unsqueeze_91")
    2252 |  # node_add_37
            %"add_37"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_91", %"mul_92")
    2253 |  # node_Shape_1524
            %"val_1562"<?,?> ⬅️ ::Shape(%"add_36") {start=0}
    2254 |  # node_Constant_1525
            %"val_1563"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2255 |  # node_Gather_1526
            %"val_1564"<?,?> ⬅️ ::Gather(%"val_1562", %"val_1563") {axis=0}
    2256 |  # node_CastLike_1527
            %"val_1565"<?,?> ⬅️ ::CastLike(%"val_1564", %"add_36")
    2257 |  # node_Constant_1528
            %"val_1566"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2258 |  # node_CastLike_1529
            %"val_1567"<?,?> ⬅️ ::CastLike(%"val_1566", %"add_36")
    2259 |  # node_Sqrt_1530
            %"val_1568"<?,?> ⬅️ ::Sqrt(%"val_1565")
    2260 |  # node_Div_1531
            %"val_1569"<?,?> ⬅️ ::Div(%"val_1567", %"val_1568")
    2261 |  # node_CastLike_1532
            %"val_1570"<?,?> ⬅️ ::CastLike(%"val_1569", %"add_36")
    2262 |  # node_Shape_1533
            %"val_1571"<?,?> ⬅️ ::Shape(%"add_37") {start=0}
    2263 |  # node_Constant_1534
            %"val_1572"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2264 |  # node_Slice_1535
            %"val_1573"<?,?> ⬅️ ::Slice(%"val_1571", %"val_804", %"val_1572")
    2265 |  # node_Slice_1536
            %"val_1574"<?,?> ⬅️ ::Slice(%"val_1571", %"val_806", %"val_804")
    2266 |  # node_Constant_1537
            %"val_1575"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2267 |  # node_Slice_1538
            %"val_1576"<?,?> ⬅️ ::Slice(%"val_1571", %"val_1575", %"val_806")
    2268 |  # node_Constant_1539
            %"val_1577"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2269 |  # node_Concat_1540
            %"val_1578"<?,?> ⬅️ ::Concat(%"val_1577", %"val_1574", %"val_1573") {axis=0}
    2270 |  # node_Reshape_1541
            %"val_1579"<?,?> ⬅️ ::Reshape(%"add_37", %"val_1578") {allowzero=0}
    2271 |  # node_Transpose_1542
            %"val_1580"<?,?> ⬅️ ::Transpose(%"val_1579") {perm=(0, 2, 1)}
    2272 |  # node_Concat_1543
            %"val_1581"<?,?> ⬅️ ::Concat(%"val_1576", %"val_1573", %"val_1574") {axis=0}
    2273 |  # node_Reshape_1544
            %"val_1582"<?,?> ⬅️ ::Reshape(%"val_1580", %"val_1581") {allowzero=0}
    2274 |  # node_Sqrt_1545
            %"val_1583"<?,?> ⬅️ ::Sqrt(%"val_1570")
    2275 |  # node_Mul_1546
            %"val_1584"<?,?> ⬅️ ::Mul(%"add_36", %"val_1583")
    2276 |  # node_Sqrt_1547
            %"val_1585"<?,?> ⬅️ ::Sqrt(%"val_1570")
    2277 |  # node_Mul_1548
            %"val_1586"<?,?> ⬅️ ::Mul(%"val_1582", %"val_1585")
    2278 |  # node_MatMul_1549
            %"val_1587"<?,?> ⬅️ ::MatMul(%"val_1584", %"val_1586")
    2279 |  # node_Add_1550
            %"val_1588"<?,?> ⬅️ ::Add(%"val_1587", %"masked_fill")
    2280 |  # node_Softmax_1551
            %"val_1589"<?,?> ⬅️ ::Softmax(%"val_1588") {axis=-1}
    2281 |  # node_scaled_dot_product_attention_9
            %"scaled_dot_product_attention_9"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1589", %"getitem_47")
    2282 |  # node_transpose_41
            %"transpose_41"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_9") {perm=(0, 2, 1, 3)}
    2283 |  # node_Cast_1552
            %"val_1590"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2284 |  # node_view_19
            %"view_19"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_41", %"val_1590") {allowzero=1}
    2285 |  # node_Transpose_1553
            %"val_1591"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.attn.Wo.weight"{...}) {perm=(1, 0)}
    2286 |  # node_linear_37
            %"linear_37"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_19", %"val_1591")
    2287 |  # node_add_38
            %"add_38"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_35", %"linear_37")
    2288 |  # node_layer_norm_19
            %"layer_norm_19"<FLOAT,[1,97,768]>, %"val_1592"<?,?>, %"val_1593"<?,?> ⬅️ ::LayerNormalization(%"add_38", %"encoder.layers.9.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2289 |  # node_Transpose_1554
            %"val_1594"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2290 |  # node_linear_38
            %"linear_38"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_19", %"val_1594")
    2291 |  # node_split_9
            %"split_9"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_38", %"val_829") {dim=-1}
    2292 |  # node_getitem_48
            %"getitem_48"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_9", %"val_6")
    2293 |  # node_getitem_49
            %"getitem_49"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_9", %"val_48")
    2294 |  # node_Constant_1555
            %"val_1595"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2295 |  # node_Div_1556
            %"val_1596"<?,?> ⬅️ ::Div(%"getitem_48", %"val_1595")
    2296 |  # node_Erf_1557
            %"val_1597"<?,?> ⬅️ ::Erf(%"val_1596")
    2297 |  # node_Constant_1558
            %"val_1598"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2298 |  # node_Add_1559
            %"val_1599"<?,?> ⬅️ ::Add(%"val_1597", %"val_1598")
    2299 |  # node_Constant_1560
            %"val_1600"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2300 |  # node_Mul_1561
            %"val_1601"<?,?> ⬅️ ::Mul(%"val_1600", %"val_1599")
    2301 |  # node_gelu_9
            %"gelu_9"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_48", %"val_1601")
    2302 |  # node_mul_93
            %"mul_93"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_9", %"getitem_49")
    2303 |  # node_clone_11
            %"clone_11"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_93")
    2304 |  # node_Transpose_1562
            %"val_1602"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2305 |  # node_linear_39
            %"linear_39"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_11", %"val_1602")
    2306 |  # node_add_39
            %"add_39"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_38", %"linear_39")
    2307 |  # node_layer_norm_20
            %"layer_norm_20"<FLOAT,[1,97,768]>, %"val_1603"<?,?>, %"val_1604"<?,?> ⬅️ ::LayerNormalization(%"add_39", %"encoder.layers.10.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2308 |  # node_Transpose_1563
            %"val_1605"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2309 |  # node_linear_40
            %"linear_40"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_20", %"val_1605")
    2310 |  # node_Cast_1564
            %"val_1606"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2311 |  # node_view_20
            %"view_20"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_40", %"val_1606") {allowzero=1}
    2312 |  # node_transpose_42
            %"transpose_42"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_20") {perm=(0, 3, 2, 1, 4)}
    2313 |  # node_unbind_10
            %"unbind_10"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_42") {dim=2}
    2314 |  # node_getitem_50
            %"getitem_50"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_10", %"val_6")
    2315 |  # node_getitem_51
            %"getitem_51"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_10", %"val_48")
    2316 |  # node_getitem_52
            %"getitem_52"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_10", %"val_72")
    2317 |  # node_unsqueeze_92
            %"unsqueeze_92"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2318 |  # node_unsqueeze_93
            %"unsqueeze_93"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2319 |  # node_mul_94
            %"mul_94"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_50", %"unsqueeze_92")
    2320 |  # node_Cast_1565
            %"val_1607"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2321 |  # node_Constant_1566
            %"val_1608"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2322 |  # node_Reshape_1567
            %"val_1609"<?,?> ⬅️ ::Reshape(%"val_1607", %"val_1608") {allowzero=0}
    2323 |  # node_Cast_1568
            %"val_1610"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2324 |  # node_Constant_1569
            %"val_1611"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2325 |  # node_Reshape_1570
            %"val_1612"<?,?> ⬅️ ::Reshape(%"val_1610", %"val_1611") {allowzero=0}
    2326 |  # node_Cast_1571
            %"val_1613"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2327 |  # node_Constant_1572
            %"val_1614"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2328 |  # node_Reshape_1573
            %"val_1615"<?,?> ⬅️ ::Reshape(%"val_1613", %"val_1614") {allowzero=0}
    2329 |  # node_Constant_1574
            %"val_1616"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2330 |  # node_slice_109
            %"slice_109"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_50", %"val_1609", %"val_1612", %"val_1615", %"val_1616")
    2331 |  # node_Cast_1575
            %"val_1617"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2332 |  # node_Constant_1576
            %"val_1618"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2333 |  # node_Reshape_1577
            %"val_1619"<?,?> ⬅️ ::Reshape(%"val_1617", %"val_1618") {allowzero=0}
    2334 |  # node_Cast_1578
            %"val_1620"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2335 |  # node_Constant_1579
            %"val_1621"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2336 |  # node_Reshape_1580
            %"val_1622"<?,?> ⬅️ ::Reshape(%"val_1620", %"val_1621") {allowzero=0}
    2337 |  # node_Cast_1581
            %"val_1623"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2338 |  # node_Constant_1582
            %"val_1624"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2339 |  # node_Reshape_1583
            %"val_1625"<?,?> ⬅️ ::Reshape(%"val_1623", %"val_1624") {allowzero=0}
    2340 |  # node_Constant_1584
            %"val_1626"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2341 |  # node_slice_110
            %"slice_110"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_50", %"val_1619", %"val_1622", %"val_1625", %"val_1626")
    2342 |  # node_neg_20
            %"neg_20"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_110")
    2343 |  # node_cat_42
            %"cat_42"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_20", %"slice_109") {axis=-1}
    2344 |  # node_mul_95
            %"mul_95"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_42", %"unsqueeze_93")
    2345 |  # node_add_40
            %"add_40"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_94", %"mul_95")
    2346 |  # node_mul_96
            %"mul_96"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_51", %"unsqueeze_92")
    2347 |  # node_Cast_1585
            %"val_1627"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2348 |  # node_Constant_1586
            %"val_1628"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2349 |  # node_Reshape_1587
            %"val_1629"<?,?> ⬅️ ::Reshape(%"val_1627", %"val_1628") {allowzero=0}
    2350 |  # node_Cast_1588
            %"val_1630"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2351 |  # node_Constant_1589
            %"val_1631"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2352 |  # node_Reshape_1590
            %"val_1632"<?,?> ⬅️ ::Reshape(%"val_1630", %"val_1631") {allowzero=0}
    2353 |  # node_Cast_1591
            %"val_1633"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2354 |  # node_Constant_1592
            %"val_1634"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2355 |  # node_Reshape_1593
            %"val_1635"<?,?> ⬅️ ::Reshape(%"val_1633", %"val_1634") {allowzero=0}
    2356 |  # node_Constant_1594
            %"val_1636"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2357 |  # node_slice_111
            %"slice_111"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_51", %"val_1629", %"val_1632", %"val_1635", %"val_1636")
    2358 |  # node_Cast_1595
            %"val_1637"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2359 |  # node_Constant_1596
            %"val_1638"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2360 |  # node_Reshape_1597
            %"val_1639"<?,?> ⬅️ ::Reshape(%"val_1637", %"val_1638") {allowzero=0}
    2361 |  # node_Cast_1598
            %"val_1640"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2362 |  # node_Constant_1599
            %"val_1641"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2363 |  # node_Reshape_1600
            %"val_1642"<?,?> ⬅️ ::Reshape(%"val_1640", %"val_1641") {allowzero=0}
    2364 |  # node_Cast_1601
            %"val_1643"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2365 |  # node_Constant_1602
            %"val_1644"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2366 |  # node_Reshape_1603
            %"val_1645"<?,?> ⬅️ ::Reshape(%"val_1643", %"val_1644") {allowzero=0}
    2367 |  # node_Constant_1604
            %"val_1646"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2368 |  # node_slice_112
            %"slice_112"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_51", %"val_1639", %"val_1642", %"val_1645", %"val_1646")
    2369 |  # node_neg_21
            %"neg_21"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_112")
    2370 |  # node_cat_43
            %"cat_43"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_21", %"slice_111") {axis=-1}
    2371 |  # node_mul_97
            %"mul_97"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_43", %"unsqueeze_93")
    2372 |  # node_add_41
            %"add_41"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_96", %"mul_97")
    2373 |  # node_Shape_1605
            %"val_1647"<?,?> ⬅️ ::Shape(%"add_40") {start=0}
    2374 |  # node_Constant_1606
            %"val_1648"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2375 |  # node_Gather_1607
            %"val_1649"<?,?> ⬅️ ::Gather(%"val_1647", %"val_1648") {axis=0}
    2376 |  # node_CastLike_1608
            %"val_1650"<?,?> ⬅️ ::CastLike(%"val_1649", %"add_40")
    2377 |  # node_Constant_1609
            %"val_1651"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2378 |  # node_CastLike_1610
            %"val_1652"<?,?> ⬅️ ::CastLike(%"val_1651", %"add_40")
    2379 |  # node_Sqrt_1611
            %"val_1653"<?,?> ⬅️ ::Sqrt(%"val_1650")
    2380 |  # node_Div_1612
            %"val_1654"<?,?> ⬅️ ::Div(%"val_1652", %"val_1653")
    2381 |  # node_CastLike_1613
            %"val_1655"<?,?> ⬅️ ::CastLike(%"val_1654", %"add_40")
    2382 |  # node_Shape_1614
            %"val_1656"<?,?> ⬅️ ::Shape(%"add_41") {start=0}
    2383 |  # node_Constant_1615
            %"val_1657"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2384 |  # node_Slice_1616
            %"val_1658"<?,?> ⬅️ ::Slice(%"val_1656", %"val_804", %"val_1657")
    2385 |  # node_Slice_1617
            %"val_1659"<?,?> ⬅️ ::Slice(%"val_1656", %"val_806", %"val_804")
    2386 |  # node_Constant_1618
            %"val_1660"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2387 |  # node_Slice_1619
            %"val_1661"<?,?> ⬅️ ::Slice(%"val_1656", %"val_1660", %"val_806")
    2388 |  # node_Constant_1620
            %"val_1662"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2389 |  # node_Concat_1621
            %"val_1663"<?,?> ⬅️ ::Concat(%"val_1662", %"val_1659", %"val_1658") {axis=0}
    2390 |  # node_Reshape_1622
            %"val_1664"<?,?> ⬅️ ::Reshape(%"add_41", %"val_1663") {allowzero=0}
    2391 |  # node_Transpose_1623
            %"val_1665"<?,?> ⬅️ ::Transpose(%"val_1664") {perm=(0, 2, 1)}
    2392 |  # node_Concat_1624
            %"val_1666"<?,?> ⬅️ ::Concat(%"val_1661", %"val_1658", %"val_1659") {axis=0}
    2393 |  # node_Reshape_1625
            %"val_1667"<?,?> ⬅️ ::Reshape(%"val_1665", %"val_1666") {allowzero=0}
    2394 |  # node_Sqrt_1626
            %"val_1668"<?,?> ⬅️ ::Sqrt(%"val_1655")
    2395 |  # node_Mul_1627
            %"val_1669"<?,?> ⬅️ ::Mul(%"add_40", %"val_1668")
    2396 |  # node_Sqrt_1628
            %"val_1670"<?,?> ⬅️ ::Sqrt(%"val_1655")
    2397 |  # node_Mul_1629
            %"val_1671"<?,?> ⬅️ ::Mul(%"val_1667", %"val_1670")
    2398 |  # node_MatMul_1630
            %"val_1672"<?,?> ⬅️ ::MatMul(%"val_1669", %"val_1671")
    2399 |  # node_Add_1631
            %"val_1673"<?,?> ⬅️ ::Add(%"val_1672", %"masked_fill_1")
    2400 |  # node_Softmax_1632
            %"val_1674"<?,?> ⬅️ ::Softmax(%"val_1673") {axis=-1}
    2401 |  # node_scaled_dot_product_attention_10
            %"scaled_dot_product_attention_10"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1674", %"getitem_52")
    2402 |  # node_transpose_43
            %"transpose_43"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_10") {perm=(0, 2, 1, 3)}
    2403 |  # node_Cast_1633
            %"val_1675"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2404 |  # node_view_21
            %"view_21"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_43", %"val_1675") {allowzero=1}
    2405 |  # node_Transpose_1634
            %"val_1676"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.attn.Wo.weight"{...}) {perm=(1, 0)}
    2406 |  # node_linear_41
            %"linear_41"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_21", %"val_1676")
    2407 |  # node_add_42
            %"add_42"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_39", %"linear_41")
    2408 |  # node_layer_norm_21
            %"layer_norm_21"<FLOAT,[1,97,768]>, %"val_1677"<?,?>, %"val_1678"<?,?> ⬅️ ::LayerNormalization(%"add_42", %"encoder.layers.10.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2409 |  # node_Transpose_1635
            %"val_1679"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2410 |  # node_linear_42
            %"linear_42"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_21", %"val_1679")
    2411 |  # node_split_10
            %"split_10"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_42", %"val_829") {dim=-1}
    2412 |  # node_getitem_53
            %"getitem_53"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_10", %"val_6")
    2413 |  # node_getitem_54
            %"getitem_54"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_10", %"val_48")
    2414 |  # node_Constant_1636
            %"val_1680"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2415 |  # node_Div_1637
            %"val_1681"<?,?> ⬅️ ::Div(%"getitem_53", %"val_1680")
    2416 |  # node_Erf_1638
            %"val_1682"<?,?> ⬅️ ::Erf(%"val_1681")
    2417 |  # node_Constant_1639
            %"val_1683"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2418 |  # node_Add_1640
            %"val_1684"<?,?> ⬅️ ::Add(%"val_1682", %"val_1683")
    2419 |  # node_Constant_1641
            %"val_1685"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2420 |  # node_Mul_1642
            %"val_1686"<?,?> ⬅️ ::Mul(%"val_1685", %"val_1684")
    2421 |  # node_gelu_10
            %"gelu_10"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_53", %"val_1686")
    2422 |  # node_mul_98
            %"mul_98"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_10", %"getitem_54")
    2423 |  # node_clone_12
            %"clone_12"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_98")
    2424 |  # node_Transpose_1643
            %"val_1687"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2425 |  # node_linear_43
            %"linear_43"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_12", %"val_1687")
    2426 |  # node_add_43
            %"add_43"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_42", %"linear_43")
    2427 |  # node_layer_norm_22
            %"layer_norm_22"<FLOAT,[1,97,768]>, %"val_1688"<?,?>, %"val_1689"<?,?> ⬅️ ::LayerNormalization(%"add_43", %"encoder.layers.11.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2428 |  # node_Transpose_1644
            %"val_1690"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2429 |  # node_linear_44
            %"linear_44"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_22", %"val_1690")
    2430 |  # node_Cast_1645
            %"val_1691"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2431 |  # node_view_22
            %"view_22"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_44", %"val_1691") {allowzero=1}
    2432 |  # node_transpose_44
            %"transpose_44"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_22") {perm=(0, 3, 2, 1, 4)}
    2433 |  # node_unbind_11
            %"unbind_11"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_44") {dim=2}
    2434 |  # node_getitem_55
            %"getitem_55"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_11", %"val_6")
    2435 |  # node_getitem_56
            %"getitem_56"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_11", %"val_48")
    2436 |  # node_getitem_57
            %"getitem_57"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_11", %"val_72")
    2437 |  # node_unsqueeze_94
            %"unsqueeze_94"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2438 |  # node_unsqueeze_95
            %"unsqueeze_95"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2439 |  # node_mul_99
            %"mul_99"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_55", %"unsqueeze_94")
    2440 |  # node_Cast_1646
            %"val_1692"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2441 |  # node_Constant_1647
            %"val_1693"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2442 |  # node_Reshape_1648
            %"val_1694"<?,?> ⬅️ ::Reshape(%"val_1692", %"val_1693") {allowzero=0}
    2443 |  # node_Cast_1649
            %"val_1695"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2444 |  # node_Constant_1650
            %"val_1696"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2445 |  # node_Reshape_1651
            %"val_1697"<?,?> ⬅️ ::Reshape(%"val_1695", %"val_1696") {allowzero=0}
    2446 |  # node_Cast_1652
            %"val_1698"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2447 |  # node_Constant_1653
            %"val_1699"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2448 |  # node_Reshape_1654
            %"val_1700"<?,?> ⬅️ ::Reshape(%"val_1698", %"val_1699") {allowzero=0}
    2449 |  # node_Constant_1655
            %"val_1701"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2450 |  # node_slice_113
            %"slice_113"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_55", %"val_1694", %"val_1697", %"val_1700", %"val_1701")
    2451 |  # node_Cast_1656
            %"val_1702"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2452 |  # node_Constant_1657
            %"val_1703"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2453 |  # node_Reshape_1658
            %"val_1704"<?,?> ⬅️ ::Reshape(%"val_1702", %"val_1703") {allowzero=0}
    2454 |  # node_Cast_1659
            %"val_1705"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2455 |  # node_Constant_1660
            %"val_1706"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2456 |  # node_Reshape_1661
            %"val_1707"<?,?> ⬅️ ::Reshape(%"val_1705", %"val_1706") {allowzero=0}
    2457 |  # node_Cast_1662
            %"val_1708"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2458 |  # node_Constant_1663
            %"val_1709"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2459 |  # node_Reshape_1664
            %"val_1710"<?,?> ⬅️ ::Reshape(%"val_1708", %"val_1709") {allowzero=0}
    2460 |  # node_Constant_1665
            %"val_1711"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2461 |  # node_slice_114
            %"slice_114"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_55", %"val_1704", %"val_1707", %"val_1710", %"val_1711")
    2462 |  # node_neg_22
            %"neg_22"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_114")
    2463 |  # node_cat_44
            %"cat_44"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_22", %"slice_113") {axis=-1}
    2464 |  # node_mul_100
            %"mul_100"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_44", %"unsqueeze_95")
    2465 |  # node_add_44
            %"add_44"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_99", %"mul_100")
    2466 |  # node_mul_101
            %"mul_101"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_56", %"unsqueeze_94")
    2467 |  # node_Cast_1666
            %"val_1712"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2468 |  # node_Constant_1667
            %"val_1713"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2469 |  # node_Reshape_1668
            %"val_1714"<?,?> ⬅️ ::Reshape(%"val_1712", %"val_1713") {allowzero=0}
    2470 |  # node_Cast_1669
            %"val_1715"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2471 |  # node_Constant_1670
            %"val_1716"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2472 |  # node_Reshape_1671
            %"val_1717"<?,?> ⬅️ ::Reshape(%"val_1715", %"val_1716") {allowzero=0}
    2473 |  # node_Cast_1672
            %"val_1718"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2474 |  # node_Constant_1673
            %"val_1719"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2475 |  # node_Reshape_1674
            %"val_1720"<?,?> ⬅️ ::Reshape(%"val_1718", %"val_1719") {allowzero=0}
    2476 |  # node_Constant_1675
            %"val_1721"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2477 |  # node_slice_115
            %"slice_115"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_56", %"val_1714", %"val_1717", %"val_1720", %"val_1721")
    2478 |  # node_Cast_1676
            %"val_1722"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2479 |  # node_Constant_1677
            %"val_1723"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2480 |  # node_Reshape_1678
            %"val_1724"<?,?> ⬅️ ::Reshape(%"val_1722", %"val_1723") {allowzero=0}
    2481 |  # node_Cast_1679
            %"val_1725"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2482 |  # node_Constant_1680
            %"val_1726"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2483 |  # node_Reshape_1681
            %"val_1727"<?,?> ⬅️ ::Reshape(%"val_1725", %"val_1726") {allowzero=0}
    2484 |  # node_Cast_1682
            %"val_1728"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2485 |  # node_Constant_1683
            %"val_1729"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2486 |  # node_Reshape_1684
            %"val_1730"<?,?> ⬅️ ::Reshape(%"val_1728", %"val_1729") {allowzero=0}
    2487 |  # node_Constant_1685
            %"val_1731"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2488 |  # node_slice_116
            %"slice_116"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_56", %"val_1724", %"val_1727", %"val_1730", %"val_1731")
    2489 |  # node_neg_23
            %"neg_23"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_116")
    2490 |  # node_cat_45
            %"cat_45"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_23", %"slice_115") {axis=-1}
    2491 |  # node_mul_102
            %"mul_102"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_45", %"unsqueeze_95")
    2492 |  # node_add_45
            %"add_45"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_101", %"mul_102")
    2493 |  # node_Shape_1686
            %"val_1732"<?,?> ⬅️ ::Shape(%"add_44") {start=0}
    2494 |  # node_Constant_1687
            %"val_1733"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2495 |  # node_Gather_1688
            %"val_1734"<?,?> ⬅️ ::Gather(%"val_1732", %"val_1733") {axis=0}
    2496 |  # node_CastLike_1689
            %"val_1735"<?,?> ⬅️ ::CastLike(%"val_1734", %"add_44")
    2497 |  # node_Constant_1690
            %"val_1736"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2498 |  # node_CastLike_1691
            %"val_1737"<?,?> ⬅️ ::CastLike(%"val_1736", %"add_44")
    2499 |  # node_Sqrt_1692
            %"val_1738"<?,?> ⬅️ ::Sqrt(%"val_1735")
    2500 |  # node_Div_1693
            %"val_1739"<?,?> ⬅️ ::Div(%"val_1737", %"val_1738")
    2501 |  # node_CastLike_1694
            %"val_1740"<?,?> ⬅️ ::CastLike(%"val_1739", %"add_44")
    2502 |  # node_Shape_1695
            %"val_1741"<?,?> ⬅️ ::Shape(%"add_45") {start=0}
    2503 |  # node_Constant_1696
            %"val_1742"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2504 |  # node_Slice_1697
            %"val_1743"<?,?> ⬅️ ::Slice(%"val_1741", %"val_804", %"val_1742")
    2505 |  # node_Slice_1698
            %"val_1744"<?,?> ⬅️ ::Slice(%"val_1741", %"val_806", %"val_804")
    2506 |  # node_Constant_1699
            %"val_1745"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2507 |  # node_Slice_1700
            %"val_1746"<?,?> ⬅️ ::Slice(%"val_1741", %"val_1745", %"val_806")
    2508 |  # node_Constant_1701
            %"val_1747"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2509 |  # node_Concat_1702
            %"val_1748"<?,?> ⬅️ ::Concat(%"val_1747", %"val_1744", %"val_1743") {axis=0}
    2510 |  # node_Reshape_1703
            %"val_1749"<?,?> ⬅️ ::Reshape(%"add_45", %"val_1748") {allowzero=0}
    2511 |  # node_Transpose_1704
            %"val_1750"<?,?> ⬅️ ::Transpose(%"val_1749") {perm=(0, 2, 1)}
    2512 |  # node_Concat_1705
            %"val_1751"<?,?> ⬅️ ::Concat(%"val_1746", %"val_1743", %"val_1744") {axis=0}
    2513 |  # node_Reshape_1706
            %"val_1752"<?,?> ⬅️ ::Reshape(%"val_1750", %"val_1751") {allowzero=0}
    2514 |  # node_Sqrt_1707
            %"val_1753"<?,?> ⬅️ ::Sqrt(%"val_1740")
    2515 |  # node_Mul_1708
            %"val_1754"<?,?> ⬅️ ::Mul(%"add_44", %"val_1753")
    2516 |  # node_Sqrt_1709
            %"val_1755"<?,?> ⬅️ ::Sqrt(%"val_1740")
    2517 |  # node_Mul_1710
            %"val_1756"<?,?> ⬅️ ::Mul(%"val_1752", %"val_1755")
    2518 |  # node_MatMul_1711
            %"val_1757"<?,?> ⬅️ ::MatMul(%"val_1754", %"val_1756")
    2519 |  # node_Add_1712
            %"val_1758"<?,?> ⬅️ ::Add(%"val_1757", %"masked_fill_1")
    2520 |  # node_Softmax_1713
            %"val_1759"<?,?> ⬅️ ::Softmax(%"val_1758") {axis=-1}
    2521 |  # node_scaled_dot_product_attention_11
            %"scaled_dot_product_attention_11"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1759", %"getitem_57")
    2522 |  # node_transpose_45
            %"transpose_45"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_11") {perm=(0, 2, 1, 3)}
    2523 |  # node_Cast_1714
            %"val_1760"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2524 |  # node_view_23
            %"view_23"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_45", %"val_1760") {allowzero=1}
    2525 |  # node_Transpose_1715
            %"val_1761"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.attn.Wo.weight"{...}) {perm=(1, 0)}
    2526 |  # node_linear_45
            %"linear_45"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_23", %"val_1761")
    2527 |  # node_add_46
            %"add_46"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_43", %"linear_45")
    2528 |  # node_layer_norm_23
            %"layer_norm_23"<FLOAT,[1,97,768]>, %"val_1762"<?,?>, %"val_1763"<?,?> ⬅️ ::LayerNormalization(%"add_46", %"encoder.layers.11.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2529 |  # node_Transpose_1716
            %"val_1764"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2530 |  # node_linear_46
            %"linear_46"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_23", %"val_1764")
    2531 |  # node_split_11
            %"split_11"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_46", %"val_829") {dim=-1}
    2532 |  # node_getitem_58
            %"getitem_58"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_11", %"val_6")
    2533 |  # node_getitem_59
            %"getitem_59"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_11", %"val_48")
    2534 |  # node_Constant_1717
            %"val_1765"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2535 |  # node_Div_1718
            %"val_1766"<?,?> ⬅️ ::Div(%"getitem_58", %"val_1765")
    2536 |  # node_Erf_1719
            %"val_1767"<?,?> ⬅️ ::Erf(%"val_1766")
    2537 |  # node_Constant_1720
            %"val_1768"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2538 |  # node_Add_1721
            %"val_1769"<?,?> ⬅️ ::Add(%"val_1767", %"val_1768")
    2539 |  # node_Constant_1722
            %"val_1770"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2540 |  # node_Mul_1723
            %"val_1771"<?,?> ⬅️ ::Mul(%"val_1770", %"val_1769")
    2541 |  # node_gelu_11
            %"gelu_11"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_58", %"val_1771")
    2542 |  # node_mul_103
            %"mul_103"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_11", %"getitem_59")
    2543 |  # node_clone_13
            %"clone_13"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_103")
    2544 |  # node_Transpose_1724
            %"val_1772"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2545 |  # node_linear_47
            %"linear_47"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_13", %"val_1772")
    2546 |  # node_add_47
            %"add_47"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_46", %"linear_47")
    2547 |  # node_layer_norm_24
            %"layer_norm_24"<FLOAT,[1,97,768]>, %"val_1773"<?,?>, %"val_1774"<?,?> ⬅️ ::LayerNormalization(%"add_47", %"encoder.layers.12.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2548 |  # node_Transpose_1725
            %"val_1775"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2549 |  # node_linear_48
            %"linear_48"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_24", %"val_1775")
    2550 |  # node_Cast_1726
            %"val_1776"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2551 |  # node_view_24
            %"view_24"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_48", %"val_1776") {allowzero=1}
    2552 |  # node_transpose_46
            %"transpose_46"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_24") {perm=(0, 3, 2, 1, 4)}
    2553 |  # node_unbind_12
            %"unbind_12"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_46") {dim=2}
    2554 |  # node_getitem_60
            %"getitem_60"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_12", %"val_6")
    2555 |  # node_getitem_61
            %"getitem_61"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_12", %"val_48")
    2556 |  # node_getitem_62
            %"getitem_62"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_12", %"val_72")
    2557 |  # node_unsqueeze_96
            %"unsqueeze_96"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    2558 |  # node_unsqueeze_97
            %"unsqueeze_97"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    2559 |  # node_mul_104
            %"mul_104"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_60", %"unsqueeze_96")
    2560 |  # node_Cast_1727
            %"val_1777"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2561 |  # node_Constant_1728
            %"val_1778"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2562 |  # node_Reshape_1729
            %"val_1779"<?,?> ⬅️ ::Reshape(%"val_1777", %"val_1778") {allowzero=0}
    2563 |  # node_Cast_1730
            %"val_1780"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2564 |  # node_Constant_1731
            %"val_1781"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2565 |  # node_Reshape_1732
            %"val_1782"<?,?> ⬅️ ::Reshape(%"val_1780", %"val_1781") {allowzero=0}
    2566 |  # node_Cast_1733
            %"val_1783"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2567 |  # node_Constant_1734
            %"val_1784"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2568 |  # node_Reshape_1735
            %"val_1785"<?,?> ⬅️ ::Reshape(%"val_1783", %"val_1784") {allowzero=0}
    2569 |  # node_Constant_1736
            %"val_1786"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2570 |  # node_slice_117
            %"slice_117"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_60", %"val_1779", %"val_1782", %"val_1785", %"val_1786")
    2571 |  # node_Cast_1737
            %"val_1787"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2572 |  # node_Constant_1738
            %"val_1788"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2573 |  # node_Reshape_1739
            %"val_1789"<?,?> ⬅️ ::Reshape(%"val_1787", %"val_1788") {allowzero=0}
    2574 |  # node_Cast_1740
            %"val_1790"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2575 |  # node_Constant_1741
            %"val_1791"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2576 |  # node_Reshape_1742
            %"val_1792"<?,?> ⬅️ ::Reshape(%"val_1790", %"val_1791") {allowzero=0}
    2577 |  # node_Cast_1743
            %"val_1793"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2578 |  # node_Constant_1744
            %"val_1794"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2579 |  # node_Reshape_1745
            %"val_1795"<?,?> ⬅️ ::Reshape(%"val_1793", %"val_1794") {allowzero=0}
    2580 |  # node_Constant_1746
            %"val_1796"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2581 |  # node_slice_118
            %"slice_118"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_60", %"val_1789", %"val_1792", %"val_1795", %"val_1796")
    2582 |  # node_neg_24
            %"neg_24"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_118")
    2583 |  # node_cat_46
            %"cat_46"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_24", %"slice_117") {axis=-1}
    2584 |  # node_mul_105
            %"mul_105"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_46", %"unsqueeze_97")
    2585 |  # node_add_48
            %"add_48"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_104", %"mul_105")
    2586 |  # node_mul_106
            %"mul_106"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_61", %"unsqueeze_96")
    2587 |  # node_Cast_1747
            %"val_1797"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2588 |  # node_Constant_1748
            %"val_1798"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2589 |  # node_Reshape_1749
            %"val_1799"<?,?> ⬅️ ::Reshape(%"val_1797", %"val_1798") {allowzero=0}
    2590 |  # node_Cast_1750
            %"val_1800"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2591 |  # node_Constant_1751
            %"val_1801"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2592 |  # node_Reshape_1752
            %"val_1802"<?,?> ⬅️ ::Reshape(%"val_1800", %"val_1801") {allowzero=0}
    2593 |  # node_Cast_1753
            %"val_1803"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2594 |  # node_Constant_1754
            %"val_1804"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2595 |  # node_Reshape_1755
            %"val_1805"<?,?> ⬅️ ::Reshape(%"val_1803", %"val_1804") {allowzero=0}
    2596 |  # node_Constant_1756
            %"val_1806"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2597 |  # node_slice_119
            %"slice_119"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_61", %"val_1799", %"val_1802", %"val_1805", %"val_1806")
    2598 |  # node_Cast_1757
            %"val_1807"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2599 |  # node_Constant_1758
            %"val_1808"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2600 |  # node_Reshape_1759
            %"val_1809"<?,?> ⬅️ ::Reshape(%"val_1807", %"val_1808") {allowzero=0}
    2601 |  # node_Cast_1760
            %"val_1810"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2602 |  # node_Constant_1761
            %"val_1811"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2603 |  # node_Reshape_1762
            %"val_1812"<?,?> ⬅️ ::Reshape(%"val_1810", %"val_1811") {allowzero=0}
    2604 |  # node_Cast_1763
            %"val_1813"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2605 |  # node_Constant_1764
            %"val_1814"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2606 |  # node_Reshape_1765
            %"val_1815"<?,?> ⬅️ ::Reshape(%"val_1813", %"val_1814") {allowzero=0}
    2607 |  # node_Constant_1766
            %"val_1816"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2608 |  # node_slice_120
            %"slice_120"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_61", %"val_1809", %"val_1812", %"val_1815", %"val_1816")
    2609 |  # node_neg_25
            %"neg_25"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_120")
    2610 |  # node_cat_47
            %"cat_47"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_25", %"slice_119") {axis=-1}
    2611 |  # node_mul_107
            %"mul_107"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_47", %"unsqueeze_97")
    2612 |  # node_add_49
            %"add_49"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_106", %"mul_107")
    2613 |  # node_Shape_1767
            %"val_1817"<?,?> ⬅️ ::Shape(%"add_48") {start=0}
    2614 |  # node_Constant_1768
            %"val_1818"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2615 |  # node_Gather_1769
            %"val_1819"<?,?> ⬅️ ::Gather(%"val_1817", %"val_1818") {axis=0}
    2616 |  # node_CastLike_1770
            %"val_1820"<?,?> ⬅️ ::CastLike(%"val_1819", %"add_48")
    2617 |  # node_Constant_1771
            %"val_1821"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2618 |  # node_CastLike_1772
            %"val_1822"<?,?> ⬅️ ::CastLike(%"val_1821", %"add_48")
    2619 |  # node_Sqrt_1773
            %"val_1823"<?,?> ⬅️ ::Sqrt(%"val_1820")
    2620 |  # node_Div_1774
            %"val_1824"<?,?> ⬅️ ::Div(%"val_1822", %"val_1823")
    2621 |  # node_CastLike_1775
            %"val_1825"<?,?> ⬅️ ::CastLike(%"val_1824", %"add_48")
    2622 |  # node_Shape_1776
            %"val_1826"<?,?> ⬅️ ::Shape(%"add_49") {start=0}
    2623 |  # node_Constant_1777
            %"val_1827"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2624 |  # node_Slice_1778
            %"val_1828"<?,?> ⬅️ ::Slice(%"val_1826", %"val_804", %"val_1827")
    2625 |  # node_Slice_1779
            %"val_1829"<?,?> ⬅️ ::Slice(%"val_1826", %"val_806", %"val_804")
    2626 |  # node_Constant_1780
            %"val_1830"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2627 |  # node_Slice_1781
            %"val_1831"<?,?> ⬅️ ::Slice(%"val_1826", %"val_1830", %"val_806")
    2628 |  # node_Constant_1782
            %"val_1832"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2629 |  # node_Concat_1783
            %"val_1833"<?,?> ⬅️ ::Concat(%"val_1832", %"val_1829", %"val_1828") {axis=0}
    2630 |  # node_Reshape_1784
            %"val_1834"<?,?> ⬅️ ::Reshape(%"add_49", %"val_1833") {allowzero=0}
    2631 |  # node_Transpose_1785
            %"val_1835"<?,?> ⬅️ ::Transpose(%"val_1834") {perm=(0, 2, 1)}
    2632 |  # node_Concat_1786
            %"val_1836"<?,?> ⬅️ ::Concat(%"val_1831", %"val_1828", %"val_1829") {axis=0}
    2633 |  # node_Reshape_1787
            %"val_1837"<?,?> ⬅️ ::Reshape(%"val_1835", %"val_1836") {allowzero=0}
    2634 |  # node_Sqrt_1788
            %"val_1838"<?,?> ⬅️ ::Sqrt(%"val_1825")
    2635 |  # node_Mul_1789
            %"val_1839"<?,?> ⬅️ ::Mul(%"add_48", %"val_1838")
    2636 |  # node_Sqrt_1790
            %"val_1840"<?,?> ⬅️ ::Sqrt(%"val_1825")
    2637 |  # node_Mul_1791
            %"val_1841"<?,?> ⬅️ ::Mul(%"val_1837", %"val_1840")
    2638 |  # node_MatMul_1792
            %"val_1842"<?,?> ⬅️ ::MatMul(%"val_1839", %"val_1841")
    2639 |  # node_Add_1793
            %"val_1843"<?,?> ⬅️ ::Add(%"val_1842", %"masked_fill")
    2640 |  # node_Softmax_1794
            %"val_1844"<?,?> ⬅️ ::Softmax(%"val_1843") {axis=-1}
    2641 |  # node_scaled_dot_product_attention_12
            %"scaled_dot_product_attention_12"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1844", %"getitem_62")
    2642 |  # node_transpose_47
            %"transpose_47"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_12") {perm=(0, 2, 1, 3)}
    2643 |  # node_Cast_1795
            %"val_1845"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2644 |  # node_view_25
            %"view_25"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_47", %"val_1845") {allowzero=1}
    2645 |  # node_Transpose_1796
            %"val_1846"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.attn.Wo.weight"{...}) {perm=(1, 0)}
    2646 |  # node_linear_49
            %"linear_49"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_25", %"val_1846")
    2647 |  # node_add_50
            %"add_50"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_47", %"linear_49")
    2648 |  # node_layer_norm_25
            %"layer_norm_25"<FLOAT,[1,97,768]>, %"val_1847"<?,?>, %"val_1848"<?,?> ⬅️ ::LayerNormalization(%"add_50", %"encoder.layers.12.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2649 |  # node_Transpose_1797
            %"val_1849"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2650 |  # node_linear_50
            %"linear_50"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_25", %"val_1849")
    2651 |  # node_split_12
            %"split_12"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_50", %"val_829") {dim=-1}
    2652 |  # node_getitem_63
            %"getitem_63"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_12", %"val_6")
    2653 |  # node_getitem_64
            %"getitem_64"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_12", %"val_48")
    2654 |  # node_Constant_1798
            %"val_1850"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2655 |  # node_Div_1799
            %"val_1851"<?,?> ⬅️ ::Div(%"getitem_63", %"val_1850")
    2656 |  # node_Erf_1800
            %"val_1852"<?,?> ⬅️ ::Erf(%"val_1851")
    2657 |  # node_Constant_1801
            %"val_1853"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2658 |  # node_Add_1802
            %"val_1854"<?,?> ⬅️ ::Add(%"val_1852", %"val_1853")
    2659 |  # node_Constant_1803
            %"val_1855"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2660 |  # node_Mul_1804
            %"val_1856"<?,?> ⬅️ ::Mul(%"val_1855", %"val_1854")
    2661 |  # node_gelu_12
            %"gelu_12"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_63", %"val_1856")
    2662 |  # node_mul_108
            %"mul_108"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_12", %"getitem_64")
    2663 |  # node_clone_14
            %"clone_14"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_108")
    2664 |  # node_Transpose_1805
            %"val_1857"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2665 |  # node_linear_51
            %"linear_51"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_14", %"val_1857")
    2666 |  # node_add_51
            %"add_51"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_50", %"linear_51")
    2667 |  # node_layer_norm_26
            %"layer_norm_26"<FLOAT,[1,97,768]>, %"val_1858"<?,?>, %"val_1859"<?,?> ⬅️ ::LayerNormalization(%"add_51", %"encoder.layers.13.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2668 |  # node_Transpose_1806
            %"val_1860"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2669 |  # node_linear_52
            %"linear_52"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_26", %"val_1860")
    2670 |  # node_Cast_1807
            %"val_1861"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2671 |  # node_view_26
            %"view_26"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_52", %"val_1861") {allowzero=1}
    2672 |  # node_transpose_48
            %"transpose_48"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_26") {perm=(0, 3, 2, 1, 4)}
    2673 |  # node_unbind_13
            %"unbind_13"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_48") {dim=2}
    2674 |  # node_getitem_65
            %"getitem_65"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_13", %"val_6")
    2675 |  # node_getitem_66
            %"getitem_66"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_13", %"val_48")
    2676 |  # node_getitem_67
            %"getitem_67"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_13", %"val_72")
    2677 |  # node_unsqueeze_98
            %"unsqueeze_98"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2678 |  # node_unsqueeze_99
            %"unsqueeze_99"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2679 |  # node_mul_109
            %"mul_109"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_65", %"unsqueeze_98")
    2680 |  # node_Cast_1808
            %"val_1862"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2681 |  # node_Constant_1809
            %"val_1863"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2682 |  # node_Reshape_1810
            %"val_1864"<?,?> ⬅️ ::Reshape(%"val_1862", %"val_1863") {allowzero=0}
    2683 |  # node_Cast_1811
            %"val_1865"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2684 |  # node_Constant_1812
            %"val_1866"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2685 |  # node_Reshape_1813
            %"val_1867"<?,?> ⬅️ ::Reshape(%"val_1865", %"val_1866") {allowzero=0}
    2686 |  # node_Cast_1814
            %"val_1868"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2687 |  # node_Constant_1815
            %"val_1869"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2688 |  # node_Reshape_1816
            %"val_1870"<?,?> ⬅️ ::Reshape(%"val_1868", %"val_1869") {allowzero=0}
    2689 |  # node_Constant_1817
            %"val_1871"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2690 |  # node_slice_121
            %"slice_121"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_65", %"val_1864", %"val_1867", %"val_1870", %"val_1871")
    2691 |  # node_Cast_1818
            %"val_1872"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2692 |  # node_Constant_1819
            %"val_1873"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2693 |  # node_Reshape_1820
            %"val_1874"<?,?> ⬅️ ::Reshape(%"val_1872", %"val_1873") {allowzero=0}
    2694 |  # node_Cast_1821
            %"val_1875"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2695 |  # node_Constant_1822
            %"val_1876"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2696 |  # node_Reshape_1823
            %"val_1877"<?,?> ⬅️ ::Reshape(%"val_1875", %"val_1876") {allowzero=0}
    2697 |  # node_Cast_1824
            %"val_1878"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2698 |  # node_Constant_1825
            %"val_1879"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2699 |  # node_Reshape_1826
            %"val_1880"<?,?> ⬅️ ::Reshape(%"val_1878", %"val_1879") {allowzero=0}
    2700 |  # node_Constant_1827
            %"val_1881"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2701 |  # node_slice_122
            %"slice_122"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_65", %"val_1874", %"val_1877", %"val_1880", %"val_1881")
    2702 |  # node_neg_26
            %"neg_26"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_122")
    2703 |  # node_cat_48
            %"cat_48"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_26", %"slice_121") {axis=-1}
    2704 |  # node_mul_110
            %"mul_110"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_48", %"unsqueeze_99")
    2705 |  # node_add_52
            %"add_52"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_109", %"mul_110")
    2706 |  # node_mul_111
            %"mul_111"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_66", %"unsqueeze_98")
    2707 |  # node_Cast_1828
            %"val_1882"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2708 |  # node_Constant_1829
            %"val_1883"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2709 |  # node_Reshape_1830
            %"val_1884"<?,?> ⬅️ ::Reshape(%"val_1882", %"val_1883") {allowzero=0}
    2710 |  # node_Cast_1831
            %"val_1885"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2711 |  # node_Constant_1832
            %"val_1886"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2712 |  # node_Reshape_1833
            %"val_1887"<?,?> ⬅️ ::Reshape(%"val_1885", %"val_1886") {allowzero=0}
    2713 |  # node_Cast_1834
            %"val_1888"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2714 |  # node_Constant_1835
            %"val_1889"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2715 |  # node_Reshape_1836
            %"val_1890"<?,?> ⬅️ ::Reshape(%"val_1888", %"val_1889") {allowzero=0}
    2716 |  # node_Constant_1837
            %"val_1891"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2717 |  # node_slice_123
            %"slice_123"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_66", %"val_1884", %"val_1887", %"val_1890", %"val_1891")
    2718 |  # node_Cast_1838
            %"val_1892"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2719 |  # node_Constant_1839
            %"val_1893"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2720 |  # node_Reshape_1840
            %"val_1894"<?,?> ⬅️ ::Reshape(%"val_1892", %"val_1893") {allowzero=0}
    2721 |  # node_Cast_1841
            %"val_1895"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2722 |  # node_Constant_1842
            %"val_1896"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2723 |  # node_Reshape_1843
            %"val_1897"<?,?> ⬅️ ::Reshape(%"val_1895", %"val_1896") {allowzero=0}
    2724 |  # node_Cast_1844
            %"val_1898"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2725 |  # node_Constant_1845
            %"val_1899"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2726 |  # node_Reshape_1846
            %"val_1900"<?,?> ⬅️ ::Reshape(%"val_1898", %"val_1899") {allowzero=0}
    2727 |  # node_Constant_1847
            %"val_1901"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2728 |  # node_slice_124
            %"slice_124"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_66", %"val_1894", %"val_1897", %"val_1900", %"val_1901")
    2729 |  # node_neg_27
            %"neg_27"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_124")
    2730 |  # node_cat_49
            %"cat_49"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_27", %"slice_123") {axis=-1}
    2731 |  # node_mul_112
            %"mul_112"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_49", %"unsqueeze_99")
    2732 |  # node_add_53
            %"add_53"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_111", %"mul_112")
    2733 |  # node_Shape_1848
            %"val_1902"<?,?> ⬅️ ::Shape(%"add_52") {start=0}
    2734 |  # node_Constant_1849
            %"val_1903"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2735 |  # node_Gather_1850
            %"val_1904"<?,?> ⬅️ ::Gather(%"val_1902", %"val_1903") {axis=0}
    2736 |  # node_CastLike_1851
            %"val_1905"<?,?> ⬅️ ::CastLike(%"val_1904", %"add_52")
    2737 |  # node_Constant_1852
            %"val_1906"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2738 |  # node_CastLike_1853
            %"val_1907"<?,?> ⬅️ ::CastLike(%"val_1906", %"add_52")
    2739 |  # node_Sqrt_1854
            %"val_1908"<?,?> ⬅️ ::Sqrt(%"val_1905")
    2740 |  # node_Div_1855
            %"val_1909"<?,?> ⬅️ ::Div(%"val_1907", %"val_1908")
    2741 |  # node_CastLike_1856
            %"val_1910"<?,?> ⬅️ ::CastLike(%"val_1909", %"add_52")
    2742 |  # node_Shape_1857
            %"val_1911"<?,?> ⬅️ ::Shape(%"add_53") {start=0}
    2743 |  # node_Constant_1858
            %"val_1912"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2744 |  # node_Slice_1859
            %"val_1913"<?,?> ⬅️ ::Slice(%"val_1911", %"val_804", %"val_1912")
    2745 |  # node_Slice_1860
            %"val_1914"<?,?> ⬅️ ::Slice(%"val_1911", %"val_806", %"val_804")
    2746 |  # node_Constant_1861
            %"val_1915"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2747 |  # node_Slice_1862
            %"val_1916"<?,?> ⬅️ ::Slice(%"val_1911", %"val_1915", %"val_806")
    2748 |  # node_Constant_1863
            %"val_1917"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2749 |  # node_Concat_1864
            %"val_1918"<?,?> ⬅️ ::Concat(%"val_1917", %"val_1914", %"val_1913") {axis=0}
    2750 |  # node_Reshape_1865
            %"val_1919"<?,?> ⬅️ ::Reshape(%"add_53", %"val_1918") {allowzero=0}
    2751 |  # node_Transpose_1866
            %"val_1920"<?,?> ⬅️ ::Transpose(%"val_1919") {perm=(0, 2, 1)}
    2752 |  # node_Concat_1867
            %"val_1921"<?,?> ⬅️ ::Concat(%"val_1916", %"val_1913", %"val_1914") {axis=0}
    2753 |  # node_Reshape_1868
            %"val_1922"<?,?> ⬅️ ::Reshape(%"val_1920", %"val_1921") {allowzero=0}
    2754 |  # node_Sqrt_1869
            %"val_1923"<?,?> ⬅️ ::Sqrt(%"val_1910")
    2755 |  # node_Mul_1870
            %"val_1924"<?,?> ⬅️ ::Mul(%"add_52", %"val_1923")
    2756 |  # node_Sqrt_1871
            %"val_1925"<?,?> ⬅️ ::Sqrt(%"val_1910")
    2757 |  # node_Mul_1872
            %"val_1926"<?,?> ⬅️ ::Mul(%"val_1922", %"val_1925")
    2758 |  # node_MatMul_1873
            %"val_1927"<?,?> ⬅️ ::MatMul(%"val_1924", %"val_1926")
    2759 |  # node_Add_1874
            %"val_1928"<?,?> ⬅️ ::Add(%"val_1927", %"masked_fill_1")
    2760 |  # node_Softmax_1875
            %"val_1929"<?,?> ⬅️ ::Softmax(%"val_1928") {axis=-1}
    2761 |  # node_scaled_dot_product_attention_13
            %"scaled_dot_product_attention_13"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1929", %"getitem_67")
    2762 |  # node_transpose_49
            %"transpose_49"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_13") {perm=(0, 2, 1, 3)}
    2763 |  # node_Cast_1876
            %"val_1930"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2764 |  # node_view_27
            %"view_27"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_49", %"val_1930") {allowzero=1}
    2765 |  # node_Transpose_1877
            %"val_1931"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.attn.Wo.weight"{...}) {perm=(1, 0)}
    2766 |  # node_linear_53
            %"linear_53"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_27", %"val_1931")
    2767 |  # node_add_54
            %"add_54"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_51", %"linear_53")
    2768 |  # node_layer_norm_27
            %"layer_norm_27"<FLOAT,[1,97,768]>, %"val_1932"<?,?>, %"val_1933"<?,?> ⬅️ ::LayerNormalization(%"add_54", %"encoder.layers.13.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2769 |  # node_Transpose_1878
            %"val_1934"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2770 |  # node_linear_54
            %"linear_54"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_27", %"val_1934")
    2771 |  # node_split_13
            %"split_13"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_54", %"val_829") {dim=-1}
    2772 |  # node_getitem_68
            %"getitem_68"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_13", %"val_6")
    2773 |  # node_getitem_69
            %"getitem_69"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_13", %"val_48")
    2774 |  # node_Constant_1879
            %"val_1935"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2775 |  # node_Div_1880
            %"val_1936"<?,?> ⬅️ ::Div(%"getitem_68", %"val_1935")
    2776 |  # node_Erf_1881
            %"val_1937"<?,?> ⬅️ ::Erf(%"val_1936")
    2777 |  # node_Constant_1882
            %"val_1938"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2778 |  # node_Add_1883
            %"val_1939"<?,?> ⬅️ ::Add(%"val_1937", %"val_1938")
    2779 |  # node_Constant_1884
            %"val_1940"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2780 |  # node_Mul_1885
            %"val_1941"<?,?> ⬅️ ::Mul(%"val_1940", %"val_1939")
    2781 |  # node_gelu_13
            %"gelu_13"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_68", %"val_1941")
    2782 |  # node_mul_113
            %"mul_113"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_13", %"getitem_69")
    2783 |  # node_clone_15
            %"clone_15"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_113")
    2784 |  # node_Transpose_1886
            %"val_1942"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2785 |  # node_linear_55
            %"linear_55"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_15", %"val_1942")
    2786 |  # node_add_55
            %"add_55"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_54", %"linear_55")
    2787 |  # node_layer_norm_28
            %"layer_norm_28"<FLOAT,[1,97,768]>, %"val_1943"<?,?>, %"val_1944"<?,?> ⬅️ ::LayerNormalization(%"add_55", %"encoder.layers.14.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2788 |  # node_Transpose_1887
            %"val_1945"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2789 |  # node_linear_56
            %"linear_56"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_28", %"val_1945")
    2790 |  # node_Cast_1888
            %"val_1946"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2791 |  # node_view_28
            %"view_28"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_56", %"val_1946") {allowzero=1}
    2792 |  # node_transpose_50
            %"transpose_50"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_28") {perm=(0, 3, 2, 1, 4)}
    2793 |  # node_unbind_14
            %"unbind_14"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_50") {dim=2}
    2794 |  # node_getitem_70
            %"getitem_70"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_14", %"val_6")
    2795 |  # node_getitem_71
            %"getitem_71"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_14", %"val_48")
    2796 |  # node_getitem_72
            %"getitem_72"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_14", %"val_72")
    2797 |  # node_unsqueeze_100
            %"unsqueeze_100"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2798 |  # node_unsqueeze_101
            %"unsqueeze_101"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2799 |  # node_mul_114
            %"mul_114"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_70", %"unsqueeze_100")
    2800 |  # node_Cast_1889
            %"val_1947"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2801 |  # node_Constant_1890
            %"val_1948"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2802 |  # node_Reshape_1891
            %"val_1949"<?,?> ⬅️ ::Reshape(%"val_1947", %"val_1948") {allowzero=0}
    2803 |  # node_Cast_1892
            %"val_1950"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2804 |  # node_Constant_1893
            %"val_1951"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2805 |  # node_Reshape_1894
            %"val_1952"<?,?> ⬅️ ::Reshape(%"val_1950", %"val_1951") {allowzero=0}
    2806 |  # node_Cast_1895
            %"val_1953"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2807 |  # node_Constant_1896
            %"val_1954"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2808 |  # node_Reshape_1897
            %"val_1955"<?,?> ⬅️ ::Reshape(%"val_1953", %"val_1954") {allowzero=0}
    2809 |  # node_Constant_1898
            %"val_1956"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2810 |  # node_slice_125
            %"slice_125"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_70", %"val_1949", %"val_1952", %"val_1955", %"val_1956")
    2811 |  # node_Cast_1899
            %"val_1957"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2812 |  # node_Constant_1900
            %"val_1958"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2813 |  # node_Reshape_1901
            %"val_1959"<?,?> ⬅️ ::Reshape(%"val_1957", %"val_1958") {allowzero=0}
    2814 |  # node_Cast_1902
            %"val_1960"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2815 |  # node_Constant_1903
            %"val_1961"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2816 |  # node_Reshape_1904
            %"val_1962"<?,?> ⬅️ ::Reshape(%"val_1960", %"val_1961") {allowzero=0}
    2817 |  # node_Cast_1905
            %"val_1963"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2818 |  # node_Constant_1906
            %"val_1964"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2819 |  # node_Reshape_1907
            %"val_1965"<?,?> ⬅️ ::Reshape(%"val_1963", %"val_1964") {allowzero=0}
    2820 |  # node_Constant_1908
            %"val_1966"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2821 |  # node_slice_126
            %"slice_126"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_70", %"val_1959", %"val_1962", %"val_1965", %"val_1966")
    2822 |  # node_neg_28
            %"neg_28"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_126")
    2823 |  # node_cat_50
            %"cat_50"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_28", %"slice_125") {axis=-1}
    2824 |  # node_mul_115
            %"mul_115"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_50", %"unsqueeze_101")
    2825 |  # node_add_56
            %"add_56"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_114", %"mul_115")
    2826 |  # node_mul_116
            %"mul_116"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_71", %"unsqueeze_100")
    2827 |  # node_Cast_1909
            %"val_1967"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2828 |  # node_Constant_1910
            %"val_1968"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2829 |  # node_Reshape_1911
            %"val_1969"<?,?> ⬅️ ::Reshape(%"val_1967", %"val_1968") {allowzero=0}
    2830 |  # node_Cast_1912
            %"val_1970"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2831 |  # node_Constant_1913
            %"val_1971"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2832 |  # node_Reshape_1914
            %"val_1972"<?,?> ⬅️ ::Reshape(%"val_1970", %"val_1971") {allowzero=0}
    2833 |  # node_Cast_1915
            %"val_1973"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2834 |  # node_Constant_1916
            %"val_1974"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2835 |  # node_Reshape_1917
            %"val_1975"<?,?> ⬅️ ::Reshape(%"val_1973", %"val_1974") {allowzero=0}
    2836 |  # node_Constant_1918
            %"val_1976"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2837 |  # node_slice_127
            %"slice_127"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_71", %"val_1969", %"val_1972", %"val_1975", %"val_1976")
    2838 |  # node_Cast_1919
            %"val_1977"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2839 |  # node_Constant_1920
            %"val_1978"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2840 |  # node_Reshape_1921
            %"val_1979"<?,?> ⬅️ ::Reshape(%"val_1977", %"val_1978") {allowzero=0}
    2841 |  # node_Cast_1922
            %"val_1980"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2842 |  # node_Constant_1923
            %"val_1981"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2843 |  # node_Reshape_1924
            %"val_1982"<?,?> ⬅️ ::Reshape(%"val_1980", %"val_1981") {allowzero=0}
    2844 |  # node_Cast_1925
            %"val_1983"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2845 |  # node_Constant_1926
            %"val_1984"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2846 |  # node_Reshape_1927
            %"val_1985"<?,?> ⬅️ ::Reshape(%"val_1983", %"val_1984") {allowzero=0}
    2847 |  # node_Constant_1928
            %"val_1986"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2848 |  # node_slice_128
            %"slice_128"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_71", %"val_1979", %"val_1982", %"val_1985", %"val_1986")
    2849 |  # node_neg_29
            %"neg_29"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_128")
    2850 |  # node_cat_51
            %"cat_51"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_29", %"slice_127") {axis=-1}
    2851 |  # node_mul_117
            %"mul_117"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_51", %"unsqueeze_101")
    2852 |  # node_add_57
            %"add_57"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_116", %"mul_117")
    2853 |  # node_Shape_1929
            %"val_1987"<?,?> ⬅️ ::Shape(%"add_56") {start=0}
    2854 |  # node_Constant_1930
            %"val_1988"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2855 |  # node_Gather_1931
            %"val_1989"<?,?> ⬅️ ::Gather(%"val_1987", %"val_1988") {axis=0}
    2856 |  # node_CastLike_1932
            %"val_1990"<?,?> ⬅️ ::CastLike(%"val_1989", %"add_56")
    2857 |  # node_Constant_1933
            %"val_1991"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2858 |  # node_CastLike_1934
            %"val_1992"<?,?> ⬅️ ::CastLike(%"val_1991", %"add_56")
    2859 |  # node_Sqrt_1935
            %"val_1993"<?,?> ⬅️ ::Sqrt(%"val_1990")
    2860 |  # node_Div_1936
            %"val_1994"<?,?> ⬅️ ::Div(%"val_1992", %"val_1993")
    2861 |  # node_CastLike_1937
            %"val_1995"<?,?> ⬅️ ::CastLike(%"val_1994", %"add_56")
    2862 |  # node_Shape_1938
            %"val_1996"<?,?> ⬅️ ::Shape(%"add_57") {start=0}
    2863 |  # node_Constant_1939
            %"val_1997"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2864 |  # node_Slice_1940
            %"val_1998"<?,?> ⬅️ ::Slice(%"val_1996", %"val_804", %"val_1997")
    2865 |  # node_Slice_1941
            %"val_1999"<?,?> ⬅️ ::Slice(%"val_1996", %"val_806", %"val_804")
    2866 |  # node_Constant_1942
            %"val_2000"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2867 |  # node_Slice_1943
            %"val_2001"<?,?> ⬅️ ::Slice(%"val_1996", %"val_2000", %"val_806")
    2868 |  # node_Constant_1944
            %"val_2002"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2869 |  # node_Concat_1945
            %"val_2003"<?,?> ⬅️ ::Concat(%"val_2002", %"val_1999", %"val_1998") {axis=0}
    2870 |  # node_Reshape_1946
            %"val_2004"<?,?> ⬅️ ::Reshape(%"add_57", %"val_2003") {allowzero=0}
    2871 |  # node_Transpose_1947
            %"val_2005"<?,?> ⬅️ ::Transpose(%"val_2004") {perm=(0, 2, 1)}
    2872 |  # node_Concat_1948
            %"val_2006"<?,?> ⬅️ ::Concat(%"val_2001", %"val_1998", %"val_1999") {axis=0}
    2873 |  # node_Reshape_1949
            %"val_2007"<?,?> ⬅️ ::Reshape(%"val_2005", %"val_2006") {allowzero=0}
    2874 |  # node_Sqrt_1950
            %"val_2008"<?,?> ⬅️ ::Sqrt(%"val_1995")
    2875 |  # node_Mul_1951
            %"val_2009"<?,?> ⬅️ ::Mul(%"add_56", %"val_2008")
    2876 |  # node_Sqrt_1952
            %"val_2010"<?,?> ⬅️ ::Sqrt(%"val_1995")
    2877 |  # node_Mul_1953
            %"val_2011"<?,?> ⬅️ ::Mul(%"val_2007", %"val_2010")
    2878 |  # node_MatMul_1954
            %"val_2012"<?,?> ⬅️ ::MatMul(%"val_2009", %"val_2011")
    2879 |  # node_Add_1955
            %"val_2013"<?,?> ⬅️ ::Add(%"val_2012", %"masked_fill_1")
    2880 |  # node_Softmax_1956
            %"val_2014"<?,?> ⬅️ ::Softmax(%"val_2013") {axis=-1}
    2881 |  # node_scaled_dot_product_attention_14
            %"scaled_dot_product_attention_14"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2014", %"getitem_72")
    2882 |  # node_transpose_51
            %"transpose_51"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_14") {perm=(0, 2, 1, 3)}
    2883 |  # node_Cast_1957
            %"val_2015"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    2884 |  # node_view_29
            %"view_29"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_51", %"val_2015") {allowzero=1}
    2885 |  # node_Transpose_1958
            %"val_2016"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.attn.Wo.weight"{...}) {perm=(1, 0)}
    2886 |  # node_linear_57
            %"linear_57"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_29", %"val_2016")
    2887 |  # node_add_58
            %"add_58"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_55", %"linear_57")
    2888 |  # node_layer_norm_29
            %"layer_norm_29"<FLOAT,[1,97,768]>, %"val_2017"<?,?>, %"val_2018"<?,?> ⬅️ ::LayerNormalization(%"add_58", %"encoder.layers.14.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2889 |  # node_Transpose_1959
            %"val_2019"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2890 |  # node_linear_58
            %"linear_58"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_29", %"val_2019")
    2891 |  # node_split_14
            %"split_14"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_58", %"val_829") {dim=-1}
    2892 |  # node_getitem_73
            %"getitem_73"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_14", %"val_6")
    2893 |  # node_getitem_74
            %"getitem_74"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_14", %"val_48")
    2894 |  # node_Constant_1960
            %"val_2020"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2895 |  # node_Div_1961
            %"val_2021"<?,?> ⬅️ ::Div(%"getitem_73", %"val_2020")
    2896 |  # node_Erf_1962
            %"val_2022"<?,?> ⬅️ ::Erf(%"val_2021")
    2897 |  # node_Constant_1963
            %"val_2023"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2898 |  # node_Add_1964
            %"val_2024"<?,?> ⬅️ ::Add(%"val_2022", %"val_2023")
    2899 |  # node_Constant_1965
            %"val_2025"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2900 |  # node_Mul_1966
            %"val_2026"<?,?> ⬅️ ::Mul(%"val_2025", %"val_2024")
    2901 |  # node_gelu_14
            %"gelu_14"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_73", %"val_2026")
    2902 |  # node_mul_118
            %"mul_118"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_14", %"getitem_74")
    2903 |  # node_clone_16
            %"clone_16"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_118")
    2904 |  # node_Transpose_1967
            %"val_2027"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2905 |  # node_linear_59
            %"linear_59"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_16", %"val_2027")
    2906 |  # node_add_59
            %"add_59"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_58", %"linear_59")
    2907 |  # node_layer_norm_30
            %"layer_norm_30"<FLOAT,[1,97,768]>, %"val_2028"<?,?>, %"val_2029"<?,?> ⬅️ ::LayerNormalization(%"add_59", %"encoder.layers.15.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2908 |  # node_Transpose_1968
            %"val_2030"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2909 |  # node_linear_60
            %"linear_60"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_30", %"val_2030")
    2910 |  # node_Cast_1969
            %"val_2031"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    2911 |  # node_view_30
            %"view_30"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_60", %"val_2031") {allowzero=1}
    2912 |  # node_transpose_52
            %"transpose_52"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_30") {perm=(0, 3, 2, 1, 4)}
    2913 |  # node_unbind_15
            %"unbind_15"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_52") {dim=2}
    2914 |  # node_getitem_75
            %"getitem_75"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_15", %"val_6")
    2915 |  # node_getitem_76
            %"getitem_76"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_15", %"val_48")
    2916 |  # node_getitem_77
            %"getitem_77"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_15", %"val_72")
    2917 |  # node_unsqueeze_102
            %"unsqueeze_102"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    2918 |  # node_unsqueeze_103
            %"unsqueeze_103"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    2919 |  # node_mul_119
            %"mul_119"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_75", %"unsqueeze_102")
    2920 |  # node_Cast_1970
            %"val_2032"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2921 |  # node_Constant_1971
            %"val_2033"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2922 |  # node_Reshape_1972
            %"val_2034"<?,?> ⬅️ ::Reshape(%"val_2032", %"val_2033") {allowzero=0}
    2923 |  # node_Cast_1973
            %"val_2035"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2924 |  # node_Constant_1974
            %"val_2036"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2925 |  # node_Reshape_1975
            %"val_2037"<?,?> ⬅️ ::Reshape(%"val_2035", %"val_2036") {allowzero=0}
    2926 |  # node_Cast_1976
            %"val_2038"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2927 |  # node_Constant_1977
            %"val_2039"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2928 |  # node_Reshape_1978
            %"val_2040"<?,?> ⬅️ ::Reshape(%"val_2038", %"val_2039") {allowzero=0}
    2929 |  # node_Constant_1979
            %"val_2041"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2930 |  # node_slice_129
            %"slice_129"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_75", %"val_2034", %"val_2037", %"val_2040", %"val_2041")
    2931 |  # node_Cast_1980
            %"val_2042"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2932 |  # node_Constant_1981
            %"val_2043"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2933 |  # node_Reshape_1982
            %"val_2044"<?,?> ⬅️ ::Reshape(%"val_2042", %"val_2043") {allowzero=0}
    2934 |  # node_Cast_1983
            %"val_2045"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2935 |  # node_Constant_1984
            %"val_2046"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2936 |  # node_Reshape_1985
            %"val_2047"<?,?> ⬅️ ::Reshape(%"val_2045", %"val_2046") {allowzero=0}
    2937 |  # node_Cast_1986
            %"val_2048"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2938 |  # node_Constant_1987
            %"val_2049"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2939 |  # node_Reshape_1988
            %"val_2050"<?,?> ⬅️ ::Reshape(%"val_2048", %"val_2049") {allowzero=0}
    2940 |  # node_Constant_1989
            %"val_2051"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2941 |  # node_slice_130
            %"slice_130"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_75", %"val_2044", %"val_2047", %"val_2050", %"val_2051")
    2942 |  # node_neg_30
            %"neg_30"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_130")
    2943 |  # node_cat_52
            %"cat_52"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_30", %"slice_129") {axis=-1}
    2944 |  # node_mul_120
            %"mul_120"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_52", %"unsqueeze_103")
    2945 |  # node_add_60
            %"add_60"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_119", %"mul_120")
    2946 |  # node_mul_121
            %"mul_121"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_76", %"unsqueeze_102")
    2947 |  # node_Cast_1990
            %"val_2052"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2948 |  # node_Constant_1991
            %"val_2053"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2949 |  # node_Reshape_1992
            %"val_2054"<?,?> ⬅️ ::Reshape(%"val_2052", %"val_2053") {allowzero=0}
    2950 |  # node_Cast_1993
            %"val_2055"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2951 |  # node_Constant_1994
            %"val_2056"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2952 |  # node_Reshape_1995
            %"val_2057"<?,?> ⬅️ ::Reshape(%"val_2055", %"val_2056") {allowzero=0}
    2953 |  # node_Cast_1996
            %"val_2058"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2954 |  # node_Constant_1997
            %"val_2059"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2955 |  # node_Reshape_1998
            %"val_2060"<?,?> ⬅️ ::Reshape(%"val_2058", %"val_2059") {allowzero=0}
    2956 |  # node_Constant_1999
            %"val_2061"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2957 |  # node_slice_131
            %"slice_131"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_76", %"val_2054", %"val_2057", %"val_2060", %"val_2061")
    2958 |  # node_Cast_2000
            %"val_2062"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    2959 |  # node_Constant_2001
            %"val_2063"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2960 |  # node_Reshape_2002
            %"val_2064"<?,?> ⬅️ ::Reshape(%"val_2062", %"val_2063") {allowzero=0}
    2961 |  # node_Cast_2003
            %"val_2065"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2962 |  # node_Constant_2004
            %"val_2066"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2963 |  # node_Reshape_2005
            %"val_2067"<?,?> ⬅️ ::Reshape(%"val_2065", %"val_2066") {allowzero=0}
    2964 |  # node_Cast_2006
            %"val_2068"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2965 |  # node_Constant_2007
            %"val_2069"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2966 |  # node_Reshape_2008
            %"val_2070"<?,?> ⬅️ ::Reshape(%"val_2068", %"val_2069") {allowzero=0}
    2967 |  # node_Constant_2009
            %"val_2071"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2968 |  # node_slice_132
            %"slice_132"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_76", %"val_2064", %"val_2067", %"val_2070", %"val_2071")
    2969 |  # node_neg_31
            %"neg_31"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_132")
    2970 |  # node_cat_53
            %"cat_53"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_31", %"slice_131") {axis=-1}
    2971 |  # node_mul_122
            %"mul_122"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_53", %"unsqueeze_103")
    2972 |  # node_add_61
            %"add_61"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_121", %"mul_122")
    2973 |  # node_Shape_2010
            %"val_2072"<?,?> ⬅️ ::Shape(%"add_60") {start=0}
    2974 |  # node_Constant_2011
            %"val_2073"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2975 |  # node_Gather_2012
            %"val_2074"<?,?> ⬅️ ::Gather(%"val_2072", %"val_2073") {axis=0}
    2976 |  # node_CastLike_2013
            %"val_2075"<?,?> ⬅️ ::CastLike(%"val_2074", %"add_60")
    2977 |  # node_Constant_2014
            %"val_2076"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2978 |  # node_CastLike_2015
            %"val_2077"<?,?> ⬅️ ::CastLike(%"val_2076", %"add_60")
    2979 |  # node_Sqrt_2016
            %"val_2078"<?,?> ⬅️ ::Sqrt(%"val_2075")
    2980 |  # node_Div_2017
            %"val_2079"<?,?> ⬅️ ::Div(%"val_2077", %"val_2078")
    2981 |  # node_CastLike_2018
            %"val_2080"<?,?> ⬅️ ::CastLike(%"val_2079", %"add_60")
    2982 |  # node_Shape_2019
            %"val_2081"<?,?> ⬅️ ::Shape(%"add_61") {start=0}
    2983 |  # node_Constant_2020
            %"val_2082"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2984 |  # node_Slice_2021
            %"val_2083"<?,?> ⬅️ ::Slice(%"val_2081", %"val_804", %"val_2082")
    2985 |  # node_Slice_2022
            %"val_2084"<?,?> ⬅️ ::Slice(%"val_2081", %"val_806", %"val_804")
    2986 |  # node_Constant_2023
            %"val_2085"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2987 |  # node_Slice_2024
            %"val_2086"<?,?> ⬅️ ::Slice(%"val_2081", %"val_2085", %"val_806")
    2988 |  # node_Constant_2025
            %"val_2087"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2989 |  # node_Concat_2026
            %"val_2088"<?,?> ⬅️ ::Concat(%"val_2087", %"val_2084", %"val_2083") {axis=0}
    2990 |  # node_Reshape_2027
            %"val_2089"<?,?> ⬅️ ::Reshape(%"add_61", %"val_2088") {allowzero=0}
    2991 |  # node_Transpose_2028
            %"val_2090"<?,?> ⬅️ ::Transpose(%"val_2089") {perm=(0, 2, 1)}
    2992 |  # node_Concat_2029
            %"val_2091"<?,?> ⬅️ ::Concat(%"val_2086", %"val_2083", %"val_2084") {axis=0}
    2993 |  # node_Reshape_2030
            %"val_2092"<?,?> ⬅️ ::Reshape(%"val_2090", %"val_2091") {allowzero=0}
    2994 |  # node_Sqrt_2031
            %"val_2093"<?,?> ⬅️ ::Sqrt(%"val_2080")
    2995 |  # node_Mul_2032
            %"val_2094"<?,?> ⬅️ ::Mul(%"add_60", %"val_2093")
    2996 |  # node_Sqrt_2033
            %"val_2095"<?,?> ⬅️ ::Sqrt(%"val_2080")
    2997 |  # node_Mul_2034
            %"val_2096"<?,?> ⬅️ ::Mul(%"val_2092", %"val_2095")
    2998 |  # node_MatMul_2035
            %"val_2097"<?,?> ⬅️ ::MatMul(%"val_2094", %"val_2096")
    2999 |  # node_Add_2036
            %"val_2098"<?,?> ⬅️ ::Add(%"val_2097", %"masked_fill")
    3000 |  # node_Softmax_2037
            %"val_2099"<?,?> ⬅️ ::Softmax(%"val_2098") {axis=-1}
    3001 |  # node_scaled_dot_product_attention_15
            %"scaled_dot_product_attention_15"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2099", %"getitem_77")
    3002 |  # node_transpose_53
            %"transpose_53"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_15") {perm=(0, 2, 1, 3)}
    3003 |  # node_Cast_2038
            %"val_2100"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3004 |  # node_view_31
            %"view_31"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_53", %"val_2100") {allowzero=1}
    3005 |  # node_Transpose_2039
            %"val_2101"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.attn.Wo.weight"{...}) {perm=(1, 0)}
    3006 |  # node_linear_61
            %"linear_61"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_31", %"val_2101")
    3007 |  # node_add_62
            %"add_62"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_59", %"linear_61")
    3008 |  # node_layer_norm_31
            %"layer_norm_31"<FLOAT,[1,97,768]>, %"val_2102"<?,?>, %"val_2103"<?,?> ⬅️ ::LayerNormalization(%"add_62", %"encoder.layers.15.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3009 |  # node_Transpose_2040
            %"val_2104"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3010 |  # node_linear_62
            %"linear_62"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_31", %"val_2104")
    3011 |  # node_split_15
            %"split_15"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_62", %"val_829") {dim=-1}
    3012 |  # node_getitem_78
            %"getitem_78"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_15", %"val_6")
    3013 |  # node_getitem_79
            %"getitem_79"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_15", %"val_48")
    3014 |  # node_Constant_2041
            %"val_2105"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3015 |  # node_Div_2042
            %"val_2106"<?,?> ⬅️ ::Div(%"getitem_78", %"val_2105")
    3016 |  # node_Erf_2043
            %"val_2107"<?,?> ⬅️ ::Erf(%"val_2106")
    3017 |  # node_Constant_2044
            %"val_2108"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3018 |  # node_Add_2045
            %"val_2109"<?,?> ⬅️ ::Add(%"val_2107", %"val_2108")
    3019 |  # node_Constant_2046
            %"val_2110"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3020 |  # node_Mul_2047
            %"val_2111"<?,?> ⬅️ ::Mul(%"val_2110", %"val_2109")
    3021 |  # node_gelu_15
            %"gelu_15"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_78", %"val_2111")
    3022 |  # node_mul_123
            %"mul_123"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_15", %"getitem_79")
    3023 |  # node_clone_17
            %"clone_17"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_123")
    3024 |  # node_Transpose_2048
            %"val_2112"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3025 |  # node_linear_63
            %"linear_63"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_17", %"val_2112")
    3026 |  # node_add_63
            %"add_63"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_62", %"linear_63")
    3027 |  # node_layer_norm_32
            %"layer_norm_32"<FLOAT,[1,97,768]>, %"val_2113"<?,?>, %"val_2114"<?,?> ⬅️ ::LayerNormalization(%"add_63", %"encoder.layers.16.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3028 |  # node_Transpose_2049
            %"val_2115"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3029 |  # node_linear_64
            %"linear_64"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_32", %"val_2115")
    3030 |  # node_Cast_2050
            %"val_2116"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    3031 |  # node_view_32
            %"view_32"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_64", %"val_2116") {allowzero=1}
    3032 |  # node_transpose_54
            %"transpose_54"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_32") {perm=(0, 3, 2, 1, 4)}
    3033 |  # node_unbind_16
            %"unbind_16"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_54") {dim=2}
    3034 |  # node_getitem_80
            %"getitem_80"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_16", %"val_6")
    3035 |  # node_getitem_81
            %"getitem_81"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_16", %"val_48")
    3036 |  # node_getitem_82
            %"getitem_82"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_16", %"val_72")
    3037 |  # node_unsqueeze_104
            %"unsqueeze_104"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3038 |  # node_unsqueeze_105
            %"unsqueeze_105"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3039 |  # node_mul_124
            %"mul_124"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_80", %"unsqueeze_104")
    3040 |  # node_Cast_2051
            %"val_2117"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3041 |  # node_Constant_2052
            %"val_2118"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3042 |  # node_Reshape_2053
            %"val_2119"<?,?> ⬅️ ::Reshape(%"val_2117", %"val_2118") {allowzero=0}
    3043 |  # node_Cast_2054
            %"val_2120"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3044 |  # node_Constant_2055
            %"val_2121"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3045 |  # node_Reshape_2056
            %"val_2122"<?,?> ⬅️ ::Reshape(%"val_2120", %"val_2121") {allowzero=0}
    3046 |  # node_Cast_2057
            %"val_2123"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3047 |  # node_Constant_2058
            %"val_2124"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3048 |  # node_Reshape_2059
            %"val_2125"<?,?> ⬅️ ::Reshape(%"val_2123", %"val_2124") {allowzero=0}
    3049 |  # node_Constant_2060
            %"val_2126"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3050 |  # node_slice_133
            %"slice_133"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_80", %"val_2119", %"val_2122", %"val_2125", %"val_2126")
    3051 |  # node_Cast_2061
            %"val_2127"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3052 |  # node_Constant_2062
            %"val_2128"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3053 |  # node_Reshape_2063
            %"val_2129"<?,?> ⬅️ ::Reshape(%"val_2127", %"val_2128") {allowzero=0}
    3054 |  # node_Cast_2064
            %"val_2130"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3055 |  # node_Constant_2065
            %"val_2131"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3056 |  # node_Reshape_2066
            %"val_2132"<?,?> ⬅️ ::Reshape(%"val_2130", %"val_2131") {allowzero=0}
    3057 |  # node_Cast_2067
            %"val_2133"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3058 |  # node_Constant_2068
            %"val_2134"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3059 |  # node_Reshape_2069
            %"val_2135"<?,?> ⬅️ ::Reshape(%"val_2133", %"val_2134") {allowzero=0}
    3060 |  # node_Constant_2070
            %"val_2136"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3061 |  # node_slice_134
            %"slice_134"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_80", %"val_2129", %"val_2132", %"val_2135", %"val_2136")
    3062 |  # node_neg_32
            %"neg_32"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_134")
    3063 |  # node_cat_54
            %"cat_54"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_32", %"slice_133") {axis=-1}
    3064 |  # node_mul_125
            %"mul_125"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_54", %"unsqueeze_105")
    3065 |  # node_add_64
            %"add_64"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_124", %"mul_125")
    3066 |  # node_mul_126
            %"mul_126"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_81", %"unsqueeze_104")
    3067 |  # node_Cast_2071
            %"val_2137"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3068 |  # node_Constant_2072
            %"val_2138"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3069 |  # node_Reshape_2073
            %"val_2139"<?,?> ⬅️ ::Reshape(%"val_2137", %"val_2138") {allowzero=0}
    3070 |  # node_Cast_2074
            %"val_2140"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3071 |  # node_Constant_2075
            %"val_2141"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3072 |  # node_Reshape_2076
            %"val_2142"<?,?> ⬅️ ::Reshape(%"val_2140", %"val_2141") {allowzero=0}
    3073 |  # node_Cast_2077
            %"val_2143"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3074 |  # node_Constant_2078
            %"val_2144"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3075 |  # node_Reshape_2079
            %"val_2145"<?,?> ⬅️ ::Reshape(%"val_2143", %"val_2144") {allowzero=0}
    3076 |  # node_Constant_2080
            %"val_2146"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3077 |  # node_slice_135
            %"slice_135"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_81", %"val_2139", %"val_2142", %"val_2145", %"val_2146")
    3078 |  # node_Cast_2081
            %"val_2147"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3079 |  # node_Constant_2082
            %"val_2148"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3080 |  # node_Reshape_2083
            %"val_2149"<?,?> ⬅️ ::Reshape(%"val_2147", %"val_2148") {allowzero=0}
    3081 |  # node_Cast_2084
            %"val_2150"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3082 |  # node_Constant_2085
            %"val_2151"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3083 |  # node_Reshape_2086
            %"val_2152"<?,?> ⬅️ ::Reshape(%"val_2150", %"val_2151") {allowzero=0}
    3084 |  # node_Cast_2087
            %"val_2153"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3085 |  # node_Constant_2088
            %"val_2154"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3086 |  # node_Reshape_2089
            %"val_2155"<?,?> ⬅️ ::Reshape(%"val_2153", %"val_2154") {allowzero=0}
    3087 |  # node_Constant_2090
            %"val_2156"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3088 |  # node_slice_136
            %"slice_136"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_81", %"val_2149", %"val_2152", %"val_2155", %"val_2156")
    3089 |  # node_neg_33
            %"neg_33"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_136")
    3090 |  # node_cat_55
            %"cat_55"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_33", %"slice_135") {axis=-1}
    3091 |  # node_mul_127
            %"mul_127"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_55", %"unsqueeze_105")
    3092 |  # node_add_65
            %"add_65"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_126", %"mul_127")
    3093 |  # node_Shape_2091
            %"val_2157"<?,?> ⬅️ ::Shape(%"add_64") {start=0}
    3094 |  # node_Constant_2092
            %"val_2158"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3095 |  # node_Gather_2093
            %"val_2159"<?,?> ⬅️ ::Gather(%"val_2157", %"val_2158") {axis=0}
    3096 |  # node_CastLike_2094
            %"val_2160"<?,?> ⬅️ ::CastLike(%"val_2159", %"add_64")
    3097 |  # node_Constant_2095
            %"val_2161"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3098 |  # node_CastLike_2096
            %"val_2162"<?,?> ⬅️ ::CastLike(%"val_2161", %"add_64")
    3099 |  # node_Sqrt_2097
            %"val_2163"<?,?> ⬅️ ::Sqrt(%"val_2160")
    3100 |  # node_Div_2098
            %"val_2164"<?,?> ⬅️ ::Div(%"val_2162", %"val_2163")
    3101 |  # node_CastLike_2099
            %"val_2165"<?,?> ⬅️ ::CastLike(%"val_2164", %"add_64")
    3102 |  # node_Shape_2100
            %"val_2166"<?,?> ⬅️ ::Shape(%"add_65") {start=0}
    3103 |  # node_Constant_2101
            %"val_2167"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3104 |  # node_Slice_2102
            %"val_2168"<?,?> ⬅️ ::Slice(%"val_2166", %"val_804", %"val_2167")
    3105 |  # node_Slice_2103
            %"val_2169"<?,?> ⬅️ ::Slice(%"val_2166", %"val_806", %"val_804")
    3106 |  # node_Constant_2104
            %"val_2170"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3107 |  # node_Slice_2105
            %"val_2171"<?,?> ⬅️ ::Slice(%"val_2166", %"val_2170", %"val_806")
    3108 |  # node_Constant_2106
            %"val_2172"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3109 |  # node_Concat_2107
            %"val_2173"<?,?> ⬅️ ::Concat(%"val_2172", %"val_2169", %"val_2168") {axis=0}
    3110 |  # node_Reshape_2108
            %"val_2174"<?,?> ⬅️ ::Reshape(%"add_65", %"val_2173") {allowzero=0}
    3111 |  # node_Transpose_2109
            %"val_2175"<?,?> ⬅️ ::Transpose(%"val_2174") {perm=(0, 2, 1)}
    3112 |  # node_Concat_2110
            %"val_2176"<?,?> ⬅️ ::Concat(%"val_2171", %"val_2168", %"val_2169") {axis=0}
    3113 |  # node_Reshape_2111
            %"val_2177"<?,?> ⬅️ ::Reshape(%"val_2175", %"val_2176") {allowzero=0}
    3114 |  # node_Sqrt_2112
            %"val_2178"<?,?> ⬅️ ::Sqrt(%"val_2165")
    3115 |  # node_Mul_2113
            %"val_2179"<?,?> ⬅️ ::Mul(%"add_64", %"val_2178")
    3116 |  # node_Sqrt_2114
            %"val_2180"<?,?> ⬅️ ::Sqrt(%"val_2165")
    3117 |  # node_Mul_2115
            %"val_2181"<?,?> ⬅️ ::Mul(%"val_2177", %"val_2180")
    3118 |  # node_MatMul_2116
            %"val_2182"<?,?> ⬅️ ::MatMul(%"val_2179", %"val_2181")
    3119 |  # node_Add_2117
            %"val_2183"<?,?> ⬅️ ::Add(%"val_2182", %"masked_fill_1")
    3120 |  # node_Softmax_2118
            %"val_2184"<?,?> ⬅️ ::Softmax(%"val_2183") {axis=-1}
    3121 |  # node_scaled_dot_product_attention_16
            %"scaled_dot_product_attention_16"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2184", %"getitem_82")
    3122 |  # node_transpose_55
            %"transpose_55"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_16") {perm=(0, 2, 1, 3)}
    3123 |  # node_Cast_2119
            %"val_2185"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3124 |  # node_view_33
            %"view_33"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_55", %"val_2185") {allowzero=1}
    3125 |  # node_Transpose_2120
            %"val_2186"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.attn.Wo.weight"{...}) {perm=(1, 0)}
    3126 |  # node_linear_65
            %"linear_65"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_33", %"val_2186")
    3127 |  # node_add_66
            %"add_66"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_63", %"linear_65")
    3128 |  # node_layer_norm_33
            %"layer_norm_33"<FLOAT,[1,97,768]>, %"val_2187"<?,?>, %"val_2188"<?,?> ⬅️ ::LayerNormalization(%"add_66", %"encoder.layers.16.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3129 |  # node_Transpose_2121
            %"val_2189"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3130 |  # node_linear_66
            %"linear_66"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_33", %"val_2189")
    3131 |  # node_split_16
            %"split_16"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_66", %"val_829") {dim=-1}
    3132 |  # node_getitem_83
            %"getitem_83"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_16", %"val_6")
    3133 |  # node_getitem_84
            %"getitem_84"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_16", %"val_48")
    3134 |  # node_Constant_2122
            %"val_2190"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3135 |  # node_Div_2123
            %"val_2191"<?,?> ⬅️ ::Div(%"getitem_83", %"val_2190")
    3136 |  # node_Erf_2124
            %"val_2192"<?,?> ⬅️ ::Erf(%"val_2191")
    3137 |  # node_Constant_2125
            %"val_2193"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3138 |  # node_Add_2126
            %"val_2194"<?,?> ⬅️ ::Add(%"val_2192", %"val_2193")
    3139 |  # node_Constant_2127
            %"val_2195"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3140 |  # node_Mul_2128
            %"val_2196"<?,?> ⬅️ ::Mul(%"val_2195", %"val_2194")
    3141 |  # node_gelu_16
            %"gelu_16"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_83", %"val_2196")
    3142 |  # node_mul_128
            %"mul_128"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_16", %"getitem_84")
    3143 |  # node_clone_18
            %"clone_18"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_128")
    3144 |  # node_Transpose_2129
            %"val_2197"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3145 |  # node_linear_67
            %"linear_67"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_18", %"val_2197")
    3146 |  # node_add_67
            %"add_67"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_66", %"linear_67")
    3147 |  # node_layer_norm_34
            %"layer_norm_34"<FLOAT,[1,97,768]>, %"val_2198"<?,?>, %"val_2199"<?,?> ⬅️ ::LayerNormalization(%"add_67", %"encoder.layers.17.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3148 |  # node_Transpose_2130
            %"val_2200"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3149 |  # node_linear_68
            %"linear_68"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_34", %"val_2200")
    3150 |  # node_Cast_2131
            %"val_2201"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    3151 |  # node_view_34
            %"view_34"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_68", %"val_2201") {allowzero=1}
    3152 |  # node_transpose_56
            %"transpose_56"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_34") {perm=(0, 3, 2, 1, 4)}
    3153 |  # node_unbind_17
            %"unbind_17"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_56") {dim=2}
    3154 |  # node_getitem_85
            %"getitem_85"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_17", %"val_6")
    3155 |  # node_getitem_86
            %"getitem_86"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_17", %"val_48")
    3156 |  # node_getitem_87
            %"getitem_87"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_17", %"val_72")
    3157 |  # node_unsqueeze_106
            %"unsqueeze_106"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3158 |  # node_unsqueeze_107
            %"unsqueeze_107"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3159 |  # node_mul_129
            %"mul_129"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_85", %"unsqueeze_106")
    3160 |  # node_Cast_2132
            %"val_2202"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3161 |  # node_Constant_2133
            %"val_2203"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3162 |  # node_Reshape_2134
            %"val_2204"<?,?> ⬅️ ::Reshape(%"val_2202", %"val_2203") {allowzero=0}
    3163 |  # node_Cast_2135
            %"val_2205"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3164 |  # node_Constant_2136
            %"val_2206"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3165 |  # node_Reshape_2137
            %"val_2207"<?,?> ⬅️ ::Reshape(%"val_2205", %"val_2206") {allowzero=0}
    3166 |  # node_Cast_2138
            %"val_2208"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3167 |  # node_Constant_2139
            %"val_2209"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3168 |  # node_Reshape_2140
            %"val_2210"<?,?> ⬅️ ::Reshape(%"val_2208", %"val_2209") {allowzero=0}
    3169 |  # node_Constant_2141
            %"val_2211"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3170 |  # node_slice_137
            %"slice_137"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_85", %"val_2204", %"val_2207", %"val_2210", %"val_2211")
    3171 |  # node_Cast_2142
            %"val_2212"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3172 |  # node_Constant_2143
            %"val_2213"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3173 |  # node_Reshape_2144
            %"val_2214"<?,?> ⬅️ ::Reshape(%"val_2212", %"val_2213") {allowzero=0}
    3174 |  # node_Cast_2145
            %"val_2215"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3175 |  # node_Constant_2146
            %"val_2216"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3176 |  # node_Reshape_2147
            %"val_2217"<?,?> ⬅️ ::Reshape(%"val_2215", %"val_2216") {allowzero=0}
    3177 |  # node_Cast_2148
            %"val_2218"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3178 |  # node_Constant_2149
            %"val_2219"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3179 |  # node_Reshape_2150
            %"val_2220"<?,?> ⬅️ ::Reshape(%"val_2218", %"val_2219") {allowzero=0}
    3180 |  # node_Constant_2151
            %"val_2221"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3181 |  # node_slice_138
            %"slice_138"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_85", %"val_2214", %"val_2217", %"val_2220", %"val_2221")
    3182 |  # node_neg_34
            %"neg_34"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_138")
    3183 |  # node_cat_56
            %"cat_56"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_34", %"slice_137") {axis=-1}
    3184 |  # node_mul_130
            %"mul_130"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_56", %"unsqueeze_107")
    3185 |  # node_add_68
            %"add_68"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_129", %"mul_130")
    3186 |  # node_mul_131
            %"mul_131"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_86", %"unsqueeze_106")
    3187 |  # node_Cast_2152
            %"val_2222"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3188 |  # node_Constant_2153
            %"val_2223"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3189 |  # node_Reshape_2154
            %"val_2224"<?,?> ⬅️ ::Reshape(%"val_2222", %"val_2223") {allowzero=0}
    3190 |  # node_Cast_2155
            %"val_2225"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3191 |  # node_Constant_2156
            %"val_2226"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3192 |  # node_Reshape_2157
            %"val_2227"<?,?> ⬅️ ::Reshape(%"val_2225", %"val_2226") {allowzero=0}
    3193 |  # node_Cast_2158
            %"val_2228"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3194 |  # node_Constant_2159
            %"val_2229"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3195 |  # node_Reshape_2160
            %"val_2230"<?,?> ⬅️ ::Reshape(%"val_2228", %"val_2229") {allowzero=0}
    3196 |  # node_Constant_2161
            %"val_2231"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3197 |  # node_slice_139
            %"slice_139"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_86", %"val_2224", %"val_2227", %"val_2230", %"val_2231")
    3198 |  # node_Cast_2162
            %"val_2232"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3199 |  # node_Constant_2163
            %"val_2233"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3200 |  # node_Reshape_2164
            %"val_2234"<?,?> ⬅️ ::Reshape(%"val_2232", %"val_2233") {allowzero=0}
    3201 |  # node_Cast_2165
            %"val_2235"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3202 |  # node_Constant_2166
            %"val_2236"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3203 |  # node_Reshape_2167
            %"val_2237"<?,?> ⬅️ ::Reshape(%"val_2235", %"val_2236") {allowzero=0}
    3204 |  # node_Cast_2168
            %"val_2238"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3205 |  # node_Constant_2169
            %"val_2239"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3206 |  # node_Reshape_2170
            %"val_2240"<?,?> ⬅️ ::Reshape(%"val_2238", %"val_2239") {allowzero=0}
    3207 |  # node_Constant_2171
            %"val_2241"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3208 |  # node_slice_140
            %"slice_140"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_86", %"val_2234", %"val_2237", %"val_2240", %"val_2241")
    3209 |  # node_neg_35
            %"neg_35"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_140")
    3210 |  # node_cat_57
            %"cat_57"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_35", %"slice_139") {axis=-1}
    3211 |  # node_mul_132
            %"mul_132"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_57", %"unsqueeze_107")
    3212 |  # node_add_69
            %"add_69"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_131", %"mul_132")
    3213 |  # node_Shape_2172
            %"val_2242"<?,?> ⬅️ ::Shape(%"add_68") {start=0}
    3214 |  # node_Constant_2173
            %"val_2243"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3215 |  # node_Gather_2174
            %"val_2244"<?,?> ⬅️ ::Gather(%"val_2242", %"val_2243") {axis=0}
    3216 |  # node_CastLike_2175
            %"val_2245"<?,?> ⬅️ ::CastLike(%"val_2244", %"add_68")
    3217 |  # node_Constant_2176
            %"val_2246"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3218 |  # node_CastLike_2177
            %"val_2247"<?,?> ⬅️ ::CastLike(%"val_2246", %"add_68")
    3219 |  # node_Sqrt_2178
            %"val_2248"<?,?> ⬅️ ::Sqrt(%"val_2245")
    3220 |  # node_Div_2179
            %"val_2249"<?,?> ⬅️ ::Div(%"val_2247", %"val_2248")
    3221 |  # node_CastLike_2180
            %"val_2250"<?,?> ⬅️ ::CastLike(%"val_2249", %"add_68")
    3222 |  # node_Shape_2181
            %"val_2251"<?,?> ⬅️ ::Shape(%"add_69") {start=0}
    3223 |  # node_Constant_2182
            %"val_2252"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3224 |  # node_Slice_2183
            %"val_2253"<?,?> ⬅️ ::Slice(%"val_2251", %"val_804", %"val_2252")
    3225 |  # node_Slice_2184
            %"val_2254"<?,?> ⬅️ ::Slice(%"val_2251", %"val_806", %"val_804")
    3226 |  # node_Constant_2185
            %"val_2255"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3227 |  # node_Slice_2186
            %"val_2256"<?,?> ⬅️ ::Slice(%"val_2251", %"val_2255", %"val_806")
    3228 |  # node_Constant_2187
            %"val_2257"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3229 |  # node_Concat_2188
            %"val_2258"<?,?> ⬅️ ::Concat(%"val_2257", %"val_2254", %"val_2253") {axis=0}
    3230 |  # node_Reshape_2189
            %"val_2259"<?,?> ⬅️ ::Reshape(%"add_69", %"val_2258") {allowzero=0}
    3231 |  # node_Transpose_2190
            %"val_2260"<?,?> ⬅️ ::Transpose(%"val_2259") {perm=(0, 2, 1)}
    3232 |  # node_Concat_2191
            %"val_2261"<?,?> ⬅️ ::Concat(%"val_2256", %"val_2253", %"val_2254") {axis=0}
    3233 |  # node_Reshape_2192
            %"val_2262"<?,?> ⬅️ ::Reshape(%"val_2260", %"val_2261") {allowzero=0}
    3234 |  # node_Sqrt_2193
            %"val_2263"<?,?> ⬅️ ::Sqrt(%"val_2250")
    3235 |  # node_Mul_2194
            %"val_2264"<?,?> ⬅️ ::Mul(%"add_68", %"val_2263")
    3236 |  # node_Sqrt_2195
            %"val_2265"<?,?> ⬅️ ::Sqrt(%"val_2250")
    3237 |  # node_Mul_2196
            %"val_2266"<?,?> ⬅️ ::Mul(%"val_2262", %"val_2265")
    3238 |  # node_MatMul_2197
            %"val_2267"<?,?> ⬅️ ::MatMul(%"val_2264", %"val_2266")
    3239 |  # node_Add_2198
            %"val_2268"<?,?> ⬅️ ::Add(%"val_2267", %"masked_fill_1")
    3240 |  # node_Softmax_2199
            %"val_2269"<?,?> ⬅️ ::Softmax(%"val_2268") {axis=-1}
    3241 |  # node_scaled_dot_product_attention_17
            %"scaled_dot_product_attention_17"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2269", %"getitem_87")
    3242 |  # node_transpose_57
            %"transpose_57"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_17") {perm=(0, 2, 1, 3)}
    3243 |  # node_Cast_2200
            %"val_2270"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3244 |  # node_view_35
            %"view_35"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_57", %"val_2270") {allowzero=1}
    3245 |  # node_Transpose_2201
            %"val_2271"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.attn.Wo.weight"{...}) {perm=(1, 0)}
    3246 |  # node_linear_69
            %"linear_69"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_35", %"val_2271")
    3247 |  # node_add_70
            %"add_70"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_67", %"linear_69")
    3248 |  # node_layer_norm_35
            %"layer_norm_35"<FLOAT,[1,97,768]>, %"val_2272"<?,?>, %"val_2273"<?,?> ⬅️ ::LayerNormalization(%"add_70", %"encoder.layers.17.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3249 |  # node_Transpose_2202
            %"val_2274"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3250 |  # node_linear_70
            %"linear_70"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_35", %"val_2274")
    3251 |  # node_split_17
            %"split_17"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_70", %"val_829") {dim=-1}
    3252 |  # node_getitem_88
            %"getitem_88"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_17", %"val_6")
    3253 |  # node_getitem_89
            %"getitem_89"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_17", %"val_48")
    3254 |  # node_Constant_2203
            %"val_2275"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3255 |  # node_Div_2204
            %"val_2276"<?,?> ⬅️ ::Div(%"getitem_88", %"val_2275")
    3256 |  # node_Erf_2205
            %"val_2277"<?,?> ⬅️ ::Erf(%"val_2276")
    3257 |  # node_Constant_2206
            %"val_2278"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3258 |  # node_Add_2207
            %"val_2279"<?,?> ⬅️ ::Add(%"val_2277", %"val_2278")
    3259 |  # node_Constant_2208
            %"val_2280"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3260 |  # node_Mul_2209
            %"val_2281"<?,?> ⬅️ ::Mul(%"val_2280", %"val_2279")
    3261 |  # node_gelu_17
            %"gelu_17"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_88", %"val_2281")
    3262 |  # node_mul_133
            %"mul_133"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_17", %"getitem_89")
    3263 |  # node_clone_19
            %"clone_19"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_133")
    3264 |  # node_Transpose_2210
            %"val_2282"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3265 |  # node_linear_71
            %"linear_71"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_19", %"val_2282")
    3266 |  # node_add_71
            %"add_71"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_70", %"linear_71")
    3267 |  # node_layer_norm_36
            %"layer_norm_36"<FLOAT,[1,97,768]>, %"val_2283"<?,?>, %"val_2284"<?,?> ⬅️ ::LayerNormalization(%"add_71", %"encoder.layers.18.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3268 |  # node_Transpose_2211
            %"val_2285"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3269 |  # node_linear_72
            %"linear_72"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_36", %"val_2285")
    3270 |  # node_Cast_2212
            %"val_2286"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    3271 |  # node_view_36
            %"view_36"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_72", %"val_2286") {allowzero=1}
    3272 |  # node_transpose_58
            %"transpose_58"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_36") {perm=(0, 3, 2, 1, 4)}
    3273 |  # node_unbind_18
            %"unbind_18"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_58") {dim=2}
    3274 |  # node_getitem_90
            %"getitem_90"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_18", %"val_6")
    3275 |  # node_getitem_91
            %"getitem_91"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_18", %"val_48")
    3276 |  # node_getitem_92
            %"getitem_92"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_18", %"val_72")
    3277 |  # node_unsqueeze_108
            %"unsqueeze_108"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    3278 |  # node_unsqueeze_109
            %"unsqueeze_109"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    3279 |  # node_mul_134
            %"mul_134"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_90", %"unsqueeze_108")
    3280 |  # node_Cast_2213
            %"val_2287"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3281 |  # node_Constant_2214
            %"val_2288"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3282 |  # node_Reshape_2215
            %"val_2289"<?,?> ⬅️ ::Reshape(%"val_2287", %"val_2288") {allowzero=0}
    3283 |  # node_Cast_2216
            %"val_2290"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3284 |  # node_Constant_2217
            %"val_2291"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3285 |  # node_Reshape_2218
            %"val_2292"<?,?> ⬅️ ::Reshape(%"val_2290", %"val_2291") {allowzero=0}
    3286 |  # node_Cast_2219
            %"val_2293"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3287 |  # node_Constant_2220
            %"val_2294"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3288 |  # node_Reshape_2221
            %"val_2295"<?,?> ⬅️ ::Reshape(%"val_2293", %"val_2294") {allowzero=0}
    3289 |  # node_Constant_2222
            %"val_2296"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3290 |  # node_slice_141
            %"slice_141"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_90", %"val_2289", %"val_2292", %"val_2295", %"val_2296")
    3291 |  # node_Cast_2223
            %"val_2297"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3292 |  # node_Constant_2224
            %"val_2298"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3293 |  # node_Reshape_2225
            %"val_2299"<?,?> ⬅️ ::Reshape(%"val_2297", %"val_2298") {allowzero=0}
    3294 |  # node_Cast_2226
            %"val_2300"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3295 |  # node_Constant_2227
            %"val_2301"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3296 |  # node_Reshape_2228
            %"val_2302"<?,?> ⬅️ ::Reshape(%"val_2300", %"val_2301") {allowzero=0}
    3297 |  # node_Cast_2229
            %"val_2303"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3298 |  # node_Constant_2230
            %"val_2304"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3299 |  # node_Reshape_2231
            %"val_2305"<?,?> ⬅️ ::Reshape(%"val_2303", %"val_2304") {allowzero=0}
    3300 |  # node_Constant_2232
            %"val_2306"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3301 |  # node_slice_142
            %"slice_142"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_90", %"val_2299", %"val_2302", %"val_2305", %"val_2306")
    3302 |  # node_neg_36
            %"neg_36"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_142")
    3303 |  # node_cat_58
            %"cat_58"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_36", %"slice_141") {axis=-1}
    3304 |  # node_mul_135
            %"mul_135"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_58", %"unsqueeze_109")
    3305 |  # node_add_72
            %"add_72"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_134", %"mul_135")
    3306 |  # node_mul_136
            %"mul_136"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_91", %"unsqueeze_108")
    3307 |  # node_Cast_2233
            %"val_2307"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3308 |  # node_Constant_2234
            %"val_2308"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3309 |  # node_Reshape_2235
            %"val_2309"<?,?> ⬅️ ::Reshape(%"val_2307", %"val_2308") {allowzero=0}
    3310 |  # node_Cast_2236
            %"val_2310"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3311 |  # node_Constant_2237
            %"val_2311"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3312 |  # node_Reshape_2238
            %"val_2312"<?,?> ⬅️ ::Reshape(%"val_2310", %"val_2311") {allowzero=0}
    3313 |  # node_Cast_2239
            %"val_2313"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3314 |  # node_Constant_2240
            %"val_2314"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3315 |  # node_Reshape_2241
            %"val_2315"<?,?> ⬅️ ::Reshape(%"val_2313", %"val_2314") {allowzero=0}
    3316 |  # node_Constant_2242
            %"val_2316"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3317 |  # node_slice_143
            %"slice_143"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_91", %"val_2309", %"val_2312", %"val_2315", %"val_2316")
    3318 |  # node_Cast_2243
            %"val_2317"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3319 |  # node_Constant_2244
            %"val_2318"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3320 |  # node_Reshape_2245
            %"val_2319"<?,?> ⬅️ ::Reshape(%"val_2317", %"val_2318") {allowzero=0}
    3321 |  # node_Cast_2246
            %"val_2320"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3322 |  # node_Constant_2247
            %"val_2321"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3323 |  # node_Reshape_2248
            %"val_2322"<?,?> ⬅️ ::Reshape(%"val_2320", %"val_2321") {allowzero=0}
    3324 |  # node_Cast_2249
            %"val_2323"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3325 |  # node_Constant_2250
            %"val_2324"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3326 |  # node_Reshape_2251
            %"val_2325"<?,?> ⬅️ ::Reshape(%"val_2323", %"val_2324") {allowzero=0}
    3327 |  # node_Constant_2252
            %"val_2326"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3328 |  # node_slice_144
            %"slice_144"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_91", %"val_2319", %"val_2322", %"val_2325", %"val_2326")
    3329 |  # node_neg_37
            %"neg_37"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_144")
    3330 |  # node_cat_59
            %"cat_59"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_37", %"slice_143") {axis=-1}
    3331 |  # node_mul_137
            %"mul_137"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_59", %"unsqueeze_109")
    3332 |  # node_add_73
            %"add_73"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_136", %"mul_137")
    3333 |  # node_Shape_2253
            %"val_2327"<?,?> ⬅️ ::Shape(%"add_72") {start=0}
    3334 |  # node_Constant_2254
            %"val_2328"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3335 |  # node_Gather_2255
            %"val_2329"<?,?> ⬅️ ::Gather(%"val_2327", %"val_2328") {axis=0}
    3336 |  # node_CastLike_2256
            %"val_2330"<?,?> ⬅️ ::CastLike(%"val_2329", %"add_72")
    3337 |  # node_Constant_2257
            %"val_2331"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3338 |  # node_CastLike_2258
            %"val_2332"<?,?> ⬅️ ::CastLike(%"val_2331", %"add_72")
    3339 |  # node_Sqrt_2259
            %"val_2333"<?,?> ⬅️ ::Sqrt(%"val_2330")
    3340 |  # node_Div_2260
            %"val_2334"<?,?> ⬅️ ::Div(%"val_2332", %"val_2333")
    3341 |  # node_CastLike_2261
            %"val_2335"<?,?> ⬅️ ::CastLike(%"val_2334", %"add_72")
    3342 |  # node_Shape_2262
            %"val_2336"<?,?> ⬅️ ::Shape(%"add_73") {start=0}
    3343 |  # node_Constant_2263
            %"val_2337"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3344 |  # node_Slice_2264
            %"val_2338"<?,?> ⬅️ ::Slice(%"val_2336", %"val_804", %"val_2337")
    3345 |  # node_Slice_2265
            %"val_2339"<?,?> ⬅️ ::Slice(%"val_2336", %"val_806", %"val_804")
    3346 |  # node_Constant_2266
            %"val_2340"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3347 |  # node_Slice_2267
            %"val_2341"<?,?> ⬅️ ::Slice(%"val_2336", %"val_2340", %"val_806")
    3348 |  # node_Constant_2268
            %"val_2342"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3349 |  # node_Concat_2269
            %"val_2343"<?,?> ⬅️ ::Concat(%"val_2342", %"val_2339", %"val_2338") {axis=0}
    3350 |  # node_Reshape_2270
            %"val_2344"<?,?> ⬅️ ::Reshape(%"add_73", %"val_2343") {allowzero=0}
    3351 |  # node_Transpose_2271
            %"val_2345"<?,?> ⬅️ ::Transpose(%"val_2344") {perm=(0, 2, 1)}
    3352 |  # node_Concat_2272
            %"val_2346"<?,?> ⬅️ ::Concat(%"val_2341", %"val_2338", %"val_2339") {axis=0}
    3353 |  # node_Reshape_2273
            %"val_2347"<?,?> ⬅️ ::Reshape(%"val_2345", %"val_2346") {allowzero=0}
    3354 |  # node_Sqrt_2274
            %"val_2348"<?,?> ⬅️ ::Sqrt(%"val_2335")
    3355 |  # node_Mul_2275
            %"val_2349"<?,?> ⬅️ ::Mul(%"add_72", %"val_2348")
    3356 |  # node_Sqrt_2276
            %"val_2350"<?,?> ⬅️ ::Sqrt(%"val_2335")
    3357 |  # node_Mul_2277
            %"val_2351"<?,?> ⬅️ ::Mul(%"val_2347", %"val_2350")
    3358 |  # node_MatMul_2278
            %"val_2352"<?,?> ⬅️ ::MatMul(%"val_2349", %"val_2351")
    3359 |  # node_Add_2279
            %"val_2353"<?,?> ⬅️ ::Add(%"val_2352", %"masked_fill")
    3360 |  # node_Softmax_2280
            %"val_2354"<?,?> ⬅️ ::Softmax(%"val_2353") {axis=-1}
    3361 |  # node_scaled_dot_product_attention_18
            %"scaled_dot_product_attention_18"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2354", %"getitem_92")
    3362 |  # node_transpose_59
            %"transpose_59"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_18") {perm=(0, 2, 1, 3)}
    3363 |  # node_Cast_2281
            %"val_2355"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3364 |  # node_view_37
            %"view_37"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_59", %"val_2355") {allowzero=1}
    3365 |  # node_Transpose_2282
            %"val_2356"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.attn.Wo.weight"{...}) {perm=(1, 0)}
    3366 |  # node_linear_73
            %"linear_73"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_37", %"val_2356")
    3367 |  # node_add_74
            %"add_74"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_71", %"linear_73")
    3368 |  # node_layer_norm_37
            %"layer_norm_37"<FLOAT,[1,97,768]>, %"val_2357"<?,?>, %"val_2358"<?,?> ⬅️ ::LayerNormalization(%"add_74", %"encoder.layers.18.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3369 |  # node_Transpose_2283
            %"val_2359"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3370 |  # node_linear_74
            %"linear_74"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_37", %"val_2359")
    3371 |  # node_split_18
            %"split_18"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_74", %"val_829") {dim=-1}
    3372 |  # node_getitem_93
            %"getitem_93"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_18", %"val_6")
    3373 |  # node_getitem_94
            %"getitem_94"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_18", %"val_48")
    3374 |  # node_Constant_2284
            %"val_2360"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3375 |  # node_Div_2285
            %"val_2361"<?,?> ⬅️ ::Div(%"getitem_93", %"val_2360")
    3376 |  # node_Erf_2286
            %"val_2362"<?,?> ⬅️ ::Erf(%"val_2361")
    3377 |  # node_Constant_2287
            %"val_2363"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3378 |  # node_Add_2288
            %"val_2364"<?,?> ⬅️ ::Add(%"val_2362", %"val_2363")
    3379 |  # node_Constant_2289
            %"val_2365"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3380 |  # node_Mul_2290
            %"val_2366"<?,?> ⬅️ ::Mul(%"val_2365", %"val_2364")
    3381 |  # node_gelu_18
            %"gelu_18"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_93", %"val_2366")
    3382 |  # node_mul_138
            %"mul_138"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_18", %"getitem_94")
    3383 |  # node_clone_20
            %"clone_20"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_138")
    3384 |  # node_Transpose_2291
            %"val_2367"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3385 |  # node_linear_75
            %"linear_75"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_20", %"val_2367")
    3386 |  # node_add_75
            %"add_75"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_74", %"linear_75")
    3387 |  # node_layer_norm_38
            %"layer_norm_38"<FLOAT,[1,97,768]>, %"val_2368"<?,?>, %"val_2369"<?,?> ⬅️ ::LayerNormalization(%"add_75", %"encoder.layers.19.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3388 |  # node_Transpose_2292
            %"val_2370"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3389 |  # node_linear_76
            %"linear_76"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_38", %"val_2370")
    3390 |  # node_Cast_2293
            %"val_2371"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    3391 |  # node_view_38
            %"view_38"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_76", %"val_2371") {allowzero=1}
    3392 |  # node_transpose_60
            %"transpose_60"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_38") {perm=(0, 3, 2, 1, 4)}
    3393 |  # node_unbind_19
            %"unbind_19"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_60") {dim=2}
    3394 |  # node_getitem_95
            %"getitem_95"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_19", %"val_6")
    3395 |  # node_getitem_96
            %"getitem_96"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_19", %"val_48")
    3396 |  # node_getitem_97
            %"getitem_97"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_19", %"val_72")
    3397 |  # node_unsqueeze_110
            %"unsqueeze_110"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3398 |  # node_unsqueeze_111
            %"unsqueeze_111"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3399 |  # node_mul_139
            %"mul_139"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_95", %"unsqueeze_110")
    3400 |  # node_Cast_2294
            %"val_2372"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3401 |  # node_Constant_2295
            %"val_2373"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3402 |  # node_Reshape_2296
            %"val_2374"<?,?> ⬅️ ::Reshape(%"val_2372", %"val_2373") {allowzero=0}
    3403 |  # node_Cast_2297
            %"val_2375"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3404 |  # node_Constant_2298
            %"val_2376"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3405 |  # node_Reshape_2299
            %"val_2377"<?,?> ⬅️ ::Reshape(%"val_2375", %"val_2376") {allowzero=0}
    3406 |  # node_Cast_2300
            %"val_2378"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3407 |  # node_Constant_2301
            %"val_2379"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3408 |  # node_Reshape_2302
            %"val_2380"<?,?> ⬅️ ::Reshape(%"val_2378", %"val_2379") {allowzero=0}
    3409 |  # node_Constant_2303
            %"val_2381"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3410 |  # node_slice_145
            %"slice_145"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_95", %"val_2374", %"val_2377", %"val_2380", %"val_2381")
    3411 |  # node_Cast_2304
            %"val_2382"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3412 |  # node_Constant_2305
            %"val_2383"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3413 |  # node_Reshape_2306
            %"val_2384"<?,?> ⬅️ ::Reshape(%"val_2382", %"val_2383") {allowzero=0}
    3414 |  # node_Cast_2307
            %"val_2385"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3415 |  # node_Constant_2308
            %"val_2386"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3416 |  # node_Reshape_2309
            %"val_2387"<?,?> ⬅️ ::Reshape(%"val_2385", %"val_2386") {allowzero=0}
    3417 |  # node_Cast_2310
            %"val_2388"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3418 |  # node_Constant_2311
            %"val_2389"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3419 |  # node_Reshape_2312
            %"val_2390"<?,?> ⬅️ ::Reshape(%"val_2388", %"val_2389") {allowzero=0}
    3420 |  # node_Constant_2313
            %"val_2391"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3421 |  # node_slice_146
            %"slice_146"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_95", %"val_2384", %"val_2387", %"val_2390", %"val_2391")
    3422 |  # node_neg_38
            %"neg_38"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_146")
    3423 |  # node_cat_60
            %"cat_60"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_38", %"slice_145") {axis=-1}
    3424 |  # node_mul_140
            %"mul_140"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_60", %"unsqueeze_111")
    3425 |  # node_add_76
            %"add_76"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_139", %"mul_140")
    3426 |  # node_mul_141
            %"mul_141"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_96", %"unsqueeze_110")
    3427 |  # node_Cast_2314
            %"val_2392"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3428 |  # node_Constant_2315
            %"val_2393"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3429 |  # node_Reshape_2316
            %"val_2394"<?,?> ⬅️ ::Reshape(%"val_2392", %"val_2393") {allowzero=0}
    3430 |  # node_Cast_2317
            %"val_2395"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3431 |  # node_Constant_2318
            %"val_2396"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3432 |  # node_Reshape_2319
            %"val_2397"<?,?> ⬅️ ::Reshape(%"val_2395", %"val_2396") {allowzero=0}
    3433 |  # node_Cast_2320
            %"val_2398"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3434 |  # node_Constant_2321
            %"val_2399"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3435 |  # node_Reshape_2322
            %"val_2400"<?,?> ⬅️ ::Reshape(%"val_2398", %"val_2399") {allowzero=0}
    3436 |  # node_Constant_2323
            %"val_2401"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3437 |  # node_slice_147
            %"slice_147"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_96", %"val_2394", %"val_2397", %"val_2400", %"val_2401")
    3438 |  # node_Cast_2324
            %"val_2402"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3439 |  # node_Constant_2325
            %"val_2403"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3440 |  # node_Reshape_2326
            %"val_2404"<?,?> ⬅️ ::Reshape(%"val_2402", %"val_2403") {allowzero=0}
    3441 |  # node_Cast_2327
            %"val_2405"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3442 |  # node_Constant_2328
            %"val_2406"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3443 |  # node_Reshape_2329
            %"val_2407"<?,?> ⬅️ ::Reshape(%"val_2405", %"val_2406") {allowzero=0}
    3444 |  # node_Cast_2330
            %"val_2408"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3445 |  # node_Constant_2331
            %"val_2409"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3446 |  # node_Reshape_2332
            %"val_2410"<?,?> ⬅️ ::Reshape(%"val_2408", %"val_2409") {allowzero=0}
    3447 |  # node_Constant_2333
            %"val_2411"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3448 |  # node_slice_148
            %"slice_148"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_96", %"val_2404", %"val_2407", %"val_2410", %"val_2411")
    3449 |  # node_neg_39
            %"neg_39"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_148")
    3450 |  # node_cat_61
            %"cat_61"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_39", %"slice_147") {axis=-1}
    3451 |  # node_mul_142
            %"mul_142"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_61", %"unsqueeze_111")
    3452 |  # node_add_77
            %"add_77"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_141", %"mul_142")
    3453 |  # node_Shape_2334
            %"val_2412"<?,?> ⬅️ ::Shape(%"add_76") {start=0}
    3454 |  # node_Constant_2335
            %"val_2413"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3455 |  # node_Gather_2336
            %"val_2414"<?,?> ⬅️ ::Gather(%"val_2412", %"val_2413") {axis=0}
    3456 |  # node_CastLike_2337
            %"val_2415"<?,?> ⬅️ ::CastLike(%"val_2414", %"add_76")
    3457 |  # node_Constant_2338
            %"val_2416"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3458 |  # node_CastLike_2339
            %"val_2417"<?,?> ⬅️ ::CastLike(%"val_2416", %"add_76")
    3459 |  # node_Sqrt_2340
            %"val_2418"<?,?> ⬅️ ::Sqrt(%"val_2415")
    3460 |  # node_Div_2341
            %"val_2419"<?,?> ⬅️ ::Div(%"val_2417", %"val_2418")
    3461 |  # node_CastLike_2342
            %"val_2420"<?,?> ⬅️ ::CastLike(%"val_2419", %"add_76")
    3462 |  # node_Shape_2343
            %"val_2421"<?,?> ⬅️ ::Shape(%"add_77") {start=0}
    3463 |  # node_Constant_2344
            %"val_2422"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3464 |  # node_Slice_2345
            %"val_2423"<?,?> ⬅️ ::Slice(%"val_2421", %"val_804", %"val_2422")
    3465 |  # node_Slice_2346
            %"val_2424"<?,?> ⬅️ ::Slice(%"val_2421", %"val_806", %"val_804")
    3466 |  # node_Constant_2347
            %"val_2425"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3467 |  # node_Slice_2348
            %"val_2426"<?,?> ⬅️ ::Slice(%"val_2421", %"val_2425", %"val_806")
    3468 |  # node_Constant_2349
            %"val_2427"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3469 |  # node_Concat_2350
            %"val_2428"<?,?> ⬅️ ::Concat(%"val_2427", %"val_2424", %"val_2423") {axis=0}
    3470 |  # node_Reshape_2351
            %"val_2429"<?,?> ⬅️ ::Reshape(%"add_77", %"val_2428") {allowzero=0}
    3471 |  # node_Transpose_2352
            %"val_2430"<?,?> ⬅️ ::Transpose(%"val_2429") {perm=(0, 2, 1)}
    3472 |  # node_Concat_2353
            %"val_2431"<?,?> ⬅️ ::Concat(%"val_2426", %"val_2423", %"val_2424") {axis=0}
    3473 |  # node_Reshape_2354
            %"val_2432"<?,?> ⬅️ ::Reshape(%"val_2430", %"val_2431") {allowzero=0}
    3474 |  # node_Sqrt_2355
            %"val_2433"<?,?> ⬅️ ::Sqrt(%"val_2420")
    3475 |  # node_Mul_2356
            %"val_2434"<?,?> ⬅️ ::Mul(%"add_76", %"val_2433")
    3476 |  # node_Sqrt_2357
            %"val_2435"<?,?> ⬅️ ::Sqrt(%"val_2420")
    3477 |  # node_Mul_2358
            %"val_2436"<?,?> ⬅️ ::Mul(%"val_2432", %"val_2435")
    3478 |  # node_MatMul_2359
            %"val_2437"<?,?> ⬅️ ::MatMul(%"val_2434", %"val_2436")
    3479 |  # node_Add_2360
            %"val_2438"<?,?> ⬅️ ::Add(%"val_2437", %"masked_fill_1")
    3480 |  # node_Softmax_2361
            %"val_2439"<?,?> ⬅️ ::Softmax(%"val_2438") {axis=-1}
    3481 |  # node_scaled_dot_product_attention_19
            %"scaled_dot_product_attention_19"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2439", %"getitem_97")
    3482 |  # node_transpose_61
            %"transpose_61"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_19") {perm=(0, 2, 1, 3)}
    3483 |  # node_Cast_2362
            %"val_2440"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3484 |  # node_view_39
            %"view_39"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_61", %"val_2440") {allowzero=1}
    3485 |  # node_Transpose_2363
            %"val_2441"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.attn.Wo.weight"{...}) {perm=(1, 0)}
    3486 |  # node_linear_77
            %"linear_77"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_39", %"val_2441")
    3487 |  # node_add_78
            %"add_78"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_75", %"linear_77")
    3488 |  # node_layer_norm_39
            %"layer_norm_39"<FLOAT,[1,97,768]>, %"val_2442"<?,?>, %"val_2443"<?,?> ⬅️ ::LayerNormalization(%"add_78", %"encoder.layers.19.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3489 |  # node_Transpose_2364
            %"val_2444"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3490 |  # node_linear_78
            %"linear_78"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_39", %"val_2444")
    3491 |  # node_split_19
            %"split_19"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_78", %"val_829") {dim=-1}
    3492 |  # node_getitem_98
            %"getitem_98"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_19", %"val_6")
    3493 |  # node_getitem_99
            %"getitem_99"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_19", %"val_48")
    3494 |  # node_Constant_2365
            %"val_2445"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3495 |  # node_Div_2366
            %"val_2446"<?,?> ⬅️ ::Div(%"getitem_98", %"val_2445")
    3496 |  # node_Erf_2367
            %"val_2447"<?,?> ⬅️ ::Erf(%"val_2446")
    3497 |  # node_Constant_2368
            %"val_2448"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3498 |  # node_Add_2369
            %"val_2449"<?,?> ⬅️ ::Add(%"val_2447", %"val_2448")
    3499 |  # node_Constant_2370
            %"val_2450"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3500 |  # node_Mul_2371
            %"val_2451"<?,?> ⬅️ ::Mul(%"val_2450", %"val_2449")
    3501 |  # node_gelu_19
            %"gelu_19"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_98", %"val_2451")
    3502 |  # node_mul_143
            %"mul_143"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_19", %"getitem_99")
    3503 |  # node_clone_21
            %"clone_21"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_143")
    3504 |  # node_Transpose_2372
            %"val_2452"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3505 |  # node_linear_79
            %"linear_79"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_21", %"val_2452")
    3506 |  # node_add_79
            %"add_79"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_78", %"linear_79")
    3507 |  # node_layer_norm_40
            %"layer_norm_40"<FLOAT,[1,97,768]>, %"val_2453"<?,?>, %"val_2454"<?,?> ⬅️ ::LayerNormalization(%"add_79", %"encoder.layers.20.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3508 |  # node_Transpose_2373
            %"val_2455"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3509 |  # node_linear_80
            %"linear_80"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_40", %"val_2455")
    3510 |  # node_Cast_2374
            %"val_2456"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    3511 |  # node_view_40
            %"view_40"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_80", %"val_2456") {allowzero=1}
    3512 |  # node_transpose_62
            %"transpose_62"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_40") {perm=(0, 3, 2, 1, 4)}
    3513 |  # node_unbind_20
            %"unbind_20"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_62") {dim=2}
    3514 |  # node_getitem_100
            %"getitem_100"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_20", %"val_6")
    3515 |  # node_getitem_101
            %"getitem_101"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_20", %"val_48")
    3516 |  # node_getitem_102
            %"getitem_102"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_20", %"val_72")
    3517 |  # node_unsqueeze_112
            %"unsqueeze_112"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3518 |  # node_unsqueeze_113
            %"unsqueeze_113"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3519 |  # node_mul_144
            %"mul_144"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_100", %"unsqueeze_112")
    3520 |  # node_Cast_2375
            %"val_2457"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3521 |  # node_Constant_2376
            %"val_2458"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3522 |  # node_Reshape_2377
            %"val_2459"<?,?> ⬅️ ::Reshape(%"val_2457", %"val_2458") {allowzero=0}
    3523 |  # node_Cast_2378
            %"val_2460"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3524 |  # node_Constant_2379
            %"val_2461"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3525 |  # node_Reshape_2380
            %"val_2462"<?,?> ⬅️ ::Reshape(%"val_2460", %"val_2461") {allowzero=0}
    3526 |  # node_Cast_2381
            %"val_2463"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3527 |  # node_Constant_2382
            %"val_2464"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3528 |  # node_Reshape_2383
            %"val_2465"<?,?> ⬅️ ::Reshape(%"val_2463", %"val_2464") {allowzero=0}
    3529 |  # node_Constant_2384
            %"val_2466"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3530 |  # node_slice_149
            %"slice_149"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_100", %"val_2459", %"val_2462", %"val_2465", %"val_2466")
    3531 |  # node_Cast_2385
            %"val_2467"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3532 |  # node_Constant_2386
            %"val_2468"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3533 |  # node_Reshape_2387
            %"val_2469"<?,?> ⬅️ ::Reshape(%"val_2467", %"val_2468") {allowzero=0}
    3534 |  # node_Cast_2388
            %"val_2470"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3535 |  # node_Constant_2389
            %"val_2471"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3536 |  # node_Reshape_2390
            %"val_2472"<?,?> ⬅️ ::Reshape(%"val_2470", %"val_2471") {allowzero=0}
    3537 |  # node_Cast_2391
            %"val_2473"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3538 |  # node_Constant_2392
            %"val_2474"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3539 |  # node_Reshape_2393
            %"val_2475"<?,?> ⬅️ ::Reshape(%"val_2473", %"val_2474") {allowzero=0}
    3540 |  # node_Constant_2394
            %"val_2476"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3541 |  # node_slice_150
            %"slice_150"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_100", %"val_2469", %"val_2472", %"val_2475", %"val_2476")
    3542 |  # node_neg_40
            %"neg_40"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_150")
    3543 |  # node_cat_62
            %"cat_62"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_40", %"slice_149") {axis=-1}
    3544 |  # node_mul_145
            %"mul_145"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_62", %"unsqueeze_113")
    3545 |  # node_add_80
            %"add_80"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_144", %"mul_145")
    3546 |  # node_mul_146
            %"mul_146"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_101", %"unsqueeze_112")
    3547 |  # node_Cast_2395
            %"val_2477"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3548 |  # node_Constant_2396
            %"val_2478"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3549 |  # node_Reshape_2397
            %"val_2479"<?,?> ⬅️ ::Reshape(%"val_2477", %"val_2478") {allowzero=0}
    3550 |  # node_Cast_2398
            %"val_2480"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3551 |  # node_Constant_2399
            %"val_2481"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3552 |  # node_Reshape_2400
            %"val_2482"<?,?> ⬅️ ::Reshape(%"val_2480", %"val_2481") {allowzero=0}
    3553 |  # node_Cast_2401
            %"val_2483"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3554 |  # node_Constant_2402
            %"val_2484"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3555 |  # node_Reshape_2403
            %"val_2485"<?,?> ⬅️ ::Reshape(%"val_2483", %"val_2484") {allowzero=0}
    3556 |  # node_Constant_2404
            %"val_2486"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3557 |  # node_slice_151
            %"slice_151"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_101", %"val_2479", %"val_2482", %"val_2485", %"val_2486")
    3558 |  # node_Cast_2405
            %"val_2487"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3559 |  # node_Constant_2406
            %"val_2488"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3560 |  # node_Reshape_2407
            %"val_2489"<?,?> ⬅️ ::Reshape(%"val_2487", %"val_2488") {allowzero=0}
    3561 |  # node_Cast_2408
            %"val_2490"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3562 |  # node_Constant_2409
            %"val_2491"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3563 |  # node_Reshape_2410
            %"val_2492"<?,?> ⬅️ ::Reshape(%"val_2490", %"val_2491") {allowzero=0}
    3564 |  # node_Cast_2411
            %"val_2493"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3565 |  # node_Constant_2412
            %"val_2494"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3566 |  # node_Reshape_2413
            %"val_2495"<?,?> ⬅️ ::Reshape(%"val_2493", %"val_2494") {allowzero=0}
    3567 |  # node_Constant_2414
            %"val_2496"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3568 |  # node_slice_152
            %"slice_152"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_101", %"val_2489", %"val_2492", %"val_2495", %"val_2496")
    3569 |  # node_neg_41
            %"neg_41"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_152")
    3570 |  # node_cat_63
            %"cat_63"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_41", %"slice_151") {axis=-1}
    3571 |  # node_mul_147
            %"mul_147"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_63", %"unsqueeze_113")
    3572 |  # node_add_81
            %"add_81"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_146", %"mul_147")
    3573 |  # node_Shape_2415
            %"val_2497"<?,?> ⬅️ ::Shape(%"add_80") {start=0}
    3574 |  # node_Constant_2416
            %"val_2498"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3575 |  # node_Gather_2417
            %"val_2499"<?,?> ⬅️ ::Gather(%"val_2497", %"val_2498") {axis=0}
    3576 |  # node_CastLike_2418
            %"val_2500"<?,?> ⬅️ ::CastLike(%"val_2499", %"add_80")
    3577 |  # node_Constant_2419
            %"val_2501"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3578 |  # node_CastLike_2420
            %"val_2502"<?,?> ⬅️ ::CastLike(%"val_2501", %"add_80")
    3579 |  # node_Sqrt_2421
            %"val_2503"<?,?> ⬅️ ::Sqrt(%"val_2500")
    3580 |  # node_Div_2422
            %"val_2504"<?,?> ⬅️ ::Div(%"val_2502", %"val_2503")
    3581 |  # node_CastLike_2423
            %"val_2505"<?,?> ⬅️ ::CastLike(%"val_2504", %"add_80")
    3582 |  # node_Shape_2424
            %"val_2506"<?,?> ⬅️ ::Shape(%"add_81") {start=0}
    3583 |  # node_Constant_2425
            %"val_2507"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3584 |  # node_Slice_2426
            %"val_2508"<?,?> ⬅️ ::Slice(%"val_2506", %"val_804", %"val_2507")
    3585 |  # node_Slice_2427
            %"val_2509"<?,?> ⬅️ ::Slice(%"val_2506", %"val_806", %"val_804")
    3586 |  # node_Constant_2428
            %"val_2510"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3587 |  # node_Slice_2429
            %"val_2511"<?,?> ⬅️ ::Slice(%"val_2506", %"val_2510", %"val_806")
    3588 |  # node_Constant_2430
            %"val_2512"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3589 |  # node_Concat_2431
            %"val_2513"<?,?> ⬅️ ::Concat(%"val_2512", %"val_2509", %"val_2508") {axis=0}
    3590 |  # node_Reshape_2432
            %"val_2514"<?,?> ⬅️ ::Reshape(%"add_81", %"val_2513") {allowzero=0}
    3591 |  # node_Transpose_2433
            %"val_2515"<?,?> ⬅️ ::Transpose(%"val_2514") {perm=(0, 2, 1)}
    3592 |  # node_Concat_2434
            %"val_2516"<?,?> ⬅️ ::Concat(%"val_2511", %"val_2508", %"val_2509") {axis=0}
    3593 |  # node_Reshape_2435
            %"val_2517"<?,?> ⬅️ ::Reshape(%"val_2515", %"val_2516") {allowzero=0}
    3594 |  # node_Sqrt_2436
            %"val_2518"<?,?> ⬅️ ::Sqrt(%"val_2505")
    3595 |  # node_Mul_2437
            %"val_2519"<?,?> ⬅️ ::Mul(%"add_80", %"val_2518")
    3596 |  # node_Sqrt_2438
            %"val_2520"<?,?> ⬅️ ::Sqrt(%"val_2505")
    3597 |  # node_Mul_2439
            %"val_2521"<?,?> ⬅️ ::Mul(%"val_2517", %"val_2520")
    3598 |  # node_MatMul_2440
            %"val_2522"<?,?> ⬅️ ::MatMul(%"val_2519", %"val_2521")
    3599 |  # node_Add_2441
            %"val_2523"<?,?> ⬅️ ::Add(%"val_2522", %"masked_fill_1")
    3600 |  # node_Softmax_2442
            %"val_2524"<?,?> ⬅️ ::Softmax(%"val_2523") {axis=-1}
    3601 |  # node_scaled_dot_product_attention_20
            %"scaled_dot_product_attention_20"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2524", %"getitem_102")
    3602 |  # node_transpose_63
            %"transpose_63"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_20") {perm=(0, 2, 1, 3)}
    3603 |  # node_Cast_2443
            %"val_2525"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3604 |  # node_view_41
            %"view_41"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_63", %"val_2525") {allowzero=1}
    3605 |  # node_Transpose_2444
            %"val_2526"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.attn.Wo.weight"{...}) {perm=(1, 0)}
    3606 |  # node_linear_81
            %"linear_81"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_41", %"val_2526")
    3607 |  # node_add_82
            %"add_82"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_79", %"linear_81")
    3608 |  # node_layer_norm_41
            %"layer_norm_41"<FLOAT,[1,97,768]>, %"val_2527"<?,?>, %"val_2528"<?,?> ⬅️ ::LayerNormalization(%"add_82", %"encoder.layers.20.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3609 |  # node_Transpose_2445
            %"val_2529"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3610 |  # node_linear_82
            %"linear_82"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_41", %"val_2529")
    3611 |  # node_split_20
            %"split_20"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_82", %"val_829") {dim=-1}
    3612 |  # node_getitem_103
            %"getitem_103"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_20", %"val_6")
    3613 |  # node_getitem_104
            %"getitem_104"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_20", %"val_48")
    3614 |  # node_Constant_2446
            %"val_2530"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3615 |  # node_Div_2447
            %"val_2531"<?,?> ⬅️ ::Div(%"getitem_103", %"val_2530")
    3616 |  # node_Erf_2448
            %"val_2532"<?,?> ⬅️ ::Erf(%"val_2531")
    3617 |  # node_Constant_2449
            %"val_2533"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3618 |  # node_Add_2450
            %"val_2534"<?,?> ⬅️ ::Add(%"val_2532", %"val_2533")
    3619 |  # node_Constant_2451
            %"val_2535"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3620 |  # node_Mul_2452
            %"val_2536"<?,?> ⬅️ ::Mul(%"val_2535", %"val_2534")
    3621 |  # node_gelu_20
            %"gelu_20"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_103", %"val_2536")
    3622 |  # node_mul_148
            %"mul_148"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_20", %"getitem_104")
    3623 |  # node_clone_22
            %"clone_22"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_148")
    3624 |  # node_Transpose_2453
            %"val_2537"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3625 |  # node_linear_83
            %"linear_83"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_22", %"val_2537")
    3626 |  # node_add_83
            %"add_83"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_82", %"linear_83")
    3627 |  # node_layer_norm_42
            %"layer_norm_42"<FLOAT,[1,97,768]>, %"val_2538"<?,?>, %"val_2539"<?,?> ⬅️ ::LayerNormalization(%"add_83", %"encoder.layers.21.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3628 |  # node_Transpose_2454
            %"val_2540"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3629 |  # node_linear_84
            %"linear_84"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_42", %"val_2540")
    3630 |  # node_Cast_2455
            %"val_2541"<?,?> ⬅️ ::Cast(%"val_750") {to=7}
    3631 |  # node_view_42
            %"view_42"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_84", %"val_2541") {allowzero=1}
    3632 |  # node_transpose_64
            %"transpose_64"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_42") {perm=(0, 3, 2, 1, 4)}
    3633 |  # node_unbind_21
            %"unbind_21"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_unbind(%"transpose_64") {dim=2}
    3634 |  # node_getitem_105
            %"getitem_105"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_21", %"val_6")
    3635 |  # node_getitem_106
            %"getitem_106"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_21", %"val_48")
    3636 |  # node_getitem_107
            %"getitem_107"<FLOAT,[1,12,97,64]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"unbind_21", %"val_72")
    3637 |  # node_unsqueeze_114
            %"unsqueeze_114"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    3638 |  # node_unsqueeze_115
            %"unsqueeze_115"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    3639 |  # node_mul_149
            %"mul_149"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_105", %"unsqueeze_114")
    3640 |  # node_Cast_2456
            %"val_2542"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3641 |  # node_Constant_2457
            %"val_2543"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3642 |  # node_Reshape_2458
            %"val_2544"<?,?> ⬅️ ::Reshape(%"val_2542", %"val_2543") {allowzero=0}
    3643 |  # node_Cast_2459
            %"val_2545"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3644 |  # node_Constant_2460
            %"val_2546"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3645 |  # node_Reshape_2461
            %"val_2547"<?,?> ⬅️ ::Reshape(%"val_2545", %"val_2546") {allowzero=0}
    3646 |  # node_Cast_2462
            %"val_2548"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3647 |  # node_Constant_2463
            %"val_2549"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3648 |  # node_Reshape_2464
            %"val_2550"<?,?> ⬅️ ::Reshape(%"val_2548", %"val_2549") {allowzero=0}
    3649 |  # node_Constant_2465
            %"val_2551"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3650 |  # node_slice_153
            %"slice_153"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_105", %"val_2544", %"val_2547", %"val_2550", %"val_2551")
    3651 |  # node_Cast_2466
            %"val_2552"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3652 |  # node_Constant_2467
            %"val_2553"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3653 |  # node_Reshape_2468
            %"val_2554"<?,?> ⬅️ ::Reshape(%"val_2552", %"val_2553") {allowzero=0}
    3654 |  # node_Cast_2469
            %"val_2555"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3655 |  # node_Constant_2470
            %"val_2556"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3656 |  # node_Reshape_2471
            %"val_2557"<?,?> ⬅️ ::Reshape(%"val_2555", %"val_2556") {allowzero=0}
    3657 |  # node_Cast_2472
            %"val_2558"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3658 |  # node_Constant_2473
            %"val_2559"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3659 |  # node_Reshape_2474
            %"val_2560"<?,?> ⬅️ ::Reshape(%"val_2558", %"val_2559") {allowzero=0}
    3660 |  # node_Constant_2475
            %"val_2561"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3661 |  # node_slice_154
            %"slice_154"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_105", %"val_2554", %"val_2557", %"val_2560", %"val_2561")
    3662 |  # node_neg_42
            %"neg_42"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_154")
    3663 |  # node_cat_64
            %"cat_64"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_42", %"slice_153") {axis=-1}
    3664 |  # node_mul_150
            %"mul_150"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_64", %"unsqueeze_115")
    3665 |  # node_add_84
            %"add_84"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_149", %"mul_150")
    3666 |  # node_mul_151
            %"mul_151"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_106", %"unsqueeze_114")
    3667 |  # node_Cast_2476
            %"val_2562"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3668 |  # node_Constant_2477
            %"val_2563"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3669 |  # node_Reshape_2478
            %"val_2564"<?,?> ⬅️ ::Reshape(%"val_2562", %"val_2563") {allowzero=0}
    3670 |  # node_Cast_2479
            %"val_2565"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3671 |  # node_Constant_2480
            %"val_2566"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3672 |  # node_Reshape_2481
            %"val_2567"<?,?> ⬅️ ::Reshape(%"val_2565", %"val_2566") {allowzero=0}
    3673 |  # node_Cast_2482
            %"val_2568"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3674 |  # node_Constant_2483
            %"val_2569"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3675 |  # node_Reshape_2484
            %"val_2570"<?,?> ⬅️ ::Reshape(%"val_2568", %"val_2569") {allowzero=0}
    3676 |  # node_Constant_2485
            %"val_2571"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3677 |  # node_slice_155
            %"slice_155"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_106", %"val_2564", %"val_2567", %"val_2570", %"val_2571")
    3678 |  # node_Cast_2486
            %"val_2572"<?,?> ⬅️ ::Cast(%"val_755") {to=7}
    3679 |  # node_Constant_2487
            %"val_2573"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3680 |  # node_Reshape_2488
            %"val_2574"<?,?> ⬅️ ::Reshape(%"val_2572", %"val_2573") {allowzero=0}
    3681 |  # node_Cast_2489
            %"val_2575"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3682 |  # node_Constant_2490
            %"val_2576"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3683 |  # node_Reshape_2491
            %"val_2577"<?,?> ⬅️ ::Reshape(%"val_2575", %"val_2576") {allowzero=0}
    3684 |  # node_Cast_2492
            %"val_2578"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3685 |  # node_Constant_2493
            %"val_2579"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3686 |  # node_Reshape_2494
            %"val_2580"<?,?> ⬅️ ::Reshape(%"val_2578", %"val_2579") {allowzero=0}
    3687 |  # node_Constant_2495
            %"val_2581"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3688 |  # node_slice_156
            %"slice_156"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_106", %"val_2574", %"val_2577", %"val_2580", %"val_2581")
    3689 |  # node_neg_43
            %"neg_43"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_156")
    3690 |  # node_cat_65
            %"cat_65"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_43", %"slice_155") {axis=-1}
    3691 |  # node_mul_152
            %"mul_152"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_65", %"unsqueeze_115")
    3692 |  # node_add_85
            %"add_85"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_151", %"mul_152")
    3693 |  # node_Shape_2496
            %"val_2582"<?,?> ⬅️ ::Shape(%"add_84") {start=0}
    3694 |  # node_Constant_2497
            %"val_2583"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3695 |  # node_Gather_2498
            %"val_2584"<?,?> ⬅️ ::Gather(%"val_2582", %"val_2583") {axis=0}
    3696 |  # node_CastLike_2499
            %"val_2585"<?,?> ⬅️ ::CastLike(%"val_2584", %"add_84")
    3697 |  # node_Constant_2500
            %"val_2586"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3698 |  # node_CastLike_2501
            %"val_2587"<?,?> ⬅️ ::CastLike(%"val_2586", %"add_84")
    3699 |  # node_Sqrt_2502
            %"val_2588"<?,?> ⬅️ ::Sqrt(%"val_2585")
    3700 |  # node_Div_2503
            %"val_2589"<?,?> ⬅️ ::Div(%"val_2587", %"val_2588")
    3701 |  # node_CastLike_2504
            %"val_2590"<?,?> ⬅️ ::CastLike(%"val_2589", %"add_84")
    3702 |  # node_Shape_2505
            %"val_2591"<?,?> ⬅️ ::Shape(%"add_85") {start=0}
    3703 |  # node_Constant_2506
            %"val_2592"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3704 |  # node_Slice_2507
            %"val_2593"<?,?> ⬅️ ::Slice(%"val_2591", %"val_804", %"val_2592")
    3705 |  # node_Slice_2508
            %"val_2594"<?,?> ⬅️ ::Slice(%"val_2591", %"val_806", %"val_804")
    3706 |  # node_Constant_2509
            %"val_2595"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3707 |  # node_Slice_2510
            %"val_2596"<?,?> ⬅️ ::Slice(%"val_2591", %"val_2595", %"val_806")
    3708 |  # node_Constant_2511
            %"val_2597"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3709 |  # node_Concat_2512
            %"val_2598"<?,?> ⬅️ ::Concat(%"val_2597", %"val_2594", %"val_2593") {axis=0}
    3710 |  # node_Reshape_2513
            %"val_2599"<?,?> ⬅️ ::Reshape(%"add_85", %"val_2598") {allowzero=0}
    3711 |  # node_Transpose_2514
            %"val_2600"<?,?> ⬅️ ::Transpose(%"val_2599") {perm=(0, 2, 1)}
    3712 |  # node_Concat_2515
            %"val_2601"<?,?> ⬅️ ::Concat(%"val_2596", %"val_2593", %"val_2594") {axis=0}
    3713 |  # node_Reshape_2516
            %"val_2602"<?,?> ⬅️ ::Reshape(%"val_2600", %"val_2601") {allowzero=0}
    3714 |  # node_Sqrt_2517
            %"val_2603"<?,?> ⬅️ ::Sqrt(%"val_2590")
    3715 |  # node_Mul_2518
            %"val_2604"<?,?> ⬅️ ::Mul(%"add_84", %"val_2603")
    3716 |  # node_Sqrt_2519
            %"val_2605"<?,?> ⬅️ ::Sqrt(%"val_2590")
    3717 |  # node_Mul_2520
            %"val_2606"<?,?> ⬅️ ::Mul(%"val_2602", %"val_2605")
    3718 |  # node_MatMul_2521
            %"val_2607"<?,?> ⬅️ ::MatMul(%"val_2604", %"val_2606")
    3719 |  # node_Add_2522
            %"val_2608"<?,?> ⬅️ ::Add(%"val_2607", %"masked_fill")
    3720 |  # node_Softmax_2523
            %"val_2609"<?,?> ⬅️ ::Softmax(%"val_2608") {axis=-1}
    3721 |  # node_scaled_dot_product_attention_21
            %"scaled_dot_product_attention_21"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2609", %"getitem_107")
    3722 |  # node_transpose_65
            %"transpose_65"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_21") {perm=(0, 2, 1, 3)}
    3723 |  # node_Cast_2524
            %"val_2610"<?,?> ⬅️ ::Cast(%"val_823") {to=7}
    3724 |  # node_view_43
            %"view_43"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_65", %"val_2610") {allowzero=1}
    3725 |  # node_Transpose_2525
            %"val_2611"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.attn.Wo.weight"{...}) {perm=(1, 0)}
    3726 |  # node_linear_85
            %"linear_85"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_43", %"val_2611")
    3727 |  # node_add_86
            %"add_86"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_83", %"linear_85")
    3728 |  # node_layer_norm_43
            %"layer_norm_43"<FLOAT,[1,97,768]>, %"val_2612"<?,?>, %"val_2613"<?,?> ⬅️ ::LayerNormalization(%"add_86", %"encoder.layers.21.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3729 |  # node_Transpose_2526
            %"val_2614"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3730 |  # node_linear_86
            %"linear_86"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_43", %"val_2614")
    3731 |  # node_split_21
            %"split_21"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_86", %"val_829") {dim=-1}
    3732 |  # node_getitem_108
            %"getitem_108"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_21", %"val_6")
    3733 |  # node_getitem_109
            %"getitem_109"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_21", %"val_48")
    3734 |  # node_Constant_2527
            %"val_2615"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3735 |  # node_Div_2528
            %"val_2616"<?,?> ⬅️ ::Div(%"getitem_108", %"val_2615")
    3736 |  # node_Erf_2529
            %"val_2617"<?,?> ⬅️ ::Erf(%"val_2616")
    3737 |  # node_Constant_2530
            %"val_2618"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3738 |  # node_Add_2531
            %"val_2619"<?,?> ⬅️ ::Add(%"val_2617", %"val_2618")
    3739 |  # node_Constant_2532
            %"val_2620"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3740 |  # node_Mul_2533
            %"val_2621"<?,?> ⬅️ ::Mul(%"val_2620", %"val_2619")
    3741 |  # node_gelu_21
            %"gelu_21"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_108", %"val_2621")
    3742 |  # node_mul_153
            %"mul_153"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_21", %"getitem_109")
    3743 |  # node_clone_23
            %"clone_23"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_153")
    3744 |  # node_Transpose_2534
            %"val_2622"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3745 |  # node_linear_87
            %"linear_87"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_23", %"val_2622")
    3746 |  # node_add_87
            %"add_87"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_86", %"linear_87")
    3747 |  # node_layer_norm_44
            %"layer_norm_44"<FLOAT,[1,97,768]>, %"val_2623"<?,?>, %"val_2624"<?,?> ⬅️ ::LayerNormalization(%"add_87", %"encoder.final_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3748 |  # node_embedding_1
            %"embedding_1"<FLOAT,[1,768]> ⬅️ ::Gather(%"type_emb.weight"{...}, %"qtype") {axis=0}
    3749 |  # node_Cast_2535
            %"val_2625"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3750 |  # node_Constant_2536
            %"val_2626"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3751 |  # node_Reshape_2537
            %"val_2627"<?,?> ⬅️ ::Reshape(%"val_2625", %"val_2626") {allowzero=0}
    3752 |  # node_Cast_2538
            %"val_2628"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3753 |  # node_Constant_2539
            %"val_2629"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3754 |  # node_Reshape_2540
            %"val_2630"<?,?> ⬅️ ::Reshape(%"val_2628", %"val_2629") {allowzero=0}
    3755 |  # node_Cast_2541
            %"val_2631"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3756 |  # node_Constant_2542
            %"val_2632"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3757 |  # node_Reshape_2543
            %"val_2633"<?,?> ⬅️ ::Reshape(%"val_2631", %"val_2632") {allowzero=0}
    3758 |  # node_Constant_2544
            %"val_2634"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3759 |  # node_slice_157
            %"slice_157"<FLOAT,[1,768]> ⬅️ ::Slice(%"embedding_1", %"val_2627", %"val_2630", %"val_2633", %"val_2634")
    3760 |  # node_unsqueeze_116
            %"unsqueeze_116"<FLOAT,[1,1,768]> ⬅️ ::Unsqueeze(%"slice_157", %"val_18")
    3761 |  # node_Cast_2545
            %"val_2635"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3762 |  # node_Constant_2546
            %"val_2636"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3763 |  # node_Reshape_2547
            %"val_2637"<?,?> ⬅️ ::Reshape(%"val_2635", %"val_2636") {allowzero=0}
    3764 |  # node_Cast_2548
            %"val_2638"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3765 |  # node_Constant_2549
            %"val_2639"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3766 |  # node_Reshape_2550
            %"val_2640"<?,?> ⬅️ ::Reshape(%"val_2638", %"val_2639") {allowzero=0}
    3767 |  # node_Cast_2551
            %"val_2641"<?,?> ⬅️ ::Cast(%"val_72") {to=7}
    3768 |  # node_Constant_2552
            %"val_2642"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3769 |  # node_Reshape_2553
            %"val_2643"<?,?> ⬅️ ::Reshape(%"val_2641", %"val_2642") {allowzero=0}
    3770 |  # node_Constant_2554
            %"val_2644"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3771 |  # node_slice_158
            %"slice_158"<FLOAT,[1,1,768]> ⬅️ ::Slice(%"unsqueeze_116", %"val_2637", %"val_2640", %"val_2643", %"val_2644")
    3772 |  # node_add_88
            %"add_88"<FLOAT,[1,97,768]> ⬅️ ::Add(%"layer_norm_44", %"slice_158")
    3773 |  # node__to_copy_24
            %"_to_copy_24"<BOOL,[1,97]> ⬅️ ::Cast(%"attention_mask") {to=9}
    3774 |  # node_bitwise_not
            %"bitwise_not"<BOOL,[1,97]> ⬅️ ::Not(%"_to_copy_24")
    3775 |  # node_Cast_2555
            %"val_2645"<?,?> ⬅️ ::Cast(%"val_6") {to=1}
    3776 |  # node_Shape_2556
            %"val_2646"<?,?> ⬅️ ::Shape(%"bitwise_not") {start=0}
    3777 |  # node_zeros_like
            %"zeros_like"<FLOAT,[1,97]> ⬅️ ::Expand(%"val_2645", %"val_2646")
    3778 |  # node_Constant_2557
            %"val_2647"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(-inf, dtype=float32), name=None)}
    3779 |  # node_CastLike_2558
            %"val_2648"<?,?> ⬅️ ::CastLike(%"val_2647", %"zeros_like")
    3780 |  # node_masked_fill_2
            %"masked_fill_2"<FLOAT,[1,97]> ⬅️ ::Where(%"bitwise_not", %"val_2648", %"zeros_like")
    3781 |  # node_layer_norm_45
            %"layer_norm_45"<FLOAT,[1,97,768]>, %"val_2649"<?,?>, %"val_2650"<?,?> ⬅️ ::LayerNormalization(%"add_88", %"head.layers.0.norm1.weight"{...}, %"head.layers.0.norm1.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3782 |  # node_transpose_66
            %"transpose_66"<FLOAT,[97,1,768]> ⬅️ ::Transpose(%"layer_norm_45") {perm=(1, 0, 2)}
    3783 |  # node_Transpose_2559
            %"val_2651"<?,?> ⬅️ ::Transpose(%"head.layers.0.self_attn.in_proj_weight"{...}) {perm=(1, 0)}
    3784 |  # node_MatMul_2560
            %"val_2652"<?,?> ⬅️ ::MatMul(%"transpose_66", %"val_2651")
    3785 |  # node_linear_88
            %"linear_88"<FLOAT,[97,1,2304]> ⬅️ ::Add(%"val_2652", %"head.layers.0.self_attn.in_proj_bias"{...})
    3786 |  # node_Constant_2561
            %"val_2653"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[4]>(array([ 97,   1,   3, 768]), name=None)}
    3787 |  # node_Cast_2562
            %"val_2654"<?,?> ⬅️ ::Cast(%"val_2653") {to=7}
    3788 |  # node_view_44
            %"view_44"<FLOAT,[97,1,3,768]> ⬅️ ::Reshape(%"linear_88", %"val_2654") {allowzero=1}
    3789 |  # node_unsqueeze_117
            %"unsqueeze_117"<FLOAT,[1,97,1,3,768]> ⬅️ ::Unsqueeze(%"view_44", %"val_5")
    3790 |  # node_transpose_67
            %"transpose_67"<FLOAT,[3,97,1,1,768]> ⬅️ ::Transpose(%"unsqueeze_117") {perm=(3, 1, 2, 0, 4)}
    3791 |  # node_squeeze
            %"squeeze"<FLOAT,[3,97,1,768]> ⬅️ ::Squeeze(%"transpose_67", %"val_806")
    3792 |  # node_clone_24
            %"clone_24"<FLOAT,[3,97,1,768]> ⬅️ ::Identity(%"squeeze")
    3793 |  # node_select
            %"select"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_24", %"val_6") {axis=0}
    3794 |  # node_select_1
            %"select_1"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_24", %"val_48") {axis=0}
    3795 |  # node_select_2
            %"select_2"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_24", %"val_72") {axis=0}
    3796 |  # node_Constant_2563
            %"val_2655"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[3]>(array([97, 12, 64]), name=None)}
    3797 |  # node_Cast_2564
            %"val_2656"<?,?> ⬅️ ::Cast(%"val_2655") {to=7}
    3798 |  # node_view_45
            %"view_45"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select", %"val_2656") {allowzero=1}
    3799 |  # node_transpose_68
            %"transpose_68"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_45") {perm=(1, 0, 2)}
    3800 |  # node_Cast_2565
            %"val_2657"<?,?> ⬅️ ::Cast(%"val_2655") {to=7}
    3801 |  # node_view_46
            %"view_46"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_1", %"val_2657") {allowzero=1}
    3802 |  # node_transpose_69
            %"transpose_69"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_46") {perm=(1, 0, 2)}
    3803 |  # node_Cast_2566
            %"val_2658"<?,?> ⬅️ ::Cast(%"val_2655") {to=7}
    3804 |  # node_view_47
            %"view_47"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_2", %"val_2658") {allowzero=1}
    3805 |  # node_transpose_70
            %"transpose_70"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_47") {perm=(1, 0, 2)}
    3806 |  # node_Constant_2567
            %"val_2659"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[4]>(array([ 1, 12, 97, 64]), name=None)}
    3807 |  # node_Cast_2568
            %"val_2660"<?,?> ⬅️ ::Cast(%"val_2659") {to=7}
    3808 |  # node_view_51
            %"view_51"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_68", %"val_2660") {allowzero=1}
    3809 |  # node_Cast_2569
            %"val_2661"<?,?> ⬅️ ::Cast(%"val_2659") {to=7}
    3810 |  # node_view_52
            %"view_52"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_69", %"val_2661") {allowzero=1}
    3811 |  # node_Cast_2570
            %"val_2662"<?,?> ⬅️ ::Cast(%"val_2659") {to=7}
    3812 |  # node_view_53
            %"view_53"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_70", %"val_2662") {allowzero=1}
    3813 |  # node_Constant_2571
            %"val_2663"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[4]>(array([ 1,  1,  1, 97]), name=None)}
    3814 |  # node_Cast_2572
            %"val_2664"<?,?> ⬅️ ::Cast(%"val_2663") {to=7}
    3815 |  # node_view_54
            %"view_54"<FLOAT,[1,1,1,97]> ⬅️ ::Reshape(%"masked_fill_2", %"val_2664") {allowzero=1}
    3816 |  # node_Constant_2573
            %"val_2665"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[4]>(array([-1, 12, -1, -1]), name=None)}
    3817 |  # node_Cast_2574
            %"val_2666"<?,?> ⬅️ ::Cast(%"val_2665") {to=7}
    3818 |  # node_Abs_2575
            %"val_2667"<?,?> ⬅️ ::Abs(%"val_2666")
    3819 |  # node_expand_24
            %"expand_24"<FLOAT,[1,12,1,97]> ⬅️ ::Expand(%"view_54", %"val_2667")
    3820 |  # node_Constant_2576
            %"val_2668"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[3]>(array([12,  1, 97]), name=None)}
    3821 |  # node_Cast_2577
            %"val_2669"<?,?> ⬅️ ::Cast(%"val_2668") {to=7}
    3822 |  # node_view_55
            %"view_55"<FLOAT,[12,1,97]> ⬅️ ::Reshape(%"expand_24", %"val_2669") {allowzero=1}
    3823 |  # node_Constant_2578
            %"val_2670"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[4]>(array([ 1, 12, -1, 97]), name=None)}
    3824 |  # node_Cast_2579
            %"val_2671"<?,?> ⬅️ ::Cast(%"val_2670") {to=7}
    3825 |  # node_view_56
            %"view_56"<FLOAT,[1,12,1,97]> ⬅️ ::Reshape(%"view_55", %"val_2671") {allowzero=1}
    3826 |  # node_Shape_2580
            %"val_2672"<?,?> ⬅️ ::Shape(%"view_51") {start=0}
    3827 |  # node_Constant_2581
            %"val_2673"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3828 |  # node_Gather_2582
            %"val_2674"<?,?> ⬅️ ::Gather(%"val_2672", %"val_2673") {axis=0}
    3829 |  # node_CastLike_2583
            %"val_2675"<?,?> ⬅️ ::CastLike(%"val_2674", %"view_51")
    3830 |  # node_Constant_2584
            %"val_2676"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3831 |  # node_CastLike_2585
            %"val_2677"<?,?> ⬅️ ::CastLike(%"val_2676", %"view_51")
    3832 |  # node_Sqrt_2586
            %"val_2678"<?,?> ⬅️ ::Sqrt(%"val_2675")
    3833 |  # node_Div_2587
            %"val_2679"<?,?> ⬅️ ::Div(%"val_2677", %"val_2678")
    3834 |  # node_CastLike_2588
            %"val_2680"<?,?> ⬅️ ::CastLike(%"val_2679", %"view_51")
    3835 |  # node_Shape_2589
            %"val_2681"<?,?> ⬅️ ::Shape(%"view_52") {start=0}
    3836 |  # node_Constant_2590
            %"val_2682"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3837 |  # node_Slice_2591
            %"val_2683"<?,?> ⬅️ ::Slice(%"val_2681", %"val_804", %"val_2682")
    3838 |  # node_Slice_2592
            %"val_2684"<?,?> ⬅️ ::Slice(%"val_2681", %"val_806", %"val_804")
    3839 |  # node_Constant_2593
            %"val_2685"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3840 |  # node_Slice_2594
            %"val_2686"<?,?> ⬅️ ::Slice(%"val_2681", %"val_2685", %"val_806")
    3841 |  # node_Constant_2595
            %"val_2687"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3842 |  # node_Concat_2596
            %"val_2688"<?,?> ⬅️ ::Concat(%"val_2687", %"val_2684", %"val_2683") {axis=0}
    3843 |  # node_Reshape_2597
            %"val_2689"<?,?> ⬅️ ::Reshape(%"view_52", %"val_2688") {allowzero=0}
    3844 |  # node_Transpose_2598
            %"val_2690"<?,?> ⬅️ ::Transpose(%"val_2689") {perm=(0, 2, 1)}
    3845 |  # node_Concat_2599
            %"val_2691"<?,?> ⬅️ ::Concat(%"val_2686", %"val_2683", %"val_2684") {axis=0}
    3846 |  # node_Reshape_2600
            %"val_2692"<?,?> ⬅️ ::Reshape(%"val_2690", %"val_2691") {allowzero=0}
    3847 |  # node_Sqrt_2601
            %"val_2693"<?,?> ⬅️ ::Sqrt(%"val_2680")
    3848 |  # node_Mul_2602
            %"val_2694"<?,?> ⬅️ ::Mul(%"view_51", %"val_2693")
    3849 |  # node_Sqrt_2603
            %"val_2695"<?,?> ⬅️ ::Sqrt(%"val_2680")
    3850 |  # node_Mul_2604
            %"val_2696"<?,?> ⬅️ ::Mul(%"val_2692", %"val_2695")
    3851 |  # node_MatMul_2605
            %"val_2697"<?,?> ⬅️ ::MatMul(%"val_2694", %"val_2696")
    3852 |  # node_Add_2606
            %"val_2698"<?,?> ⬅️ ::Add(%"val_2697", %"view_56")
    3853 |  # node_Softmax_2607
            %"val_2699"<?,?> ⬅️ ::Softmax(%"val_2698") {axis=-1}
    3854 |  # node_scaled_dot_product_attention_22
            %"scaled_dot_product_attention_22"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2699", %"view_53")
    3855 |  # node_permute_1
            %"permute_1"<FLOAT,[97,1,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_22") {perm=(2, 0, 1, 3)}
    3856 |  # node_Constant_2608
            %"val_2700"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[2]>(array([ 97, 768]), name=None)}
    3857 |  # node_Cast_2609
            %"val_2701"<?,?> ⬅️ ::Cast(%"val_2700") {to=7}
    3858 |  # node_view_57
            %"view_57"<FLOAT,[97,768]> ⬅️ ::Reshape(%"permute_1", %"val_2701") {allowzero=1}
    3859 |  # node_linear_89
            %"linear_89"<FLOAT,[97,768]> ⬅️ ::Gemm(%"view_57", %"head.layers.0.self_attn.out_proj.weight"{...}, %"head.layers.0.self_attn.out_proj.bias"{...}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    3860 |  # node_Constant_2610
            %"val_2702"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[3]>(array([ 97,   1, 768]), name=None)}
    3861 |  # node_Cast_2611
            %"val_2703"<?,?> ⬅️ ::Cast(%"val_2702") {to=7}
    3862 |  # node_view_58
            %"view_58"<FLOAT,[97,1,768]> ⬅️ ::Reshape(%"linear_89", %"val_2703") {allowzero=1}
    3863 |  # node_transpose_71
            %"transpose_71"<FLOAT,[1,97,768]> ⬅️ ::Transpose(%"view_58") {perm=(1, 0, 2)}
    3864 |  # node_clone_25
            %"clone_25"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"transpose_71")
    3865 |  # node_add_89
            %"add_89"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_88", %"clone_25")
    3866 |  # node_layer_norm_46
            %"layer_norm_46"<FLOAT,[1,97,768]>, %"val_2704"<?,?>, %"val_2705"<?,?> ⬅️ ::LayerNormalization(%"add_89", %"head.layers.0.norm2.weight"{...}, %"head.layers.0.norm2.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3867 |  # node_Transpose_2612
            %"val_2706"<?,?> ⬅️ ::Transpose(%"head.layers.0.linear1.weight"{...}) {perm=(1, 0)}
    3868 |  # node_MatMul_2613
            %"val_2707"<?,?> ⬅️ ::MatMul(%"layer_norm_46", %"val_2706")
    3869 |  # node_linear_90
            %"linear_90"<FLOAT,[1,97,3072]> ⬅️ ::Add(%"val_2707", %"head.layers.0.linear1.bias"{...})
    3870 |  # node_relu
            %"relu"<FLOAT,[1,97,3072]> ⬅️ ::Relu(%"linear_90")
    3871 |  # node_clone_26
            %"clone_26"<FLOAT,[1,97,3072]> ⬅️ ::Identity(%"relu")
    3872 |  # node_Transpose_2614
            %"val_2708"<?,?> ⬅️ ::Transpose(%"head.layers.0.linear2.weight"{...}) {perm=(1, 0)}
    3873 |  # node_MatMul_2615
            %"val_2709"<?,?> ⬅️ ::MatMul(%"clone_26", %"val_2708")
    3874 |  # node_linear_91
            %"linear_91"<FLOAT,[1,97,768]> ⬅️ ::Add(%"val_2709", %"head.layers.0.linear2.bias"{...})
    3875 |  # node_clone_27
            %"clone_27"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"linear_91")
    3876 |  # node_add_90
            %"add_90"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_89", %"clone_27")
    3877 |  # node_Cast_2616
            %"val_2710"<?,?> ⬅️ ::Cast(%"val_6") {to=1}
    3878 |  # node_Shape_2617
            %"val_2711"<?,?> ⬅️ ::Shape(%"bitwise_not") {start=0}
    3879 |  # node_zeros_like_1
            %"zeros_like_1"<FLOAT,[1,97]> ⬅️ ::Expand(%"val_2710", %"val_2711")
    3880 |  # node_CastLike_2618
            %"val_2712"<?,?> ⬅️ ::CastLike(%"val_2647", %"zeros_like_1")
    3881 |  # node_masked_fill_3
            %"masked_fill_3"<FLOAT,[1,97]> ⬅️ ::Where(%"bitwise_not", %"val_2712", %"zeros_like_1")
    3882 |  # node_layer_norm_47
            %"layer_norm_47"<FLOAT,[1,97,768]>, %"val_2713"<?,?>, %"val_2714"<?,?> ⬅️ ::LayerNormalization(%"add_90", %"head.layers.1.norm1.weight"{...}, %"head.layers.1.norm1.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3883 |  # node_transpose_72
            %"transpose_72"<FLOAT,[97,1,768]> ⬅️ ::Transpose(%"layer_norm_47") {perm=(1, 0, 2)}
    3884 |  # node_Transpose_2619
            %"val_2715"<?,?> ⬅️ ::Transpose(%"head.layers.1.self_attn.in_proj_weight"{...}) {perm=(1, 0)}
    3885 |  # node_MatMul_2620
            %"val_2716"<?,?> ⬅️ ::MatMul(%"transpose_72", %"val_2715")
    3886 |  # node_linear_92
            %"linear_92"<FLOAT,[97,1,2304]> ⬅️ ::Add(%"val_2716", %"head.layers.1.self_attn.in_proj_bias"{...})
    3887 |  # node_Cast_2621
            %"val_2717"<?,?> ⬅️ ::Cast(%"val_2653") {to=7}
    3888 |  # node_view_59
            %"view_59"<FLOAT,[97,1,3,768]> ⬅️ ::Reshape(%"linear_92", %"val_2717") {allowzero=1}
    3889 |  # node_unsqueeze_118
            %"unsqueeze_118"<FLOAT,[1,97,1,3,768]> ⬅️ ::Unsqueeze(%"view_59", %"val_5")
    3890 |  # node_transpose_73
            %"transpose_73"<FLOAT,[3,97,1,1,768]> ⬅️ ::Transpose(%"unsqueeze_118") {perm=(3, 1, 2, 0, 4)}
    3891 |  # node_squeeze_1
            %"squeeze_1"<FLOAT,[3,97,1,768]> ⬅️ ::Squeeze(%"transpose_73", %"val_806")
    3892 |  # node_clone_28
            %"clone_28"<FLOAT,[3,97,1,768]> ⬅️ ::Identity(%"squeeze_1")
    3893 |  # node_select_3
            %"select_3"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_28", %"val_6") {axis=0}
    3894 |  # node_select_4
            %"select_4"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_28", %"val_48") {axis=0}
    3895 |  # node_select_5
            %"select_5"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_28", %"val_72") {axis=0}
    3896 |  # node_Cast_2622
            %"val_2718"<?,?> ⬅️ ::Cast(%"val_2655") {to=7}
    3897 |  # node_view_60
            %"view_60"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_3", %"val_2718") {allowzero=1}
    3898 |  # node_transpose_74
            %"transpose_74"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_60") {perm=(1, 0, 2)}
    3899 |  # node_Cast_2623
            %"val_2719"<?,?> ⬅️ ::Cast(%"val_2655") {to=7}
    3900 |  # node_view_61
            %"view_61"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_4", %"val_2719") {allowzero=1}
    3901 |  # node_transpose_75
            %"transpose_75"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_61") {perm=(1, 0, 2)}
    3902 |  # node_Cast_2624
            %"val_2720"<?,?> ⬅️ ::Cast(%"val_2655") {to=7}
    3903 |  # node_view_62
            %"view_62"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_5", %"val_2720") {allowzero=1}
    3904 |  # node_transpose_76
            %"transpose_76"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_62") {perm=(1, 0, 2)}
    3905 |  # node_Cast_2625
            %"val_2721"<?,?> ⬅️ ::Cast(%"val_2659") {to=7}
    3906 |  # node_view_66
            %"view_66"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_74", %"val_2721") {allowzero=1}
    3907 |  # node_Cast_2626
            %"val_2722"<?,?> ⬅️ ::Cast(%"val_2659") {to=7}
    3908 |  # node_view_67
            %"view_67"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_75", %"val_2722") {allowzero=1}
    3909 |  # node_Cast_2627
            %"val_2723"<?,?> ⬅️ ::Cast(%"val_2659") {to=7}
    3910 |  # node_view_68
            %"view_68"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_76", %"val_2723") {allowzero=1}
    3911 |  # node_Cast_2628
            %"val_2724"<?,?> ⬅️ ::Cast(%"val_2663") {to=7}
    3912 |  # node_view_69
            %"view_69"<FLOAT,[1,1,1,97]> ⬅️ ::Reshape(%"masked_fill_3", %"val_2724") {allowzero=1}
    3913 |  # node_Cast_2629
            %"val_2725"<?,?> ⬅️ ::Cast(%"val_2665") {to=7}
    3914 |  # node_Abs_2630
            %"val_2726"<?,?> ⬅️ ::Abs(%"val_2725")
    3915 |  # node_expand_26
            %"expand_26"<FLOAT,[1,12,1,97]> ⬅️ ::Expand(%"view_69", %"val_2726")
    3916 |  # node_Cast_2631
            %"val_2727"<?,?> ⬅️ ::Cast(%"val_2668") {to=7}
    3917 |  # node_view_70
            %"view_70"<FLOAT,[12,1,97]> ⬅️ ::Reshape(%"expand_26", %"val_2727") {allowzero=1}
    3918 |  # node_Cast_2632
            %"val_2728"<?,?> ⬅️ ::Cast(%"val_2670") {to=7}
    3919 |  # node_view_71
            %"view_71"<FLOAT,[1,12,1,97]> ⬅️ ::Reshape(%"view_70", %"val_2728") {allowzero=1}
    3920 |  # node_Shape_2633
            %"val_2729"<?,?> ⬅️ ::Shape(%"view_66") {start=0}
    3921 |  # node_Constant_2634
            %"val_2730"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3922 |  # node_Gather_2635
            %"val_2731"<?,?> ⬅️ ::Gather(%"val_2729", %"val_2730") {axis=0}
    3923 |  # node_CastLike_2636
            %"val_2732"<?,?> ⬅️ ::CastLike(%"val_2731", %"view_66")
    3924 |  # node_Constant_2637
            %"val_2733"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3925 |  # node_CastLike_2638
            %"val_2734"<?,?> ⬅️ ::CastLike(%"val_2733", %"view_66")
    3926 |  # node_Sqrt_2639
            %"val_2735"<?,?> ⬅️ ::Sqrt(%"val_2732")
    3927 |  # node_Div_2640
            %"val_2736"<?,?> ⬅️ ::Div(%"val_2734", %"val_2735")
    3928 |  # node_CastLike_2641
            %"val_2737"<?,?> ⬅️ ::CastLike(%"val_2736", %"view_66")
    3929 |  # node_Shape_2642
            %"val_2738"<?,?> ⬅️ ::Shape(%"view_67") {start=0}
    3930 |  # node_Constant_2643
            %"val_2739"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3931 |  # node_Slice_2644
            %"val_2740"<?,?> ⬅️ ::Slice(%"val_2738", %"val_804", %"val_2739")
    3932 |  # node_Slice_2645
            %"val_2741"<?,?> ⬅️ ::Slice(%"val_2738", %"val_806", %"val_804")
    3933 |  # node_Constant_2646
            %"val_2742"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3934 |  # node_Slice_2647
            %"val_2743"<?,?> ⬅️ ::Slice(%"val_2738", %"val_2742", %"val_806")
    3935 |  # node_Constant_2648
            %"val_2744"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3936 |  # node_Concat_2649
            %"val_2745"<?,?> ⬅️ ::Concat(%"val_2744", %"val_2741", %"val_2740") {axis=0}
    3937 |  # node_Reshape_2650
            %"val_2746"<?,?> ⬅️ ::Reshape(%"view_67", %"val_2745") {allowzero=0}
    3938 |  # node_Transpose_2651
            %"val_2747"<?,?> ⬅️ ::Transpose(%"val_2746") {perm=(0, 2, 1)}
    3939 |  # node_Concat_2652
            %"val_2748"<?,?> ⬅️ ::Concat(%"val_2743", %"val_2740", %"val_2741") {axis=0}
    3940 |  # node_Reshape_2653
            %"val_2749"<?,?> ⬅️ ::Reshape(%"val_2747", %"val_2748") {allowzero=0}
    3941 |  # node_Sqrt_2654
            %"val_2750"<?,?> ⬅️ ::Sqrt(%"val_2737")
    3942 |  # node_Mul_2655
            %"val_2751"<?,?> ⬅️ ::Mul(%"view_66", %"val_2750")
    3943 |  # node_Sqrt_2656
            %"val_2752"<?,?> ⬅️ ::Sqrt(%"val_2737")
    3944 |  # node_Mul_2657
            %"val_2753"<?,?> ⬅️ ::Mul(%"val_2749", %"val_2752")
    3945 |  # node_MatMul_2658
            %"val_2754"<?,?> ⬅️ ::MatMul(%"val_2751", %"val_2753")
    3946 |  # node_Add_2659
            %"val_2755"<?,?> ⬅️ ::Add(%"val_2754", %"view_71")
    3947 |  # node_Softmax_2660
            %"val_2756"<?,?> ⬅️ ::Softmax(%"val_2755") {axis=-1}
    3948 |  # node_scaled_dot_product_attention_23
            %"scaled_dot_product_attention_23"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2756", %"view_68")
    3949 |  # node_permute_2
            %"permute_2"<FLOAT,[97,1,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_23") {perm=(2, 0, 1, 3)}
    3950 |  # node_Cast_2661
            %"val_2757"<?,?> ⬅️ ::Cast(%"val_2700") {to=7}
    3951 |  # node_view_72
            %"view_72"<FLOAT,[97,768]> ⬅️ ::Reshape(%"permute_2", %"val_2757") {allowzero=1}
    3952 |  # node_linear_93
            %"linear_93"<FLOAT,[97,768]> ⬅️ ::Gemm(%"view_72", %"head.layers.1.self_attn.out_proj.weight"{...}, %"head.layers.1.self_attn.out_proj.bias"{...}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    3953 |  # node_Cast_2662
            %"val_2758"<?,?> ⬅️ ::Cast(%"val_2702") {to=7}
    3954 |  # node_view_73
            %"view_73"<FLOAT,[97,1,768]> ⬅️ ::Reshape(%"linear_93", %"val_2758") {allowzero=1}
    3955 |  # node_transpose_77
            %"transpose_77"<FLOAT,[1,97,768]> ⬅️ ::Transpose(%"view_73") {perm=(1, 0, 2)}
    3956 |  # node_clone_29
            %"clone_29"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"transpose_77")
    3957 |  # node_add_91
            %"add_91"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_90", %"clone_29")
    3958 |  # node_layer_norm_48
            %"layer_norm_48"<FLOAT,[1,97,768]>, %"val_2759"<?,?>, %"val_2760"<?,?> ⬅️ ::LayerNormalization(%"add_91", %"head.layers.1.norm2.weight"{...}, %"head.layers.1.norm2.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3959 |  # node_Transpose_2663
            %"val_2761"<?,?> ⬅️ ::Transpose(%"head.layers.1.linear1.weight"{...}) {perm=(1, 0)}
    3960 |  # node_MatMul_2664
            %"val_2762"<?,?> ⬅️ ::MatMul(%"layer_norm_48", %"val_2761")
    3961 |  # node_linear_94
            %"linear_94"<FLOAT,[1,97,3072]> ⬅️ ::Add(%"val_2762", %"head.layers.1.linear1.bias"{...})
    3962 |  # node_relu_1
            %"relu_1"<FLOAT,[1,97,3072]> ⬅️ ::Relu(%"linear_94")
    3963 |  # node_clone_30
            %"clone_30"<FLOAT,[1,97,3072]> ⬅️ ::Identity(%"relu_1")
    3964 |  # node_Transpose_2665
            %"val_2763"<?,?> ⬅️ ::Transpose(%"head.layers.1.linear2.weight"{...}) {perm=(1, 0)}
    3965 |  # node_MatMul_2666
            %"val_2764"<?,?> ⬅️ ::MatMul(%"clone_30", %"val_2763")
    3966 |  # node_linear_95
            %"linear_95"<FLOAT,[1,97,768]> ⬅️ ::Add(%"val_2764", %"head.layers.1.linear2.bias"{...})
    3967 |  # node_clone_31
            %"clone_31"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"linear_95")
    3968 |  # node_add_92
            %"add_92"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_91", %"clone_31")
    3969 |  # node_CastLike_2667
            %"val_2765"<?,?> ⬅️ ::CastLike(%"val_6", %"marker_pos")
    3970 |  # node_clamp
            %"clamp"<INT64,[1,3]> ⬅️ ::Clip(%"marker_pos", %"val_2765")
    3971 |  # node_Cast_2668
            %"val_2766"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3972 |  # node_Constant_2669
            %"val_2767"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3973 |  # node_Reshape_2670
            %"val_2768"<?,?> ⬅️ ::Reshape(%"val_2766", %"val_2767") {allowzero=0}
    3974 |  # node_Cast_2671
            %"val_2769"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3975 |  # node_Constant_2672
            %"val_2770"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3976 |  # node_Reshape_2673
            %"val_2771"<?,?> ⬅️ ::Reshape(%"val_2769", %"val_2770") {allowzero=0}
    3977 |  # node_Cast_2674
            %"val_2772"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3978 |  # node_Constant_2675
            %"val_2773"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3979 |  # node_Reshape_2676
            %"val_2774"<?,?> ⬅️ ::Reshape(%"val_2772", %"val_2773") {allowzero=0}
    3980 |  # node_Constant_2677
            %"val_2775"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3981 |  # node_slice_159
            %"slice_159"<INT64,[1,3]> ⬅️ ::Slice(%"clamp", %"val_2768", %"val_2771", %"val_2774", %"val_2775")
    3982 |  # node_Cast_2678
            %"val_2776"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3983 |  # node_Constant_2679
            %"val_2777"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3984 |  # node_Reshape_2680
            %"val_2778"<?,?> ⬅️ ::Reshape(%"val_2776", %"val_2777") {allowzero=0}
    3985 |  # node_Cast_2681
            %"val_2779"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3986 |  # node_Constant_2682
            %"val_2780"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3987 |  # node_Reshape_2683
            %"val_2781"<?,?> ⬅️ ::Reshape(%"val_2779", %"val_2780") {allowzero=0}
    3988 |  # node_Cast_2684
            %"val_2782"<?,?> ⬅️ ::Cast(%"val_48") {to=7}
    3989 |  # node_Constant_2685
            %"val_2783"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3990 |  # node_Reshape_2686
            %"val_2784"<?,?> ⬅️ ::Reshape(%"val_2782", %"val_2783") {allowzero=0}
    3991 |  # node_Constant_2687
            %"val_2785"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3992 |  # node_slice_160
            %"slice_160"<INT64,[1,3]> ⬅️ ::Slice(%"slice_159", %"val_2778", %"val_2781", %"val_2784", %"val_2785")
    3993 |  # node_unsqueeze_119
            %"unsqueeze_119"<INT64,[1,3,1]> ⬅️ ::Unsqueeze(%"slice_160", %"val_19")
    3994 |  # node_Constant_2688
            %"val_2786"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[3]>(array([ -1,  -1, 768]), name=None)}
    3995 |  # node_Cast_2689
            %"val_2787"<?,?> ⬅️ ::Cast(%"val_2786") {to=7}
    3996 |  # node_Abs_2690
            %"val_2788"<?,?> ⬅️ ::Abs(%"val_2787")
    3997 |  # node_expand_27
            %"expand_27"<INT64,[1,3,768]> ⬅️ ::Expand(%"unsqueeze_119", %"val_2788")
    3998 |  # node_Cast_2691
            %"val_2789"<?,?> ⬅️ ::Cast(%"expand_27") {to=7}
    3999 |  # node_gather
            %"gather"<FLOAT,[1,3,768]> ⬅️ ::GatherElements(%"add_92", %"val_2789") {axis=1}
    4000 |  # node_layer_norm_49
            %"layer_norm_49"<FLOAT,[1,3,768]>, %"val_2790"<?,?>, %"val_2791"<?,?> ⬅️ ::LayerNormalization(%"gather", %"scorer.0.weight"{...}, %"scorer.0.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4001 |  # node_Transpose_2692
            %"val_2792"<?,?> ⬅️ ::Transpose(%"scorer.1.weight"{...}) {perm=(1, 0)}
    4002 |  # node_MatMul_2693
            %"val_2793"<?,?> ⬅️ ::MatMul(%"layer_norm_49", %"val_2792")
    4003 |  # node_linear_96
            %"linear_96"<FLOAT,[1,3,768]> ⬅️ ::Add(%"val_2793", %"scorer.1.bias"{...})
    4004 |  # node_Constant_2694
            %"val_2794"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    4005 |  # node_Div_2695
            %"val_2795"<?,?> ⬅️ ::Div(%"linear_96", %"val_2794")
    4006 |  # node_Erf_2696
            %"val_2796"<?,?> ⬅️ ::Erf(%"val_2795")
    4007 |  # node_Constant_2697
            %"val_2797"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    4008 |  # node_Add_2698
            %"val_2798"<?,?> ⬅️ ::Add(%"val_2796", %"val_2797")
    4009 |  # node_Constant_2699
            %"val_2799"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    4010 |  # node_Mul_2700
            %"val_2800"<?,?> ⬅️ ::Mul(%"val_2799", %"val_2798")
    4011 |  # node_gelu_22
            %"gelu_22"<FLOAT,[1,3,768]> ⬅️ ::Mul(%"linear_96", %"val_2800")
    4012 |  # node_Transpose_2701
            %"val_2801"<?,?> ⬅️ ::Transpose(%"scorer.3.weight"{...}) {perm=(1, 0)}
    4013 |  # node_MatMul_2702
            %"val_2802"<?,?> ⬅️ ::MatMul(%"gelu_22", %"val_2801")
    4014 |  # node_linear_97
            %"linear_97"<FLOAT,[1,3,1]> ⬅️ ::Add(%"val_2802", %"scorer.3.bias"{[0.0258636474609375]})
    4015 |  # node_squeeze_2
            %"squeeze_2"<FLOAT,[1,3]> ⬅️ ::Squeeze(%"linear_97", %"val_804")
    4016 |  # node_bitwise_not_1
            %"bitwise_not_1"<BOOL,[1,3]> ⬅️ ::Not(%"marker_mask")
    4017 |  # node_Constant_2703
            %"val_2803"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(-10000., dtype=float32), name=None)}
    4018 |  # node_CastLike_2704
            %"val_2804"<?,?> ⬅️ ::CastLike(%"val_2803", %"squeeze_2")
    4019 |  # node_masked_fill_4
            %"logits"<FLOAT,[1,3]> ⬅️ ::Where(%"bitwise_not_1", %"val_2804", %"squeeze_2")
    4020 |  # node_detach
            %"detach"<FLOAT,[1,3]> ⬅️ ::Identity(%"logits")
    4021 |  # node_detach_1
            %"detach_1"<FLOAT,[1,3]> ⬅️ ::Identity(%"detach")
    4022 |  # node_detach_2
            %"detach_2"<FLOAT,[1,3]> ⬅️ ::Identity(%"detach_1")
    4023 |  # node_softmax
            %"softmax"<FLOAT,[1,3]> ⬅️ ::Softmax(%"detach_2") {axis=-1}
    4024 |  # node_convert_element_type_default
            %"convert_element_type_default"<INT64,[1,3]> ⬅️ ::Cast(%"marker_mask") {to=7}
    4025 |  # node_Constant_2705
            %"val_2805"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4026 |  # node_Reshape_2706
            %"val_2806"<?,?> ⬅️ ::Reshape(%"val_804", %"val_2805") {allowzero=0}
    4027 |  # node_Cast_2707
            %"val_2807"<?,?> ⬅️ ::Cast(%"val_2806") {to=7}
    4028 |  # node_sum_1
            %"sum_1"<INT64,[1]> ⬅️ ::ReduceSum(%"convert_element_type_default", %"val_2807") {noop_with_empty_axes=0, keepdims=0}
    4029 |  # node_CastLike_2708
            %"val_2808"<?,?> ⬅️ ::CastLike(%"val_72", %"sum_1")
    4030 |  # node_clamp_1
            %"clamp_1"<INT64,[1]> ⬅️ ::Clip(%"sum_1", %"val_2808")
    4031 |  # node__to_copy_25
            %"_to_copy_25"<FLOAT,[1]> ⬅️ ::Cast(%"clamp_1") {to=1}
    4032 |  # node_Constant_2709
            %"val_2809"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.e-09, dtype=float32), name=None)}
    4033 |  # node_CastLike_2710
            %"val_2810"<?,?> ⬅️ ::CastLike(%"val_2809", %"softmax")
    4034 |  # node_clamp_min
            %"clamp_min"<FLOAT,[1,3]> ⬅️ ::Clip(%"softmax", %"val_2810")
    4035 |  # node_log
            %"log"<FLOAT,[1,3]> ⬅️ ::Log(%"clamp_min")
    4036 |  # node_mul_154
            %"mul_154"<FLOAT,[1,3]> ⬅️ ::Mul(%"softmax", %"log")
    4037 |  # node_Constant_2711
            %"val_2811"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4038 |  # node_Reshape_2712
            %"val_2812"<?,?> ⬅️ ::Reshape(%"val_804", %"val_2811") {allowzero=0}
    4039 |  # node_Cast_2713
            %"val_2813"<?,?> ⬅️ ::Cast(%"val_2812") {to=7}
    4040 |  # node_sum_2
            %"sum_2"<FLOAT,[1]> ⬅️ ::ReduceSum(%"mul_154", %"val_2813") {noop_with_empty_axes=0, keepdims=0}
    4041 |  # node_neg_44
            %"neg_44"<FLOAT,[1]> ⬅️ ::Neg(%"sum_2")
    4042 |  # node_log_1
            %"log_1"<FLOAT,[1]> ⬅️ ::Log(%"_to_copy_25")
    4043 |  # node_div
            %"div"<FLOAT,[1]> ⬅️ ::Div(%"neg_44", %"log_1")
    4044 |  # node_topk__1
            %"getitem_110"<FLOAT,[1,2]>, %"topk__1"<INT64,[1,2]> ⬅️ ::TopK(%"softmax", %"val_19") {sorted=1, largest=1, axis=-1}
    4045 |  # node_Constant_2714
            %"val_2814"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4046 |  # node_Constant_2715
            %"val_2815"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4047 |  # node_Cast_2716
            %"val_2816"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4048 |  # node_Constant_2717
            %"val_2817"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4049 |  # node_Reshape_2718
            %"val_2818"<?,?> ⬅️ ::Reshape(%"val_2816", %"val_2817") {allowzero=0}
    4050 |  # node_Constant_2719
            %"val_2819"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4051 |  # node_slice_161
            %"slice_161"<FLOAT,[1,2]> ⬅️ ::Slice(%"getitem_110", %"val_2814", %"val_2815", %"val_2818", %"val_2819")
    4052 |  # node_select_6
            %"select_6"<FLOAT,[1]> ⬅️ ::Gather(%"slice_161", %"val_6") {axis=1}
    4053 |  # node_Constant_2720
            %"val_2820"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4054 |  # node_Constant_2721
            %"val_2821"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4055 |  # node_Cast_2722
            %"val_2822"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4056 |  # node_Constant_2723
            %"val_2823"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4057 |  # node_Reshape_2724
            %"val_2824"<?,?> ⬅️ ::Reshape(%"val_2822", %"val_2823") {allowzero=0}
    4058 |  # node_Constant_2725
            %"val_2825"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4059 |  # node_slice_162
            %"slice_162"<FLOAT,[1,2]> ⬅️ ::Slice(%"getitem_110", %"val_2820", %"val_2821", %"val_2824", %"val_2825")
    4060 |  # node_select_7
            %"select_7"<FLOAT,[1]> ⬅️ ::Gather(%"slice_162", %"val_6") {axis=1}
    4061 |  # node_Constant_2726
            %"val_2826"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4062 |  # node_Constant_2727
            %"val_2827"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4063 |  # node_Cast_2728
            %"val_2828"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4064 |  # node_Constant_2729
            %"val_2829"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4065 |  # node_Reshape_2730
            %"val_2830"<?,?> ⬅️ ::Reshape(%"val_2828", %"val_2829") {allowzero=0}
    4066 |  # node_Constant_2731
            %"val_2831"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4067 |  # node_slice_163
            %"slice_163"<FLOAT,[1,2]> ⬅️ ::Slice(%"getitem_110", %"val_2826", %"val_2827", %"val_2830", %"val_2831")
    4068 |  # node_select_8
            %"select_8"<FLOAT,[1]> ⬅️ ::Gather(%"slice_163", %"val_48") {axis=1}
    4069 |  # node_sub_2
            %"sub_2"<FLOAT,[1]> ⬅️ ::Sub(%"select_7", %"select_8")
    4070 |  # node_Constant_2732
            %"val_2832"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(255., dtype=float32), name=None)}
    4071 |  # node_div_1
            %"div_1"<FLOAT,[1]> ⬅️ ::Div(%"_to_copy_25", %"val_2832")
    4072 |  # node_Constant_2733
            %"val_2833"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4073 |  # node_Unsqueeze_2734
            %"val_2834"<?,?> ⬅️ ::Unsqueeze(%"select_6", %"val_2833")
    4074 |  # node_Constant_2735
            %"val_2835"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4075 |  # node_Unsqueeze_2736
            %"val_2836"<?,?> ⬅️ ::Unsqueeze(%"sub_2", %"val_2835")
    4076 |  # node_Constant_2737
            %"val_2837"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4077 |  # node_Unsqueeze_2738
            %"val_2838"<?,?> ⬅️ ::Unsqueeze(%"div", %"val_2837")
    4078 |  # node_Constant_2739
            %"val_2839"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4079 |  # node_Unsqueeze_2740
            %"val_2840"<?,?> ⬅️ ::Unsqueeze(%"div_1", %"val_2839")
    4080 |  # node_stack
            %"stack"<FLOAT,[1,4]> ⬅️ ::Concat(%"val_2834", %"val_2836", %"val_2838", %"val_2840") {axis=-1}
    4081 |  # node_Constant_2741
            %"val_2841"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4082 |  # node_Constant_2742
            %"val_2842"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4083 |  # node_Cast_2743
            %"val_2843"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4084 |  # node_Constant_2744
            %"val_2844"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4085 |  # node_Reshape_2745
            %"val_2845"<?,?> ⬅️ ::Reshape(%"val_2843", %"val_2844") {allowzero=0}
    4086 |  # node_Constant_2746
            %"val_2846"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4087 |  # node_slice_164
            %"slice_164"<FLOAT,[1,97,768]> ⬅️ ::Slice(%"add_92", %"val_2841", %"val_2842", %"val_2845", %"val_2846")
    4088 |  # node_select_9
            %"select_9"<FLOAT,[1,768]> ⬅️ ::Gather(%"slice_164", %"val_6") {axis=1}
    4089 |  # node_cat_66
            %"cat_66"<FLOAT,[1,772]> ⬅️ ::Concat(%"select_9", %"stack") {axis=-1}
    4090 |  # node_linear_98
            %"linear_98"<FLOAT,[1,256]> ⬅️ ::Gemm(%"cat_66", %"act_head.0.weight"{...}, %"act_head.0.bias"{...}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    4091 |  # node_Constant_2747
            %"val_2847"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    4092 |  # node_Div_2748
            %"val_2848"<?,?> ⬅️ ::Div(%"linear_98", %"val_2847")
    4093 |  # node_Erf_2749
            %"val_2849"<?,?> ⬅️ ::Erf(%"val_2848")
    4094 |  # node_Constant_2750
            %"val_2850"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    4095 |  # node_Add_2751
            %"val_2851"<?,?> ⬅️ ::Add(%"val_2849", %"val_2850")
    4096 |  # node_Constant_2752
            %"val_2852"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    4097 |  # node_Mul_2753
            %"val_2853"<?,?> ⬅️ ::Mul(%"val_2852", %"val_2851")
    4098 |  # node_gelu_23
            %"gelu_23"<FLOAT,[1,256]> ⬅️ ::Mul(%"linear_98", %"val_2853")
    4099 |  # node_linear_99
            %"act_logits"<FLOAT,[1,2]> ⬅️ ::Gemm(%"gelu_23", %"act_head.2.weight"{...}, %"act_head.2.bias"{[0.023529052734375, -0.0204925537109375]}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    return %"logits"<FLOAT,[1,3]>, %"act_logits"<FLOAT,[1,2]>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib::aten_unbind(
    inputs=(
        %"self"<?,?>
    ),
    attributes={
        dim: INT = 0
    }
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"split_sizes"<?,?> ⬅️ ::Constant() {value_int=1}
    1 |  # n1
         %"return_val"<?,?> ⬅️ ::SplitToSequence(%"self", %"split_sizes") {keepdims=0, axis=@dim}
    return %"return_val"<?,?>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib::aten_getitem(
    inputs=(
        %"self"<?,?>,
        %"i"<?,?>
    ),
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"return_val"<?,?> ⬅️ ::SequenceAt(%"self", %"i")
    return %"return_val"<?,?>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib::aten_split(
    inputs=(
        %"self"<?,?>,
        %"split_size"<?,?>
    ),
    attributes={
        dim: INT = 0
    }
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"return_val"<?,?> ⬅️ ::SplitToSequence(%"self", %"split_size") {axis=@dim}
    return %"return_val"<?,?>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib.common::Rank(
    inputs=(
        %"input"<?,?>
    ),
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"tmp"<?,?> ⬅️ ::Shape(%"input")
    1 |  # n1
         %"return_val"<?,?> ⬅️ ::Size(%"tmp")
    return %"return_val"<?,?>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib.common::IsScalar(
    inputs=(
        %"input"<?,?>
    ),
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"tmp"<?,?> ⬅️ ::Shape(%"input")
    1 |  # n1
         %"tmp_0"<?,?> ⬅️ ::Size(%"tmp")
    2 |  # n2
         %"tmp_1"<?,?> ⬅️ ::Constant() {value_int=0}
    3 |  # n3
         %"return_val"<?,?> ⬅️ ::Equal(%"tmp_0", %"tmp_1")
    return %"return_val"<?,?>
}
```

## Analysis

PyTorch ONNX Conversion Analysis

## Model Information

The model has 321908995 parameters and 131 buffers (non-trainable parameters).
Number of parameters per dtype:
```python
defaultdict(<class 'int'>, {torch.float32: 321908995})
```
Number of buffers per dtype:
```python
defaultdict(<class 'int'>, {torch.float32: 131})
```

Inputs:
- `input_ids`: `TensorMetadata(shape=torch.Size([1, 97]), dtype=torch.int64, requires_grad=False, stride=(97, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `attention_mask`: `TensorMetadata(shape=torch.Size([1, 97]), dtype=torch.int64, requires_grad=False, stride=(97, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `marker_pos`: `TensorMetadata(shape=torch.Size([1, 3]), dtype=torch.int64, requires_grad=False, stride=(3, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `marker_mask`: `TensorMetadata(shape=torch.Size([1, 3]), dtype=torch.bool, requires_grad=False, stride=(3, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `qtype`: `TensorMetadata(shape=torch.Size([1]), dtype=torch.int64, requires_grad=False, stride=(1,), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`

Outputs:
- `masked_fill_4`: `TensorMetadata(shape=torch.Size([1, 3]), dtype=torch.float32, requires_grad=False, stride=(3, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `linear_99`: `TensorMetadata(shape=torch.Size([1, 2]), dtype=torch.float32, requires_grad=False, stride=(2, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`

The FX graph has 1528 nodes in total. Number of FX nodes per op:
- `placeholder`: 180
- `call_function`: 1347
- `output`: 1


Of the call_function nodes, the counts of operators used are:

- `aten.slice.Tensor`: 164
- `aten.mul.Tensor`: 155
- `aten.unsqueeze.default`: 120
- `<built-in function getitem>`: 111
- `aten.linear.default`: 100
- `aten.add.Tensor`: 93
- `aten.transpose.int`: 78
- `aten.view.default`: 68
- `aten.cat.default`: 67
- `aten.layer_norm.default`: 50
- `aten.neg.default`: 45
- `aten.clone.default`: 32
- `aten.expand.default`: 26
- `aten._to_copy.default`: 26
- `aten.scaled_dot_product_attention.default`: 24
- `aten.gelu.default`: 24
- `aten.matmul.default`: 22
- `aten.cos.default`: 22
- `aten.sin.default`: 22
- `aten.unbind.int`: 22
- `aten.split.Tensor`: 22
- `aten.select.int`: 10
- `aten.masked_fill.Scalar`: 5
- `aten.sub.Tensor`: 3
- `aten.permute.default`: 3
- `aten.squeeze.dim`: 3
- `aten.detach.default`: 3
- `aten.arange.default`: 2
- `aten.embedding.default`: 2
- `aten.bitwise_not.default`: 2
- `aten.zeros_like.default`: 2
- `aten.relu.default`: 2
- `aten.clamp.default`: 2
- `aten.sum.dim_IntList`: 2
- `aten.log.default`: 2
- `aten.div.Tensor`: 2
- `aten.abs.default`: 1
- `aten.le.Scalar`: 1
- `aten.logical_not.default`: 1
- `aten.gather.default`: 1
- `aten.softmax.int`: 1
- `prims.convert_element_type.default`: 1
- `aten.clamp_min.default`: 1
- `aten.topk.default`: 1
- `aten.stack.default`: 1

## ONNX Conversion Information

All operators in the model have registered ONNX decompositions.

## Decomposition comparison

Ops exist only in the ExportedProgram before decomposition: `['aten._assert_tensor_metadata.default', 'aten.chunk.default', 'aten.contiguous.default', 'aten.detach_.default', 'aten.dropout.default', 'aten.lift_fresh_copy.default', 'aten.masked_fill_.Scalar', 'aten.numpy_T.default', 'aten.reshape.default', 'aten.sym_size.int', 'aten.to.dtype', 'aten.to.dtype_layout', 'aten.unflatten.int', 'wrap_with_set_grad_enabled']`

Ops exist only in the ExportedProgram after decomposition: `['aten._to_copy.default', 'aten.clone.default', 'aten.cos.default', 'aten.matmul.default', 'aten.sin.default', 'aten.split.Tensor', 'prims.convert_element_type.default']`

