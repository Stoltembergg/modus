# PyTorch ONNX Conversion Report

```
❌ Obtain model graph with `torch.export.export(..., strict=False)`
❌ Obtain model graph with `torch.export.export(..., strict=True)`
✅ Obtain model graph with `torch.export._draft_export.draft_export`
✅ Decompose operators for ONNX compatibility
✅ Translate the graph into ONNX
⚪ Run `onnx.checker` on the ONNX model
⚪ Execute the model with ONNX Runtime
⚪ Validate model output accuracy
```

## Error messages

```pytb
# ⚠️ Errors from strategy 'TorchExportNonStrictStrategy': -----------------------

Traceback (most recent call last):

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 118, in __call__
    exported_program = self._capture(model, args, kwargs, dynamic_shapes)
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 225, in _capture
    raise exc from None

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 210, in _capture
    return torch.export.export(
           ^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 319, in export
    raise e

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 286, in export
    return _export(
           ^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2176, in _export
    ep = _export_for_training(
         ^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2037, in _export_for_training
    export_artifact = export_func(
                      ^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1979, in _non_strict_export
    aten_export_artifact = _to_aten_func(  # type: ignore[operator]
                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1800, in _export_to_aten_ir_make_fx
    raise UserError(UserErrorType.CONSTRAINT_VIOLATION, str(e))  # noqa: B904
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

torch._dynamo.exc.UserError: Constraints violated (sequence)! For more information, run with TORCH_LOGS="+dynamic".
  - Not all values of sequence = L['input_ids'].size()[1] in the specified range sequence <= 1024 satisfy the generated guard 1 != L['input_ids'].size()[1].

The error above occurred when calling torch.export.export. If you would like to view some more information about this error, and get a list of all other errors that may occur in your export call, you can replace your `export()` call with `draft_export()`.


# ⚠️ Errors from strategy 'TorchExportStrictStrategy': -----------------------

Traceback (most recent call last):

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 118, in __call__
    exported_program = self._capture(model, args, kwargs, dynamic_shapes)
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 176, in _capture
    raise exc from None

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/onnx/_internal/exporter/_capture_strategies.py", line 161, in _capture
    return torch.export.export(
           ^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 319, in export
    raise e

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/__init__.py", line 286, in export
    return _export(
           ^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2176, in _export
    ep = _export_for_training(
         ^^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1164, in wrapper
    raise e

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1130, in wrapper
    ep = fn(*args, **kwargs)
         ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/exported_program.py", line 123, in wrapper
    return fn(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 2037, in _export_for_training
    export_artifact = export_func(
                      ^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 1411, in _strict_export
    gm_torch_level = _export_to_torch_ir(
                     ^^^^^^^^^^^^^^^^^^^^

  File "/workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/export/_trace.py", line 815, in _export_to_torch_ir
    raise UserError(UserErrorType.CONSTRAINT_VIOLATION, str(e))  # noqa: B904
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

torch._dynamo.exc.UserError: Constraints violated (sequence)! For more information, run with TORCH_LOGS="+dynamic".
  - Not all values of sequence = L['input_ids'].size()[1] in the specified range sequence <= 1024 satisfy the generated guard 1 != L['input_ids'].size()[1].


The error above occurred when calling torch.export.export. If you would like to view some more information about this error, and get a list of all other errors that may occur in your export call, you can replace your `export()` call with `draft_export()`.


# ⚠️ Errors from strategy 'TorchExportDraftExportStrategy': -----------------------

RuntimeError: [93m
###################################################################################################
WARNING: 2 issue(s) found during export, and it was not able to soundly produce a graph.
Please follow the instructions to fix the errors.
###################################################################################################

1. Guard Added.
    A guard was added during tracing, which might've resulted in some incorrect
    tracing or constraint violation error.
    Specifically, this guard was added: Eq(s53, s70), where {'s70': "L['input_ids'].size()[1]", 's53': "L['attention_mask'].size()[1]"}.
    This occurred at the following stacktrace: 
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/module.py, lineno 1784, in _call_impl
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py, lineno 550, in forward
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py, lineno 465, in sdpa_attention_forward
            F.scaled_dot_product_attention(:
        
        Locals:
            query: ['Tensor(shape: torch.Size([1, 12, s70, 64]), stride: (768*s70, 64, 768, 1), storage_offset: 0)']
            key: ['Tensor(shape: torch.Size([1, 12, s70, 64]), stride: (768*s70, 64, 768, 1), storage_offset: 0)']
            value: ['Tensor(shape: torch.Size([1, 12, s70, 64]), stride: (2304*s70, 64, 2304, 1), storage_offset: 1536)']
            module: [None]
            attention_mask: ['Tensor(shape: torch.Size([1, 1, s53, s53]), stride: (s53**2, s53**2, s53, 1), storage_offset: 0)']

        Symbols:
           s70: L['input_ids'].size()[1]
           s53: L['attention_mask'].size()[1]

    And the following framework stacktrace: 
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/fx/experimental/proxy_tensor.py, lineno 1462, in __torch_dispatch__
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/fx/experimental/proxy_tensor.py, lineno 914, in proxy_call
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/_ops.py, lineno 829, in __call__
            return self._op(*args, **kwargs)

    Because of this, we have modified the dynamic shapes structure to be the
    following. You can also use torch.export.Dim.AUTO instead to specify your
    dynamic shapes, and we will automatically infer the dynamism for you.
    ```
    dynamic_shapes = ({1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, {1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, None, None, None)
    ```

2. Guard Added.
    A guard was added during tracing, which might've resulted in some incorrect
    tracing or constraint violation error.
    Specifically, this guard was added: Eq(768*s53, 74496), where {'s53': "L['attention_mask'].size()[1]"}.
    This occurred at the following stacktrace: 
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/module.py, lineno 1773, in _wrapped_call_impl
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/module.py, lineno 1784, in _call_impl
        File /workspace/scratch/thx01-m1/snapshot/thx01/common.py, lineno 113, in forward
            h = layer(h, src_key_padding_mask=pad):
        
        Locals:
            layer: [None]
            h: ['Tensor(shape: torch.Size([1, s53, 768]), stride: (768*s53, 768, 1), storage_offset: 0)']
            pad: ['Tensor(shape: torch.Size([1, s53]), stride: (s53, 1), storage_offset: 0)']

        Symbols:
           s53: L['attention_mask'].size()[1]

    And the following framework stacktrace: 
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/_ops.py, lineno 829, in __call__
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/utils/_stats.py, lineno 28, in wrapper
        File /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/_subclasses/fake_utils.py, lineno 193, in _check_fake_real_tensors
            if r_offset != f_offset:

    Because of this, we have modified the dynamic shapes structure to be the
    following. You can also use torch.export.Dim.AUTO instead to specify your
    dynamic shapes, and we will automatically infer the dynamism for you.
    ```
    dynamic_shapes = ({1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, {1: _DimHint(type=<_DimHintType.AUTO: 1>, min=1, max=1024, _factory=False)}, None, None, None)
    ```

[0m


```

## Exported program

```python
ExportedProgram:
    class GraphModule(torch.nn.Module):
        def forward(self, p_encoder_embeddings_tok_embeddings_weight: "f32[256000, 768]", p_encoder_embeddings_norm_weight: "f32[768]", p_encoder_layers_0_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_0_attn_wo_weight: "f32[768, 768]", p_encoder_layers_0_mlp_norm_weight: "f32[768]", p_encoder_layers_0_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_0_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_1_attn_norm_weight: "f32[768]", p_encoder_layers_1_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_1_attn_wo_weight: "f32[768, 768]", p_encoder_layers_1_mlp_norm_weight: "f32[768]", p_encoder_layers_1_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_1_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_2_attn_norm_weight: "f32[768]", p_encoder_layers_2_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_2_attn_wo_weight: "f32[768, 768]", p_encoder_layers_2_mlp_norm_weight: "f32[768]", p_encoder_layers_2_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_2_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_3_attn_norm_weight: "f32[768]", p_encoder_layers_3_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_3_attn_wo_weight: "f32[768, 768]", p_encoder_layers_3_mlp_norm_weight: "f32[768]", p_encoder_layers_3_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_3_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_4_attn_norm_weight: "f32[768]", p_encoder_layers_4_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_4_attn_wo_weight: "f32[768, 768]", p_encoder_layers_4_mlp_norm_weight: "f32[768]", p_encoder_layers_4_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_4_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_5_attn_norm_weight: "f32[768]", p_encoder_layers_5_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_5_attn_wo_weight: "f32[768, 768]", p_encoder_layers_5_mlp_norm_weight: "f32[768]", p_encoder_layers_5_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_5_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_6_attn_norm_weight: "f32[768]", p_encoder_layers_6_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_6_attn_wo_weight: "f32[768, 768]", p_encoder_layers_6_mlp_norm_weight: "f32[768]", p_encoder_layers_6_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_6_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_7_attn_norm_weight: "f32[768]", p_encoder_layers_7_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_7_attn_wo_weight: "f32[768, 768]", p_encoder_layers_7_mlp_norm_weight: "f32[768]", p_encoder_layers_7_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_7_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_8_attn_norm_weight: "f32[768]", p_encoder_layers_8_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_8_attn_wo_weight: "f32[768, 768]", p_encoder_layers_8_mlp_norm_weight: "f32[768]", p_encoder_layers_8_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_8_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_9_attn_norm_weight: "f32[768]", p_encoder_layers_9_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_9_attn_wo_weight: "f32[768, 768]", p_encoder_layers_9_mlp_norm_weight: "f32[768]", p_encoder_layers_9_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_9_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_10_attn_norm_weight: "f32[768]", p_encoder_layers_10_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_10_attn_wo_weight: "f32[768, 768]", p_encoder_layers_10_mlp_norm_weight: "f32[768]", p_encoder_layers_10_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_10_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_11_attn_norm_weight: "f32[768]", p_encoder_layers_11_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_11_attn_wo_weight: "f32[768, 768]", p_encoder_layers_11_mlp_norm_weight: "f32[768]", p_encoder_layers_11_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_11_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_12_attn_norm_weight: "f32[768]", p_encoder_layers_12_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_12_attn_wo_weight: "f32[768, 768]", p_encoder_layers_12_mlp_norm_weight: "f32[768]", p_encoder_layers_12_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_12_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_13_attn_norm_weight: "f32[768]", p_encoder_layers_13_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_13_attn_wo_weight: "f32[768, 768]", p_encoder_layers_13_mlp_norm_weight: "f32[768]", p_encoder_layers_13_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_13_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_14_attn_norm_weight: "f32[768]", p_encoder_layers_14_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_14_attn_wo_weight: "f32[768, 768]", p_encoder_layers_14_mlp_norm_weight: "f32[768]", p_encoder_layers_14_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_14_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_15_attn_norm_weight: "f32[768]", p_encoder_layers_15_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_15_attn_wo_weight: "f32[768, 768]", p_encoder_layers_15_mlp_norm_weight: "f32[768]", p_encoder_layers_15_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_15_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_16_attn_norm_weight: "f32[768]", p_encoder_layers_16_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_16_attn_wo_weight: "f32[768, 768]", p_encoder_layers_16_mlp_norm_weight: "f32[768]", p_encoder_layers_16_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_16_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_17_attn_norm_weight: "f32[768]", p_encoder_layers_17_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_17_attn_wo_weight: "f32[768, 768]", p_encoder_layers_17_mlp_norm_weight: "f32[768]", p_encoder_layers_17_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_17_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_18_attn_norm_weight: "f32[768]", p_encoder_layers_18_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_18_attn_wo_weight: "f32[768, 768]", p_encoder_layers_18_mlp_norm_weight: "f32[768]", p_encoder_layers_18_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_18_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_19_attn_norm_weight: "f32[768]", p_encoder_layers_19_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_19_attn_wo_weight: "f32[768, 768]", p_encoder_layers_19_mlp_norm_weight: "f32[768]", p_encoder_layers_19_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_19_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_20_attn_norm_weight: "f32[768]", p_encoder_layers_20_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_20_attn_wo_weight: "f32[768, 768]", p_encoder_layers_20_mlp_norm_weight: "f32[768]", p_encoder_layers_20_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_20_mlp_wo_weight: "f32[768, 1152]", p_encoder_layers_21_attn_norm_weight: "f32[768]", p_encoder_layers_21_attn_wqkv_weight: "f32[2304, 768]", p_encoder_layers_21_attn_wo_weight: "f32[768, 768]", p_encoder_layers_21_mlp_norm_weight: "f32[768]", p_encoder_layers_21_mlp_wi_weight: "f32[2304, 768]", p_encoder_layers_21_mlp_wo_weight: "f32[768, 1152]", p_encoder_final_norm_weight: "f32[768]", p_head_layers_0_self_attn_in_proj_weight: "f32[2304, 768]", p_head_layers_0_self_attn_in_proj_bias: "f32[2304]", p_head_layers_0_self_attn_out_proj_weight: "f32[768, 768]", p_head_layers_0_self_attn_out_proj_bias: "f32[768]", p_head_layers_0_linear1_weight: "f32[3072, 768]", p_head_layers_0_linear1_bias: "f32[3072]", p_head_layers_0_linear2_weight: "f32[768, 3072]", p_head_layers_0_linear2_bias: "f32[768]", p_head_layers_0_norm1_weight: "f32[768]", p_head_layers_0_norm1_bias: "f32[768]", p_head_layers_0_norm2_weight: "f32[768]", p_head_layers_0_norm2_bias: "f32[768]", p_head_layers_1_self_attn_in_proj_weight: "f32[2304, 768]", p_head_layers_1_self_attn_in_proj_bias: "f32[2304]", p_head_layers_1_self_attn_out_proj_weight: "f32[768, 768]", p_head_layers_1_self_attn_out_proj_bias: "f32[768]", p_head_layers_1_linear1_weight: "f32[3072, 768]", p_head_layers_1_linear1_bias: "f32[3072]", p_head_layers_1_linear2_weight: "f32[768, 3072]", p_head_layers_1_linear2_bias: "f32[768]", p_head_layers_1_norm1_weight: "f32[768]", p_head_layers_1_norm1_bias: "f32[768]", p_head_layers_1_norm2_weight: "f32[768]", p_head_layers_1_norm2_bias: "f32[768]", p_type_emb_weight: "f32[3, 768]", p_scorer_0_weight: "f32[768]", p_scorer_0_bias: "f32[768]", p_scorer_1_weight: "f32[768, 768]", p_scorer_1_bias: "f32[768]", p_scorer_3_weight: "f32[1, 768]", p_scorer_3_bias: "f32[1]", p_act_head_0_weight: "f32[256, 772]", p_act_head_0_bias: "f32[256]", p_act_head_2_weight: "f32[2, 256]", p_act_head_2_bias: "f32[2]", b_temperature: "f32[3]", c_encoder_lifted_tensor_0: "f32[]", b_encoder_rotary_emb_full_attention_inv_freq: "f32[32]", b_encoder_rotary_emb_full_attention_original_inv_freq: "f32[32]", b_encoder_rotary_emb_sliding_attention_inv_freq: "f32[32]", b_encoder_rotary_emb_sliding_attention_original_inv_freq: "f32[32]", input_ids: "i64[1, 97]", attention_mask: "i64[1, 97]", marker_pos: "i64[1, 3]", marker_mask: "b8[1, 3]", qtype: "i64[1]"):
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:927 in forward, code: position_ids = torch.arange(seq_len, device=device).unsqueeze(0)
            arange: "i64[97]" = torch.ops.aten.arange.default(97, device = device(type='cpu'), pin_memory = False)
            unsqueeze: "i64[1, 97]" = torch.ops.aten.unsqueeze.default(arange, 0);  arange = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:929 in forward, code: attention_mask, sliding_window_mask = self._update_attention_mask(
            slice_1: "i64[1, 97]" = torch.ops.aten.slice.Tensor(attention_mask, 0, 0, 9223372036854775807)
            unsqueeze_1: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_1, 1);  slice_1 = None
            unsqueeze_2: "i64[1, 1, 1, 97]" = torch.ops.aten.unsqueeze.default(unsqueeze_1, 2);  unsqueeze_1 = None
            slice_2: "i64[1, 1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_2, 3, 0, 9223372036854775807);  unsqueeze_2 = None
            expand: "i64[1, 1, 97, 97]" = torch.ops.aten.expand.default(slice_2, [1, 1, 97, 97]);  slice_2 = None
            _to_copy: "f32[1, 1, 97, 97]" = torch.ops.aten._to_copy.default(expand, dtype = torch.float32);  expand = None
            clone: "f32[]" = torch.ops.aten.clone.default(c_encoder_lifted_tensor_0);  c_encoder_lifted_tensor_0 = None
            sub: "f32[1, 1, 97, 97]" = torch.ops.aten.sub.Tensor(clone, _to_copy);  clone = _to_copy = None
            _to_copy_1: "b8[1, 1, 97, 97]" = torch.ops.aten._to_copy.default(sub, dtype = torch.bool)
            masked_fill: "f32[1, 1, 97, 97]" = torch.ops.aten.masked_fill.Scalar(sub, _to_copy_1, -3.4028234663852886e+38);  sub = _to_copy_1 = None
            arange_1: "i64[97]" = torch.ops.aten.arange.default(97, device = device(type='cpu'), pin_memory = False)
            unsqueeze_3: "i64[1, 97]" = torch.ops.aten.unsqueeze.default(arange_1, 0);  arange_1 = None
            permute: "i64[97, 1]" = torch.ops.aten.permute.default(unsqueeze_3, [1, 0])
            sub_1: "i64[97, 97]" = torch.ops.aten.sub.Tensor(unsqueeze_3, permute);  unsqueeze_3 = permute = None
            abs_1: "i64[97, 97]" = torch.ops.aten.abs.default(sub_1);  sub_1 = None
            le: "b8[97, 97]" = torch.ops.aten.le.Scalar(abs_1, 64);  abs_1 = None
            unsqueeze_4: "b8[1, 97, 97]" = torch.ops.aten.unsqueeze.default(le, 0);  le = None
            unsqueeze_5: "b8[1, 1, 97, 97]" = torch.ops.aten.unsqueeze.default(unsqueeze_4, 0);  unsqueeze_4 = None
            logical_not: "b8[1, 1, 97, 97]" = torch.ops.aten.logical_not.default(unsqueeze_5);  unsqueeze_5 = None
            masked_fill_1: "f32[1, 1, 97, 97]" = torch.ops.aten.masked_fill.Scalar(masked_fill, logical_not, -3.4028234663852886e+38);  logical_not = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/sparse.py:192 in forward, code: return F.embedding(
            embedding: "f32[1, 97, 768]" = torch.ops.aten.embedding.default(p_encoder_embeddings_tok_embeddings_weight, input_ids, 0);  p_encoder_embeddings_tok_embeddings_weight = input_ids = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(embedding, [768], p_encoder_embeddings_norm_weight);  embedding = p_encoder_embeddings_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_1: "f32[1, 97, 768]" = torch.ops.aten.clone.default(layer_norm);  layer_norm = None
            
             # File: <eval_with_key>.121:5 in forward, code: unsqueeze_6 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_6: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.121:6 in forward, code: slice_3 = torch.ops.aten.slice.Tensor(unsqueeze_6, 1, 0, 9223372036854775807);  unsqueeze_6 = None
            slice_3: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_6, 1, 0, 9223372036854775807);  unsqueeze_6 = None
            
             # File: <eval_with_key>.121:7 in forward, code: unsqueeze_7 = torch.ops.aten.unsqueeze.default(slice_3, 2);  slice_3 = None
            unsqueeze_7: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_3, 2);  slice_3 = None
            
             # File: <eval_with_key>.121:10 in forward, code: expand_1 = torch.ops.aten.expand.default(to_3, [1, -1, 1]);  to_3 = None
            expand_1: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_7, [1, -1, 1]);  unsqueeze_7 = None
            
             # File: <eval_with_key>.121:13 in forward, code: slice_4 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_4: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.121:14 in forward, code: unsqueeze_8 = torch.ops.aten.unsqueeze.default(slice_4, 1);  slice_4 = None
            unsqueeze_8: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_4, 1);  slice_4 = None
            
             # File: <eval_with_key>.121:15 in forward, code: slice_5 = torch.ops.aten.slice.Tensor(unsqueeze_8, 2, 0, 9223372036854775807);  unsqueeze_8 = None
            slice_5: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_8, 2, 0, 9223372036854775807);  unsqueeze_8 = None
            
             # File: <eval_with_key>.121:17 in forward, code: to_5 = torch.ops.aten.to.dtype(slice_5, torch.float32);  slice_5 = None
            _to_copy_2: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_5, dtype = torch.float32);  slice_5 = None
            
             # File: <eval_with_key>.121:22 in forward, code: matmul = torch.ops.aten.matmul.default(to_6, to_7);  to_6 = to_7 = None
            matmul: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_1, _to_copy_2);  expand_1 = _to_copy_2 = None
            
             # File: <eval_with_key>.121:23 in forward, code: transpose = torch.ops.aten.transpose.int(matmul, 1, 2);  matmul = None
            transpose: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul, 1, 2);  matmul = None
            
             # File: <eval_with_key>.121:24 in forward, code: cat = torch.ops.aten.cat.default([transpose, transpose], -1);  transpose = None
            cat: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose, transpose], -1);  transpose = None
            
             # File: <eval_with_key>.121:25 in forward, code: cos = torch.ops.aten.cos.default(cat)
            cos: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat)
            
             # File: <eval_with_key>.121:26 in forward, code: mul = torch.ops.aten.mul.Tensor(cos, 1.0);  cos = None
            mul: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos, 1.0);  cos = mul = None
            
             # File: <eval_with_key>.121:27 in forward, code: sin = torch.ops.aten.sin.default(cat);  cat = None
            sin: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat);  cat = None
            
             # File: <eval_with_key>.121:28 in forward, code: mul_1 = torch.ops.aten.mul.Tensor(sin, 1.0);  sin = None
            mul_1: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin, 1.0);  sin = mul_1 = None
            
             # File: <eval_with_key>.122:5 in forward, code: unsqueeze_9 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_9: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.122:6 in forward, code: slice_6 = torch.ops.aten.slice.Tensor(unsqueeze_9, 1, 0, 9223372036854775807);  unsqueeze_9 = None
            slice_6: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_9, 1, 0, 9223372036854775807);  unsqueeze_9 = None
            
             # File: <eval_with_key>.122:7 in forward, code: unsqueeze_10 = torch.ops.aten.unsqueeze.default(slice_6, 2);  slice_6 = None
            unsqueeze_10: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_6, 2);  slice_6 = None
            
             # File: <eval_with_key>.122:10 in forward, code: expand_2 = torch.ops.aten.expand.default(to_10, [1, -1, 1]);  to_10 = None
            expand_2: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_10, [1, -1, 1]);  unsqueeze_10 = None
            
             # File: <eval_with_key>.122:13 in forward, code: slice_7 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_7: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.122:14 in forward, code: unsqueeze_11 = torch.ops.aten.unsqueeze.default(slice_7, 1);  slice_7 = None
            unsqueeze_11: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_7, 1);  slice_7 = None
            
             # File: <eval_with_key>.122:15 in forward, code: slice_8 = torch.ops.aten.slice.Tensor(unsqueeze_11, 2, 0, 9223372036854775807);  unsqueeze_11 = None
            slice_8: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_11, 2, 0, 9223372036854775807);  unsqueeze_11 = None
            
             # File: <eval_with_key>.122:17 in forward, code: to_12 = torch.ops.aten.to.dtype(slice_8, torch.float32);  slice_8 = None
            _to_copy_3: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_8, dtype = torch.float32);  slice_8 = None
            
             # File: <eval_with_key>.122:22 in forward, code: matmul_1 = torch.ops.aten.matmul.default(to_13, to_14);  to_13 = to_14 = None
            matmul_1: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_2, _to_copy_3);  expand_2 = _to_copy_3 = None
            
             # File: <eval_with_key>.122:23 in forward, code: transpose_1 = torch.ops.aten.transpose.int(matmul_1, 1, 2);  matmul_1 = None
            transpose_1: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_1, 1, 2);  matmul_1 = None
            
             # File: <eval_with_key>.122:24 in forward, code: cat_1 = torch.ops.aten.cat.default([transpose_1, transpose_1], -1);  transpose_1 = None
            cat_1: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_1, transpose_1], -1);  transpose_1 = None
            
             # File: <eval_with_key>.122:25 in forward, code: cos_1 = torch.ops.aten.cos.default(cat_1)
            cos_1: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_1)
            
             # File: <eval_with_key>.122:26 in forward, code: mul_2 = torch.ops.aten.mul.Tensor(cos_1, 1.0);  cos_1 = None
            mul_2: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_1, 1.0);  cos_1 = mul_2 = None
            
             # File: <eval_with_key>.122:27 in forward, code: sin_1 = torch.ops.aten.sin.default(cat_1);  cat_1 = None
            sin_1: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_1);  cat_1 = None
            
             # File: <eval_with_key>.122:28 in forward, code: mul_3 = torch.ops.aten.mul.Tensor(sin_1, 1.0);  sin_1 = None
            mul_3: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_1, 1.0);  sin_1 = mul_3 = None
            
             # File: <eval_with_key>.123:5 in forward, code: unsqueeze_12 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_12: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.123:6 in forward, code: slice_9 = torch.ops.aten.slice.Tensor(unsqueeze_12, 1, 0, 9223372036854775807);  unsqueeze_12 = None
            slice_9: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_12, 1, 0, 9223372036854775807);  unsqueeze_12 = None
            
             # File: <eval_with_key>.123:7 in forward, code: unsqueeze_13 = torch.ops.aten.unsqueeze.default(slice_9, 2);  slice_9 = None
            unsqueeze_13: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_9, 2);  slice_9 = None
            
             # File: <eval_with_key>.123:10 in forward, code: expand_3 = torch.ops.aten.expand.default(to_17, [1, -1, 1]);  to_17 = None
            expand_3: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_13, [1, -1, 1]);  unsqueeze_13 = None
            
             # File: <eval_with_key>.123:13 in forward, code: slice_10 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_10: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.123:14 in forward, code: unsqueeze_14 = torch.ops.aten.unsqueeze.default(slice_10, 1);  slice_10 = None
            unsqueeze_14: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_10, 1);  slice_10 = None
            
             # File: <eval_with_key>.123:15 in forward, code: slice_11 = torch.ops.aten.slice.Tensor(unsqueeze_14, 2, 0, 9223372036854775807);  unsqueeze_14 = None
            slice_11: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_14, 2, 0, 9223372036854775807);  unsqueeze_14 = None
            
             # File: <eval_with_key>.123:17 in forward, code: to_19 = torch.ops.aten.to.dtype(slice_11, torch.float32);  slice_11 = None
            _to_copy_4: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_11, dtype = torch.float32);  slice_11 = None
            
             # File: <eval_with_key>.123:22 in forward, code: matmul_2 = torch.ops.aten.matmul.default(to_20, to_21);  to_20 = to_21 = None
            matmul_2: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_3, _to_copy_4);  expand_3 = _to_copy_4 = None
            
             # File: <eval_with_key>.123:23 in forward, code: transpose_2 = torch.ops.aten.transpose.int(matmul_2, 1, 2);  matmul_2 = None
            transpose_2: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_2, 1, 2);  matmul_2 = None
            
             # File: <eval_with_key>.123:24 in forward, code: cat_2 = torch.ops.aten.cat.default([transpose_2, transpose_2], -1);  transpose_2 = None
            cat_2: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_2, transpose_2], -1);  transpose_2 = None
            
             # File: <eval_with_key>.123:25 in forward, code: cos_2 = torch.ops.aten.cos.default(cat_2)
            cos_2: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_2)
            
             # File: <eval_with_key>.123:26 in forward, code: mul_4 = torch.ops.aten.mul.Tensor(cos_2, 1.0);  cos_2 = None
            mul_4: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_2, 1.0);  cos_2 = mul_4 = None
            
             # File: <eval_with_key>.123:27 in forward, code: sin_2 = torch.ops.aten.sin.default(cat_2);  cat_2 = None
            sin_2: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_2);  cat_2 = None
            
             # File: <eval_with_key>.123:28 in forward, code: mul_5 = torch.ops.aten.mul.Tensor(sin_2, 1.0);  sin_2 = None
            mul_5: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_2, 1.0);  sin_2 = mul_5 = None
            
             # File: <eval_with_key>.124:5 in forward, code: unsqueeze_15 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_15: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.124:6 in forward, code: slice_12 = torch.ops.aten.slice.Tensor(unsqueeze_15, 1, 0, 9223372036854775807);  unsqueeze_15 = None
            slice_12: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_15, 1, 0, 9223372036854775807);  unsqueeze_15 = None
            
             # File: <eval_with_key>.124:7 in forward, code: unsqueeze_16 = torch.ops.aten.unsqueeze.default(slice_12, 2);  slice_12 = None
            unsqueeze_16: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_12, 2);  slice_12 = None
            
             # File: <eval_with_key>.124:10 in forward, code: expand_4 = torch.ops.aten.expand.default(to_24, [1, -1, 1]);  to_24 = None
            expand_4: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_16, [1, -1, 1]);  unsqueeze_16 = None
            
             # File: <eval_with_key>.124:13 in forward, code: slice_13 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_13: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.124:14 in forward, code: unsqueeze_17 = torch.ops.aten.unsqueeze.default(slice_13, 1);  slice_13 = None
            unsqueeze_17: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_13, 1);  slice_13 = None
            
             # File: <eval_with_key>.124:15 in forward, code: slice_14 = torch.ops.aten.slice.Tensor(unsqueeze_17, 2, 0, 9223372036854775807);  unsqueeze_17 = None
            slice_14: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_17, 2, 0, 9223372036854775807);  unsqueeze_17 = None
            
             # File: <eval_with_key>.124:17 in forward, code: to_26 = torch.ops.aten.to.dtype(slice_14, torch.float32);  slice_14 = None
            _to_copy_5: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_14, dtype = torch.float32);  slice_14 = None
            
             # File: <eval_with_key>.124:22 in forward, code: matmul_3 = torch.ops.aten.matmul.default(to_27, to_28);  to_27 = to_28 = None
            matmul_3: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_4, _to_copy_5);  expand_4 = _to_copy_5 = None
            
             # File: <eval_with_key>.124:23 in forward, code: transpose_3 = torch.ops.aten.transpose.int(matmul_3, 1, 2);  matmul_3 = None
            transpose_3: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_3, 1, 2);  matmul_3 = None
            
             # File: <eval_with_key>.124:24 in forward, code: cat_3 = torch.ops.aten.cat.default([transpose_3, transpose_3], -1);  transpose_3 = None
            cat_3: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_3, transpose_3], -1);  transpose_3 = None
            
             # File: <eval_with_key>.124:25 in forward, code: cos_3 = torch.ops.aten.cos.default(cat_3)
            cos_3: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_3)
            
             # File: <eval_with_key>.124:26 in forward, code: mul_6 = torch.ops.aten.mul.Tensor(cos_3, 1.0);  cos_3 = None
            mul_6: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_3, 1.0);  cos_3 = mul_6 = None
            
             # File: <eval_with_key>.124:27 in forward, code: sin_3 = torch.ops.aten.sin.default(cat_3);  cat_3 = None
            sin_3: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_3);  cat_3 = None
            
             # File: <eval_with_key>.124:28 in forward, code: mul_7 = torch.ops.aten.mul.Tensor(sin_3, 1.0);  sin_3 = None
            mul_7: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_3, 1.0);  sin_3 = mul_7 = None
            
             # File: <eval_with_key>.125:5 in forward, code: unsqueeze_18 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_18: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.125:6 in forward, code: slice_15 = torch.ops.aten.slice.Tensor(unsqueeze_18, 1, 0, 9223372036854775807);  unsqueeze_18 = None
            slice_15: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_18, 1, 0, 9223372036854775807);  unsqueeze_18 = None
            
             # File: <eval_with_key>.125:7 in forward, code: unsqueeze_19 = torch.ops.aten.unsqueeze.default(slice_15, 2);  slice_15 = None
            unsqueeze_19: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_15, 2);  slice_15 = None
            
             # File: <eval_with_key>.125:10 in forward, code: expand_5 = torch.ops.aten.expand.default(to_31, [1, -1, 1]);  to_31 = None
            expand_5: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_19, [1, -1, 1]);  unsqueeze_19 = None
            
             # File: <eval_with_key>.125:13 in forward, code: slice_16 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_16: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.125:14 in forward, code: unsqueeze_20 = torch.ops.aten.unsqueeze.default(slice_16, 1);  slice_16 = None
            unsqueeze_20: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_16, 1);  slice_16 = None
            
             # File: <eval_with_key>.125:15 in forward, code: slice_17 = torch.ops.aten.slice.Tensor(unsqueeze_20, 2, 0, 9223372036854775807);  unsqueeze_20 = None
            slice_17: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_20, 2, 0, 9223372036854775807);  unsqueeze_20 = None
            
             # File: <eval_with_key>.125:17 in forward, code: to_33 = torch.ops.aten.to.dtype(slice_17, torch.float32);  slice_17 = None
            _to_copy_6: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_17, dtype = torch.float32);  slice_17 = None
            
             # File: <eval_with_key>.125:22 in forward, code: matmul_4 = torch.ops.aten.matmul.default(to_34, to_35);  to_34 = to_35 = None
            matmul_4: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_5, _to_copy_6);  expand_5 = _to_copy_6 = None
            
             # File: <eval_with_key>.125:23 in forward, code: transpose_4 = torch.ops.aten.transpose.int(matmul_4, 1, 2);  matmul_4 = None
            transpose_4: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_4, 1, 2);  matmul_4 = None
            
             # File: <eval_with_key>.125:24 in forward, code: cat_4 = torch.ops.aten.cat.default([transpose_4, transpose_4], -1);  transpose_4 = None
            cat_4: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_4, transpose_4], -1);  transpose_4 = None
            
             # File: <eval_with_key>.125:25 in forward, code: cos_4 = torch.ops.aten.cos.default(cat_4)
            cos_4: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_4)
            
             # File: <eval_with_key>.125:26 in forward, code: mul_8 = torch.ops.aten.mul.Tensor(cos_4, 1.0);  cos_4 = None
            mul_8: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_4, 1.0);  cos_4 = mul_8 = None
            
             # File: <eval_with_key>.125:27 in forward, code: sin_4 = torch.ops.aten.sin.default(cat_4);  cat_4 = None
            sin_4: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_4);  cat_4 = None
            
             # File: <eval_with_key>.125:28 in forward, code: mul_9 = torch.ops.aten.mul.Tensor(sin_4, 1.0);  sin_4 = None
            mul_9: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_4, 1.0);  sin_4 = mul_9 = None
            
             # File: <eval_with_key>.126:5 in forward, code: unsqueeze_21 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_21: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.126:6 in forward, code: slice_18 = torch.ops.aten.slice.Tensor(unsqueeze_21, 1, 0, 9223372036854775807);  unsqueeze_21 = None
            slice_18: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_21, 1, 0, 9223372036854775807);  unsqueeze_21 = None
            
             # File: <eval_with_key>.126:7 in forward, code: unsqueeze_22 = torch.ops.aten.unsqueeze.default(slice_18, 2);  slice_18 = None
            unsqueeze_22: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_18, 2);  slice_18 = None
            
             # File: <eval_with_key>.126:10 in forward, code: expand_6 = torch.ops.aten.expand.default(to_38, [1, -1, 1]);  to_38 = None
            expand_6: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_22, [1, -1, 1]);  unsqueeze_22 = None
            
             # File: <eval_with_key>.126:13 in forward, code: slice_19 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_19: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.126:14 in forward, code: unsqueeze_23 = torch.ops.aten.unsqueeze.default(slice_19, 1);  slice_19 = None
            unsqueeze_23: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_19, 1);  slice_19 = None
            
             # File: <eval_with_key>.126:15 in forward, code: slice_20 = torch.ops.aten.slice.Tensor(unsqueeze_23, 2, 0, 9223372036854775807);  unsqueeze_23 = None
            slice_20: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_23, 2, 0, 9223372036854775807);  unsqueeze_23 = None
            
             # File: <eval_with_key>.126:17 in forward, code: to_40 = torch.ops.aten.to.dtype(slice_20, torch.float32);  slice_20 = None
            _to_copy_7: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_20, dtype = torch.float32);  slice_20 = None
            
             # File: <eval_with_key>.126:22 in forward, code: matmul_5 = torch.ops.aten.matmul.default(to_41, to_42);  to_41 = to_42 = None
            matmul_5: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_6, _to_copy_7);  expand_6 = _to_copy_7 = None
            
             # File: <eval_with_key>.126:23 in forward, code: transpose_5 = torch.ops.aten.transpose.int(matmul_5, 1, 2);  matmul_5 = None
            transpose_5: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_5, 1, 2);  matmul_5 = None
            
             # File: <eval_with_key>.126:24 in forward, code: cat_5 = torch.ops.aten.cat.default([transpose_5, transpose_5], -1);  transpose_5 = None
            cat_5: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_5, transpose_5], -1);  transpose_5 = None
            
             # File: <eval_with_key>.126:25 in forward, code: cos_5 = torch.ops.aten.cos.default(cat_5)
            cos_5: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_5)
            
             # File: <eval_with_key>.126:26 in forward, code: mul_10 = torch.ops.aten.mul.Tensor(cos_5, 1.0);  cos_5 = None
            mul_10: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_5, 1.0);  cos_5 = mul_10 = None
            
             # File: <eval_with_key>.126:27 in forward, code: sin_5 = torch.ops.aten.sin.default(cat_5);  cat_5 = None
            sin_5: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_5);  cat_5 = None
            
             # File: <eval_with_key>.126:28 in forward, code: mul_11 = torch.ops.aten.mul.Tensor(sin_5, 1.0);  sin_5 = None
            mul_11: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_5, 1.0);  sin_5 = mul_11 = None
            
             # File: <eval_with_key>.127:5 in forward, code: unsqueeze_24 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_24: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.127:6 in forward, code: slice_21 = torch.ops.aten.slice.Tensor(unsqueeze_24, 1, 0, 9223372036854775807);  unsqueeze_24 = None
            slice_21: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_24, 1, 0, 9223372036854775807);  unsqueeze_24 = None
            
             # File: <eval_with_key>.127:7 in forward, code: unsqueeze_25 = torch.ops.aten.unsqueeze.default(slice_21, 2);  slice_21 = None
            unsqueeze_25: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_21, 2);  slice_21 = None
            
             # File: <eval_with_key>.127:10 in forward, code: expand_7 = torch.ops.aten.expand.default(to_45, [1, -1, 1]);  to_45 = None
            expand_7: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_25, [1, -1, 1]);  unsqueeze_25 = None
            
             # File: <eval_with_key>.127:13 in forward, code: slice_22 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_22: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.127:14 in forward, code: unsqueeze_26 = torch.ops.aten.unsqueeze.default(slice_22, 1);  slice_22 = None
            unsqueeze_26: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_22, 1);  slice_22 = None
            
             # File: <eval_with_key>.127:15 in forward, code: slice_23 = torch.ops.aten.slice.Tensor(unsqueeze_26, 2, 0, 9223372036854775807);  unsqueeze_26 = None
            slice_23: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_26, 2, 0, 9223372036854775807);  unsqueeze_26 = None
            
             # File: <eval_with_key>.127:17 in forward, code: to_47 = torch.ops.aten.to.dtype(slice_23, torch.float32);  slice_23 = None
            _to_copy_8: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_23, dtype = torch.float32);  slice_23 = None
            
             # File: <eval_with_key>.127:22 in forward, code: matmul_6 = torch.ops.aten.matmul.default(to_48, to_49);  to_48 = to_49 = None
            matmul_6: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_7, _to_copy_8);  expand_7 = _to_copy_8 = None
            
             # File: <eval_with_key>.127:23 in forward, code: transpose_6 = torch.ops.aten.transpose.int(matmul_6, 1, 2);  matmul_6 = None
            transpose_6: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_6, 1, 2);  matmul_6 = None
            
             # File: <eval_with_key>.127:24 in forward, code: cat_6 = torch.ops.aten.cat.default([transpose_6, transpose_6], -1);  transpose_6 = None
            cat_6: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_6, transpose_6], -1);  transpose_6 = None
            
             # File: <eval_with_key>.127:25 in forward, code: cos_6 = torch.ops.aten.cos.default(cat_6)
            cos_6: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_6)
            
             # File: <eval_with_key>.127:26 in forward, code: mul_12 = torch.ops.aten.mul.Tensor(cos_6, 1.0);  cos_6 = None
            mul_12: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_6, 1.0);  cos_6 = mul_12 = None
            
             # File: <eval_with_key>.127:27 in forward, code: sin_6 = torch.ops.aten.sin.default(cat_6);  cat_6 = None
            sin_6: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_6);  cat_6 = None
            
             # File: <eval_with_key>.127:28 in forward, code: mul_13 = torch.ops.aten.mul.Tensor(sin_6, 1.0);  sin_6 = None
            mul_13: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_6, 1.0);  sin_6 = mul_13 = None
            
             # File: <eval_with_key>.128:5 in forward, code: unsqueeze_27 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_27: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.128:6 in forward, code: slice_24 = torch.ops.aten.slice.Tensor(unsqueeze_27, 1, 0, 9223372036854775807);  unsqueeze_27 = None
            slice_24: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_27, 1, 0, 9223372036854775807);  unsqueeze_27 = None
            
             # File: <eval_with_key>.128:7 in forward, code: unsqueeze_28 = torch.ops.aten.unsqueeze.default(slice_24, 2);  slice_24 = None
            unsqueeze_28: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_24, 2);  slice_24 = None
            
             # File: <eval_with_key>.128:10 in forward, code: expand_8 = torch.ops.aten.expand.default(to_52, [1, -1, 1]);  to_52 = None
            expand_8: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_28, [1, -1, 1]);  unsqueeze_28 = None
            
             # File: <eval_with_key>.128:13 in forward, code: slice_25 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_25: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.128:14 in forward, code: unsqueeze_29 = torch.ops.aten.unsqueeze.default(slice_25, 1);  slice_25 = None
            unsqueeze_29: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_25, 1);  slice_25 = None
            
             # File: <eval_with_key>.128:15 in forward, code: slice_26 = torch.ops.aten.slice.Tensor(unsqueeze_29, 2, 0, 9223372036854775807);  unsqueeze_29 = None
            slice_26: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_29, 2, 0, 9223372036854775807);  unsqueeze_29 = None
            
             # File: <eval_with_key>.128:17 in forward, code: to_54 = torch.ops.aten.to.dtype(slice_26, torch.float32);  slice_26 = None
            _to_copy_9: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_26, dtype = torch.float32);  slice_26 = None
            
             # File: <eval_with_key>.128:22 in forward, code: matmul_7 = torch.ops.aten.matmul.default(to_55, to_56);  to_55 = to_56 = None
            matmul_7: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_8, _to_copy_9);  expand_8 = _to_copy_9 = None
            
             # File: <eval_with_key>.128:23 in forward, code: transpose_7 = torch.ops.aten.transpose.int(matmul_7, 1, 2);  matmul_7 = None
            transpose_7: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_7, 1, 2);  matmul_7 = None
            
             # File: <eval_with_key>.128:24 in forward, code: cat_7 = torch.ops.aten.cat.default([transpose_7, transpose_7], -1);  transpose_7 = None
            cat_7: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_7, transpose_7], -1);  transpose_7 = None
            
             # File: <eval_with_key>.128:25 in forward, code: cos_7 = torch.ops.aten.cos.default(cat_7)
            cos_7: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_7)
            
             # File: <eval_with_key>.128:26 in forward, code: mul_14 = torch.ops.aten.mul.Tensor(cos_7, 1.0);  cos_7 = None
            mul_14: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_7, 1.0);  cos_7 = mul_14 = None
            
             # File: <eval_with_key>.128:27 in forward, code: sin_7 = torch.ops.aten.sin.default(cat_7);  cat_7 = None
            sin_7: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_7);  cat_7 = None
            
             # File: <eval_with_key>.128:28 in forward, code: mul_15 = torch.ops.aten.mul.Tensor(sin_7, 1.0);  sin_7 = None
            mul_15: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_7, 1.0);  sin_7 = mul_15 = None
            
             # File: <eval_with_key>.129:5 in forward, code: unsqueeze_30 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_30: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.129:6 in forward, code: slice_27 = torch.ops.aten.slice.Tensor(unsqueeze_30, 1, 0, 9223372036854775807);  unsqueeze_30 = None
            slice_27: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_30, 1, 0, 9223372036854775807);  unsqueeze_30 = None
            
             # File: <eval_with_key>.129:7 in forward, code: unsqueeze_31 = torch.ops.aten.unsqueeze.default(slice_27, 2);  slice_27 = None
            unsqueeze_31: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_27, 2);  slice_27 = None
            
             # File: <eval_with_key>.129:10 in forward, code: expand_9 = torch.ops.aten.expand.default(to_59, [1, -1, 1]);  to_59 = None
            expand_9: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_31, [1, -1, 1]);  unsqueeze_31 = None
            
             # File: <eval_with_key>.129:13 in forward, code: slice_28 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_28: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.129:14 in forward, code: unsqueeze_32 = torch.ops.aten.unsqueeze.default(slice_28, 1);  slice_28 = None
            unsqueeze_32: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_28, 1);  slice_28 = None
            
             # File: <eval_with_key>.129:15 in forward, code: slice_29 = torch.ops.aten.slice.Tensor(unsqueeze_32, 2, 0, 9223372036854775807);  unsqueeze_32 = None
            slice_29: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_32, 2, 0, 9223372036854775807);  unsqueeze_32 = None
            
             # File: <eval_with_key>.129:17 in forward, code: to_61 = torch.ops.aten.to.dtype(slice_29, torch.float32);  slice_29 = None
            _to_copy_10: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_29, dtype = torch.float32);  slice_29 = None
            
             # File: <eval_with_key>.129:22 in forward, code: matmul_8 = torch.ops.aten.matmul.default(to_62, to_63);  to_62 = to_63 = None
            matmul_8: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_9, _to_copy_10);  expand_9 = _to_copy_10 = None
            
             # File: <eval_with_key>.129:23 in forward, code: transpose_8 = torch.ops.aten.transpose.int(matmul_8, 1, 2);  matmul_8 = None
            transpose_8: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_8, 1, 2);  matmul_8 = None
            
             # File: <eval_with_key>.129:24 in forward, code: cat_8 = torch.ops.aten.cat.default([transpose_8, transpose_8], -1);  transpose_8 = None
            cat_8: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_8, transpose_8], -1);  transpose_8 = None
            
             # File: <eval_with_key>.129:25 in forward, code: cos_8 = torch.ops.aten.cos.default(cat_8)
            cos_8: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_8)
            
             # File: <eval_with_key>.129:26 in forward, code: mul_16 = torch.ops.aten.mul.Tensor(cos_8, 1.0);  cos_8 = None
            mul_16: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_8, 1.0);  cos_8 = mul_16 = None
            
             # File: <eval_with_key>.129:27 in forward, code: sin_8 = torch.ops.aten.sin.default(cat_8);  cat_8 = None
            sin_8: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_8);  cat_8 = None
            
             # File: <eval_with_key>.129:28 in forward, code: mul_17 = torch.ops.aten.mul.Tensor(sin_8, 1.0);  sin_8 = None
            mul_17: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_8, 1.0);  sin_8 = mul_17 = None
            
             # File: <eval_with_key>.130:5 in forward, code: unsqueeze_33 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_33: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.130:6 in forward, code: slice_30 = torch.ops.aten.slice.Tensor(unsqueeze_33, 1, 0, 9223372036854775807);  unsqueeze_33 = None
            slice_30: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_33, 1, 0, 9223372036854775807);  unsqueeze_33 = None
            
             # File: <eval_with_key>.130:7 in forward, code: unsqueeze_34 = torch.ops.aten.unsqueeze.default(slice_30, 2);  slice_30 = None
            unsqueeze_34: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_30, 2);  slice_30 = None
            
             # File: <eval_with_key>.130:10 in forward, code: expand_10 = torch.ops.aten.expand.default(to_66, [1, -1, 1]);  to_66 = None
            expand_10: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_34, [1, -1, 1]);  unsqueeze_34 = None
            
             # File: <eval_with_key>.130:13 in forward, code: slice_31 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_31: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.130:14 in forward, code: unsqueeze_35 = torch.ops.aten.unsqueeze.default(slice_31, 1);  slice_31 = None
            unsqueeze_35: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_31, 1);  slice_31 = None
            
             # File: <eval_with_key>.130:15 in forward, code: slice_32 = torch.ops.aten.slice.Tensor(unsqueeze_35, 2, 0, 9223372036854775807);  unsqueeze_35 = None
            slice_32: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_35, 2, 0, 9223372036854775807);  unsqueeze_35 = None
            
             # File: <eval_with_key>.130:17 in forward, code: to_68 = torch.ops.aten.to.dtype(slice_32, torch.float32);  slice_32 = None
            _to_copy_11: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_32, dtype = torch.float32);  slice_32 = None
            
             # File: <eval_with_key>.130:22 in forward, code: matmul_9 = torch.ops.aten.matmul.default(to_69, to_70);  to_69 = to_70 = None
            matmul_9: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_10, _to_copy_11);  expand_10 = _to_copy_11 = None
            
             # File: <eval_with_key>.130:23 in forward, code: transpose_9 = torch.ops.aten.transpose.int(matmul_9, 1, 2);  matmul_9 = None
            transpose_9: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_9, 1, 2);  matmul_9 = None
            
             # File: <eval_with_key>.130:24 in forward, code: cat_9 = torch.ops.aten.cat.default([transpose_9, transpose_9], -1);  transpose_9 = None
            cat_9: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_9, transpose_9], -1);  transpose_9 = None
            
             # File: <eval_with_key>.130:25 in forward, code: cos_9 = torch.ops.aten.cos.default(cat_9)
            cos_9: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_9)
            
             # File: <eval_with_key>.130:26 in forward, code: mul_18 = torch.ops.aten.mul.Tensor(cos_9, 1.0);  cos_9 = None
            mul_18: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_9, 1.0);  cos_9 = mul_18 = None
            
             # File: <eval_with_key>.130:27 in forward, code: sin_9 = torch.ops.aten.sin.default(cat_9);  cat_9 = None
            sin_9: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_9);  cat_9 = None
            
             # File: <eval_with_key>.130:28 in forward, code: mul_19 = torch.ops.aten.mul.Tensor(sin_9, 1.0);  sin_9 = None
            mul_19: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_9, 1.0);  sin_9 = mul_19 = None
            
             # File: <eval_with_key>.131:5 in forward, code: unsqueeze_36 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_36: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.131:6 in forward, code: slice_33 = torch.ops.aten.slice.Tensor(unsqueeze_36, 1, 0, 9223372036854775807);  unsqueeze_36 = None
            slice_33: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_36, 1, 0, 9223372036854775807);  unsqueeze_36 = None
            
             # File: <eval_with_key>.131:7 in forward, code: unsqueeze_37 = torch.ops.aten.unsqueeze.default(slice_33, 2);  slice_33 = None
            unsqueeze_37: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_33, 2);  slice_33 = None
            
             # File: <eval_with_key>.131:10 in forward, code: expand_11 = torch.ops.aten.expand.default(to_73, [1, -1, 1]);  to_73 = None
            expand_11: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_37, [1, -1, 1]);  unsqueeze_37 = None
            
             # File: <eval_with_key>.131:13 in forward, code: slice_34 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_34: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.131:14 in forward, code: unsqueeze_38 = torch.ops.aten.unsqueeze.default(slice_34, 1);  slice_34 = None
            unsqueeze_38: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_34, 1);  slice_34 = None
            
             # File: <eval_with_key>.131:15 in forward, code: slice_35 = torch.ops.aten.slice.Tensor(unsqueeze_38, 2, 0, 9223372036854775807);  unsqueeze_38 = None
            slice_35: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_38, 2, 0, 9223372036854775807);  unsqueeze_38 = None
            
             # File: <eval_with_key>.131:17 in forward, code: to_75 = torch.ops.aten.to.dtype(slice_35, torch.float32);  slice_35 = None
            _to_copy_12: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_35, dtype = torch.float32);  slice_35 = None
            
             # File: <eval_with_key>.131:22 in forward, code: matmul_10 = torch.ops.aten.matmul.default(to_76, to_77);  to_76 = to_77 = None
            matmul_10: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_11, _to_copy_12);  expand_11 = _to_copy_12 = None
            
             # File: <eval_with_key>.131:23 in forward, code: transpose_10 = torch.ops.aten.transpose.int(matmul_10, 1, 2);  matmul_10 = None
            transpose_10: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_10, 1, 2);  matmul_10 = None
            
             # File: <eval_with_key>.131:24 in forward, code: cat_10 = torch.ops.aten.cat.default([transpose_10, transpose_10], -1);  transpose_10 = None
            cat_10: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_10, transpose_10], -1);  transpose_10 = None
            
             # File: <eval_with_key>.131:25 in forward, code: cos_10 = torch.ops.aten.cos.default(cat_10)
            cos_10: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_10)
            
             # File: <eval_with_key>.131:26 in forward, code: mul_20 = torch.ops.aten.mul.Tensor(cos_10, 1.0);  cos_10 = None
            mul_20: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_10, 1.0);  cos_10 = mul_20 = None
            
             # File: <eval_with_key>.131:27 in forward, code: sin_10 = torch.ops.aten.sin.default(cat_10);  cat_10 = None
            sin_10: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_10);  cat_10 = None
            
             # File: <eval_with_key>.131:28 in forward, code: mul_21 = torch.ops.aten.mul.Tensor(sin_10, 1.0);  sin_10 = None
            mul_21: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_10, 1.0);  sin_10 = mul_21 = None
            
             # File: <eval_with_key>.132:5 in forward, code: unsqueeze_39 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_39: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.132:6 in forward, code: slice_36 = torch.ops.aten.slice.Tensor(unsqueeze_39, 1, 0, 9223372036854775807);  unsqueeze_39 = None
            slice_36: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_39, 1, 0, 9223372036854775807);  unsqueeze_39 = None
            
             # File: <eval_with_key>.132:7 in forward, code: unsqueeze_40 = torch.ops.aten.unsqueeze.default(slice_36, 2);  slice_36 = None
            unsqueeze_40: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_36, 2);  slice_36 = None
            
             # File: <eval_with_key>.132:10 in forward, code: expand_12 = torch.ops.aten.expand.default(to_80, [1, -1, 1]);  to_80 = None
            expand_12: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_40, [1, -1, 1]);  unsqueeze_40 = None
            
             # File: <eval_with_key>.132:13 in forward, code: slice_37 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_37: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.132:14 in forward, code: unsqueeze_41 = torch.ops.aten.unsqueeze.default(slice_37, 1);  slice_37 = None
            unsqueeze_41: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_37, 1);  slice_37 = None
            
             # File: <eval_with_key>.132:15 in forward, code: slice_38 = torch.ops.aten.slice.Tensor(unsqueeze_41, 2, 0, 9223372036854775807);  unsqueeze_41 = None
            slice_38: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_41, 2, 0, 9223372036854775807);  unsqueeze_41 = None
            
             # File: <eval_with_key>.132:17 in forward, code: to_82 = torch.ops.aten.to.dtype(slice_38, torch.float32);  slice_38 = None
            _to_copy_13: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_38, dtype = torch.float32);  slice_38 = None
            
             # File: <eval_with_key>.132:22 in forward, code: matmul_11 = torch.ops.aten.matmul.default(to_83, to_84);  to_83 = to_84 = None
            matmul_11: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_12, _to_copy_13);  expand_12 = _to_copy_13 = None
            
             # File: <eval_with_key>.132:23 in forward, code: transpose_11 = torch.ops.aten.transpose.int(matmul_11, 1, 2);  matmul_11 = None
            transpose_11: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_11, 1, 2);  matmul_11 = None
            
             # File: <eval_with_key>.132:24 in forward, code: cat_11 = torch.ops.aten.cat.default([transpose_11, transpose_11], -1);  transpose_11 = None
            cat_11: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_11, transpose_11], -1);  transpose_11 = None
            
             # File: <eval_with_key>.132:25 in forward, code: cos_11 = torch.ops.aten.cos.default(cat_11)
            cos_11: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_11)
            
             # File: <eval_with_key>.132:26 in forward, code: mul_22 = torch.ops.aten.mul.Tensor(cos_11, 1.0);  cos_11 = None
            mul_22: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_11, 1.0);  cos_11 = mul_22 = None
            
             # File: <eval_with_key>.132:27 in forward, code: sin_11 = torch.ops.aten.sin.default(cat_11);  cat_11 = None
            sin_11: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_11);  cat_11 = None
            
             # File: <eval_with_key>.132:28 in forward, code: mul_23 = torch.ops.aten.mul.Tensor(sin_11, 1.0);  sin_11 = None
            mul_23: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_11, 1.0);  sin_11 = mul_23 = None
            
             # File: <eval_with_key>.133:5 in forward, code: unsqueeze_42 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_42: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.133:6 in forward, code: slice_39 = torch.ops.aten.slice.Tensor(unsqueeze_42, 1, 0, 9223372036854775807);  unsqueeze_42 = None
            slice_39: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_42, 1, 0, 9223372036854775807);  unsqueeze_42 = None
            
             # File: <eval_with_key>.133:7 in forward, code: unsqueeze_43 = torch.ops.aten.unsqueeze.default(slice_39, 2);  slice_39 = None
            unsqueeze_43: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_39, 2);  slice_39 = None
            
             # File: <eval_with_key>.133:10 in forward, code: expand_13 = torch.ops.aten.expand.default(to_87, [1, -1, 1]);  to_87 = None
            expand_13: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_43, [1, -1, 1]);  unsqueeze_43 = None
            
             # File: <eval_with_key>.133:13 in forward, code: slice_40 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_40: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.133:14 in forward, code: unsqueeze_44 = torch.ops.aten.unsqueeze.default(slice_40, 1);  slice_40 = None
            unsqueeze_44: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_40, 1);  slice_40 = None
            
             # File: <eval_with_key>.133:15 in forward, code: slice_41 = torch.ops.aten.slice.Tensor(unsqueeze_44, 2, 0, 9223372036854775807);  unsqueeze_44 = None
            slice_41: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_44, 2, 0, 9223372036854775807);  unsqueeze_44 = None
            
             # File: <eval_with_key>.133:17 in forward, code: to_89 = torch.ops.aten.to.dtype(slice_41, torch.float32);  slice_41 = None
            _to_copy_14: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_41, dtype = torch.float32);  slice_41 = None
            
             # File: <eval_with_key>.133:22 in forward, code: matmul_12 = torch.ops.aten.matmul.default(to_90, to_91);  to_90 = to_91 = None
            matmul_12: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_13, _to_copy_14);  expand_13 = _to_copy_14 = None
            
             # File: <eval_with_key>.133:23 in forward, code: transpose_12 = torch.ops.aten.transpose.int(matmul_12, 1, 2);  matmul_12 = None
            transpose_12: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_12, 1, 2);  matmul_12 = None
            
             # File: <eval_with_key>.133:24 in forward, code: cat_12 = torch.ops.aten.cat.default([transpose_12, transpose_12], -1);  transpose_12 = None
            cat_12: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_12, transpose_12], -1);  transpose_12 = None
            
             # File: <eval_with_key>.133:25 in forward, code: cos_12 = torch.ops.aten.cos.default(cat_12)
            cos_12: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_12)
            
             # File: <eval_with_key>.133:26 in forward, code: mul_24 = torch.ops.aten.mul.Tensor(cos_12, 1.0);  cos_12 = None
            mul_24: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_12, 1.0);  cos_12 = mul_24 = None
            
             # File: <eval_with_key>.133:27 in forward, code: sin_12 = torch.ops.aten.sin.default(cat_12);  cat_12 = None
            sin_12: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_12);  cat_12 = None
            
             # File: <eval_with_key>.133:28 in forward, code: mul_25 = torch.ops.aten.mul.Tensor(sin_12, 1.0);  sin_12 = None
            mul_25: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_12, 1.0);  sin_12 = mul_25 = None
            
             # File: <eval_with_key>.134:5 in forward, code: unsqueeze_45 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_45: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.134:6 in forward, code: slice_42 = torch.ops.aten.slice.Tensor(unsqueeze_45, 1, 0, 9223372036854775807);  unsqueeze_45 = None
            slice_42: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_45, 1, 0, 9223372036854775807);  unsqueeze_45 = None
            
             # File: <eval_with_key>.134:7 in forward, code: unsqueeze_46 = torch.ops.aten.unsqueeze.default(slice_42, 2);  slice_42 = None
            unsqueeze_46: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_42, 2);  slice_42 = None
            
             # File: <eval_with_key>.134:10 in forward, code: expand_14 = torch.ops.aten.expand.default(to_94, [1, -1, 1]);  to_94 = None
            expand_14: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_46, [1, -1, 1]);  unsqueeze_46 = None
            
             # File: <eval_with_key>.134:13 in forward, code: slice_43 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_43: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.134:14 in forward, code: unsqueeze_47 = torch.ops.aten.unsqueeze.default(slice_43, 1);  slice_43 = None
            unsqueeze_47: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_43, 1);  slice_43 = None
            
             # File: <eval_with_key>.134:15 in forward, code: slice_44 = torch.ops.aten.slice.Tensor(unsqueeze_47, 2, 0, 9223372036854775807);  unsqueeze_47 = None
            slice_44: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_47, 2, 0, 9223372036854775807);  unsqueeze_47 = None
            
             # File: <eval_with_key>.134:17 in forward, code: to_96 = torch.ops.aten.to.dtype(slice_44, torch.float32);  slice_44 = None
            _to_copy_15: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_44, dtype = torch.float32);  slice_44 = None
            
             # File: <eval_with_key>.134:22 in forward, code: matmul_13 = torch.ops.aten.matmul.default(to_97, to_98);  to_97 = to_98 = None
            matmul_13: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_14, _to_copy_15);  expand_14 = _to_copy_15 = None
            
             # File: <eval_with_key>.134:23 in forward, code: transpose_13 = torch.ops.aten.transpose.int(matmul_13, 1, 2);  matmul_13 = None
            transpose_13: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_13, 1, 2);  matmul_13 = None
            
             # File: <eval_with_key>.134:24 in forward, code: cat_13 = torch.ops.aten.cat.default([transpose_13, transpose_13], -1);  transpose_13 = None
            cat_13: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_13, transpose_13], -1);  transpose_13 = None
            
             # File: <eval_with_key>.134:25 in forward, code: cos_13 = torch.ops.aten.cos.default(cat_13)
            cos_13: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_13)
            
             # File: <eval_with_key>.134:26 in forward, code: mul_26 = torch.ops.aten.mul.Tensor(cos_13, 1.0);  cos_13 = None
            mul_26: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_13, 1.0);  cos_13 = mul_26 = None
            
             # File: <eval_with_key>.134:27 in forward, code: sin_13 = torch.ops.aten.sin.default(cat_13);  cat_13 = None
            sin_13: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_13);  cat_13 = None
            
             # File: <eval_with_key>.134:28 in forward, code: mul_27 = torch.ops.aten.mul.Tensor(sin_13, 1.0);  sin_13 = None
            mul_27: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_13, 1.0);  sin_13 = mul_27 = None
            
             # File: <eval_with_key>.135:5 in forward, code: unsqueeze_48 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_48: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.135:6 in forward, code: slice_45 = torch.ops.aten.slice.Tensor(unsqueeze_48, 1, 0, 9223372036854775807);  unsqueeze_48 = None
            slice_45: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_48, 1, 0, 9223372036854775807);  unsqueeze_48 = None
            
             # File: <eval_with_key>.135:7 in forward, code: unsqueeze_49 = torch.ops.aten.unsqueeze.default(slice_45, 2);  slice_45 = None
            unsqueeze_49: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_45, 2);  slice_45 = None
            
             # File: <eval_with_key>.135:10 in forward, code: expand_15 = torch.ops.aten.expand.default(to_101, [1, -1, 1]);  to_101 = None
            expand_15: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_49, [1, -1, 1]);  unsqueeze_49 = None
            
             # File: <eval_with_key>.135:13 in forward, code: slice_46 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_46: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.135:14 in forward, code: unsqueeze_50 = torch.ops.aten.unsqueeze.default(slice_46, 1);  slice_46 = None
            unsqueeze_50: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_46, 1);  slice_46 = None
            
             # File: <eval_with_key>.135:15 in forward, code: slice_47 = torch.ops.aten.slice.Tensor(unsqueeze_50, 2, 0, 9223372036854775807);  unsqueeze_50 = None
            slice_47: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_50, 2, 0, 9223372036854775807);  unsqueeze_50 = None
            
             # File: <eval_with_key>.135:17 in forward, code: to_103 = torch.ops.aten.to.dtype(slice_47, torch.float32);  slice_47 = None
            _to_copy_16: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_47, dtype = torch.float32);  slice_47 = None
            
             # File: <eval_with_key>.135:22 in forward, code: matmul_14 = torch.ops.aten.matmul.default(to_104, to_105);  to_104 = to_105 = None
            matmul_14: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_15, _to_copy_16);  expand_15 = _to_copy_16 = None
            
             # File: <eval_with_key>.135:23 in forward, code: transpose_14 = torch.ops.aten.transpose.int(matmul_14, 1, 2);  matmul_14 = None
            transpose_14: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_14, 1, 2);  matmul_14 = None
            
             # File: <eval_with_key>.135:24 in forward, code: cat_14 = torch.ops.aten.cat.default([transpose_14, transpose_14], -1);  transpose_14 = None
            cat_14: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_14, transpose_14], -1);  transpose_14 = None
            
             # File: <eval_with_key>.135:25 in forward, code: cos_14 = torch.ops.aten.cos.default(cat_14)
            cos_14: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_14)
            
             # File: <eval_with_key>.135:26 in forward, code: mul_28 = torch.ops.aten.mul.Tensor(cos_14, 1.0);  cos_14 = None
            mul_28: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_14, 1.0);  cos_14 = mul_28 = None
            
             # File: <eval_with_key>.135:27 in forward, code: sin_14 = torch.ops.aten.sin.default(cat_14);  cat_14 = None
            sin_14: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_14);  cat_14 = None
            
             # File: <eval_with_key>.135:28 in forward, code: mul_29 = torch.ops.aten.mul.Tensor(sin_14, 1.0);  sin_14 = None
            mul_29: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_14, 1.0);  sin_14 = mul_29 = None
            
             # File: <eval_with_key>.136:5 in forward, code: unsqueeze_51 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_51: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.136:6 in forward, code: slice_48 = torch.ops.aten.slice.Tensor(unsqueeze_51, 1, 0, 9223372036854775807);  unsqueeze_51 = None
            slice_48: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_51, 1, 0, 9223372036854775807);  unsqueeze_51 = None
            
             # File: <eval_with_key>.136:7 in forward, code: unsqueeze_52 = torch.ops.aten.unsqueeze.default(slice_48, 2);  slice_48 = None
            unsqueeze_52: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_48, 2);  slice_48 = None
            
             # File: <eval_with_key>.136:10 in forward, code: expand_16 = torch.ops.aten.expand.default(to_108, [1, -1, 1]);  to_108 = None
            expand_16: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_52, [1, -1, 1]);  unsqueeze_52 = None
            
             # File: <eval_with_key>.136:13 in forward, code: slice_49 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_49: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.136:14 in forward, code: unsqueeze_53 = torch.ops.aten.unsqueeze.default(slice_49, 1);  slice_49 = None
            unsqueeze_53: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_49, 1);  slice_49 = None
            
             # File: <eval_with_key>.136:15 in forward, code: slice_50 = torch.ops.aten.slice.Tensor(unsqueeze_53, 2, 0, 9223372036854775807);  unsqueeze_53 = None
            slice_50: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_53, 2, 0, 9223372036854775807);  unsqueeze_53 = None
            
             # File: <eval_with_key>.136:17 in forward, code: to_110 = torch.ops.aten.to.dtype(slice_50, torch.float32);  slice_50 = None
            _to_copy_17: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_50, dtype = torch.float32);  slice_50 = None
            
             # File: <eval_with_key>.136:22 in forward, code: matmul_15 = torch.ops.aten.matmul.default(to_111, to_112);  to_111 = to_112 = None
            matmul_15: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_16, _to_copy_17);  expand_16 = _to_copy_17 = None
            
             # File: <eval_with_key>.136:23 in forward, code: transpose_15 = torch.ops.aten.transpose.int(matmul_15, 1, 2);  matmul_15 = None
            transpose_15: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_15, 1, 2);  matmul_15 = None
            
             # File: <eval_with_key>.136:24 in forward, code: cat_15 = torch.ops.aten.cat.default([transpose_15, transpose_15], -1);  transpose_15 = None
            cat_15: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_15, transpose_15], -1);  transpose_15 = None
            
             # File: <eval_with_key>.136:25 in forward, code: cos_15 = torch.ops.aten.cos.default(cat_15)
            cos_15: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_15)
            
             # File: <eval_with_key>.136:26 in forward, code: mul_30 = torch.ops.aten.mul.Tensor(cos_15, 1.0);  cos_15 = None
            mul_30: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_15, 1.0);  cos_15 = mul_30 = None
            
             # File: <eval_with_key>.136:27 in forward, code: sin_15 = torch.ops.aten.sin.default(cat_15);  cat_15 = None
            sin_15: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_15);  cat_15 = None
            
             # File: <eval_with_key>.136:28 in forward, code: mul_31 = torch.ops.aten.mul.Tensor(sin_15, 1.0);  sin_15 = None
            mul_31: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_15, 1.0);  sin_15 = mul_31 = None
            
             # File: <eval_with_key>.137:5 in forward, code: unsqueeze_54 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_54: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.137:6 in forward, code: slice_51 = torch.ops.aten.slice.Tensor(unsqueeze_54, 1, 0, 9223372036854775807);  unsqueeze_54 = None
            slice_51: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_54, 1, 0, 9223372036854775807);  unsqueeze_54 = None
            
             # File: <eval_with_key>.137:7 in forward, code: unsqueeze_55 = torch.ops.aten.unsqueeze.default(slice_51, 2);  slice_51 = None
            unsqueeze_55: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_51, 2);  slice_51 = None
            
             # File: <eval_with_key>.137:10 in forward, code: expand_17 = torch.ops.aten.expand.default(to_115, [1, -1, 1]);  to_115 = None
            expand_17: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_55, [1, -1, 1]);  unsqueeze_55 = None
            
             # File: <eval_with_key>.137:13 in forward, code: slice_52 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_52: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.137:14 in forward, code: unsqueeze_56 = torch.ops.aten.unsqueeze.default(slice_52, 1);  slice_52 = None
            unsqueeze_56: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_52, 1);  slice_52 = None
            
             # File: <eval_with_key>.137:15 in forward, code: slice_53 = torch.ops.aten.slice.Tensor(unsqueeze_56, 2, 0, 9223372036854775807);  unsqueeze_56 = None
            slice_53: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_56, 2, 0, 9223372036854775807);  unsqueeze_56 = None
            
             # File: <eval_with_key>.137:17 in forward, code: to_117 = torch.ops.aten.to.dtype(slice_53, torch.float32);  slice_53 = None
            _to_copy_18: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_53, dtype = torch.float32);  slice_53 = None
            
             # File: <eval_with_key>.137:22 in forward, code: matmul_16 = torch.ops.aten.matmul.default(to_118, to_119);  to_118 = to_119 = None
            matmul_16: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_17, _to_copy_18);  expand_17 = _to_copy_18 = None
            
             # File: <eval_with_key>.137:23 in forward, code: transpose_16 = torch.ops.aten.transpose.int(matmul_16, 1, 2);  matmul_16 = None
            transpose_16: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_16, 1, 2);  matmul_16 = None
            
             # File: <eval_with_key>.137:24 in forward, code: cat_16 = torch.ops.aten.cat.default([transpose_16, transpose_16], -1);  transpose_16 = None
            cat_16: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_16, transpose_16], -1);  transpose_16 = None
            
             # File: <eval_with_key>.137:25 in forward, code: cos_16 = torch.ops.aten.cos.default(cat_16)
            cos_16: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_16)
            
             # File: <eval_with_key>.137:26 in forward, code: mul_32 = torch.ops.aten.mul.Tensor(cos_16, 1.0);  cos_16 = None
            mul_32: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_16, 1.0);  cos_16 = mul_32 = None
            
             # File: <eval_with_key>.137:27 in forward, code: sin_16 = torch.ops.aten.sin.default(cat_16);  cat_16 = None
            sin_16: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_16);  cat_16 = None
            
             # File: <eval_with_key>.137:28 in forward, code: mul_33 = torch.ops.aten.mul.Tensor(sin_16, 1.0);  sin_16 = None
            mul_33: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_16, 1.0);  sin_16 = mul_33 = None
            
             # File: <eval_with_key>.138:5 in forward, code: unsqueeze_57 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_57: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.138:6 in forward, code: slice_54 = torch.ops.aten.slice.Tensor(unsqueeze_57, 1, 0, 9223372036854775807);  unsqueeze_57 = None
            slice_54: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_57, 1, 0, 9223372036854775807);  unsqueeze_57 = None
            
             # File: <eval_with_key>.138:7 in forward, code: unsqueeze_58 = torch.ops.aten.unsqueeze.default(slice_54, 2);  slice_54 = None
            unsqueeze_58: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_54, 2);  slice_54 = None
            
             # File: <eval_with_key>.138:10 in forward, code: expand_18 = torch.ops.aten.expand.default(to_122, [1, -1, 1]);  to_122 = None
            expand_18: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_58, [1, -1, 1]);  unsqueeze_58 = None
            
             # File: <eval_with_key>.138:13 in forward, code: slice_55 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_55: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.138:14 in forward, code: unsqueeze_59 = torch.ops.aten.unsqueeze.default(slice_55, 1);  slice_55 = None
            unsqueeze_59: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_55, 1);  slice_55 = None
            
             # File: <eval_with_key>.138:15 in forward, code: slice_56 = torch.ops.aten.slice.Tensor(unsqueeze_59, 2, 0, 9223372036854775807);  unsqueeze_59 = None
            slice_56: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_59, 2, 0, 9223372036854775807);  unsqueeze_59 = None
            
             # File: <eval_with_key>.138:17 in forward, code: to_124 = torch.ops.aten.to.dtype(slice_56, torch.float32);  slice_56 = None
            _to_copy_19: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_56, dtype = torch.float32);  slice_56 = None
            
             # File: <eval_with_key>.138:22 in forward, code: matmul_17 = torch.ops.aten.matmul.default(to_125, to_126);  to_125 = to_126 = None
            matmul_17: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_18, _to_copy_19);  expand_18 = _to_copy_19 = None
            
             # File: <eval_with_key>.138:23 in forward, code: transpose_17 = torch.ops.aten.transpose.int(matmul_17, 1, 2);  matmul_17 = None
            transpose_17: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_17, 1, 2);  matmul_17 = None
            
             # File: <eval_with_key>.138:24 in forward, code: cat_17 = torch.ops.aten.cat.default([transpose_17, transpose_17], -1);  transpose_17 = None
            cat_17: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_17, transpose_17], -1);  transpose_17 = None
            
             # File: <eval_with_key>.138:25 in forward, code: cos_17 = torch.ops.aten.cos.default(cat_17)
            cos_17: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_17)
            
             # File: <eval_with_key>.138:26 in forward, code: mul_34 = torch.ops.aten.mul.Tensor(cos_17, 1.0);  cos_17 = None
            mul_34: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_17, 1.0);  cos_17 = mul_34 = None
            
             # File: <eval_with_key>.138:27 in forward, code: sin_17 = torch.ops.aten.sin.default(cat_17);  cat_17 = None
            sin_17: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_17);  cat_17 = None
            
             # File: <eval_with_key>.138:28 in forward, code: mul_35 = torch.ops.aten.mul.Tensor(sin_17, 1.0);  sin_17 = None
            mul_35: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_17, 1.0);  sin_17 = mul_35 = None
            
             # File: <eval_with_key>.139:5 in forward, code: unsqueeze_60 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_60: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0)
            
             # File: <eval_with_key>.139:6 in forward, code: slice_57 = torch.ops.aten.slice.Tensor(unsqueeze_60, 1, 0, 9223372036854775807);  unsqueeze_60 = None
            slice_57: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_60, 1, 0, 9223372036854775807);  unsqueeze_60 = None
            
             # File: <eval_with_key>.139:7 in forward, code: unsqueeze_61 = torch.ops.aten.unsqueeze.default(slice_57, 2);  slice_57 = None
            unsqueeze_61: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_57, 2);  slice_57 = None
            
             # File: <eval_with_key>.139:10 in forward, code: expand_19 = torch.ops.aten.expand.default(to_129, [1, -1, 1]);  to_129 = None
            expand_19: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_61, [1, -1, 1]);  unsqueeze_61 = None
            
             # File: <eval_with_key>.139:13 in forward, code: slice_58 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_58: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.139:14 in forward, code: unsqueeze_62 = torch.ops.aten.unsqueeze.default(slice_58, 1);  slice_58 = None
            unsqueeze_62: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_58, 1);  slice_58 = None
            
             # File: <eval_with_key>.139:15 in forward, code: slice_59 = torch.ops.aten.slice.Tensor(unsqueeze_62, 2, 0, 9223372036854775807);  unsqueeze_62 = None
            slice_59: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_62, 2, 0, 9223372036854775807);  unsqueeze_62 = None
            
             # File: <eval_with_key>.139:17 in forward, code: to_131 = torch.ops.aten.to.dtype(slice_59, torch.float32);  slice_59 = None
            _to_copy_20: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_59, dtype = torch.float32);  slice_59 = None
            
             # File: <eval_with_key>.139:22 in forward, code: matmul_18 = torch.ops.aten.matmul.default(to_132, to_133);  to_132 = to_133 = None
            matmul_18: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_19, _to_copy_20);  expand_19 = _to_copy_20 = None
            
             # File: <eval_with_key>.139:23 in forward, code: transpose_18 = torch.ops.aten.transpose.int(matmul_18, 1, 2);  matmul_18 = None
            transpose_18: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_18, 1, 2);  matmul_18 = None
            
             # File: <eval_with_key>.139:24 in forward, code: cat_18 = torch.ops.aten.cat.default([transpose_18, transpose_18], -1);  transpose_18 = None
            cat_18: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_18, transpose_18], -1);  transpose_18 = None
            
             # File: <eval_with_key>.139:25 in forward, code: cos_18 = torch.ops.aten.cos.default(cat_18)
            cos_18: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_18)
            
             # File: <eval_with_key>.139:26 in forward, code: mul_36 = torch.ops.aten.mul.Tensor(cos_18, 1.0);  cos_18 = None
            mul_36: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_18, 1.0);  cos_18 = mul_36 = None
            
             # File: <eval_with_key>.139:27 in forward, code: sin_18 = torch.ops.aten.sin.default(cat_18);  cat_18 = None
            sin_18: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_18);  cat_18 = None
            
             # File: <eval_with_key>.139:28 in forward, code: mul_37 = torch.ops.aten.mul.Tensor(sin_18, 1.0);  sin_18 = None
            mul_37: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_18, 1.0);  sin_18 = mul_37 = None
            
             # File: <eval_with_key>.140:5 in forward, code: unsqueeze_63 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_63: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0)
            
             # File: <eval_with_key>.140:6 in forward, code: slice_60 = torch.ops.aten.slice.Tensor(unsqueeze_63, 1, 0, 9223372036854775807);  unsqueeze_63 = None
            slice_60: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_63, 1, 0, 9223372036854775807);  unsqueeze_63 = None
            
             # File: <eval_with_key>.140:7 in forward, code: unsqueeze_64 = torch.ops.aten.unsqueeze.default(slice_60, 2);  slice_60 = None
            unsqueeze_64: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_60, 2);  slice_60 = None
            
             # File: <eval_with_key>.140:10 in forward, code: expand_20 = torch.ops.aten.expand.default(to_136, [1, -1, 1]);  to_136 = None
            expand_20: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_64, [1, -1, 1]);  unsqueeze_64 = None
            
             # File: <eval_with_key>.140:13 in forward, code: slice_61 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_61: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.140:14 in forward, code: unsqueeze_65 = torch.ops.aten.unsqueeze.default(slice_61, 1);  slice_61 = None
            unsqueeze_65: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_61, 1);  slice_61 = None
            
             # File: <eval_with_key>.140:15 in forward, code: slice_62 = torch.ops.aten.slice.Tensor(unsqueeze_65, 2, 0, 9223372036854775807);  unsqueeze_65 = None
            slice_62: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_65, 2, 0, 9223372036854775807);  unsqueeze_65 = None
            
             # File: <eval_with_key>.140:17 in forward, code: to_138 = torch.ops.aten.to.dtype(slice_62, torch.float32);  slice_62 = None
            _to_copy_21: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_62, dtype = torch.float32);  slice_62 = None
            
             # File: <eval_with_key>.140:22 in forward, code: matmul_19 = torch.ops.aten.matmul.default(to_139, to_140);  to_139 = to_140 = None
            matmul_19: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_20, _to_copy_21);  expand_20 = _to_copy_21 = None
            
             # File: <eval_with_key>.140:23 in forward, code: transpose_19 = torch.ops.aten.transpose.int(matmul_19, 1, 2);  matmul_19 = None
            transpose_19: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_19, 1, 2);  matmul_19 = None
            
             # File: <eval_with_key>.140:24 in forward, code: cat_19 = torch.ops.aten.cat.default([transpose_19, transpose_19], -1);  transpose_19 = None
            cat_19: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_19, transpose_19], -1);  transpose_19 = None
            
             # File: <eval_with_key>.140:25 in forward, code: cos_19 = torch.ops.aten.cos.default(cat_19)
            cos_19: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_19)
            
             # File: <eval_with_key>.140:26 in forward, code: mul_38 = torch.ops.aten.mul.Tensor(cos_19, 1.0);  cos_19 = None
            mul_38: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_19, 1.0);  cos_19 = mul_38 = None
            
             # File: <eval_with_key>.140:27 in forward, code: sin_19 = torch.ops.aten.sin.default(cat_19);  cat_19 = None
            sin_19: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_19);  cat_19 = None
            
             # File: <eval_with_key>.140:28 in forward, code: mul_39 = torch.ops.aten.mul.Tensor(sin_19, 1.0);  sin_19 = None
            mul_39: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_19, 1.0);  sin_19 = mul_39 = None
            
             # File: <eval_with_key>.141:5 in forward, code: unsqueeze_66 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            unsqueeze_66: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_sliding_attention_inv_freq, 0);  b_encoder_rotary_emb_sliding_attention_inv_freq = None
            
             # File: <eval_with_key>.141:6 in forward, code: slice_63 = torch.ops.aten.slice.Tensor(unsqueeze_66, 1, 0, 9223372036854775807);  unsqueeze_66 = None
            slice_63: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_66, 1, 0, 9223372036854775807);  unsqueeze_66 = None
            
             # File: <eval_with_key>.141:7 in forward, code: unsqueeze_67 = torch.ops.aten.unsqueeze.default(slice_63, 2);  slice_63 = None
            unsqueeze_67: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_63, 2);  slice_63 = None
            
             # File: <eval_with_key>.141:10 in forward, code: expand_21 = torch.ops.aten.expand.default(to_143, [1, -1, 1]);  to_143 = None
            expand_21: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_67, [1, -1, 1]);  unsqueeze_67 = None
            
             # File: <eval_with_key>.141:13 in forward, code: slice_64 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_64: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807)
            
             # File: <eval_with_key>.141:14 in forward, code: unsqueeze_68 = torch.ops.aten.unsqueeze.default(slice_64, 1);  slice_64 = None
            unsqueeze_68: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_64, 1);  slice_64 = None
            
             # File: <eval_with_key>.141:15 in forward, code: slice_65 = torch.ops.aten.slice.Tensor(unsqueeze_68, 2, 0, 9223372036854775807);  unsqueeze_68 = None
            slice_65: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_68, 2, 0, 9223372036854775807);  unsqueeze_68 = None
            
             # File: <eval_with_key>.141:17 in forward, code: to_145 = torch.ops.aten.to.dtype(slice_65, torch.float32);  slice_65 = None
            _to_copy_22: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_65, dtype = torch.float32);  slice_65 = None
            
             # File: <eval_with_key>.141:22 in forward, code: matmul_20 = torch.ops.aten.matmul.default(to_146, to_147);  to_146 = to_147 = None
            matmul_20: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_21, _to_copy_22);  expand_21 = _to_copy_22 = None
            
             # File: <eval_with_key>.141:23 in forward, code: transpose_20 = torch.ops.aten.transpose.int(matmul_20, 1, 2);  matmul_20 = None
            transpose_20: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_20, 1, 2);  matmul_20 = None
            
             # File: <eval_with_key>.141:24 in forward, code: cat_20 = torch.ops.aten.cat.default([transpose_20, transpose_20], -1);  transpose_20 = None
            cat_20: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_20, transpose_20], -1);  transpose_20 = None
            
             # File: <eval_with_key>.141:25 in forward, code: cos_20 = torch.ops.aten.cos.default(cat_20)
            cos_20: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_20)
            
             # File: <eval_with_key>.141:26 in forward, code: mul_40 = torch.ops.aten.mul.Tensor(cos_20, 1.0);  cos_20 = None
            mul_40: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_20, 1.0);  cos_20 = None
            
             # File: <eval_with_key>.141:27 in forward, code: sin_20 = torch.ops.aten.sin.default(cat_20);  cat_20 = None
            sin_20: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_20);  cat_20 = None
            
             # File: <eval_with_key>.141:28 in forward, code: mul_41 = torch.ops.aten.mul.Tensor(sin_20, 1.0);  sin_20 = None
            mul_41: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_20, 1.0);  sin_20 = None
            
             # File: <eval_with_key>.142:5 in forward, code: unsqueeze_69 = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            unsqueeze_69: "f32[1, 32]" = torch.ops.aten.unsqueeze.default(b_encoder_rotary_emb_full_attention_inv_freq, 0);  b_encoder_rotary_emb_full_attention_inv_freq = None
            
             # File: <eval_with_key>.142:6 in forward, code: slice_66 = torch.ops.aten.slice.Tensor(unsqueeze_69, 1, 0, 9223372036854775807);  unsqueeze_69 = None
            slice_66: "f32[1, 32]" = torch.ops.aten.slice.Tensor(unsqueeze_69, 1, 0, 9223372036854775807);  unsqueeze_69 = None
            
             # File: <eval_with_key>.142:7 in forward, code: unsqueeze_70 = torch.ops.aten.unsqueeze.default(slice_66, 2);  slice_66 = None
            unsqueeze_70: "f32[1, 32, 1]" = torch.ops.aten.unsqueeze.default(slice_66, 2);  slice_66 = None
            
             # File: <eval_with_key>.142:10 in forward, code: expand_22 = torch.ops.aten.expand.default(to_150, [1, -1, 1]);  to_150 = None
            expand_22: "f32[1, 32, 1]" = torch.ops.aten.expand.default(unsqueeze_70, [1, -1, 1]);  unsqueeze_70 = None
            
             # File: <eval_with_key>.142:13 in forward, code: slice_67 = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            slice_67: "i64[1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze, 0, 0, 9223372036854775807);  unsqueeze = None
            
             # File: <eval_with_key>.142:14 in forward, code: unsqueeze_71 = torch.ops.aten.unsqueeze.default(slice_67, 1);  slice_67 = None
            unsqueeze_71: "i64[1, 1, 97]" = torch.ops.aten.unsqueeze.default(slice_67, 1);  slice_67 = None
            
             # File: <eval_with_key>.142:15 in forward, code: slice_68 = torch.ops.aten.slice.Tensor(unsqueeze_71, 2, 0, 9223372036854775807);  unsqueeze_71 = None
            slice_68: "i64[1, 1, 97]" = torch.ops.aten.slice.Tensor(unsqueeze_71, 2, 0, 9223372036854775807);  unsqueeze_71 = None
            
             # File: <eval_with_key>.142:17 in forward, code: to_152 = torch.ops.aten.to.dtype(slice_68, torch.float32);  slice_68 = None
            _to_copy_23: "f32[1, 1, 97]" = torch.ops.aten._to_copy.default(slice_68, dtype = torch.float32);  slice_68 = None
            
             # File: <eval_with_key>.142:22 in forward, code: matmul_21 = torch.ops.aten.matmul.default(to_153, to_154);  to_153 = to_154 = None
            matmul_21: "f32[1, 32, 97]" = torch.ops.aten.matmul.default(expand_22, _to_copy_23);  expand_22 = _to_copy_23 = None
            
             # File: <eval_with_key>.142:23 in forward, code: transpose_21 = torch.ops.aten.transpose.int(matmul_21, 1, 2);  matmul_21 = None
            transpose_21: "f32[1, 97, 32]" = torch.ops.aten.transpose.int(matmul_21, 1, 2);  matmul_21 = None
            
             # File: <eval_with_key>.142:24 in forward, code: cat_21 = torch.ops.aten.cat.default([transpose_21, transpose_21], -1);  transpose_21 = None
            cat_21: "f32[1, 97, 64]" = torch.ops.aten.cat.default([transpose_21, transpose_21], -1);  transpose_21 = None
            
             # File: <eval_with_key>.142:25 in forward, code: cos_21 = torch.ops.aten.cos.default(cat_21)
            cos_21: "f32[1, 97, 64]" = torch.ops.aten.cos.default(cat_21)
            
             # File: <eval_with_key>.142:26 in forward, code: mul_42 = torch.ops.aten.mul.Tensor(cos_21, 1.0);  cos_21 = None
            mul_42: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(cos_21, 1.0);  cos_21 = None
            
             # File: <eval_with_key>.142:27 in forward, code: sin_21 = torch.ops.aten.sin.default(cat_21);  cat_21 = None
            sin_21: "f32[1, 97, 64]" = torch.ops.aten.sin.default(cat_21);  cat_21 = None
            
             # File: <eval_with_key>.142:28 in forward, code: mul_43 = torch.ops.aten.mul.Tensor(sin_21, 1.0);  sin_21 = None
            mul_43: "f32[1, 97, 64]" = torch.ops.aten.mul.Tensor(sin_21, 1.0);  sin_21 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(clone_1, p_encoder_layers_0_attn_wqkv_weight);  p_encoder_layers_0_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear, [1, -1, 3, 12, 64]);  linear = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_22: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view, 3, 1);  view = None
            unbind = torch.ops.aten.unbind.int(transpose_22, 2);  transpose_22 = None
            getitem: "f32[1, 12, 97, 64]" = unbind[0]
            getitem_1: "f32[1, 12, 97, 64]" = unbind[1]
            getitem_2: "f32[1, 12, 97, 64]" = unbind[2];  unbind = None
            unsqueeze_72: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_73: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_44: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem, unsqueeze_72)
            slice_69: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem, 3, 0, 32)
            slice_70: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem, 3, 32, 9223372036854775807);  getitem = None
            neg: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_70);  slice_70 = None
            cat_22: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg, slice_69], -1);  neg = slice_69 = None
            mul_45: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_22, unsqueeze_73);  cat_22 = None
            add: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_44, mul_45);  mul_44 = mul_45 = None
            mul_46: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_1, unsqueeze_72);  unsqueeze_72 = None
            slice_71: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_1, 3, 0, 32)
            slice_72: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_1, 3, 32, 9223372036854775807);  getitem_1 = None
            neg_1: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_72);  slice_72 = None
            cat_23: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_1, slice_71], -1);  neg_1 = slice_71 = None
            mul_47: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_23, unsqueeze_73);  cat_23 = unsqueeze_73 = None
            add_1: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_46, mul_47);  mul_46 = mul_47 = None
            scaled_dot_product_attention: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add, add_1, getitem_2, masked_fill);  add = add_1 = getitem_2 = None
            transpose_23: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention, 1, 2);  scaled_dot_product_attention = None
            view_1: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_23, [1, -1, 768]);  transpose_23 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_1: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_1, p_encoder_layers_0_attn_wo_weight);  view_1 = p_encoder_layers_0_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_2: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(clone_1, linear_1);  clone_1 = linear_1 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_1: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_2, [768], p_encoder_layers_0_mlp_norm_weight);  p_encoder_layers_0_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_2: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_1, p_encoder_layers_0_mlp_wi_weight);  layer_norm_1 = p_encoder_layers_0_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split = torch.ops.aten.split.Tensor(linear_2, 1152, -1);  linear_2 = None
            getitem_3: "f32[1, 97, 1152]" = split[0]
            getitem_4: "f32[1, 97, 1152]" = split[1];  split = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_3);  getitem_3 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_48: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu, getitem_4);  gelu = getitem_4 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_2: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_48);  mul_48 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_3: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_2, p_encoder_layers_0_mlp_wo_weight);  clone_2 = p_encoder_layers_0_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_3: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_2, linear_3);  add_2 = linear_3 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_2: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_3, [768], p_encoder_layers_1_attn_norm_weight);  p_encoder_layers_1_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_4: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_2, p_encoder_layers_1_attn_wqkv_weight);  layer_norm_2 = p_encoder_layers_1_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_2: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_4, [1, -1, 3, 12, 64]);  linear_4 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_24: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_2, 3, 1);  view_2 = None
            unbind_1 = torch.ops.aten.unbind.int(transpose_24, 2);  transpose_24 = None
            getitem_5: "f32[1, 12, 97, 64]" = unbind_1[0]
            getitem_6: "f32[1, 12, 97, 64]" = unbind_1[1]
            getitem_7: "f32[1, 12, 97, 64]" = unbind_1[2];  unbind_1 = None
            unsqueeze_74: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_75: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_49: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_5, unsqueeze_74)
            slice_73: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_5, 3, 0, 32)
            slice_74: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_5, 3, 32, 9223372036854775807);  getitem_5 = None
            neg_2: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_74);  slice_74 = None
            cat_24: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_2, slice_73], -1);  neg_2 = slice_73 = None
            mul_50: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_24, unsqueeze_75);  cat_24 = None
            add_4: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_49, mul_50);  mul_49 = mul_50 = None
            mul_51: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_6, unsqueeze_74);  unsqueeze_74 = None
            slice_75: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_6, 3, 0, 32)
            slice_76: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_6, 3, 32, 9223372036854775807);  getitem_6 = None
            neg_3: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_76);  slice_76 = None
            cat_25: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_3, slice_75], -1);  neg_3 = slice_75 = None
            mul_52: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_25, unsqueeze_75);  cat_25 = unsqueeze_75 = None
            add_5: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_51, mul_52);  mul_51 = mul_52 = None
            scaled_dot_product_attention_1: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_4, add_5, getitem_7, masked_fill_1);  add_4 = add_5 = getitem_7 = None
            transpose_25: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_1, 1, 2);  scaled_dot_product_attention_1 = None
            view_3: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_25, [1, -1, 768]);  transpose_25 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_5: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_3, p_encoder_layers_1_attn_wo_weight);  view_3 = p_encoder_layers_1_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_6: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_3, linear_5);  add_3 = linear_5 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_3: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_6, [768], p_encoder_layers_1_mlp_norm_weight);  p_encoder_layers_1_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_6: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_3, p_encoder_layers_1_mlp_wi_weight);  layer_norm_3 = p_encoder_layers_1_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_1 = torch.ops.aten.split.Tensor(linear_6, 1152, -1);  linear_6 = None
            getitem_8: "f32[1, 97, 1152]" = split_1[0]
            getitem_9: "f32[1, 97, 1152]" = split_1[1];  split_1 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_1: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_8);  getitem_8 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_53: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_1, getitem_9);  gelu_1 = getitem_9 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_3: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_53);  mul_53 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_7: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_3, p_encoder_layers_1_mlp_wo_weight);  clone_3 = p_encoder_layers_1_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_7: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_6, linear_7);  add_6 = linear_7 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_4: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_7, [768], p_encoder_layers_2_attn_norm_weight);  p_encoder_layers_2_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_8: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_4, p_encoder_layers_2_attn_wqkv_weight);  layer_norm_4 = p_encoder_layers_2_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_4: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_8, [1, -1, 3, 12, 64]);  linear_8 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_26: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_4, 3, 1);  view_4 = None
            unbind_2 = torch.ops.aten.unbind.int(transpose_26, 2);  transpose_26 = None
            getitem_10: "f32[1, 12, 97, 64]" = unbind_2[0]
            getitem_11: "f32[1, 12, 97, 64]" = unbind_2[1]
            getitem_12: "f32[1, 12, 97, 64]" = unbind_2[2];  unbind_2 = None
            unsqueeze_76: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_77: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_54: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_10, unsqueeze_76)
            slice_77: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_10, 3, 0, 32)
            slice_78: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_10, 3, 32, 9223372036854775807);  getitem_10 = None
            neg_4: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_78);  slice_78 = None
            cat_26: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_4, slice_77], -1);  neg_4 = slice_77 = None
            mul_55: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_26, unsqueeze_77);  cat_26 = None
            add_8: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_54, mul_55);  mul_54 = mul_55 = None
            mul_56: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_11, unsqueeze_76);  unsqueeze_76 = None
            slice_79: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_11, 3, 0, 32)
            slice_80: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_11, 3, 32, 9223372036854775807);  getitem_11 = None
            neg_5: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_80);  slice_80 = None
            cat_27: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_5, slice_79], -1);  neg_5 = slice_79 = None
            mul_57: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_27, unsqueeze_77);  cat_27 = unsqueeze_77 = None
            add_9: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_56, mul_57);  mul_56 = mul_57 = None
            scaled_dot_product_attention_2: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_8, add_9, getitem_12, masked_fill_1);  add_8 = add_9 = getitem_12 = None
            transpose_27: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_2, 1, 2);  scaled_dot_product_attention_2 = None
            view_5: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_27, [1, -1, 768]);  transpose_27 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_9: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_5, p_encoder_layers_2_attn_wo_weight);  view_5 = p_encoder_layers_2_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_10: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_7, linear_9);  add_7 = linear_9 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_5: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_10, [768], p_encoder_layers_2_mlp_norm_weight);  p_encoder_layers_2_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_10: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_5, p_encoder_layers_2_mlp_wi_weight);  layer_norm_5 = p_encoder_layers_2_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_2 = torch.ops.aten.split.Tensor(linear_10, 1152, -1);  linear_10 = None
            getitem_13: "f32[1, 97, 1152]" = split_2[0]
            getitem_14: "f32[1, 97, 1152]" = split_2[1];  split_2 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_2: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_13);  getitem_13 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_58: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_2, getitem_14);  gelu_2 = getitem_14 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_4: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_58);  mul_58 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_11: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_4, p_encoder_layers_2_mlp_wo_weight);  clone_4 = p_encoder_layers_2_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_11: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_10, linear_11);  add_10 = linear_11 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_6: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_11, [768], p_encoder_layers_3_attn_norm_weight);  p_encoder_layers_3_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_12: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_6, p_encoder_layers_3_attn_wqkv_weight);  layer_norm_6 = p_encoder_layers_3_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_6: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_12, [1, -1, 3, 12, 64]);  linear_12 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_28: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_6, 3, 1);  view_6 = None
            unbind_3 = torch.ops.aten.unbind.int(transpose_28, 2);  transpose_28 = None
            getitem_15: "f32[1, 12, 97, 64]" = unbind_3[0]
            getitem_16: "f32[1, 12, 97, 64]" = unbind_3[1]
            getitem_17: "f32[1, 12, 97, 64]" = unbind_3[2];  unbind_3 = None
            unsqueeze_78: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_79: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_59: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_15, unsqueeze_78)
            slice_81: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_15, 3, 0, 32)
            slice_82: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_15, 3, 32, 9223372036854775807);  getitem_15 = None
            neg_6: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_82);  slice_82 = None
            cat_28: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_6, slice_81], -1);  neg_6 = slice_81 = None
            mul_60: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_28, unsqueeze_79);  cat_28 = None
            add_12: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_59, mul_60);  mul_59 = mul_60 = None
            mul_61: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_16, unsqueeze_78);  unsqueeze_78 = None
            slice_83: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_16, 3, 0, 32)
            slice_84: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_16, 3, 32, 9223372036854775807);  getitem_16 = None
            neg_7: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_84);  slice_84 = None
            cat_29: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_7, slice_83], -1);  neg_7 = slice_83 = None
            mul_62: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_29, unsqueeze_79);  cat_29 = unsqueeze_79 = None
            add_13: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_61, mul_62);  mul_61 = mul_62 = None
            scaled_dot_product_attention_3: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_12, add_13, getitem_17, masked_fill);  add_12 = add_13 = getitem_17 = None
            transpose_29: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_3, 1, 2);  scaled_dot_product_attention_3 = None
            view_7: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_29, [1, -1, 768]);  transpose_29 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_13: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_7, p_encoder_layers_3_attn_wo_weight);  view_7 = p_encoder_layers_3_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_14: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_11, linear_13);  add_11 = linear_13 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_7: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_14, [768], p_encoder_layers_3_mlp_norm_weight);  p_encoder_layers_3_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_14: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_7, p_encoder_layers_3_mlp_wi_weight);  layer_norm_7 = p_encoder_layers_3_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_3 = torch.ops.aten.split.Tensor(linear_14, 1152, -1);  linear_14 = None
            getitem_18: "f32[1, 97, 1152]" = split_3[0]
            getitem_19: "f32[1, 97, 1152]" = split_3[1];  split_3 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_3: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_18);  getitem_18 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_63: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_3, getitem_19);  gelu_3 = getitem_19 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_5: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_63);  mul_63 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_15: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_5, p_encoder_layers_3_mlp_wo_weight);  clone_5 = p_encoder_layers_3_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_15: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_14, linear_15);  add_14 = linear_15 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_8: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_15, [768], p_encoder_layers_4_attn_norm_weight);  p_encoder_layers_4_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_16: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_8, p_encoder_layers_4_attn_wqkv_weight);  layer_norm_8 = p_encoder_layers_4_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_8: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_16, [1, -1, 3, 12, 64]);  linear_16 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_30: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_8, 3, 1);  view_8 = None
            unbind_4 = torch.ops.aten.unbind.int(transpose_30, 2);  transpose_30 = None
            getitem_20: "f32[1, 12, 97, 64]" = unbind_4[0]
            getitem_21: "f32[1, 12, 97, 64]" = unbind_4[1]
            getitem_22: "f32[1, 12, 97, 64]" = unbind_4[2];  unbind_4 = None
            unsqueeze_80: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_81: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_64: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_20, unsqueeze_80)
            slice_85: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_20, 3, 0, 32)
            slice_86: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_20, 3, 32, 9223372036854775807);  getitem_20 = None
            neg_8: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_86);  slice_86 = None
            cat_30: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_8, slice_85], -1);  neg_8 = slice_85 = None
            mul_65: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_30, unsqueeze_81);  cat_30 = None
            add_16: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_64, mul_65);  mul_64 = mul_65 = None
            mul_66: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_21, unsqueeze_80);  unsqueeze_80 = None
            slice_87: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_21, 3, 0, 32)
            slice_88: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_21, 3, 32, 9223372036854775807);  getitem_21 = None
            neg_9: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_88);  slice_88 = None
            cat_31: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_9, slice_87], -1);  neg_9 = slice_87 = None
            mul_67: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_31, unsqueeze_81);  cat_31 = unsqueeze_81 = None
            add_17: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_66, mul_67);  mul_66 = mul_67 = None
            scaled_dot_product_attention_4: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_16, add_17, getitem_22, masked_fill_1);  add_16 = add_17 = getitem_22 = None
            transpose_31: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_4, 1, 2);  scaled_dot_product_attention_4 = None
            view_9: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_31, [1, -1, 768]);  transpose_31 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_17: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_9, p_encoder_layers_4_attn_wo_weight);  view_9 = p_encoder_layers_4_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_18: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_15, linear_17);  add_15 = linear_17 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_9: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_18, [768], p_encoder_layers_4_mlp_norm_weight);  p_encoder_layers_4_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_18: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_9, p_encoder_layers_4_mlp_wi_weight);  layer_norm_9 = p_encoder_layers_4_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_4 = torch.ops.aten.split.Tensor(linear_18, 1152, -1);  linear_18 = None
            getitem_23: "f32[1, 97, 1152]" = split_4[0]
            getitem_24: "f32[1, 97, 1152]" = split_4[1];  split_4 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_4: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_23);  getitem_23 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_68: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_4, getitem_24);  gelu_4 = getitem_24 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_6: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_68);  mul_68 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_19: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_6, p_encoder_layers_4_mlp_wo_weight);  clone_6 = p_encoder_layers_4_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_19: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_18, linear_19);  add_18 = linear_19 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_10: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_19, [768], p_encoder_layers_5_attn_norm_weight);  p_encoder_layers_5_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_20: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_10, p_encoder_layers_5_attn_wqkv_weight);  layer_norm_10 = p_encoder_layers_5_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_10: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_20, [1, -1, 3, 12, 64]);  linear_20 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_32: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_10, 3, 1);  view_10 = None
            unbind_5 = torch.ops.aten.unbind.int(transpose_32, 2);  transpose_32 = None
            getitem_25: "f32[1, 12, 97, 64]" = unbind_5[0]
            getitem_26: "f32[1, 12, 97, 64]" = unbind_5[1]
            getitem_27: "f32[1, 12, 97, 64]" = unbind_5[2];  unbind_5 = None
            unsqueeze_82: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_83: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_69: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_25, unsqueeze_82)
            slice_89: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_25, 3, 0, 32)
            slice_90: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_25, 3, 32, 9223372036854775807);  getitem_25 = None
            neg_10: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_90);  slice_90 = None
            cat_32: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_10, slice_89], -1);  neg_10 = slice_89 = None
            mul_70: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_32, unsqueeze_83);  cat_32 = None
            add_20: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_69, mul_70);  mul_69 = mul_70 = None
            mul_71: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_26, unsqueeze_82);  unsqueeze_82 = None
            slice_91: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_26, 3, 0, 32)
            slice_92: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_26, 3, 32, 9223372036854775807);  getitem_26 = None
            neg_11: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_92);  slice_92 = None
            cat_33: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_11, slice_91], -1);  neg_11 = slice_91 = None
            mul_72: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_33, unsqueeze_83);  cat_33 = unsqueeze_83 = None
            add_21: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_71, mul_72);  mul_71 = mul_72 = None
            scaled_dot_product_attention_5: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_20, add_21, getitem_27, masked_fill_1);  add_20 = add_21 = getitem_27 = None
            transpose_33: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_5, 1, 2);  scaled_dot_product_attention_5 = None
            view_11: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_33, [1, -1, 768]);  transpose_33 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_21: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_11, p_encoder_layers_5_attn_wo_weight);  view_11 = p_encoder_layers_5_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_22: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_19, linear_21);  add_19 = linear_21 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_11: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_22, [768], p_encoder_layers_5_mlp_norm_weight);  p_encoder_layers_5_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_22: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_11, p_encoder_layers_5_mlp_wi_weight);  layer_norm_11 = p_encoder_layers_5_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_5 = torch.ops.aten.split.Tensor(linear_22, 1152, -1);  linear_22 = None
            getitem_28: "f32[1, 97, 1152]" = split_5[0]
            getitem_29: "f32[1, 97, 1152]" = split_5[1];  split_5 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_5: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_28);  getitem_28 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_73: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_5, getitem_29);  gelu_5 = getitem_29 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_7: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_73);  mul_73 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_23: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_7, p_encoder_layers_5_mlp_wo_weight);  clone_7 = p_encoder_layers_5_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_23: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_22, linear_23);  add_22 = linear_23 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_12: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_23, [768], p_encoder_layers_6_attn_norm_weight);  p_encoder_layers_6_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_24: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_12, p_encoder_layers_6_attn_wqkv_weight);  layer_norm_12 = p_encoder_layers_6_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_12: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_24, [1, -1, 3, 12, 64]);  linear_24 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_34: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_12, 3, 1);  view_12 = None
            unbind_6 = torch.ops.aten.unbind.int(transpose_34, 2);  transpose_34 = None
            getitem_30: "f32[1, 12, 97, 64]" = unbind_6[0]
            getitem_31: "f32[1, 12, 97, 64]" = unbind_6[1]
            getitem_32: "f32[1, 12, 97, 64]" = unbind_6[2];  unbind_6 = None
            unsqueeze_84: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_85: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_74: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_30, unsqueeze_84)
            slice_93: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_30, 3, 0, 32)
            slice_94: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_30, 3, 32, 9223372036854775807);  getitem_30 = None
            neg_12: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_94);  slice_94 = None
            cat_34: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_12, slice_93], -1);  neg_12 = slice_93 = None
            mul_75: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_34, unsqueeze_85);  cat_34 = None
            add_24: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_74, mul_75);  mul_74 = mul_75 = None
            mul_76: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_31, unsqueeze_84);  unsqueeze_84 = None
            slice_95: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_31, 3, 0, 32)
            slice_96: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_31, 3, 32, 9223372036854775807);  getitem_31 = None
            neg_13: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_96);  slice_96 = None
            cat_35: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_13, slice_95], -1);  neg_13 = slice_95 = None
            mul_77: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_35, unsqueeze_85);  cat_35 = unsqueeze_85 = None
            add_25: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_76, mul_77);  mul_76 = mul_77 = None
            scaled_dot_product_attention_6: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_24, add_25, getitem_32, masked_fill);  add_24 = add_25 = getitem_32 = None
            transpose_35: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_6, 1, 2);  scaled_dot_product_attention_6 = None
            view_13: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_35, [1, -1, 768]);  transpose_35 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_25: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_13, p_encoder_layers_6_attn_wo_weight);  view_13 = p_encoder_layers_6_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_26: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_23, linear_25);  add_23 = linear_25 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_13: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_26, [768], p_encoder_layers_6_mlp_norm_weight);  p_encoder_layers_6_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_26: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_13, p_encoder_layers_6_mlp_wi_weight);  layer_norm_13 = p_encoder_layers_6_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_6 = torch.ops.aten.split.Tensor(linear_26, 1152, -1);  linear_26 = None
            getitem_33: "f32[1, 97, 1152]" = split_6[0]
            getitem_34: "f32[1, 97, 1152]" = split_6[1];  split_6 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_6: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_33);  getitem_33 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_78: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_6, getitem_34);  gelu_6 = getitem_34 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_8: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_78);  mul_78 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_27: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_8, p_encoder_layers_6_mlp_wo_weight);  clone_8 = p_encoder_layers_6_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_27: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_26, linear_27);  add_26 = linear_27 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_14: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_27, [768], p_encoder_layers_7_attn_norm_weight);  p_encoder_layers_7_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_28: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_14, p_encoder_layers_7_attn_wqkv_weight);  layer_norm_14 = p_encoder_layers_7_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_14: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_28, [1, -1, 3, 12, 64]);  linear_28 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_36: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_14, 3, 1);  view_14 = None
            unbind_7 = torch.ops.aten.unbind.int(transpose_36, 2);  transpose_36 = None
            getitem_35: "f32[1, 12, 97, 64]" = unbind_7[0]
            getitem_36: "f32[1, 12, 97, 64]" = unbind_7[1]
            getitem_37: "f32[1, 12, 97, 64]" = unbind_7[2];  unbind_7 = None
            unsqueeze_86: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_87: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_79: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_35, unsqueeze_86)
            slice_97: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_35, 3, 0, 32)
            slice_98: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_35, 3, 32, 9223372036854775807);  getitem_35 = None
            neg_14: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_98);  slice_98 = None
            cat_36: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_14, slice_97], -1);  neg_14 = slice_97 = None
            mul_80: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_36, unsqueeze_87);  cat_36 = None
            add_28: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_79, mul_80);  mul_79 = mul_80 = None
            mul_81: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_36, unsqueeze_86);  unsqueeze_86 = None
            slice_99: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_36, 3, 0, 32)
            slice_100: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_36, 3, 32, 9223372036854775807);  getitem_36 = None
            neg_15: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_100);  slice_100 = None
            cat_37: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_15, slice_99], -1);  neg_15 = slice_99 = None
            mul_82: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_37, unsqueeze_87);  cat_37 = unsqueeze_87 = None
            add_29: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_81, mul_82);  mul_81 = mul_82 = None
            scaled_dot_product_attention_7: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_28, add_29, getitem_37, masked_fill_1);  add_28 = add_29 = getitem_37 = None
            transpose_37: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_7, 1, 2);  scaled_dot_product_attention_7 = None
            view_15: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_37, [1, -1, 768]);  transpose_37 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_29: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_15, p_encoder_layers_7_attn_wo_weight);  view_15 = p_encoder_layers_7_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_30: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_27, linear_29);  add_27 = linear_29 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_15: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_30, [768], p_encoder_layers_7_mlp_norm_weight);  p_encoder_layers_7_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_30: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_15, p_encoder_layers_7_mlp_wi_weight);  layer_norm_15 = p_encoder_layers_7_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_7 = torch.ops.aten.split.Tensor(linear_30, 1152, -1);  linear_30 = None
            getitem_38: "f32[1, 97, 1152]" = split_7[0]
            getitem_39: "f32[1, 97, 1152]" = split_7[1];  split_7 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_7: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_38);  getitem_38 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_83: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_7, getitem_39);  gelu_7 = getitem_39 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_9: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_83);  mul_83 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_31: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_9, p_encoder_layers_7_mlp_wo_weight);  clone_9 = p_encoder_layers_7_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_31: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_30, linear_31);  add_30 = linear_31 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_16: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_31, [768], p_encoder_layers_8_attn_norm_weight);  p_encoder_layers_8_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_32: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_16, p_encoder_layers_8_attn_wqkv_weight);  layer_norm_16 = p_encoder_layers_8_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_16: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_32, [1, -1, 3, 12, 64]);  linear_32 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_38: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_16, 3, 1);  view_16 = None
            unbind_8 = torch.ops.aten.unbind.int(transpose_38, 2);  transpose_38 = None
            getitem_40: "f32[1, 12, 97, 64]" = unbind_8[0]
            getitem_41: "f32[1, 12, 97, 64]" = unbind_8[1]
            getitem_42: "f32[1, 12, 97, 64]" = unbind_8[2];  unbind_8 = None
            unsqueeze_88: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_89: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_84: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_40, unsqueeze_88)
            slice_101: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_40, 3, 0, 32)
            slice_102: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_40, 3, 32, 9223372036854775807);  getitem_40 = None
            neg_16: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_102);  slice_102 = None
            cat_38: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_16, slice_101], -1);  neg_16 = slice_101 = None
            mul_85: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_38, unsqueeze_89);  cat_38 = None
            add_32: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_84, mul_85);  mul_84 = mul_85 = None
            mul_86: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_41, unsqueeze_88);  unsqueeze_88 = None
            slice_103: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_41, 3, 0, 32)
            slice_104: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_41, 3, 32, 9223372036854775807);  getitem_41 = None
            neg_17: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_104);  slice_104 = None
            cat_39: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_17, slice_103], -1);  neg_17 = slice_103 = None
            mul_87: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_39, unsqueeze_89);  cat_39 = unsqueeze_89 = None
            add_33: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_86, mul_87);  mul_86 = mul_87 = None
            scaled_dot_product_attention_8: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_32, add_33, getitem_42, masked_fill_1);  add_32 = add_33 = getitem_42 = None
            transpose_39: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_8, 1, 2);  scaled_dot_product_attention_8 = None
            view_17: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_39, [1, -1, 768]);  transpose_39 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_33: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_17, p_encoder_layers_8_attn_wo_weight);  view_17 = p_encoder_layers_8_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_34: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_31, linear_33);  add_31 = linear_33 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_17: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_34, [768], p_encoder_layers_8_mlp_norm_weight);  p_encoder_layers_8_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_34: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_17, p_encoder_layers_8_mlp_wi_weight);  layer_norm_17 = p_encoder_layers_8_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_8 = torch.ops.aten.split.Tensor(linear_34, 1152, -1);  linear_34 = None
            getitem_43: "f32[1, 97, 1152]" = split_8[0]
            getitem_44: "f32[1, 97, 1152]" = split_8[1];  split_8 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_8: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_43);  getitem_43 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_88: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_8, getitem_44);  gelu_8 = getitem_44 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_10: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_88);  mul_88 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_35: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_10, p_encoder_layers_8_mlp_wo_weight);  clone_10 = p_encoder_layers_8_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_35: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_34, linear_35);  add_34 = linear_35 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_18: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_35, [768], p_encoder_layers_9_attn_norm_weight);  p_encoder_layers_9_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_36: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_18, p_encoder_layers_9_attn_wqkv_weight);  layer_norm_18 = p_encoder_layers_9_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_18: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_36, [1, -1, 3, 12, 64]);  linear_36 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_40: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_18, 3, 1);  view_18 = None
            unbind_9 = torch.ops.aten.unbind.int(transpose_40, 2);  transpose_40 = None
            getitem_45: "f32[1, 12, 97, 64]" = unbind_9[0]
            getitem_46: "f32[1, 12, 97, 64]" = unbind_9[1]
            getitem_47: "f32[1, 12, 97, 64]" = unbind_9[2];  unbind_9 = None
            unsqueeze_90: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_91: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_89: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_45, unsqueeze_90)
            slice_105: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_45, 3, 0, 32)
            slice_106: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_45, 3, 32, 9223372036854775807);  getitem_45 = None
            neg_18: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_106);  slice_106 = None
            cat_40: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_18, slice_105], -1);  neg_18 = slice_105 = None
            mul_90: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_40, unsqueeze_91);  cat_40 = None
            add_36: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_89, mul_90);  mul_89 = mul_90 = None
            mul_91: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_46, unsqueeze_90);  unsqueeze_90 = None
            slice_107: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_46, 3, 0, 32)
            slice_108: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_46, 3, 32, 9223372036854775807);  getitem_46 = None
            neg_19: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_108);  slice_108 = None
            cat_41: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_19, slice_107], -1);  neg_19 = slice_107 = None
            mul_92: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_41, unsqueeze_91);  cat_41 = unsqueeze_91 = None
            add_37: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_91, mul_92);  mul_91 = mul_92 = None
            scaled_dot_product_attention_9: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_36, add_37, getitem_47, masked_fill);  add_36 = add_37 = getitem_47 = None
            transpose_41: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_9, 1, 2);  scaled_dot_product_attention_9 = None
            view_19: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_41, [1, -1, 768]);  transpose_41 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_37: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_19, p_encoder_layers_9_attn_wo_weight);  view_19 = p_encoder_layers_9_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_38: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_35, linear_37);  add_35 = linear_37 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_19: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_38, [768], p_encoder_layers_9_mlp_norm_weight);  p_encoder_layers_9_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_38: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_19, p_encoder_layers_9_mlp_wi_weight);  layer_norm_19 = p_encoder_layers_9_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_9 = torch.ops.aten.split.Tensor(linear_38, 1152, -1);  linear_38 = None
            getitem_48: "f32[1, 97, 1152]" = split_9[0]
            getitem_49: "f32[1, 97, 1152]" = split_9[1];  split_9 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_9: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_48);  getitem_48 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_93: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_9, getitem_49);  gelu_9 = getitem_49 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_11: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_93);  mul_93 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_39: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_11, p_encoder_layers_9_mlp_wo_weight);  clone_11 = p_encoder_layers_9_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_39: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_38, linear_39);  add_38 = linear_39 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_20: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_39, [768], p_encoder_layers_10_attn_norm_weight);  p_encoder_layers_10_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_40: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_20, p_encoder_layers_10_attn_wqkv_weight);  layer_norm_20 = p_encoder_layers_10_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_20: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_40, [1, -1, 3, 12, 64]);  linear_40 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_42: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_20, 3, 1);  view_20 = None
            unbind_10 = torch.ops.aten.unbind.int(transpose_42, 2);  transpose_42 = None
            getitem_50: "f32[1, 12, 97, 64]" = unbind_10[0]
            getitem_51: "f32[1, 12, 97, 64]" = unbind_10[1]
            getitem_52: "f32[1, 12, 97, 64]" = unbind_10[2];  unbind_10 = None
            unsqueeze_92: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_93: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_94: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_50, unsqueeze_92)
            slice_109: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_50, 3, 0, 32)
            slice_110: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_50, 3, 32, 9223372036854775807);  getitem_50 = None
            neg_20: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_110);  slice_110 = None
            cat_42: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_20, slice_109], -1);  neg_20 = slice_109 = None
            mul_95: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_42, unsqueeze_93);  cat_42 = None
            add_40: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_94, mul_95);  mul_94 = mul_95 = None
            mul_96: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_51, unsqueeze_92);  unsqueeze_92 = None
            slice_111: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_51, 3, 0, 32)
            slice_112: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_51, 3, 32, 9223372036854775807);  getitem_51 = None
            neg_21: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_112);  slice_112 = None
            cat_43: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_21, slice_111], -1);  neg_21 = slice_111 = None
            mul_97: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_43, unsqueeze_93);  cat_43 = unsqueeze_93 = None
            add_41: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_96, mul_97);  mul_96 = mul_97 = None
            scaled_dot_product_attention_10: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_40, add_41, getitem_52, masked_fill_1);  add_40 = add_41 = getitem_52 = None
            transpose_43: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_10, 1, 2);  scaled_dot_product_attention_10 = None
            view_21: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_43, [1, -1, 768]);  transpose_43 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_41: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_21, p_encoder_layers_10_attn_wo_weight);  view_21 = p_encoder_layers_10_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_42: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_39, linear_41);  add_39 = linear_41 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_21: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_42, [768], p_encoder_layers_10_mlp_norm_weight);  p_encoder_layers_10_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_42: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_21, p_encoder_layers_10_mlp_wi_weight);  layer_norm_21 = p_encoder_layers_10_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_10 = torch.ops.aten.split.Tensor(linear_42, 1152, -1);  linear_42 = None
            getitem_53: "f32[1, 97, 1152]" = split_10[0]
            getitem_54: "f32[1, 97, 1152]" = split_10[1];  split_10 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_10: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_53);  getitem_53 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_98: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_10, getitem_54);  gelu_10 = getitem_54 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_12: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_98);  mul_98 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_43: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_12, p_encoder_layers_10_mlp_wo_weight);  clone_12 = p_encoder_layers_10_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_43: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_42, linear_43);  add_42 = linear_43 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_22: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_43, [768], p_encoder_layers_11_attn_norm_weight);  p_encoder_layers_11_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_44: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_22, p_encoder_layers_11_attn_wqkv_weight);  layer_norm_22 = p_encoder_layers_11_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_22: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_44, [1, -1, 3, 12, 64]);  linear_44 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_44: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_22, 3, 1);  view_22 = None
            unbind_11 = torch.ops.aten.unbind.int(transpose_44, 2);  transpose_44 = None
            getitem_55: "f32[1, 12, 97, 64]" = unbind_11[0]
            getitem_56: "f32[1, 12, 97, 64]" = unbind_11[1]
            getitem_57: "f32[1, 12, 97, 64]" = unbind_11[2];  unbind_11 = None
            unsqueeze_94: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_95: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_99: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_55, unsqueeze_94)
            slice_113: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_55, 3, 0, 32)
            slice_114: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_55, 3, 32, 9223372036854775807);  getitem_55 = None
            neg_22: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_114);  slice_114 = None
            cat_44: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_22, slice_113], -1);  neg_22 = slice_113 = None
            mul_100: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_44, unsqueeze_95);  cat_44 = None
            add_44: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_99, mul_100);  mul_99 = mul_100 = None
            mul_101: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_56, unsqueeze_94);  unsqueeze_94 = None
            slice_115: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_56, 3, 0, 32)
            slice_116: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_56, 3, 32, 9223372036854775807);  getitem_56 = None
            neg_23: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_116);  slice_116 = None
            cat_45: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_23, slice_115], -1);  neg_23 = slice_115 = None
            mul_102: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_45, unsqueeze_95);  cat_45 = unsqueeze_95 = None
            add_45: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_101, mul_102);  mul_101 = mul_102 = None
            scaled_dot_product_attention_11: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_44, add_45, getitem_57, masked_fill_1);  add_44 = add_45 = getitem_57 = None
            transpose_45: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_11, 1, 2);  scaled_dot_product_attention_11 = None
            view_23: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_45, [1, -1, 768]);  transpose_45 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_45: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_23, p_encoder_layers_11_attn_wo_weight);  view_23 = p_encoder_layers_11_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_46: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_43, linear_45);  add_43 = linear_45 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_23: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_46, [768], p_encoder_layers_11_mlp_norm_weight);  p_encoder_layers_11_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_46: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_23, p_encoder_layers_11_mlp_wi_weight);  layer_norm_23 = p_encoder_layers_11_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_11 = torch.ops.aten.split.Tensor(linear_46, 1152, -1);  linear_46 = None
            getitem_58: "f32[1, 97, 1152]" = split_11[0]
            getitem_59: "f32[1, 97, 1152]" = split_11[1];  split_11 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_11: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_58);  getitem_58 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_103: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_11, getitem_59);  gelu_11 = getitem_59 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_13: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_103);  mul_103 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_47: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_13, p_encoder_layers_11_mlp_wo_weight);  clone_13 = p_encoder_layers_11_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_47: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_46, linear_47);  add_46 = linear_47 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_24: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_47, [768], p_encoder_layers_12_attn_norm_weight);  p_encoder_layers_12_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_48: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_24, p_encoder_layers_12_attn_wqkv_weight);  layer_norm_24 = p_encoder_layers_12_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_24: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_48, [1, -1, 3, 12, 64]);  linear_48 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_46: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_24, 3, 1);  view_24 = None
            unbind_12 = torch.ops.aten.unbind.int(transpose_46, 2);  transpose_46 = None
            getitem_60: "f32[1, 12, 97, 64]" = unbind_12[0]
            getitem_61: "f32[1, 12, 97, 64]" = unbind_12[1]
            getitem_62: "f32[1, 12, 97, 64]" = unbind_12[2];  unbind_12 = None
            unsqueeze_96: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_97: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_104: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_60, unsqueeze_96)
            slice_117: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_60, 3, 0, 32)
            slice_118: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_60, 3, 32, 9223372036854775807);  getitem_60 = None
            neg_24: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_118);  slice_118 = None
            cat_46: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_24, slice_117], -1);  neg_24 = slice_117 = None
            mul_105: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_46, unsqueeze_97);  cat_46 = None
            add_48: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_104, mul_105);  mul_104 = mul_105 = None
            mul_106: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_61, unsqueeze_96);  unsqueeze_96 = None
            slice_119: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_61, 3, 0, 32)
            slice_120: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_61, 3, 32, 9223372036854775807);  getitem_61 = None
            neg_25: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_120);  slice_120 = None
            cat_47: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_25, slice_119], -1);  neg_25 = slice_119 = None
            mul_107: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_47, unsqueeze_97);  cat_47 = unsqueeze_97 = None
            add_49: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_106, mul_107);  mul_106 = mul_107 = None
            scaled_dot_product_attention_12: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_48, add_49, getitem_62, masked_fill);  add_48 = add_49 = getitem_62 = None
            transpose_47: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_12, 1, 2);  scaled_dot_product_attention_12 = None
            view_25: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_47, [1, -1, 768]);  transpose_47 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_49: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_25, p_encoder_layers_12_attn_wo_weight);  view_25 = p_encoder_layers_12_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_50: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_47, linear_49);  add_47 = linear_49 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_25: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_50, [768], p_encoder_layers_12_mlp_norm_weight);  p_encoder_layers_12_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_50: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_25, p_encoder_layers_12_mlp_wi_weight);  layer_norm_25 = p_encoder_layers_12_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_12 = torch.ops.aten.split.Tensor(linear_50, 1152, -1);  linear_50 = None
            getitem_63: "f32[1, 97, 1152]" = split_12[0]
            getitem_64: "f32[1, 97, 1152]" = split_12[1];  split_12 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_12: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_63);  getitem_63 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_108: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_12, getitem_64);  gelu_12 = getitem_64 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_14: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_108);  mul_108 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_51: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_14, p_encoder_layers_12_mlp_wo_weight);  clone_14 = p_encoder_layers_12_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_51: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_50, linear_51);  add_50 = linear_51 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_26: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_51, [768], p_encoder_layers_13_attn_norm_weight);  p_encoder_layers_13_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_52: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_26, p_encoder_layers_13_attn_wqkv_weight);  layer_norm_26 = p_encoder_layers_13_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_26: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_52, [1, -1, 3, 12, 64]);  linear_52 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_48: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_26, 3, 1);  view_26 = None
            unbind_13 = torch.ops.aten.unbind.int(transpose_48, 2);  transpose_48 = None
            getitem_65: "f32[1, 12, 97, 64]" = unbind_13[0]
            getitem_66: "f32[1, 12, 97, 64]" = unbind_13[1]
            getitem_67: "f32[1, 12, 97, 64]" = unbind_13[2];  unbind_13 = None
            unsqueeze_98: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_99: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_109: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_65, unsqueeze_98)
            slice_121: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_65, 3, 0, 32)
            slice_122: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_65, 3, 32, 9223372036854775807);  getitem_65 = None
            neg_26: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_122);  slice_122 = None
            cat_48: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_26, slice_121], -1);  neg_26 = slice_121 = None
            mul_110: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_48, unsqueeze_99);  cat_48 = None
            add_52: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_109, mul_110);  mul_109 = mul_110 = None
            mul_111: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_66, unsqueeze_98);  unsqueeze_98 = None
            slice_123: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_66, 3, 0, 32)
            slice_124: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_66, 3, 32, 9223372036854775807);  getitem_66 = None
            neg_27: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_124);  slice_124 = None
            cat_49: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_27, slice_123], -1);  neg_27 = slice_123 = None
            mul_112: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_49, unsqueeze_99);  cat_49 = unsqueeze_99 = None
            add_53: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_111, mul_112);  mul_111 = mul_112 = None
            scaled_dot_product_attention_13: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_52, add_53, getitem_67, masked_fill_1);  add_52 = add_53 = getitem_67 = None
            transpose_49: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_13, 1, 2);  scaled_dot_product_attention_13 = None
            view_27: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_49, [1, -1, 768]);  transpose_49 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_53: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_27, p_encoder_layers_13_attn_wo_weight);  view_27 = p_encoder_layers_13_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_54: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_51, linear_53);  add_51 = linear_53 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_27: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_54, [768], p_encoder_layers_13_mlp_norm_weight);  p_encoder_layers_13_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_54: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_27, p_encoder_layers_13_mlp_wi_weight);  layer_norm_27 = p_encoder_layers_13_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_13 = torch.ops.aten.split.Tensor(linear_54, 1152, -1);  linear_54 = None
            getitem_68: "f32[1, 97, 1152]" = split_13[0]
            getitem_69: "f32[1, 97, 1152]" = split_13[1];  split_13 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_13: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_68);  getitem_68 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_113: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_13, getitem_69);  gelu_13 = getitem_69 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_15: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_113);  mul_113 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_55: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_15, p_encoder_layers_13_mlp_wo_weight);  clone_15 = p_encoder_layers_13_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_55: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_54, linear_55);  add_54 = linear_55 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_28: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_55, [768], p_encoder_layers_14_attn_norm_weight);  p_encoder_layers_14_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_56: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_28, p_encoder_layers_14_attn_wqkv_weight);  layer_norm_28 = p_encoder_layers_14_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_28: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_56, [1, -1, 3, 12, 64]);  linear_56 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_50: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_28, 3, 1);  view_28 = None
            unbind_14 = torch.ops.aten.unbind.int(transpose_50, 2);  transpose_50 = None
            getitem_70: "f32[1, 12, 97, 64]" = unbind_14[0]
            getitem_71: "f32[1, 12, 97, 64]" = unbind_14[1]
            getitem_72: "f32[1, 12, 97, 64]" = unbind_14[2];  unbind_14 = None
            unsqueeze_100: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_101: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_114: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_70, unsqueeze_100)
            slice_125: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_70, 3, 0, 32)
            slice_126: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_70, 3, 32, 9223372036854775807);  getitem_70 = None
            neg_28: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_126);  slice_126 = None
            cat_50: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_28, slice_125], -1);  neg_28 = slice_125 = None
            mul_115: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_50, unsqueeze_101);  cat_50 = None
            add_56: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_114, mul_115);  mul_114 = mul_115 = None
            mul_116: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_71, unsqueeze_100);  unsqueeze_100 = None
            slice_127: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_71, 3, 0, 32)
            slice_128: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_71, 3, 32, 9223372036854775807);  getitem_71 = None
            neg_29: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_128);  slice_128 = None
            cat_51: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_29, slice_127], -1);  neg_29 = slice_127 = None
            mul_117: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_51, unsqueeze_101);  cat_51 = unsqueeze_101 = None
            add_57: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_116, mul_117);  mul_116 = mul_117 = None
            scaled_dot_product_attention_14: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_56, add_57, getitem_72, masked_fill_1);  add_56 = add_57 = getitem_72 = None
            transpose_51: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_14, 1, 2);  scaled_dot_product_attention_14 = None
            view_29: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_51, [1, -1, 768]);  transpose_51 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_57: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_29, p_encoder_layers_14_attn_wo_weight);  view_29 = p_encoder_layers_14_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_58: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_55, linear_57);  add_55 = linear_57 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_29: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_58, [768], p_encoder_layers_14_mlp_norm_weight);  p_encoder_layers_14_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_58: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_29, p_encoder_layers_14_mlp_wi_weight);  layer_norm_29 = p_encoder_layers_14_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_14 = torch.ops.aten.split.Tensor(linear_58, 1152, -1);  linear_58 = None
            getitem_73: "f32[1, 97, 1152]" = split_14[0]
            getitem_74: "f32[1, 97, 1152]" = split_14[1];  split_14 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_14: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_73);  getitem_73 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_118: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_14, getitem_74);  gelu_14 = getitem_74 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_16: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_118);  mul_118 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_59: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_16, p_encoder_layers_14_mlp_wo_weight);  clone_16 = p_encoder_layers_14_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_59: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_58, linear_59);  add_58 = linear_59 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_30: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_59, [768], p_encoder_layers_15_attn_norm_weight);  p_encoder_layers_15_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_60: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_30, p_encoder_layers_15_attn_wqkv_weight);  layer_norm_30 = p_encoder_layers_15_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_30: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_60, [1, -1, 3, 12, 64]);  linear_60 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_52: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_30, 3, 1);  view_30 = None
            unbind_15 = torch.ops.aten.unbind.int(transpose_52, 2);  transpose_52 = None
            getitem_75: "f32[1, 12, 97, 64]" = unbind_15[0]
            getitem_76: "f32[1, 12, 97, 64]" = unbind_15[1]
            getitem_77: "f32[1, 12, 97, 64]" = unbind_15[2];  unbind_15 = None
            unsqueeze_102: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_103: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_119: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_75, unsqueeze_102)
            slice_129: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_75, 3, 0, 32)
            slice_130: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_75, 3, 32, 9223372036854775807);  getitem_75 = None
            neg_30: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_130);  slice_130 = None
            cat_52: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_30, slice_129], -1);  neg_30 = slice_129 = None
            mul_120: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_52, unsqueeze_103);  cat_52 = None
            add_60: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_119, mul_120);  mul_119 = mul_120 = None
            mul_121: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_76, unsqueeze_102);  unsqueeze_102 = None
            slice_131: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_76, 3, 0, 32)
            slice_132: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_76, 3, 32, 9223372036854775807);  getitem_76 = None
            neg_31: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_132);  slice_132 = None
            cat_53: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_31, slice_131], -1);  neg_31 = slice_131 = None
            mul_122: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_53, unsqueeze_103);  cat_53 = unsqueeze_103 = None
            add_61: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_121, mul_122);  mul_121 = mul_122 = None
            scaled_dot_product_attention_15: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_60, add_61, getitem_77, masked_fill);  add_60 = add_61 = getitem_77 = None
            transpose_53: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_15, 1, 2);  scaled_dot_product_attention_15 = None
            view_31: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_53, [1, -1, 768]);  transpose_53 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_61: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_31, p_encoder_layers_15_attn_wo_weight);  view_31 = p_encoder_layers_15_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_62: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_59, linear_61);  add_59 = linear_61 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_31: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_62, [768], p_encoder_layers_15_mlp_norm_weight);  p_encoder_layers_15_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_62: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_31, p_encoder_layers_15_mlp_wi_weight);  layer_norm_31 = p_encoder_layers_15_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_15 = torch.ops.aten.split.Tensor(linear_62, 1152, -1);  linear_62 = None
            getitem_78: "f32[1, 97, 1152]" = split_15[0]
            getitem_79: "f32[1, 97, 1152]" = split_15[1];  split_15 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_15: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_78);  getitem_78 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_123: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_15, getitem_79);  gelu_15 = getitem_79 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_17: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_123);  mul_123 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_63: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_17, p_encoder_layers_15_mlp_wo_weight);  clone_17 = p_encoder_layers_15_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_63: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_62, linear_63);  add_62 = linear_63 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_32: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_63, [768], p_encoder_layers_16_attn_norm_weight);  p_encoder_layers_16_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_64: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_32, p_encoder_layers_16_attn_wqkv_weight);  layer_norm_32 = p_encoder_layers_16_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_32: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_64, [1, -1, 3, 12, 64]);  linear_64 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_54: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_32, 3, 1);  view_32 = None
            unbind_16 = torch.ops.aten.unbind.int(transpose_54, 2);  transpose_54 = None
            getitem_80: "f32[1, 12, 97, 64]" = unbind_16[0]
            getitem_81: "f32[1, 12, 97, 64]" = unbind_16[1]
            getitem_82: "f32[1, 12, 97, 64]" = unbind_16[2];  unbind_16 = None
            unsqueeze_104: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_105: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_124: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_80, unsqueeze_104)
            slice_133: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_80, 3, 0, 32)
            slice_134: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_80, 3, 32, 9223372036854775807);  getitem_80 = None
            neg_32: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_134);  slice_134 = None
            cat_54: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_32, slice_133], -1);  neg_32 = slice_133 = None
            mul_125: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_54, unsqueeze_105);  cat_54 = None
            add_64: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_124, mul_125);  mul_124 = mul_125 = None
            mul_126: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_81, unsqueeze_104);  unsqueeze_104 = None
            slice_135: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_81, 3, 0, 32)
            slice_136: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_81, 3, 32, 9223372036854775807);  getitem_81 = None
            neg_33: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_136);  slice_136 = None
            cat_55: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_33, slice_135], -1);  neg_33 = slice_135 = None
            mul_127: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_55, unsqueeze_105);  cat_55 = unsqueeze_105 = None
            add_65: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_126, mul_127);  mul_126 = mul_127 = None
            scaled_dot_product_attention_16: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_64, add_65, getitem_82, masked_fill_1);  add_64 = add_65 = getitem_82 = None
            transpose_55: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_16, 1, 2);  scaled_dot_product_attention_16 = None
            view_33: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_55, [1, -1, 768]);  transpose_55 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_65: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_33, p_encoder_layers_16_attn_wo_weight);  view_33 = p_encoder_layers_16_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_66: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_63, linear_65);  add_63 = linear_65 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_33: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_66, [768], p_encoder_layers_16_mlp_norm_weight);  p_encoder_layers_16_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_66: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_33, p_encoder_layers_16_mlp_wi_weight);  layer_norm_33 = p_encoder_layers_16_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_16 = torch.ops.aten.split.Tensor(linear_66, 1152, -1);  linear_66 = None
            getitem_83: "f32[1, 97, 1152]" = split_16[0]
            getitem_84: "f32[1, 97, 1152]" = split_16[1];  split_16 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_16: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_83);  getitem_83 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_128: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_16, getitem_84);  gelu_16 = getitem_84 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_18: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_128);  mul_128 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_67: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_18, p_encoder_layers_16_mlp_wo_weight);  clone_18 = p_encoder_layers_16_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_67: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_66, linear_67);  add_66 = linear_67 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_34: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_67, [768], p_encoder_layers_17_attn_norm_weight);  p_encoder_layers_17_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_68: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_34, p_encoder_layers_17_attn_wqkv_weight);  layer_norm_34 = p_encoder_layers_17_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_34: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_68, [1, -1, 3, 12, 64]);  linear_68 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_56: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_34, 3, 1);  view_34 = None
            unbind_17 = torch.ops.aten.unbind.int(transpose_56, 2);  transpose_56 = None
            getitem_85: "f32[1, 12, 97, 64]" = unbind_17[0]
            getitem_86: "f32[1, 12, 97, 64]" = unbind_17[1]
            getitem_87: "f32[1, 12, 97, 64]" = unbind_17[2];  unbind_17 = None
            unsqueeze_106: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_107: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_129: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_85, unsqueeze_106)
            slice_137: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_85, 3, 0, 32)
            slice_138: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_85, 3, 32, 9223372036854775807);  getitem_85 = None
            neg_34: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_138);  slice_138 = None
            cat_56: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_34, slice_137], -1);  neg_34 = slice_137 = None
            mul_130: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_56, unsqueeze_107);  cat_56 = None
            add_68: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_129, mul_130);  mul_129 = mul_130 = None
            mul_131: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_86, unsqueeze_106);  unsqueeze_106 = None
            slice_139: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_86, 3, 0, 32)
            slice_140: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_86, 3, 32, 9223372036854775807);  getitem_86 = None
            neg_35: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_140);  slice_140 = None
            cat_57: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_35, slice_139], -1);  neg_35 = slice_139 = None
            mul_132: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_57, unsqueeze_107);  cat_57 = unsqueeze_107 = None
            add_69: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_131, mul_132);  mul_131 = mul_132 = None
            scaled_dot_product_attention_17: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_68, add_69, getitem_87, masked_fill_1);  add_68 = add_69 = getitem_87 = None
            transpose_57: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_17, 1, 2);  scaled_dot_product_attention_17 = None
            view_35: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_57, [1, -1, 768]);  transpose_57 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_69: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_35, p_encoder_layers_17_attn_wo_weight);  view_35 = p_encoder_layers_17_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_70: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_67, linear_69);  add_67 = linear_69 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_35: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_70, [768], p_encoder_layers_17_mlp_norm_weight);  p_encoder_layers_17_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_70: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_35, p_encoder_layers_17_mlp_wi_weight);  layer_norm_35 = p_encoder_layers_17_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_17 = torch.ops.aten.split.Tensor(linear_70, 1152, -1);  linear_70 = None
            getitem_88: "f32[1, 97, 1152]" = split_17[0]
            getitem_89: "f32[1, 97, 1152]" = split_17[1];  split_17 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_17: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_88);  getitem_88 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_133: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_17, getitem_89);  gelu_17 = getitem_89 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_19: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_133);  mul_133 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_71: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_19, p_encoder_layers_17_mlp_wo_weight);  clone_19 = p_encoder_layers_17_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_71: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_70, linear_71);  add_70 = linear_71 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_36: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_71, [768], p_encoder_layers_18_attn_norm_weight);  p_encoder_layers_18_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_72: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_36, p_encoder_layers_18_attn_wqkv_weight);  layer_norm_36 = p_encoder_layers_18_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_36: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_72, [1, -1, 3, 12, 64]);  linear_72 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_58: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_36, 3, 1);  view_36 = None
            unbind_18 = torch.ops.aten.unbind.int(transpose_58, 2);  transpose_58 = None
            getitem_90: "f32[1, 12, 97, 64]" = unbind_18[0]
            getitem_91: "f32[1, 12, 97, 64]" = unbind_18[1]
            getitem_92: "f32[1, 12, 97, 64]" = unbind_18[2];  unbind_18 = None
            unsqueeze_108: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1)
            unsqueeze_109: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1)
            mul_134: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_90, unsqueeze_108)
            slice_141: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_90, 3, 0, 32)
            slice_142: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_90, 3, 32, 9223372036854775807);  getitem_90 = None
            neg_36: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_142);  slice_142 = None
            cat_58: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_36, slice_141], -1);  neg_36 = slice_141 = None
            mul_135: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_58, unsqueeze_109);  cat_58 = None
            add_72: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_134, mul_135);  mul_134 = mul_135 = None
            mul_136: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_91, unsqueeze_108);  unsqueeze_108 = None
            slice_143: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_91, 3, 0, 32)
            slice_144: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_91, 3, 32, 9223372036854775807);  getitem_91 = None
            neg_37: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_144);  slice_144 = None
            cat_59: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_37, slice_143], -1);  neg_37 = slice_143 = None
            mul_137: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_59, unsqueeze_109);  cat_59 = unsqueeze_109 = None
            add_73: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_136, mul_137);  mul_136 = mul_137 = None
            scaled_dot_product_attention_18: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_72, add_73, getitem_92, masked_fill);  add_72 = add_73 = getitem_92 = None
            transpose_59: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_18, 1, 2);  scaled_dot_product_attention_18 = None
            view_37: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_59, [1, -1, 768]);  transpose_59 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_73: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_37, p_encoder_layers_18_attn_wo_weight);  view_37 = p_encoder_layers_18_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_74: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_71, linear_73);  add_71 = linear_73 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_37: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_74, [768], p_encoder_layers_18_mlp_norm_weight);  p_encoder_layers_18_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_74: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_37, p_encoder_layers_18_mlp_wi_weight);  layer_norm_37 = p_encoder_layers_18_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_18 = torch.ops.aten.split.Tensor(linear_74, 1152, -1);  linear_74 = None
            getitem_93: "f32[1, 97, 1152]" = split_18[0]
            getitem_94: "f32[1, 97, 1152]" = split_18[1];  split_18 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_18: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_93);  getitem_93 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_138: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_18, getitem_94);  gelu_18 = getitem_94 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_20: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_138);  mul_138 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_75: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_20, p_encoder_layers_18_mlp_wo_weight);  clone_20 = p_encoder_layers_18_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_75: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_74, linear_75);  add_74 = linear_75 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_38: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_75, [768], p_encoder_layers_19_attn_norm_weight);  p_encoder_layers_19_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_76: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_38, p_encoder_layers_19_attn_wqkv_weight);  layer_norm_38 = p_encoder_layers_19_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_38: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_76, [1, -1, 3, 12, 64]);  linear_76 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_60: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_38, 3, 1);  view_38 = None
            unbind_19 = torch.ops.aten.unbind.int(transpose_60, 2);  transpose_60 = None
            getitem_95: "f32[1, 12, 97, 64]" = unbind_19[0]
            getitem_96: "f32[1, 12, 97, 64]" = unbind_19[1]
            getitem_97: "f32[1, 12, 97, 64]" = unbind_19[2];  unbind_19 = None
            unsqueeze_110: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1)
            unsqueeze_111: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1)
            mul_139: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_95, unsqueeze_110)
            slice_145: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_95, 3, 0, 32)
            slice_146: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_95, 3, 32, 9223372036854775807);  getitem_95 = None
            neg_38: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_146);  slice_146 = None
            cat_60: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_38, slice_145], -1);  neg_38 = slice_145 = None
            mul_140: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_60, unsqueeze_111);  cat_60 = None
            add_76: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_139, mul_140);  mul_139 = mul_140 = None
            mul_141: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_96, unsqueeze_110);  unsqueeze_110 = None
            slice_147: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_96, 3, 0, 32)
            slice_148: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_96, 3, 32, 9223372036854775807);  getitem_96 = None
            neg_39: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_148);  slice_148 = None
            cat_61: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_39, slice_147], -1);  neg_39 = slice_147 = None
            mul_142: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_61, unsqueeze_111);  cat_61 = unsqueeze_111 = None
            add_77: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_141, mul_142);  mul_141 = mul_142 = None
            scaled_dot_product_attention_19: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_76, add_77, getitem_97, masked_fill_1);  add_76 = add_77 = getitem_97 = None
            transpose_61: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_19, 1, 2);  scaled_dot_product_attention_19 = None
            view_39: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_61, [1, -1, 768]);  transpose_61 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_77: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_39, p_encoder_layers_19_attn_wo_weight);  view_39 = p_encoder_layers_19_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_78: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_75, linear_77);  add_75 = linear_77 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_39: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_78, [768], p_encoder_layers_19_mlp_norm_weight);  p_encoder_layers_19_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_78: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_39, p_encoder_layers_19_mlp_wi_weight);  layer_norm_39 = p_encoder_layers_19_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_19 = torch.ops.aten.split.Tensor(linear_78, 1152, -1);  linear_78 = None
            getitem_98: "f32[1, 97, 1152]" = split_19[0]
            getitem_99: "f32[1, 97, 1152]" = split_19[1];  split_19 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_19: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_98);  getitem_98 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_143: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_19, getitem_99);  gelu_19 = getitem_99 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_21: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_143);  mul_143 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_79: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_21, p_encoder_layers_19_mlp_wo_weight);  clone_21 = p_encoder_layers_19_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_79: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_78, linear_79);  add_78 = linear_79 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_40: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_79, [768], p_encoder_layers_20_attn_norm_weight);  p_encoder_layers_20_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_80: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_40, p_encoder_layers_20_attn_wqkv_weight);  layer_norm_40 = p_encoder_layers_20_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_40: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_80, [1, -1, 3, 12, 64]);  linear_80 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_62: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_40, 3, 1);  view_40 = None
            unbind_20 = torch.ops.aten.unbind.int(transpose_62, 2);  transpose_62 = None
            getitem_100: "f32[1, 12, 97, 64]" = unbind_20[0]
            getitem_101: "f32[1, 12, 97, 64]" = unbind_20[1]
            getitem_102: "f32[1, 12, 97, 64]" = unbind_20[2];  unbind_20 = None
            unsqueeze_112: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_40, 1);  mul_40 = None
            unsqueeze_113: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_41, 1);  mul_41 = None
            mul_144: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_100, unsqueeze_112)
            slice_149: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_100, 3, 0, 32)
            slice_150: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_100, 3, 32, 9223372036854775807);  getitem_100 = None
            neg_40: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_150);  slice_150 = None
            cat_62: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_40, slice_149], -1);  neg_40 = slice_149 = None
            mul_145: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_62, unsqueeze_113);  cat_62 = None
            add_80: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_144, mul_145);  mul_144 = mul_145 = None
            mul_146: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_101, unsqueeze_112);  unsqueeze_112 = None
            slice_151: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_101, 3, 0, 32)
            slice_152: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_101, 3, 32, 9223372036854775807);  getitem_101 = None
            neg_41: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_152);  slice_152 = None
            cat_63: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_41, slice_151], -1);  neg_41 = slice_151 = None
            mul_147: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_63, unsqueeze_113);  cat_63 = unsqueeze_113 = None
            add_81: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_146, mul_147);  mul_146 = mul_147 = None
            scaled_dot_product_attention_20: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_80, add_81, getitem_102, masked_fill_1);  add_80 = add_81 = getitem_102 = masked_fill_1 = None
            transpose_63: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_20, 1, 2);  scaled_dot_product_attention_20 = None
            view_41: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_63, [1, -1, 768]);  transpose_63 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_81: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_41, p_encoder_layers_20_attn_wo_weight);  view_41 = p_encoder_layers_20_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_82: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_79, linear_81);  add_79 = linear_81 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_41: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_82, [768], p_encoder_layers_20_mlp_norm_weight);  p_encoder_layers_20_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_82: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_41, p_encoder_layers_20_mlp_wi_weight);  layer_norm_41 = p_encoder_layers_20_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_20 = torch.ops.aten.split.Tensor(linear_82, 1152, -1);  linear_82 = None
            getitem_103: "f32[1, 97, 1152]" = split_20[0]
            getitem_104: "f32[1, 97, 1152]" = split_20[1];  split_20 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_20: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_103);  getitem_103 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_148: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_20, getitem_104);  gelu_20 = getitem_104 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_22: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_148);  mul_148 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_83: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_22, p_encoder_layers_20_mlp_wo_weight);  clone_22 = p_encoder_layers_20_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_83: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_82, linear_83);  add_82 = linear_83 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_42: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_83, [768], p_encoder_layers_21_attn_norm_weight);  p_encoder_layers_21_attn_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_84: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_42, p_encoder_layers_21_attn_wqkv_weight);  layer_norm_42 = p_encoder_layers_21_attn_wqkv_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:548 in forward, code: qkv = qkv.view(bs, -1, 3, self.num_heads, self.head_dim)
            view_42: "f32[1, 97, 3, 12, 64]" = torch.ops.aten.view.default(linear_84, [1, -1, 3, 12, 64]);  linear_84 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:550 in forward, code: attn_outputs = MODERNBERT_ATTENTION_FUNCTION[self.config._attn_implementation](
            transpose_64: "f32[1, 12, 3, 97, 64]" = torch.ops.aten.transpose.int(view_42, 3, 1);  view_42 = None
            unbind_21 = torch.ops.aten.unbind.int(transpose_64, 2);  transpose_64 = None
            getitem_105: "f32[1, 12, 97, 64]" = unbind_21[0]
            getitem_106: "f32[1, 12, 97, 64]" = unbind_21[1]
            getitem_107: "f32[1, 12, 97, 64]" = unbind_21[2];  unbind_21 = None
            unsqueeze_114: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_42, 1);  mul_42 = None
            unsqueeze_115: "f32[1, 1, 97, 64]" = torch.ops.aten.unsqueeze.default(mul_43, 1);  mul_43 = None
            mul_149: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_105, unsqueeze_114)
            slice_153: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_105, 3, 0, 32)
            slice_154: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_105, 3, 32, 9223372036854775807);  getitem_105 = None
            neg_42: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_154);  slice_154 = None
            cat_64: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_42, slice_153], -1);  neg_42 = slice_153 = None
            mul_150: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_64, unsqueeze_115);  cat_64 = None
            add_84: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_149, mul_150);  mul_149 = mul_150 = None
            mul_151: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(getitem_106, unsqueeze_114);  unsqueeze_114 = None
            slice_155: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_106, 3, 0, 32)
            slice_156: "f32[1, 12, 97, 32]" = torch.ops.aten.slice.Tensor(getitem_106, 3, 32, 9223372036854775807);  getitem_106 = None
            neg_43: "f32[1, 12, 97, 32]" = torch.ops.aten.neg.default(slice_156);  slice_156 = None
            cat_65: "f32[1, 12, 97, 64]" = torch.ops.aten.cat.default([neg_43, slice_155], -1);  neg_43 = slice_155 = None
            mul_152: "f32[1, 12, 97, 64]" = torch.ops.aten.mul.Tensor(cat_65, unsqueeze_115);  cat_65 = unsqueeze_115 = None
            add_85: "f32[1, 12, 97, 64]" = torch.ops.aten.add.Tensor(mul_151, mul_152);  mul_151 = mul_152 = None
            scaled_dot_product_attention_21: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(add_84, add_85, getitem_107, masked_fill);  add_84 = add_85 = getitem_107 = masked_fill = None
            transpose_65: "f32[1, 97, 12, 64]" = torch.ops.aten.transpose.int(scaled_dot_product_attention_21, 1, 2);  scaled_dot_product_attention_21 = None
            view_43: "f32[1, 97, 768]" = torch.ops.aten.view.default(transpose_65, [1, -1, 768]);  transpose_65 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_85: "f32[1, 97, 768]" = torch.ops.aten.linear.default(view_43, p_encoder_layers_21_attn_wo_weight);  view_43 = p_encoder_layers_21_attn_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:605 in forward, code: hidden_states = hidden_states + attn_outputs[0]
            add_86: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_83, linear_85);  add_83 = linear_85 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_43: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_86, [768], p_encoder_layers_21_mlp_norm_weight);  p_encoder_layers_21_mlp_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_86: "f32[1, 97, 2304]" = torch.ops.aten.linear.default(layer_norm_43, p_encoder_layers_21_mlp_wi_weight);  layer_norm_43 = p_encoder_layers_21_mlp_wi_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:244 in forward, code: input, gate = self.Wi(hidden_states).chunk(2, dim=-1)
            split_21 = torch.ops.aten.split.Tensor(linear_86, 1152, -1);  linear_86 = None
            getitem_108: "f32[1, 97, 1152]" = split_21[0]
            getitem_109: "f32[1, 97, 1152]" = split_21[1];  split_21 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/activations.py:89 in forward, code: return self.act(input)
            gelu_21: "f32[1, 97, 1152]" = torch.ops.aten.gelu.default(getitem_108);  getitem_108 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:245 in forward, code: return self.Wo(self.drop(self.act(input) * gate))
            mul_153: "f32[1, 97, 1152]" = torch.ops.aten.mul.Tensor(gelu_21, getitem_109);  gelu_21 = getitem_109 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_23: "f32[1, 97, 1152]" = torch.ops.aten.clone.default(mul_153);  mul_153 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_87: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_23, p_encoder_layers_21_mlp_wo_weight);  clone_23 = p_encoder_layers_21_mlp_wo_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/transformers/models/modernbert/modeling_modernbert.py:611 in forward, code: hidden_states = hidden_states + mlp_output
            add_87: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_86, linear_87);  add_86 = linear_87 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_44: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_87, [768], p_encoder_final_norm_weight);  add_87 = p_encoder_final_norm_weight = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/sparse.py:192 in forward, code: return F.embedding(
            embedding_1: "f32[1, 768]" = torch.ops.aten.embedding.default(p_type_emb_weight, qtype);  p_type_emb_weight = qtype = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:109 in forward, code: h = h + self.type_emb(qtype)[:, None, :]
            slice_157: "f32[1, 768]" = torch.ops.aten.slice.Tensor(embedding_1, 0, 0, 9223372036854775807);  embedding_1 = None
            unsqueeze_116: "f32[1, 1, 768]" = torch.ops.aten.unsqueeze.default(slice_157, 1);  slice_157 = None
            slice_158: "f32[1, 1, 768]" = torch.ops.aten.slice.Tensor(unsqueeze_116, 2, 0, 9223372036854775807);  unsqueeze_116 = None
            add_88: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(layer_norm_44, slice_158);  layer_norm_44 = slice_158 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:111 in forward, code: pad = ~attention_mask.bool()
            _to_copy_24: "b8[1, 97]" = torch.ops.aten._to_copy.default(attention_mask, dtype = torch.bool);  attention_mask = None
            bitwise_not: "b8[1, 97]" = torch.ops.aten.bitwise_not.default(_to_copy_24);  _to_copy_24 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:805 in forward, code: src_key_padding_mask = F._canonical_mask(
            zeros_like: "f32[1, 97]" = torch.ops.aten.zeros_like.default(bitwise_not, dtype = torch.float32, pin_memory = False)
            masked_fill_2: "f32[1, 97]" = torch.ops.aten.masked_fill.Scalar(zeros_like, bitwise_not, -inf);  zeros_like = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_45: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_88, [768], p_head_layers_0_norm1_weight, p_head_layers_0_norm1_bias);  p_head_layers_0_norm1_weight = p_head_layers_0_norm1_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1346 in forward, code: query = key = value = query.transpose(1, 0)
            transpose_66: "f32[97, 1, 768]" = torch.ops.aten.transpose.int(layer_norm_45, 1, 0);  layer_norm_45 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1380 in forward, code: attn_output, attn_output_weights = F.multi_head_attention_forward(
            linear_88: "f32[97, 1, 2304]" = torch.ops.aten.linear.default(transpose_66, p_head_layers_0_self_attn_in_proj_weight, p_head_layers_0_self_attn_in_proj_bias);  transpose_66 = p_head_layers_0_self_attn_in_proj_weight = p_head_layers_0_self_attn_in_proj_bias = None
            view_44: "f32[97, 1, 3, 768]" = torch.ops.aten.view.default(linear_88, [97, 1, 3, 768]);  linear_88 = None
            unsqueeze_117: "f32[1, 97, 1, 3, 768]" = torch.ops.aten.unsqueeze.default(view_44, 0);  view_44 = None
            transpose_67: "f32[3, 97, 1, 1, 768]" = torch.ops.aten.transpose.int(unsqueeze_117, 0, -2);  unsqueeze_117 = None
            squeeze: "f32[3, 97, 1, 768]" = torch.ops.aten.squeeze.dim(transpose_67, -2);  transpose_67 = None
            clone_24: "f32[3, 97, 1, 768]" = torch.ops.aten.clone.default(squeeze, memory_format = torch.contiguous_format);  squeeze = None
            select: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_24, 0, 0)
            select_1: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_24, 0, 1)
            select_2: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_24, 0, 2);  clone_24 = None
            view_45: "f32[97, 12, 64]" = torch.ops.aten.view.default(select, [97, 12, 64]);  select = None
            transpose_68: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_45, 0, 1);  view_45 = None
            view_46: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_1, [97, 12, 64]);  select_1 = None
            transpose_69: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_46, 0, 1);  view_46 = None
            view_47: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_2, [97, 12, 64]);  select_2 = None
            transpose_70: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_47, 0, 1);  view_47 = None
            view_51: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_68, [1, 12, 97, 64]);  transpose_68 = None
            view_52: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_69, [1, 12, 97, 64]);  transpose_69 = None
            view_53: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_70, [1, 12, 97, 64]);  transpose_70 = None
            view_54: "f32[1, 1, 1, 97]" = torch.ops.aten.view.default(masked_fill_2, [1, 1, 1, 97]);  masked_fill_2 = None
            expand_24: "f32[1, 12, 1, 97]" = torch.ops.aten.expand.default(view_54, [-1, 12, -1, -1]);  view_54 = None
            view_55: "f32[12, 1, 97]" = torch.ops.aten.view.default(expand_24, [12, 1, 97]);  expand_24 = None
            view_56: "f32[1, 12, 1, 97]" = torch.ops.aten.view.default(view_55, [1, 12, -1, 97]);  view_55 = None
            scaled_dot_product_attention_22: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(view_51, view_52, view_53, view_56);  view_51 = view_52 = view_53 = view_56 = None
            permute_1: "f32[97, 1, 12, 64]" = torch.ops.aten.permute.default(scaled_dot_product_attention_22, [2, 0, 1, 3]);  scaled_dot_product_attention_22 = None
            view_57: "f32[97, 768]" = torch.ops.aten.view.default(permute_1, [97, 768]);  permute_1 = None
            linear_89: "f32[97, 768]" = torch.ops.aten.linear.default(view_57, p_head_layers_0_self_attn_out_proj_weight, p_head_layers_0_self_attn_out_proj_bias);  view_57 = p_head_layers_0_self_attn_out_proj_weight = p_head_layers_0_self_attn_out_proj_bias = None
            view_58: "f32[97, 1, 768]" = torch.ops.aten.view.default(linear_89, [97, 1, 768]);  linear_89 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1402 in forward, code: return attn_output.transpose(1, 0), attn_output_weights
            transpose_71: "f32[1, 97, 768]" = torch.ops.aten.transpose.int(view_58, 1, 0);  view_58 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_25: "f32[1, 97, 768]" = torch.ops.aten.clone.default(transpose_71);  transpose_71 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:928 in forward, code: x = x + self._sa_block(
            add_89: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_88, clone_25);  add_88 = clone_25 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_46: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_89, [768], p_head_layers_0_norm2_weight, p_head_layers_0_norm2_bias);  p_head_layers_0_norm2_weight = p_head_layers_0_norm2_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_90: "f32[1, 97, 3072]" = torch.ops.aten.linear.default(layer_norm_46, p_head_layers_0_linear1_weight, p_head_layers_0_linear1_bias);  layer_norm_46 = p_head_layers_0_linear1_weight = p_head_layers_0_linear1_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            relu: "f32[1, 97, 3072]" = torch.ops.aten.relu.default(linear_90);  linear_90 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_26: "f32[1, 97, 3072]" = torch.ops.aten.clone.default(relu);  relu = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_91: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_26, p_head_layers_0_linear2_weight, p_head_layers_0_linear2_bias);  clone_26 = p_head_layers_0_linear2_weight = p_head_layers_0_linear2_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_27: "f32[1, 97, 768]" = torch.ops.aten.clone.default(linear_91);  linear_91 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            add_90: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_89, clone_27);  add_89 = clone_27 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:805 in forward, code: src_key_padding_mask = F._canonical_mask(
            zeros_like_1: "f32[1, 97]" = torch.ops.aten.zeros_like.default(bitwise_not, dtype = torch.float32, pin_memory = False)
            masked_fill_3: "f32[1, 97]" = torch.ops.aten.masked_fill.Scalar(zeros_like_1, bitwise_not, -inf);  zeros_like_1 = bitwise_not = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_47: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_90, [768], p_head_layers_1_norm1_weight, p_head_layers_1_norm1_bias);  p_head_layers_1_norm1_weight = p_head_layers_1_norm1_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1346 in forward, code: query = key = value = query.transpose(1, 0)
            transpose_72: "f32[97, 1, 768]" = torch.ops.aten.transpose.int(layer_norm_47, 1, 0);  layer_norm_47 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1380 in forward, code: attn_output, attn_output_weights = F.multi_head_attention_forward(
            linear_92: "f32[97, 1, 2304]" = torch.ops.aten.linear.default(transpose_72, p_head_layers_1_self_attn_in_proj_weight, p_head_layers_1_self_attn_in_proj_bias);  transpose_72 = p_head_layers_1_self_attn_in_proj_weight = p_head_layers_1_self_attn_in_proj_bias = None
            view_59: "f32[97, 1, 3, 768]" = torch.ops.aten.view.default(linear_92, [97, 1, 3, 768]);  linear_92 = None
            unsqueeze_118: "f32[1, 97, 1, 3, 768]" = torch.ops.aten.unsqueeze.default(view_59, 0);  view_59 = None
            transpose_73: "f32[3, 97, 1, 1, 768]" = torch.ops.aten.transpose.int(unsqueeze_118, 0, -2);  unsqueeze_118 = None
            squeeze_1: "f32[3, 97, 1, 768]" = torch.ops.aten.squeeze.dim(transpose_73, -2);  transpose_73 = None
            clone_28: "f32[3, 97, 1, 768]" = torch.ops.aten.clone.default(squeeze_1, memory_format = torch.contiguous_format);  squeeze_1 = None
            select_3: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_28, 0, 0)
            select_4: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_28, 0, 1)
            select_5: "f32[97, 1, 768]" = torch.ops.aten.select.int(clone_28, 0, 2);  clone_28 = None
            view_60: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_3, [97, 12, 64]);  select_3 = None
            transpose_74: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_60, 0, 1);  view_60 = None
            view_61: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_4, [97, 12, 64]);  select_4 = None
            transpose_75: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_61, 0, 1);  view_61 = None
            view_62: "f32[97, 12, 64]" = torch.ops.aten.view.default(select_5, [97, 12, 64]);  select_5 = None
            transpose_76: "f32[12, 97, 64]" = torch.ops.aten.transpose.int(view_62, 0, 1);  view_62 = None
            view_66: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_74, [1, 12, 97, 64]);  transpose_74 = None
            view_67: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_75, [1, 12, 97, 64]);  transpose_75 = None
            view_68: "f32[1, 12, 97, 64]" = torch.ops.aten.view.default(transpose_76, [1, 12, 97, 64]);  transpose_76 = None
            view_69: "f32[1, 1, 1, 97]" = torch.ops.aten.view.default(masked_fill_3, [1, 1, 1, 97]);  masked_fill_3 = None
            expand_26: "f32[1, 12, 1, 97]" = torch.ops.aten.expand.default(view_69, [-1, 12, -1, -1]);  view_69 = None
            view_70: "f32[12, 1, 97]" = torch.ops.aten.view.default(expand_26, [12, 1, 97]);  expand_26 = None
            view_71: "f32[1, 12, 1, 97]" = torch.ops.aten.view.default(view_70, [1, 12, -1, 97]);  view_70 = None
            scaled_dot_product_attention_23: "f32[1, 12, 97, 64]" = torch.ops.aten.scaled_dot_product_attention.default(view_66, view_67, view_68, view_71);  view_66 = view_67 = view_68 = view_71 = None
            permute_2: "f32[97, 1, 12, 64]" = torch.ops.aten.permute.default(scaled_dot_product_attention_23, [2, 0, 1, 3]);  scaled_dot_product_attention_23 = None
            view_72: "f32[97, 768]" = torch.ops.aten.view.default(permute_2, [97, 768]);  permute_2 = None
            linear_93: "f32[97, 768]" = torch.ops.aten.linear.default(view_72, p_head_layers_1_self_attn_out_proj_weight, p_head_layers_1_self_attn_out_proj_bias);  view_72 = p_head_layers_1_self_attn_out_proj_weight = p_head_layers_1_self_attn_out_proj_bias = None
            view_73: "f32[97, 1, 768]" = torch.ops.aten.view.default(linear_93, [97, 1, 768]);  linear_93 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:1402 in forward, code: return attn_output.transpose(1, 0), attn_output_weights
            transpose_77: "f32[1, 97, 768]" = torch.ops.aten.transpose.int(view_73, 1, 0);  view_73 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_29: "f32[1, 97, 768]" = torch.ops.aten.clone.default(transpose_77);  transpose_77 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:928 in forward, code: x = x + self._sa_block(
            add_91: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_90, clone_29);  add_90 = clone_29 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_48: "f32[1, 97, 768]" = torch.ops.aten.layer_norm.default(add_91, [768], p_head_layers_1_norm2_weight, p_head_layers_1_norm2_bias);  p_head_layers_1_norm2_weight = p_head_layers_1_norm2_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_94: "f32[1, 97, 3072]" = torch.ops.aten.linear.default(layer_norm_48, p_head_layers_1_linear1_weight, p_head_layers_1_linear1_bias);  layer_norm_48 = p_head_layers_1_linear1_weight = p_head_layers_1_linear1_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            relu_1: "f32[1, 97, 3072]" = torch.ops.aten.relu.default(linear_94);  linear_94 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_30: "f32[1, 97, 3072]" = torch.ops.aten.clone.default(relu_1);  relu_1 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_95: "f32[1, 97, 768]" = torch.ops.aten.linear.default(clone_30, p_head_layers_1_linear2_weight, p_head_layers_1_linear2_bias);  clone_30 = p_head_layers_1_linear2_weight = p_head_layers_1_linear2_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/dropout.py:70 in forward, code: return F.dropout(input, self.p, self.training, self.inplace)
            clone_31: "f32[1, 97, 768]" = torch.ops.aten.clone.default(linear_95);  linear_95 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/transformer.py:931 in forward, code: x = x + self._ff_block(self.norm2(x))
            add_92: "f32[1, 97, 768]" = torch.ops.aten.add.Tensor(add_91, clone_31);  add_91 = clone_31 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:114 in forward, code: idx = marker_pos.clamp(min=0)[:, :, None].expand(-1, -1, h.size(-1))
            clamp: "i64[1, 3]" = torch.ops.aten.clamp.default(marker_pos, 0);  marker_pos = None
            slice_159: "i64[1, 3]" = torch.ops.aten.slice.Tensor(clamp, 0, 0, 9223372036854775807);  clamp = None
            slice_160: "i64[1, 3]" = torch.ops.aten.slice.Tensor(slice_159, 1, 0, 9223372036854775807);  slice_159 = None
            unsqueeze_119: "i64[1, 3, 1]" = torch.ops.aten.unsqueeze.default(slice_160, 2);  slice_160 = None
            expand_27: "i64[1, 3, 768]" = torch.ops.aten.expand.default(unsqueeze_119, [-1, -1, 768]);  unsqueeze_119 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:115 in forward, code: m = torch.gather(h, 1, idx)
            gather: "f32[1, 3, 768]" = torch.ops.aten.gather.default(add_92, 1, expand_27);  expand_27 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/normalization.py:217 in forward, code: return F.layer_norm(
            layer_norm_49: "f32[1, 3, 768]" = torch.ops.aten.layer_norm.default(gather, [768], p_scorer_0_weight, p_scorer_0_bias);  gather = p_scorer_0_weight = p_scorer_0_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_96: "f32[1, 3, 768]" = torch.ops.aten.linear.default(layer_norm_49, p_scorer_1_weight, p_scorer_1_bias);  layer_norm_49 = p_scorer_1_weight = p_scorer_1_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:738 in forward, code: return F.gelu(input, approximate=self.approximate)
            gelu_22: "f32[1, 3, 768]" = torch.ops.aten.gelu.default(linear_96);  linear_96 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_97: "f32[1, 3, 1]" = torch.ops.aten.linear.default(gelu_22, p_scorer_3_weight, p_scorer_3_bias);  gelu_22 = p_scorer_3_weight = p_scorer_3_bias = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:116 in forward, code: logits = self.scorer(m).squeeze(-1).float()
            squeeze_2: "f32[1, 3]" = torch.ops.aten.squeeze.dim(linear_97, -1);  linear_97 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:117 in forward, code: logits = logits.masked_fill(~marker_mask, -1e4)
            bitwise_not_1: "b8[1, 3]" = torch.ops.aten.bitwise_not.default(marker_mask)
            masked_fill_4: "f32[1, 3]" = torch.ops.aten.masked_fill.Scalar(squeeze_2, bitwise_not_1, -10000.0);  squeeze_2 = bitwise_not_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:119 in forward, code: p = torch.softmax(logits.detach(), -1)
            detach: "f32[1, 3]" = torch.ops.aten.detach.default(masked_fill_4)
            detach_1: "f32[1, 3]" = torch.ops.aten.detach.default(detach);  detach = None
            detach_2: "f32[1, 3]" = torch.ops.aten.detach.default(detach_1);  detach_1 = None
            softmax: "f32[1, 3]" = torch.ops.aten.softmax.int(detach_2, -1);  detach_2 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:120 in forward, code: k = marker_mask.sum(-1).clamp(min=2).float()
            convert_element_type_default: "i64[1, 3]" = torch.ops.prims.convert_element_type.default(marker_mask, dtype = torch.int64);  marker_mask = None
            sum_1: "i64[1]" = torch.ops.aten.sum.dim_IntList(convert_element_type_default, [-1]);  convert_element_type_default = None
            clamp_1: "i64[1]" = torch.ops.aten.clamp.default(sum_1, 2);  sum_1 = None
            _to_copy_25: "f32[1]" = torch.ops.aten._to_copy.default(clamp_1, dtype = torch.float32);  clamp_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:121 in forward, code: ent = -(p * torch.log(p.clamp_min(1e-9))).sum(-1) / torch.log(k)
            clamp_min: "f32[1, 3]" = torch.ops.aten.clamp_min.default(softmax, 1e-09)
            log: "f32[1, 3]" = torch.ops.aten.log.default(clamp_min);  clamp_min = None
            mul_154: "f32[1, 3]" = torch.ops.aten.mul.Tensor(softmax, log);  log = None
            sum_2: "f32[1]" = torch.ops.aten.sum.dim_IntList(mul_154, [-1]);  mul_154 = None
            neg_44: "f32[1]" = torch.ops.aten.neg.default(sum_2);  sum_2 = None
            log_1: "f32[1]" = torch.ops.aten.log.default(_to_copy_25)
            div: "f32[1]" = torch.ops.aten.div.Tensor(neg_44, log_1);  neg_44 = log_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:123 in forward, code: top2 = p.topk(2, -1).values
            topk = torch.ops.aten.topk.default(softmax, 2);  softmax = None
            getitem_110: "f32[1, 2]" = topk[0];  topk = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:133 in forward, code: feats = torch.stack([top2[:, 0], top2[:, 0] - top2[:, 1], ent, k / 255.0], -1)
            slice_161: "f32[1, 2]" = torch.ops.aten.slice.Tensor(getitem_110)
            select_6: "f32[1]" = torch.ops.aten.select.int(slice_161, 1, 0);  slice_161 = None
            slice_162: "f32[1, 2]" = torch.ops.aten.slice.Tensor(getitem_110)
            select_7: "f32[1]" = torch.ops.aten.select.int(slice_162, 1, 0);  slice_162 = None
            slice_163: "f32[1, 2]" = torch.ops.aten.slice.Tensor(getitem_110);  getitem_110 = None
            select_8: "f32[1]" = torch.ops.aten.select.int(slice_163, 1, 1);  slice_163 = None
            sub_2: "f32[1]" = torch.ops.aten.sub.Tensor(select_7, select_8);  select_7 = select_8 = None
            div_1: "f32[1]" = torch.ops.aten.div.Tensor(_to_copy_25, 255.0);  _to_copy_25 = None
            stack: "f32[1, 4]" = torch.ops.aten.stack.default([select_6, sub_2, div, div_1], -1);  select_6 = sub_2 = div = div_1 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:134 in forward, code: pooled = h[:, 0].float()
            slice_164: "f32[1, 97, 768]" = torch.ops.aten.slice.Tensor(add_92);  add_92 = None
            select_9: "f32[1, 768]" = torch.ops.aten.select.int(slice_164, 1, 0);  slice_164 = None
            
             # File: /workspace/scratch/thx01-m1/snapshot/thx01/common.py:135 in forward, code: act_logits = self.act_head(torch.cat([pooled, feats], -1))
            cat_66: "f32[1, 772]" = torch.ops.aten.cat.default([select_9, stack], -1);  select_9 = stack = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_98: "f32[1, 256]" = torch.ops.aten.linear.default(cat_66, p_act_head_0_weight, p_act_head_0_bias);  cat_66 = p_act_head_0_weight = p_act_head_0_bias = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/activation.py:738 in forward, code: return F.gelu(input, approximate=self.approximate)
            gelu_23: "f32[1, 256]" = torch.ops.aten.gelu.default(linear_98);  linear_98 = None
            
             # File: /workspace/scratch/thx01-m11/venv/lib/python3.12/site-packages/torch/nn/modules/linear.py:125 in forward, code: return F.linear(input, self.weight, self.bias)
            linear_99: "f32[1, 2]" = torch.ops.aten.linear.default(gelu_23, p_act_head_2_weight, p_act_head_2_bias);  gelu_23 = p_act_head_2_weight = p_act_head_2_bias = None
            return (masked_fill_4, linear_99)
            
Graph signature: 
    # inputs
    p_encoder_embeddings_tok_embeddings_weight: PARAMETER target='encoder.embeddings.tok_embeddings.weight'
    p_encoder_embeddings_norm_weight: PARAMETER target='encoder.embeddings.norm.weight'
    p_encoder_layers_0_attn_wqkv_weight: PARAMETER target='encoder.layers.0.attn.Wqkv.weight'
    p_encoder_layers_0_attn_wo_weight: PARAMETER target='encoder.layers.0.attn.Wo.weight'
    p_encoder_layers_0_mlp_norm_weight: PARAMETER target='encoder.layers.0.mlp_norm.weight'
    p_encoder_layers_0_mlp_wi_weight: PARAMETER target='encoder.layers.0.mlp.Wi.weight'
    p_encoder_layers_0_mlp_wo_weight: PARAMETER target='encoder.layers.0.mlp.Wo.weight'
    p_encoder_layers_1_attn_norm_weight: PARAMETER target='encoder.layers.1.attn_norm.weight'
    p_encoder_layers_1_attn_wqkv_weight: PARAMETER target='encoder.layers.1.attn.Wqkv.weight'
    p_encoder_layers_1_attn_wo_weight: PARAMETER target='encoder.layers.1.attn.Wo.weight'
    p_encoder_layers_1_mlp_norm_weight: PARAMETER target='encoder.layers.1.mlp_norm.weight'
    p_encoder_layers_1_mlp_wi_weight: PARAMETER target='encoder.layers.1.mlp.Wi.weight'
    p_encoder_layers_1_mlp_wo_weight: PARAMETER target='encoder.layers.1.mlp.Wo.weight'
    p_encoder_layers_2_attn_norm_weight: PARAMETER target='encoder.layers.2.attn_norm.weight'
    p_encoder_layers_2_attn_wqkv_weight: PARAMETER target='encoder.layers.2.attn.Wqkv.weight'
    p_encoder_layers_2_attn_wo_weight: PARAMETER target='encoder.layers.2.attn.Wo.weight'
    p_encoder_layers_2_mlp_norm_weight: PARAMETER target='encoder.layers.2.mlp_norm.weight'
    p_encoder_layers_2_mlp_wi_weight: PARAMETER target='encoder.layers.2.mlp.Wi.weight'
    p_encoder_layers_2_mlp_wo_weight: PARAMETER target='encoder.layers.2.mlp.Wo.weight'
    p_encoder_layers_3_attn_norm_weight: PARAMETER target='encoder.layers.3.attn_norm.weight'
    p_encoder_layers_3_attn_wqkv_weight: PARAMETER target='encoder.layers.3.attn.Wqkv.weight'
    p_encoder_layers_3_attn_wo_weight: PARAMETER target='encoder.layers.3.attn.Wo.weight'
    p_encoder_layers_3_mlp_norm_weight: PARAMETER target='encoder.layers.3.mlp_norm.weight'
    p_encoder_layers_3_mlp_wi_weight: PARAMETER target='encoder.layers.3.mlp.Wi.weight'
    p_encoder_layers_3_mlp_wo_weight: PARAMETER target='encoder.layers.3.mlp.Wo.weight'
    p_encoder_layers_4_attn_norm_weight: PARAMETER target='encoder.layers.4.attn_norm.weight'
    p_encoder_layers_4_attn_wqkv_weight: PARAMETER target='encoder.layers.4.attn.Wqkv.weight'
    p_encoder_layers_4_attn_wo_weight: PARAMETER target='encoder.layers.4.attn.Wo.weight'
    p_encoder_layers_4_mlp_norm_weight: PARAMETER target='encoder.layers.4.mlp_norm.weight'
    p_encoder_layers_4_mlp_wi_weight: PARAMETER target='encoder.layers.4.mlp.Wi.weight'
    p_encoder_layers_4_mlp_wo_weight: PARAMETER target='encoder.layers.4.mlp.Wo.weight'
    p_encoder_layers_5_attn_norm_weight: PARAMETER target='encoder.layers.5.attn_norm.weight'
    p_encoder_layers_5_attn_wqkv_weight: PARAMETER target='encoder.layers.5.attn.Wqkv.weight'
    p_encoder_layers_5_attn_wo_weight: PARAMETER target='encoder.layers.5.attn.Wo.weight'
    p_encoder_layers_5_mlp_norm_weight: PARAMETER target='encoder.layers.5.mlp_norm.weight'
    p_encoder_layers_5_mlp_wi_weight: PARAMETER target='encoder.layers.5.mlp.Wi.weight'
    p_encoder_layers_5_mlp_wo_weight: PARAMETER target='encoder.layers.5.mlp.Wo.weight'
    p_encoder_layers_6_attn_norm_weight: PARAMETER target='encoder.layers.6.attn_norm.weight'
    p_encoder_layers_6_attn_wqkv_weight: PARAMETER target='encoder.layers.6.attn.Wqkv.weight'
    p_encoder_layers_6_attn_wo_weight: PARAMETER target='encoder.layers.6.attn.Wo.weight'
    p_encoder_layers_6_mlp_norm_weight: PARAMETER target='encoder.layers.6.mlp_norm.weight'
    p_encoder_layers_6_mlp_wi_weight: PARAMETER target='encoder.layers.6.mlp.Wi.weight'
    p_encoder_layers_6_mlp_wo_weight: PARAMETER target='encoder.layers.6.mlp.Wo.weight'
    p_encoder_layers_7_attn_norm_weight: PARAMETER target='encoder.layers.7.attn_norm.weight'
    p_encoder_layers_7_attn_wqkv_weight: PARAMETER target='encoder.layers.7.attn.Wqkv.weight'
    p_encoder_layers_7_attn_wo_weight: PARAMETER target='encoder.layers.7.attn.Wo.weight'
    p_encoder_layers_7_mlp_norm_weight: PARAMETER target='encoder.layers.7.mlp_norm.weight'
    p_encoder_layers_7_mlp_wi_weight: PARAMETER target='encoder.layers.7.mlp.Wi.weight'
    p_encoder_layers_7_mlp_wo_weight: PARAMETER target='encoder.layers.7.mlp.Wo.weight'
    p_encoder_layers_8_attn_norm_weight: PARAMETER target='encoder.layers.8.attn_norm.weight'
    p_encoder_layers_8_attn_wqkv_weight: PARAMETER target='encoder.layers.8.attn.Wqkv.weight'
    p_encoder_layers_8_attn_wo_weight: PARAMETER target='encoder.layers.8.attn.Wo.weight'
    p_encoder_layers_8_mlp_norm_weight: PARAMETER target='encoder.layers.8.mlp_norm.weight'
    p_encoder_layers_8_mlp_wi_weight: PARAMETER target='encoder.layers.8.mlp.Wi.weight'
    p_encoder_layers_8_mlp_wo_weight: PARAMETER target='encoder.layers.8.mlp.Wo.weight'
    p_encoder_layers_9_attn_norm_weight: PARAMETER target='encoder.layers.9.attn_norm.weight'
    p_encoder_layers_9_attn_wqkv_weight: PARAMETER target='encoder.layers.9.attn.Wqkv.weight'
    p_encoder_layers_9_attn_wo_weight: PARAMETER target='encoder.layers.9.attn.Wo.weight'
    p_encoder_layers_9_mlp_norm_weight: PARAMETER target='encoder.layers.9.mlp_norm.weight'
    p_encoder_layers_9_mlp_wi_weight: PARAMETER target='encoder.layers.9.mlp.Wi.weight'
    p_encoder_layers_9_mlp_wo_weight: PARAMETER target='encoder.layers.9.mlp.Wo.weight'
    p_encoder_layers_10_attn_norm_weight: PARAMETER target='encoder.layers.10.attn_norm.weight'
    p_encoder_layers_10_attn_wqkv_weight: PARAMETER target='encoder.layers.10.attn.Wqkv.weight'
    p_encoder_layers_10_attn_wo_weight: PARAMETER target='encoder.layers.10.attn.Wo.weight'
    p_encoder_layers_10_mlp_norm_weight: PARAMETER target='encoder.layers.10.mlp_norm.weight'
    p_encoder_layers_10_mlp_wi_weight: PARAMETER target='encoder.layers.10.mlp.Wi.weight'
    p_encoder_layers_10_mlp_wo_weight: PARAMETER target='encoder.layers.10.mlp.Wo.weight'
    p_encoder_layers_11_attn_norm_weight: PARAMETER target='encoder.layers.11.attn_norm.weight'
    p_encoder_layers_11_attn_wqkv_weight: PARAMETER target='encoder.layers.11.attn.Wqkv.weight'
    p_encoder_layers_11_attn_wo_weight: PARAMETER target='encoder.layers.11.attn.Wo.weight'
    p_encoder_layers_11_mlp_norm_weight: PARAMETER target='encoder.layers.11.mlp_norm.weight'
    p_encoder_layers_11_mlp_wi_weight: PARAMETER target='encoder.layers.11.mlp.Wi.weight'
    p_encoder_layers_11_mlp_wo_weight: PARAMETER target='encoder.layers.11.mlp.Wo.weight'
    p_encoder_layers_12_attn_norm_weight: PARAMETER target='encoder.layers.12.attn_norm.weight'
    p_encoder_layers_12_attn_wqkv_weight: PARAMETER target='encoder.layers.12.attn.Wqkv.weight'
    p_encoder_layers_12_attn_wo_weight: PARAMETER target='encoder.layers.12.attn.Wo.weight'
    p_encoder_layers_12_mlp_norm_weight: PARAMETER target='encoder.layers.12.mlp_norm.weight'
    p_encoder_layers_12_mlp_wi_weight: PARAMETER target='encoder.layers.12.mlp.Wi.weight'
    p_encoder_layers_12_mlp_wo_weight: PARAMETER target='encoder.layers.12.mlp.Wo.weight'
    p_encoder_layers_13_attn_norm_weight: PARAMETER target='encoder.layers.13.attn_norm.weight'
    p_encoder_layers_13_attn_wqkv_weight: PARAMETER target='encoder.layers.13.attn.Wqkv.weight'
    p_encoder_layers_13_attn_wo_weight: PARAMETER target='encoder.layers.13.attn.Wo.weight'
    p_encoder_layers_13_mlp_norm_weight: PARAMETER target='encoder.layers.13.mlp_norm.weight'
    p_encoder_layers_13_mlp_wi_weight: PARAMETER target='encoder.layers.13.mlp.Wi.weight'
    p_encoder_layers_13_mlp_wo_weight: PARAMETER target='encoder.layers.13.mlp.Wo.weight'
    p_encoder_layers_14_attn_norm_weight: PARAMETER target='encoder.layers.14.attn_norm.weight'
    p_encoder_layers_14_attn_wqkv_weight: PARAMETER target='encoder.layers.14.attn.Wqkv.weight'
    p_encoder_layers_14_attn_wo_weight: PARAMETER target='encoder.layers.14.attn.Wo.weight'
    p_encoder_layers_14_mlp_norm_weight: PARAMETER target='encoder.layers.14.mlp_norm.weight'
    p_encoder_layers_14_mlp_wi_weight: PARAMETER target='encoder.layers.14.mlp.Wi.weight'
    p_encoder_layers_14_mlp_wo_weight: PARAMETER target='encoder.layers.14.mlp.Wo.weight'
    p_encoder_layers_15_attn_norm_weight: PARAMETER target='encoder.layers.15.attn_norm.weight'
    p_encoder_layers_15_attn_wqkv_weight: PARAMETER target='encoder.layers.15.attn.Wqkv.weight'
    p_encoder_layers_15_attn_wo_weight: PARAMETER target='encoder.layers.15.attn.Wo.weight'
    p_encoder_layers_15_mlp_norm_weight: PARAMETER target='encoder.layers.15.mlp_norm.weight'
    p_encoder_layers_15_mlp_wi_weight: PARAMETER target='encoder.layers.15.mlp.Wi.weight'
    p_encoder_layers_15_mlp_wo_weight: PARAMETER target='encoder.layers.15.mlp.Wo.weight'
    p_encoder_layers_16_attn_norm_weight: PARAMETER target='encoder.layers.16.attn_norm.weight'
    p_encoder_layers_16_attn_wqkv_weight: PARAMETER target='encoder.layers.16.attn.Wqkv.weight'
    p_encoder_layers_16_attn_wo_weight: PARAMETER target='encoder.layers.16.attn.Wo.weight'
    p_encoder_layers_16_mlp_norm_weight: PARAMETER target='encoder.layers.16.mlp_norm.weight'
    p_encoder_layers_16_mlp_wi_weight: PARAMETER target='encoder.layers.16.mlp.Wi.weight'
    p_encoder_layers_16_mlp_wo_weight: PARAMETER target='encoder.layers.16.mlp.Wo.weight'
    p_encoder_layers_17_attn_norm_weight: PARAMETER target='encoder.layers.17.attn_norm.weight'
    p_encoder_layers_17_attn_wqkv_weight: PARAMETER target='encoder.layers.17.attn.Wqkv.weight'
    p_encoder_layers_17_attn_wo_weight: PARAMETER target='encoder.layers.17.attn.Wo.weight'
    p_encoder_layers_17_mlp_norm_weight: PARAMETER target='encoder.layers.17.mlp_norm.weight'
    p_encoder_layers_17_mlp_wi_weight: PARAMETER target='encoder.layers.17.mlp.Wi.weight'
    p_encoder_layers_17_mlp_wo_weight: PARAMETER target='encoder.layers.17.mlp.Wo.weight'
    p_encoder_layers_18_attn_norm_weight: PARAMETER target='encoder.layers.18.attn_norm.weight'
    p_encoder_layers_18_attn_wqkv_weight: PARAMETER target='encoder.layers.18.attn.Wqkv.weight'
    p_encoder_layers_18_attn_wo_weight: PARAMETER target='encoder.layers.18.attn.Wo.weight'
    p_encoder_layers_18_mlp_norm_weight: PARAMETER target='encoder.layers.18.mlp_norm.weight'
    p_encoder_layers_18_mlp_wi_weight: PARAMETER target='encoder.layers.18.mlp.Wi.weight'
    p_encoder_layers_18_mlp_wo_weight: PARAMETER target='encoder.layers.18.mlp.Wo.weight'
    p_encoder_layers_19_attn_norm_weight: PARAMETER target='encoder.layers.19.attn_norm.weight'
    p_encoder_layers_19_attn_wqkv_weight: PARAMETER target='encoder.layers.19.attn.Wqkv.weight'
    p_encoder_layers_19_attn_wo_weight: PARAMETER target='encoder.layers.19.attn.Wo.weight'
    p_encoder_layers_19_mlp_norm_weight: PARAMETER target='encoder.layers.19.mlp_norm.weight'
    p_encoder_layers_19_mlp_wi_weight: PARAMETER target='encoder.layers.19.mlp.Wi.weight'
    p_encoder_layers_19_mlp_wo_weight: PARAMETER target='encoder.layers.19.mlp.Wo.weight'
    p_encoder_layers_20_attn_norm_weight: PARAMETER target='encoder.layers.20.attn_norm.weight'
    p_encoder_layers_20_attn_wqkv_weight: PARAMETER target='encoder.layers.20.attn.Wqkv.weight'
    p_encoder_layers_20_attn_wo_weight: PARAMETER target='encoder.layers.20.attn.Wo.weight'
    p_encoder_layers_20_mlp_norm_weight: PARAMETER target='encoder.layers.20.mlp_norm.weight'
    p_encoder_layers_20_mlp_wi_weight: PARAMETER target='encoder.layers.20.mlp.Wi.weight'
    p_encoder_layers_20_mlp_wo_weight: PARAMETER target='encoder.layers.20.mlp.Wo.weight'
    p_encoder_layers_21_attn_norm_weight: PARAMETER target='encoder.layers.21.attn_norm.weight'
    p_encoder_layers_21_attn_wqkv_weight: PARAMETER target='encoder.layers.21.attn.Wqkv.weight'
    p_encoder_layers_21_attn_wo_weight: PARAMETER target='encoder.layers.21.attn.Wo.weight'
    p_encoder_layers_21_mlp_norm_weight: PARAMETER target='encoder.layers.21.mlp_norm.weight'
    p_encoder_layers_21_mlp_wi_weight: PARAMETER target='encoder.layers.21.mlp.Wi.weight'
    p_encoder_layers_21_mlp_wo_weight: PARAMETER target='encoder.layers.21.mlp.Wo.weight'
    p_encoder_final_norm_weight: PARAMETER target='encoder.final_norm.weight'
    p_head_layers_0_self_attn_in_proj_weight: PARAMETER target='head.layers.0.self_attn.in_proj_weight'
    p_head_layers_0_self_attn_in_proj_bias: PARAMETER target='head.layers.0.self_attn.in_proj_bias'
    p_head_layers_0_self_attn_out_proj_weight: PARAMETER target='head.layers.0.self_attn.out_proj.weight'
    p_head_layers_0_self_attn_out_proj_bias: PARAMETER target='head.layers.0.self_attn.out_proj.bias'
    p_head_layers_0_linear1_weight: PARAMETER target='head.layers.0.linear1.weight'
    p_head_layers_0_linear1_bias: PARAMETER target='head.layers.0.linear1.bias'
    p_head_layers_0_linear2_weight: PARAMETER target='head.layers.0.linear2.weight'
    p_head_layers_0_linear2_bias: PARAMETER target='head.layers.0.linear2.bias'
    p_head_layers_0_norm1_weight: PARAMETER target='head.layers.0.norm1.weight'
    p_head_layers_0_norm1_bias: PARAMETER target='head.layers.0.norm1.bias'
    p_head_layers_0_norm2_weight: PARAMETER target='head.layers.0.norm2.weight'
    p_head_layers_0_norm2_bias: PARAMETER target='head.layers.0.norm2.bias'
    p_head_layers_1_self_attn_in_proj_weight: PARAMETER target='head.layers.1.self_attn.in_proj_weight'
    p_head_layers_1_self_attn_in_proj_bias: PARAMETER target='head.layers.1.self_attn.in_proj_bias'
    p_head_layers_1_self_attn_out_proj_weight: PARAMETER target='head.layers.1.self_attn.out_proj.weight'
    p_head_layers_1_self_attn_out_proj_bias: PARAMETER target='head.layers.1.self_attn.out_proj.bias'
    p_head_layers_1_linear1_weight: PARAMETER target='head.layers.1.linear1.weight'
    p_head_layers_1_linear1_bias: PARAMETER target='head.layers.1.linear1.bias'
    p_head_layers_1_linear2_weight: PARAMETER target='head.layers.1.linear2.weight'
    p_head_layers_1_linear2_bias: PARAMETER target='head.layers.1.linear2.bias'
    p_head_layers_1_norm1_weight: PARAMETER target='head.layers.1.norm1.weight'
    p_head_layers_1_norm1_bias: PARAMETER target='head.layers.1.norm1.bias'
    p_head_layers_1_norm2_weight: PARAMETER target='head.layers.1.norm2.weight'
    p_head_layers_1_norm2_bias: PARAMETER target='head.layers.1.norm2.bias'
    p_type_emb_weight: PARAMETER target='type_emb.weight'
    p_scorer_0_weight: PARAMETER target='scorer.0.weight'
    p_scorer_0_bias: PARAMETER target='scorer.0.bias'
    p_scorer_1_weight: PARAMETER target='scorer.1.weight'
    p_scorer_1_bias: PARAMETER target='scorer.1.bias'
    p_scorer_3_weight: PARAMETER target='scorer.3.weight'
    p_scorer_3_bias: PARAMETER target='scorer.3.bias'
    p_act_head_0_weight: PARAMETER target='act_head.0.weight'
    p_act_head_0_bias: PARAMETER target='act_head.0.bias'
    p_act_head_2_weight: PARAMETER target='act_head.2.weight'
    p_act_head_2_bias: PARAMETER target='act_head.2.bias'
    b_temperature: BUFFER target='temperature' persistent=True
    c_encoder_lifted_tensor_0: CONSTANT_TENSOR target='encoder.lifted_tensor_0'
    b_encoder_rotary_emb_full_attention_inv_freq: BUFFER target='encoder.rotary_emb.full_attention_inv_freq' persistent=False
    b_encoder_rotary_emb_full_attention_original_inv_freq: BUFFER target='encoder.rotary_emb.full_attention_original_inv_freq' persistent=False
    b_encoder_rotary_emb_sliding_attention_inv_freq: BUFFER target='encoder.rotary_emb.sliding_attention_inv_freq' persistent=False
    b_encoder_rotary_emb_sliding_attention_original_inv_freq: BUFFER target='encoder.rotary_emb.sliding_attention_original_inv_freq' persistent=False
    input_ids: USER_INPUT
    attention_mask: USER_INPUT
    marker_pos: USER_INPUT
    marker_mask: USER_INPUT
    qtype: USER_INPUT
    
    # outputs
    masked_fill_4: USER_OUTPUT
    linear_99: USER_OUTPUT
    
Range constraints: {}

```

## ONNX model

```python
<
    ir_version=10,
    opset_imports={'pkg.onnxscript.torch_lib.common': 1, '': 18, 'pkg.onnxscript.torch_lib': 1},
    producer_name='pytorch',
    producer_version='2.8.0+cpu',
    domain=None,
    model_version=None,
>
graph(
    name=main_graph,
    inputs=(
        %"input_ids"<INT64,[1,97]>,
        %"attention_mask"<INT64,[1,97]>,
        %"marker_pos"<INT64,[1,3]>,
        %"marker_mask"<BOOL,[1,3]>,
        %"qtype"<INT64,[1]>
    ),
    outputs=(
        %"logits"<FLOAT,[1,3]>,
        %"act_logits"<FLOAT,[1,2]>
    ),
    initializers=(
        %"encoder.embeddings.tok_embeddings.weight"<FLOAT,[256000,768]>{TorchTensor(...)},
        %"encoder.embeddings.norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.0.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.0.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.0.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.0.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.0.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.1.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.1.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.1.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.1.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.1.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.1.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.2.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.2.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.2.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.2.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.2.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.2.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.3.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.3.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.3.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.3.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.3.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.3.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.4.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.4.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.4.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.4.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.4.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.4.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.5.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.5.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.5.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.5.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.5.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.5.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.6.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.6.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.6.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.6.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.6.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.6.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.7.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.7.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.7.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.7.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.7.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.7.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.8.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.8.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.8.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.8.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.8.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.8.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.9.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.9.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.9.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.9.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.9.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.9.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.10.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.10.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.10.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.10.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.10.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.10.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.11.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.11.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.11.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.11.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.11.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.11.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.12.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.12.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.12.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.12.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.12.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.12.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.13.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.13.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.13.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.13.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.13.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.13.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.14.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.14.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.14.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.14.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.14.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.14.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.15.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.15.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.15.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.15.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.15.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.15.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.16.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.16.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.16.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.16.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.16.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.16.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.17.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.17.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.17.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.17.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.17.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.17.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.18.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.18.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.18.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.18.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.18.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.18.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.19.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.19.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.19.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.19.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.19.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.19.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.20.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.20.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.20.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.20.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.20.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.20.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.layers.21.attn_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.21.attn.Wqkv.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.21.attn.Wo.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"encoder.layers.21.mlp_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"encoder.layers.21.mlp.Wi.weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"encoder.layers.21.mlp.Wo.weight"<FLOAT,[768,1152]>{TorchTensor(...)},
        %"encoder.final_norm.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.self_attn.in_proj_weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"head.layers.0.self_attn.in_proj_bias"<FLOAT,[2304]>{TorchTensor(...)},
        %"head.layers.0.self_attn.out_proj.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"head.layers.0.self_attn.out_proj.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.linear1.weight"<FLOAT,[3072,768]>{TorchTensor(...)},
        %"head.layers.0.linear1.bias"<FLOAT,[3072]>{TorchTensor(...)},
        %"head.layers.0.linear2.weight"<FLOAT,[768,3072]>{TorchTensor(...)},
        %"head.layers.0.linear2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm1.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm1.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm2.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.0.norm2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.self_attn.in_proj_weight"<FLOAT,[2304,768]>{TorchTensor(...)},
        %"head.layers.1.self_attn.in_proj_bias"<FLOAT,[2304]>{TorchTensor(...)},
        %"head.layers.1.self_attn.out_proj.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"head.layers.1.self_attn.out_proj.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.linear1.weight"<FLOAT,[3072,768]>{TorchTensor(...)},
        %"head.layers.1.linear1.bias"<FLOAT,[3072]>{TorchTensor(...)},
        %"head.layers.1.linear2.weight"<FLOAT,[768,3072]>{TorchTensor(...)},
        %"head.layers.1.linear2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm1.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm1.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm2.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"head.layers.1.norm2.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"type_emb.weight"<FLOAT,[3,768]>{TorchTensor(...)},
        %"scorer.0.weight"<FLOAT,[768]>{TorchTensor(...)},
        %"scorer.0.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"scorer.1.weight"<FLOAT,[768,768]>{TorchTensor(...)},
        %"scorer.1.bias"<FLOAT,[768]>{TorchTensor(...)},
        %"scorer.3.weight"<FLOAT,[1,768]>{TorchTensor(...)},
        %"scorer.3.bias"<FLOAT,[1]>{TorchTensor<FLOAT,[1]>(Parameter containing: tensor([0.0259], requires_grad=True), name='scorer.3.bias')},
        %"act_head.0.weight"<FLOAT,[256,772]>{TorchTensor(...)},
        %"act_head.0.bias"<FLOAT,[256]>{TorchTensor(...)},
        %"act_head.2.weight"<FLOAT,[2,256]>{TorchTensor(...)},
        %"act_head.2.bias"<FLOAT,[2]>{TorchTensor<FLOAT,[2]>(Parameter containing: tensor([ 0.0235, -0.0205], requires_grad=True), name='act_head.2.bias')},
        %"temperature"<FLOAT,[3]>{TorchTensor<FLOAT,[3]>(tensor([1., 1., 1.]), name='temperature')},
        %"encoder.rotary_emb.full_attention_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.rotary_emb.full_attention_original_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.rotary_emb.sliding_attention_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.rotary_emb.sliding_attention_original_inv_freq"<FLOAT,[32]>{TorchTensor(...)},
        %"encoder.lifted_tensor_0"<FLOAT,[]>{TorchTensor<FLOAT,[]>(tensor(1.), name='encoder.lifted_tensor_0')}
    ),
) {
       0 |  # node_Constant_0
            %"val_0"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0., dtype=float32), name=None)}
       1 |  # node_Constant_1
            %"val_1"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(97), name=None)}
       2 |  # node_CastLike_2
            %"val_2"<?,?> ⬅️ ::CastLike(%"val_0", %"val_1")
       3 |  # node_Constant_3
            %"val_3"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
       4 |  # node_CastLike_4
            %"val_4"<?,?> ⬅️ ::CastLike(%"val_3", %"val_1")
       5 |  # node_arange
            %"arange"<INT64,[97]> ⬅️ ::Range(%"val_2", %"val_1", %"val_4")
       6 |  # node_Constant_5
            %"val_5"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([0]), name=None)}
       7 |  # node_unsqueeze
            %"unsqueeze"<INT64,[1,97]> ⬅️ ::Unsqueeze(%"arange", %"val_5")
       8 |  # node_Constant_6
            %"val_6"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(0), name=None)}
       9 |  # node_Cast_7
            %"val_7"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      10 |  # node_Constant_8
            %"val_8"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      11 |  # node_Reshape_9
            %"val_9"<?,?> ⬅️ ::Reshape(%"val_7", %"val_8") {allowzero=0}
      12 |  # node_Constant_10
            %"val_10"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(9223372036854775807), name=None)}
      13 |  # node_Cast_11
            %"val_11"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      14 |  # node_Constant_12
            %"val_12"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      15 |  # node_Reshape_13
            %"val_13"<?,?> ⬅️ ::Reshape(%"val_11", %"val_12") {allowzero=0}
      16 |  # node_Cast_14
            %"val_14"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      17 |  # node_Constant_15
            %"val_15"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      18 |  # node_Reshape_16
            %"val_16"<?,?> ⬅️ ::Reshape(%"val_14", %"val_15") {allowzero=0}
      19 |  # node_Constant_17
            %"val_17"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      20 |  # node_slice_1
            %"slice_1"<INT64,[1,97]> ⬅️ ::Slice(%"attention_mask", %"val_9", %"val_13", %"val_16", %"val_17")
      21 |  # node_Constant_18
            %"val_18"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([1]), name=None)}
      22 |  # node_unsqueeze_1
            %"unsqueeze_1"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_1", %"val_18")
      23 |  # node_Constant_19
            %"val_19"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([2]), name=None)}
      24 |  # node_unsqueeze_2
            %"unsqueeze_2"<INT64,[1,1,1,97]> ⬅️ ::Unsqueeze(%"unsqueeze_1", %"val_19")
      25 |  # node_Cast_20
            %"val_20"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      26 |  # node_Constant_21
            %"val_21"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      27 |  # node_Reshape_22
            %"val_22"<?,?> ⬅️ ::Reshape(%"val_20", %"val_21") {allowzero=0}
      28 |  # node_Cast_23
            %"val_23"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      29 |  # node_Constant_24
            %"val_24"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      30 |  # node_Reshape_25
            %"val_25"<?,?> ⬅️ ::Reshape(%"val_23", %"val_24") {allowzero=0}
      31 |  # node_Constant_26
            %"val_26"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(3), name=None)}
      32 |  # node_Cast_27
            %"val_27"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
      33 |  # node_Constant_28
            %"val_28"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      34 |  # node_Reshape_29
            %"val_29"<?,?> ⬅️ ::Reshape(%"val_27", %"val_28") {allowzero=0}
      35 |  # node_Constant_30
            %"val_30"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      36 |  # node_slice_2
            %"slice_2"<INT64,[1,1,1,97]> ⬅️ ::Slice(%"unsqueeze_2", %"val_22", %"val_25", %"val_29", %"val_30")
      37 |  # node_Constant_31
            %"val_31"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      38 |  # node_Constant_32
            %"val_32"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
      39 |  # node_Constant_33
            %"val_33"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
      40 |  # node_Constant_34
            %"val_34"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
      41 |  # node_Constant_35
            %"val_35"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
      42 |  # node_Concat_36
            %"val_36"<?,?> ⬅️ ::Concat(%"val_32", %"val_33", %"val_34", %"val_35") {axis=0}
      43 |  # node_expand
            %"expand"<INT64,[1,1,97,97]> ⬅️ ::Expand(%"slice_2", %"val_36")
      44 |  # node__to_copy
            %"_to_copy"<FLOAT,[1,1,97,97]> ⬅️ ::Cast(%"expand") {to=1}
      45 |  # node_clone
            %"clone"<FLOAT,[]> ⬅️ ::Identity(%"encoder.lifted_tensor_0"{1.0})
      46 |  # node_sub
            %"sub"<FLOAT,[1,1,97,97]> ⬅️ ::Sub(%"clone", %"_to_copy")
      47 |  # node__to_copy_1
            %"_to_copy_1"<BOOL,[1,1,97,97]> ⬅️ ::Cast(%"sub") {to=9}
      48 |  # node_Constant_37
            %"val_37"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(-3.4028235e+38, dtype=float32), name=None)}
      49 |  # node_CastLike_38
            %"val_38"<?,?> ⬅️ ::CastLike(%"val_37", %"sub")
      50 |  # node_masked_fill
            %"masked_fill"<FLOAT,[1,1,97,97]> ⬅️ ::Where(%"_to_copy_1", %"val_38", %"sub")
      51 |  # node_CastLike_39
            %"val_39"<?,?> ⬅️ ::CastLike(%"val_0", %"val_1")
      52 |  # node_CastLike_40
            %"val_40"<?,?> ⬅️ ::CastLike(%"val_3", %"val_1")
      53 |  # node_arange_1
            %"arange_1"<INT64,[97]> ⬅️ ::Range(%"val_39", %"val_1", %"val_40")
      54 |  # node_unsqueeze_3
            %"unsqueeze_3"<INT64,[1,97]> ⬅️ ::Unsqueeze(%"arange_1", %"val_5")
      55 |  # node_permute
            %"permute"<INT64,[97,1]> ⬅️ ::Transpose(%"unsqueeze_3") {perm=(1, 0)}
      56 |  # node_sub_1
            %"sub_1"<INT64,[97,97]> ⬅️ ::Sub(%"unsqueeze_3", %"permute")
      57 |  # node_abs_1
            %"abs_1"<INT64,[97,97]> ⬅️ ::Abs(%"sub_1")
      58 |  # node_Constant_41
            %"val_41"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(64), name=None)}
      59 |  # node_le
            %"le"<BOOL,[97,97]> ⬅️ ::LessOrEqual(%"abs_1", %"val_41")
      60 |  # node_unsqueeze_4
            %"unsqueeze_4"<BOOL,[1,97,97]> ⬅️ ::Unsqueeze(%"le", %"val_5")
      61 |  # node_unsqueeze_5
            %"unsqueeze_5"<BOOL,[1,1,97,97]> ⬅️ ::Unsqueeze(%"unsqueeze_4", %"val_5")
      62 |  # node_logical_not
            %"logical_not"<BOOL,[1,1,97,97]> ⬅️ ::Not(%"unsqueeze_5")
      63 |  # node_CastLike_42
            %"val_42"<?,?> ⬅️ ::CastLike(%"val_37", %"masked_fill")
      64 |  # node_masked_fill_1
            %"masked_fill_1"<FLOAT,[1,1,97,97]> ⬅️ ::Where(%"logical_not", %"val_42", %"masked_fill")
      65 |  # node_embedding
            %"embedding"<FLOAT,[1,97,768]> ⬅️ ::Gather(%"encoder.embeddings.tok_embeddings.weight"{...}, %"input_ids") {axis=0}
      66 |  # node_layer_norm
            %"layer_norm"<FLOAT,[1,97,768]>, %"val_43"<?,?>, %"val_44"<?,?> ⬅️ ::LayerNormalization(%"embedding", %"encoder.embeddings.norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
      67 |  # node_clone_1
            %"clone_1"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"layer_norm")
      68 |  # node_unsqueeze_6
            %"unsqueeze_6"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
      69 |  # node_Cast_43
            %"val_45"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      70 |  # node_Constant_44
            %"val_46"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      71 |  # node_Reshape_45
            %"val_47"<?,?> ⬅️ ::Reshape(%"val_45", %"val_46") {allowzero=0}
      72 |  # node_Cast_46
            %"val_48"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      73 |  # node_Constant_47
            %"val_49"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      74 |  # node_Reshape_48
            %"val_50"<?,?> ⬅️ ::Reshape(%"val_48", %"val_49") {allowzero=0}
      75 |  # node_Constant_49
            %"val_51"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(1), name=None)}
      76 |  # node_Cast_50
            %"val_52"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
      77 |  # node_Constant_51
            %"val_53"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      78 |  # node_Reshape_52
            %"val_54"<?,?> ⬅️ ::Reshape(%"val_52", %"val_53") {allowzero=0}
      79 |  # node_Constant_53
            %"val_55"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      80 |  # node_slice_3
            %"slice_3"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_6", %"val_47", %"val_50", %"val_54", %"val_55")
      81 |  # node_unsqueeze_7
            %"unsqueeze_7"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_3", %"val_19")
      82 |  # node_Constant_54
            %"val_56"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      83 |  # node_Constant_55
            %"val_57"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
      84 |  # node_Constant_56
            %"val_58"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
      85 |  # node_Constant_57
            %"val_59"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
      86 |  # node_Concat_58
            %"val_60"<?,?> ⬅️ ::Concat(%"val_57", %"val_58", %"val_59") {axis=0}
      87 |  # node_expand_1
            %"expand_1"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_7", %"val_60")
      88 |  # node_Cast_59
            %"val_61"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      89 |  # node_Constant_60
            %"val_62"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      90 |  # node_Reshape_61
            %"val_63"<?,?> ⬅️ ::Reshape(%"val_61", %"val_62") {allowzero=0}
      91 |  # node_Cast_62
            %"val_64"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
      92 |  # node_Constant_63
            %"val_65"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      93 |  # node_Reshape_64
            %"val_66"<?,?> ⬅️ ::Reshape(%"val_64", %"val_65") {allowzero=0}
      94 |  # node_Cast_65
            %"val_67"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
      95 |  # node_Constant_66
            %"val_68"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
      96 |  # node_Reshape_67
            %"val_69"<?,?> ⬅️ ::Reshape(%"val_67", %"val_68") {allowzero=0}
      97 |  # node_Constant_68
            %"val_70"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
      98 |  # node_slice_4
            %"slice_4"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_63", %"val_66", %"val_69", %"val_70")
      99 |  # node_unsqueeze_8
            %"unsqueeze_8"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_4", %"val_18")
     100 |  # node_Cast_69
            %"val_71"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     101 |  # node_Constant_70
            %"val_72"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     102 |  # node_Reshape_71
            %"val_73"<?,?> ⬅️ ::Reshape(%"val_71", %"val_72") {allowzero=0}
     103 |  # node_Cast_72
            %"val_74"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     104 |  # node_Constant_73
            %"val_75"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     105 |  # node_Reshape_74
            %"val_76"<?,?> ⬅️ ::Reshape(%"val_74", %"val_75") {allowzero=0}
     106 |  # node_Constant_75
            %"val_77"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(2), name=None)}
     107 |  # node_Cast_76
            %"val_78"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     108 |  # node_Constant_77
            %"val_79"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     109 |  # node_Reshape_78
            %"val_80"<?,?> ⬅️ ::Reshape(%"val_78", %"val_79") {allowzero=0}
     110 |  # node_Constant_79
            %"val_81"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     111 |  # node_slice_5
            %"slice_5"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_8", %"val_73", %"val_76", %"val_80", %"val_81")
     112 |  # node__to_copy_2
            %"_to_copy_2"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_5") {to=1}
     113 |  # node_matmul
            %"matmul"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_1", %"_to_copy_2")
     114 |  # node_transpose
            %"transpose"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul") {perm=(0, 2, 1)}
     115 |  # node_cat
            %"cat"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose", %"transpose") {axis=-1}
     116 |  # node_cos
            %"cos"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat")
     117 |  # node_mul
            %"mul"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos", %"val_3")
     118 |  # node_sin
            %"sin"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat")
     119 |  # node_mul_1
            %"mul_1"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin", %"val_3")
     120 |  # node_unsqueeze_9
            %"unsqueeze_9"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     121 |  # node_Cast_80
            %"val_82"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     122 |  # node_Constant_81
            %"val_83"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     123 |  # node_Reshape_82
            %"val_84"<?,?> ⬅️ ::Reshape(%"val_82", %"val_83") {allowzero=0}
     124 |  # node_Cast_83
            %"val_85"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     125 |  # node_Constant_84
            %"val_86"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     126 |  # node_Reshape_85
            %"val_87"<?,?> ⬅️ ::Reshape(%"val_85", %"val_86") {allowzero=0}
     127 |  # node_Cast_86
            %"val_88"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     128 |  # node_Constant_87
            %"val_89"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     129 |  # node_Reshape_88
            %"val_90"<?,?> ⬅️ ::Reshape(%"val_88", %"val_89") {allowzero=0}
     130 |  # node_Constant_89
            %"val_91"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     131 |  # node_slice_6
            %"slice_6"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_9", %"val_84", %"val_87", %"val_90", %"val_91")
     132 |  # node_unsqueeze_10
            %"unsqueeze_10"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_6", %"val_19")
     133 |  # node_Constant_90
            %"val_92"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     134 |  # node_Constant_91
            %"val_93"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     135 |  # node_Constant_92
            %"val_94"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     136 |  # node_Constant_93
            %"val_95"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     137 |  # node_Concat_94
            %"val_96"<?,?> ⬅️ ::Concat(%"val_93", %"val_94", %"val_95") {axis=0}
     138 |  # node_expand_2
            %"expand_2"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_10", %"val_96")
     139 |  # node_Cast_95
            %"val_97"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     140 |  # node_Constant_96
            %"val_98"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     141 |  # node_Reshape_97
            %"val_99"<?,?> ⬅️ ::Reshape(%"val_97", %"val_98") {allowzero=0}
     142 |  # node_Cast_98
            %"val_100"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     143 |  # node_Constant_99
            %"val_101"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     144 |  # node_Reshape_100
            %"val_102"<?,?> ⬅️ ::Reshape(%"val_100", %"val_101") {allowzero=0}
     145 |  # node_Cast_101
            %"val_103"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     146 |  # node_Constant_102
            %"val_104"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     147 |  # node_Reshape_103
            %"val_105"<?,?> ⬅️ ::Reshape(%"val_103", %"val_104") {allowzero=0}
     148 |  # node_Constant_104
            %"val_106"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     149 |  # node_slice_7
            %"slice_7"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_99", %"val_102", %"val_105", %"val_106")
     150 |  # node_unsqueeze_11
            %"unsqueeze_11"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_7", %"val_18")
     151 |  # node_Cast_105
            %"val_107"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     152 |  # node_Constant_106
            %"val_108"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     153 |  # node_Reshape_107
            %"val_109"<?,?> ⬅️ ::Reshape(%"val_107", %"val_108") {allowzero=0}
     154 |  # node_Cast_108
            %"val_110"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     155 |  # node_Constant_109
            %"val_111"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     156 |  # node_Reshape_110
            %"val_112"<?,?> ⬅️ ::Reshape(%"val_110", %"val_111") {allowzero=0}
     157 |  # node_Cast_111
            %"val_113"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     158 |  # node_Constant_112
            %"val_114"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     159 |  # node_Reshape_113
            %"val_115"<?,?> ⬅️ ::Reshape(%"val_113", %"val_114") {allowzero=0}
     160 |  # node_Constant_114
            %"val_116"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     161 |  # node_slice_8
            %"slice_8"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_11", %"val_109", %"val_112", %"val_115", %"val_116")
     162 |  # node__to_copy_3
            %"_to_copy_3"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_8") {to=1}
     163 |  # node_matmul_1
            %"matmul_1"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_2", %"_to_copy_3")
     164 |  # node_transpose_1
            %"transpose_1"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_1") {perm=(0, 2, 1)}
     165 |  # node_cat_1
            %"cat_1"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_1", %"transpose_1") {axis=-1}
     166 |  # node_cos_1
            %"cos_1"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_1")
     167 |  # node_mul_2
            %"mul_2"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_1", %"val_3")
     168 |  # node_sin_1
            %"sin_1"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_1")
     169 |  # node_mul_3
            %"mul_3"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_1", %"val_3")
     170 |  # node_unsqueeze_12
            %"unsqueeze_12"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     171 |  # node_Cast_115
            %"val_117"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     172 |  # node_Constant_116
            %"val_118"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     173 |  # node_Reshape_117
            %"val_119"<?,?> ⬅️ ::Reshape(%"val_117", %"val_118") {allowzero=0}
     174 |  # node_Cast_118
            %"val_120"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     175 |  # node_Constant_119
            %"val_121"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     176 |  # node_Reshape_120
            %"val_122"<?,?> ⬅️ ::Reshape(%"val_120", %"val_121") {allowzero=0}
     177 |  # node_Cast_121
            %"val_123"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     178 |  # node_Constant_122
            %"val_124"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     179 |  # node_Reshape_123
            %"val_125"<?,?> ⬅️ ::Reshape(%"val_123", %"val_124") {allowzero=0}
     180 |  # node_Constant_124
            %"val_126"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     181 |  # node_slice_9
            %"slice_9"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_12", %"val_119", %"val_122", %"val_125", %"val_126")
     182 |  # node_unsqueeze_13
            %"unsqueeze_13"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_9", %"val_19")
     183 |  # node_Constant_125
            %"val_127"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     184 |  # node_Constant_126
            %"val_128"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     185 |  # node_Constant_127
            %"val_129"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     186 |  # node_Constant_128
            %"val_130"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     187 |  # node_Concat_129
            %"val_131"<?,?> ⬅️ ::Concat(%"val_128", %"val_129", %"val_130") {axis=0}
     188 |  # node_expand_3
            %"expand_3"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_13", %"val_131")
     189 |  # node_Cast_130
            %"val_132"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     190 |  # node_Constant_131
            %"val_133"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     191 |  # node_Reshape_132
            %"val_134"<?,?> ⬅️ ::Reshape(%"val_132", %"val_133") {allowzero=0}
     192 |  # node_Cast_133
            %"val_135"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     193 |  # node_Constant_134
            %"val_136"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     194 |  # node_Reshape_135
            %"val_137"<?,?> ⬅️ ::Reshape(%"val_135", %"val_136") {allowzero=0}
     195 |  # node_Cast_136
            %"val_138"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     196 |  # node_Constant_137
            %"val_139"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     197 |  # node_Reshape_138
            %"val_140"<?,?> ⬅️ ::Reshape(%"val_138", %"val_139") {allowzero=0}
     198 |  # node_Constant_139
            %"val_141"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     199 |  # node_slice_10
            %"slice_10"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_134", %"val_137", %"val_140", %"val_141")
     200 |  # node_unsqueeze_14
            %"unsqueeze_14"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_10", %"val_18")
     201 |  # node_Cast_140
            %"val_142"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     202 |  # node_Constant_141
            %"val_143"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     203 |  # node_Reshape_142
            %"val_144"<?,?> ⬅️ ::Reshape(%"val_142", %"val_143") {allowzero=0}
     204 |  # node_Cast_143
            %"val_145"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     205 |  # node_Constant_144
            %"val_146"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     206 |  # node_Reshape_145
            %"val_147"<?,?> ⬅️ ::Reshape(%"val_145", %"val_146") {allowzero=0}
     207 |  # node_Cast_146
            %"val_148"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     208 |  # node_Constant_147
            %"val_149"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     209 |  # node_Reshape_148
            %"val_150"<?,?> ⬅️ ::Reshape(%"val_148", %"val_149") {allowzero=0}
     210 |  # node_Constant_149
            %"val_151"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     211 |  # node_slice_11
            %"slice_11"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_14", %"val_144", %"val_147", %"val_150", %"val_151")
     212 |  # node__to_copy_4
            %"_to_copy_4"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_11") {to=1}
     213 |  # node_matmul_2
            %"matmul_2"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_3", %"_to_copy_4")
     214 |  # node_transpose_2
            %"transpose_2"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_2") {perm=(0, 2, 1)}
     215 |  # node_cat_2
            %"cat_2"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_2", %"transpose_2") {axis=-1}
     216 |  # node_cos_2
            %"cos_2"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_2")
     217 |  # node_mul_4
            %"mul_4"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_2", %"val_3")
     218 |  # node_sin_2
            %"sin_2"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_2")
     219 |  # node_mul_5
            %"mul_5"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_2", %"val_3")
     220 |  # node_unsqueeze_15
            %"unsqueeze_15"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     221 |  # node_Cast_150
            %"val_152"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     222 |  # node_Constant_151
            %"val_153"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     223 |  # node_Reshape_152
            %"val_154"<?,?> ⬅️ ::Reshape(%"val_152", %"val_153") {allowzero=0}
     224 |  # node_Cast_153
            %"val_155"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     225 |  # node_Constant_154
            %"val_156"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     226 |  # node_Reshape_155
            %"val_157"<?,?> ⬅️ ::Reshape(%"val_155", %"val_156") {allowzero=0}
     227 |  # node_Cast_156
            %"val_158"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     228 |  # node_Constant_157
            %"val_159"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     229 |  # node_Reshape_158
            %"val_160"<?,?> ⬅️ ::Reshape(%"val_158", %"val_159") {allowzero=0}
     230 |  # node_Constant_159
            %"val_161"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     231 |  # node_slice_12
            %"slice_12"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_15", %"val_154", %"val_157", %"val_160", %"val_161")
     232 |  # node_unsqueeze_16
            %"unsqueeze_16"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_12", %"val_19")
     233 |  # node_Constant_160
            %"val_162"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     234 |  # node_Constant_161
            %"val_163"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     235 |  # node_Constant_162
            %"val_164"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     236 |  # node_Constant_163
            %"val_165"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     237 |  # node_Concat_164
            %"val_166"<?,?> ⬅️ ::Concat(%"val_163", %"val_164", %"val_165") {axis=0}
     238 |  # node_expand_4
            %"expand_4"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_16", %"val_166")
     239 |  # node_Cast_165
            %"val_167"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     240 |  # node_Constant_166
            %"val_168"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     241 |  # node_Reshape_167
            %"val_169"<?,?> ⬅️ ::Reshape(%"val_167", %"val_168") {allowzero=0}
     242 |  # node_Cast_168
            %"val_170"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     243 |  # node_Constant_169
            %"val_171"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     244 |  # node_Reshape_170
            %"val_172"<?,?> ⬅️ ::Reshape(%"val_170", %"val_171") {allowzero=0}
     245 |  # node_Cast_171
            %"val_173"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     246 |  # node_Constant_172
            %"val_174"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     247 |  # node_Reshape_173
            %"val_175"<?,?> ⬅️ ::Reshape(%"val_173", %"val_174") {allowzero=0}
     248 |  # node_Constant_174
            %"val_176"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     249 |  # node_slice_13
            %"slice_13"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_169", %"val_172", %"val_175", %"val_176")
     250 |  # node_unsqueeze_17
            %"unsqueeze_17"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_13", %"val_18")
     251 |  # node_Cast_175
            %"val_177"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     252 |  # node_Constant_176
            %"val_178"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     253 |  # node_Reshape_177
            %"val_179"<?,?> ⬅️ ::Reshape(%"val_177", %"val_178") {allowzero=0}
     254 |  # node_Cast_178
            %"val_180"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     255 |  # node_Constant_179
            %"val_181"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     256 |  # node_Reshape_180
            %"val_182"<?,?> ⬅️ ::Reshape(%"val_180", %"val_181") {allowzero=0}
     257 |  # node_Cast_181
            %"val_183"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     258 |  # node_Constant_182
            %"val_184"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     259 |  # node_Reshape_183
            %"val_185"<?,?> ⬅️ ::Reshape(%"val_183", %"val_184") {allowzero=0}
     260 |  # node_Constant_184
            %"val_186"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     261 |  # node_slice_14
            %"slice_14"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_17", %"val_179", %"val_182", %"val_185", %"val_186")
     262 |  # node__to_copy_5
            %"_to_copy_5"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_14") {to=1}
     263 |  # node_matmul_3
            %"matmul_3"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_4", %"_to_copy_5")
     264 |  # node_transpose_3
            %"transpose_3"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_3") {perm=(0, 2, 1)}
     265 |  # node_cat_3
            %"cat_3"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_3", %"transpose_3") {axis=-1}
     266 |  # node_cos_3
            %"cos_3"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_3")
     267 |  # node_mul_6
            %"mul_6"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_3", %"val_3")
     268 |  # node_sin_3
            %"sin_3"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_3")
     269 |  # node_mul_7
            %"mul_7"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_3", %"val_3")
     270 |  # node_unsqueeze_18
            %"unsqueeze_18"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     271 |  # node_Cast_185
            %"val_187"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     272 |  # node_Constant_186
            %"val_188"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     273 |  # node_Reshape_187
            %"val_189"<?,?> ⬅️ ::Reshape(%"val_187", %"val_188") {allowzero=0}
     274 |  # node_Cast_188
            %"val_190"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     275 |  # node_Constant_189
            %"val_191"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     276 |  # node_Reshape_190
            %"val_192"<?,?> ⬅️ ::Reshape(%"val_190", %"val_191") {allowzero=0}
     277 |  # node_Cast_191
            %"val_193"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     278 |  # node_Constant_192
            %"val_194"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     279 |  # node_Reshape_193
            %"val_195"<?,?> ⬅️ ::Reshape(%"val_193", %"val_194") {allowzero=0}
     280 |  # node_Constant_194
            %"val_196"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     281 |  # node_slice_15
            %"slice_15"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_18", %"val_189", %"val_192", %"val_195", %"val_196")
     282 |  # node_unsqueeze_19
            %"unsqueeze_19"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_15", %"val_19")
     283 |  # node_Constant_195
            %"val_197"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     284 |  # node_Constant_196
            %"val_198"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     285 |  # node_Constant_197
            %"val_199"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     286 |  # node_Constant_198
            %"val_200"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     287 |  # node_Concat_199
            %"val_201"<?,?> ⬅️ ::Concat(%"val_198", %"val_199", %"val_200") {axis=0}
     288 |  # node_expand_5
            %"expand_5"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_19", %"val_201")
     289 |  # node_Cast_200
            %"val_202"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     290 |  # node_Constant_201
            %"val_203"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     291 |  # node_Reshape_202
            %"val_204"<?,?> ⬅️ ::Reshape(%"val_202", %"val_203") {allowzero=0}
     292 |  # node_Cast_203
            %"val_205"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     293 |  # node_Constant_204
            %"val_206"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     294 |  # node_Reshape_205
            %"val_207"<?,?> ⬅️ ::Reshape(%"val_205", %"val_206") {allowzero=0}
     295 |  # node_Cast_206
            %"val_208"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     296 |  # node_Constant_207
            %"val_209"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     297 |  # node_Reshape_208
            %"val_210"<?,?> ⬅️ ::Reshape(%"val_208", %"val_209") {allowzero=0}
     298 |  # node_Constant_209
            %"val_211"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     299 |  # node_slice_16
            %"slice_16"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_204", %"val_207", %"val_210", %"val_211")
     300 |  # node_unsqueeze_20
            %"unsqueeze_20"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_16", %"val_18")
     301 |  # node_Cast_210
            %"val_212"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     302 |  # node_Constant_211
            %"val_213"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     303 |  # node_Reshape_212
            %"val_214"<?,?> ⬅️ ::Reshape(%"val_212", %"val_213") {allowzero=0}
     304 |  # node_Cast_213
            %"val_215"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     305 |  # node_Constant_214
            %"val_216"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     306 |  # node_Reshape_215
            %"val_217"<?,?> ⬅️ ::Reshape(%"val_215", %"val_216") {allowzero=0}
     307 |  # node_Cast_216
            %"val_218"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     308 |  # node_Constant_217
            %"val_219"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     309 |  # node_Reshape_218
            %"val_220"<?,?> ⬅️ ::Reshape(%"val_218", %"val_219") {allowzero=0}
     310 |  # node_Constant_219
            %"val_221"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     311 |  # node_slice_17
            %"slice_17"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_20", %"val_214", %"val_217", %"val_220", %"val_221")
     312 |  # node__to_copy_6
            %"_to_copy_6"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_17") {to=1}
     313 |  # node_matmul_4
            %"matmul_4"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_5", %"_to_copy_6")
     314 |  # node_transpose_4
            %"transpose_4"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_4") {perm=(0, 2, 1)}
     315 |  # node_cat_4
            %"cat_4"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_4", %"transpose_4") {axis=-1}
     316 |  # node_cos_4
            %"cos_4"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_4")
     317 |  # node_mul_8
            %"mul_8"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_4", %"val_3")
     318 |  # node_sin_4
            %"sin_4"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_4")
     319 |  # node_mul_9
            %"mul_9"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_4", %"val_3")
     320 |  # node_unsqueeze_21
            %"unsqueeze_21"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     321 |  # node_Cast_220
            %"val_222"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     322 |  # node_Constant_221
            %"val_223"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     323 |  # node_Reshape_222
            %"val_224"<?,?> ⬅️ ::Reshape(%"val_222", %"val_223") {allowzero=0}
     324 |  # node_Cast_223
            %"val_225"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     325 |  # node_Constant_224
            %"val_226"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     326 |  # node_Reshape_225
            %"val_227"<?,?> ⬅️ ::Reshape(%"val_225", %"val_226") {allowzero=0}
     327 |  # node_Cast_226
            %"val_228"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     328 |  # node_Constant_227
            %"val_229"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     329 |  # node_Reshape_228
            %"val_230"<?,?> ⬅️ ::Reshape(%"val_228", %"val_229") {allowzero=0}
     330 |  # node_Constant_229
            %"val_231"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     331 |  # node_slice_18
            %"slice_18"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_21", %"val_224", %"val_227", %"val_230", %"val_231")
     332 |  # node_unsqueeze_22
            %"unsqueeze_22"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_18", %"val_19")
     333 |  # node_Constant_230
            %"val_232"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     334 |  # node_Constant_231
            %"val_233"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     335 |  # node_Constant_232
            %"val_234"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     336 |  # node_Constant_233
            %"val_235"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     337 |  # node_Concat_234
            %"val_236"<?,?> ⬅️ ::Concat(%"val_233", %"val_234", %"val_235") {axis=0}
     338 |  # node_expand_6
            %"expand_6"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_22", %"val_236")
     339 |  # node_Cast_235
            %"val_237"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     340 |  # node_Constant_236
            %"val_238"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     341 |  # node_Reshape_237
            %"val_239"<?,?> ⬅️ ::Reshape(%"val_237", %"val_238") {allowzero=0}
     342 |  # node_Cast_238
            %"val_240"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     343 |  # node_Constant_239
            %"val_241"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     344 |  # node_Reshape_240
            %"val_242"<?,?> ⬅️ ::Reshape(%"val_240", %"val_241") {allowzero=0}
     345 |  # node_Cast_241
            %"val_243"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     346 |  # node_Constant_242
            %"val_244"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     347 |  # node_Reshape_243
            %"val_245"<?,?> ⬅️ ::Reshape(%"val_243", %"val_244") {allowzero=0}
     348 |  # node_Constant_244
            %"val_246"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     349 |  # node_slice_19
            %"slice_19"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_239", %"val_242", %"val_245", %"val_246")
     350 |  # node_unsqueeze_23
            %"unsqueeze_23"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_19", %"val_18")
     351 |  # node_Cast_245
            %"val_247"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     352 |  # node_Constant_246
            %"val_248"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     353 |  # node_Reshape_247
            %"val_249"<?,?> ⬅️ ::Reshape(%"val_247", %"val_248") {allowzero=0}
     354 |  # node_Cast_248
            %"val_250"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     355 |  # node_Constant_249
            %"val_251"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     356 |  # node_Reshape_250
            %"val_252"<?,?> ⬅️ ::Reshape(%"val_250", %"val_251") {allowzero=0}
     357 |  # node_Cast_251
            %"val_253"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     358 |  # node_Constant_252
            %"val_254"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     359 |  # node_Reshape_253
            %"val_255"<?,?> ⬅️ ::Reshape(%"val_253", %"val_254") {allowzero=0}
     360 |  # node_Constant_254
            %"val_256"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     361 |  # node_slice_20
            %"slice_20"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_23", %"val_249", %"val_252", %"val_255", %"val_256")
     362 |  # node__to_copy_7
            %"_to_copy_7"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_20") {to=1}
     363 |  # node_matmul_5
            %"matmul_5"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_6", %"_to_copy_7")
     364 |  # node_transpose_5
            %"transpose_5"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_5") {perm=(0, 2, 1)}
     365 |  # node_cat_5
            %"cat_5"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_5", %"transpose_5") {axis=-1}
     366 |  # node_cos_5
            %"cos_5"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_5")
     367 |  # node_mul_10
            %"mul_10"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_5", %"val_3")
     368 |  # node_sin_5
            %"sin_5"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_5")
     369 |  # node_mul_11
            %"mul_11"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_5", %"val_3")
     370 |  # node_unsqueeze_24
            %"unsqueeze_24"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     371 |  # node_Cast_255
            %"val_257"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     372 |  # node_Constant_256
            %"val_258"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     373 |  # node_Reshape_257
            %"val_259"<?,?> ⬅️ ::Reshape(%"val_257", %"val_258") {allowzero=0}
     374 |  # node_Cast_258
            %"val_260"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     375 |  # node_Constant_259
            %"val_261"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     376 |  # node_Reshape_260
            %"val_262"<?,?> ⬅️ ::Reshape(%"val_260", %"val_261") {allowzero=0}
     377 |  # node_Cast_261
            %"val_263"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     378 |  # node_Constant_262
            %"val_264"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     379 |  # node_Reshape_263
            %"val_265"<?,?> ⬅️ ::Reshape(%"val_263", %"val_264") {allowzero=0}
     380 |  # node_Constant_264
            %"val_266"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     381 |  # node_slice_21
            %"slice_21"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_24", %"val_259", %"val_262", %"val_265", %"val_266")
     382 |  # node_unsqueeze_25
            %"unsqueeze_25"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_21", %"val_19")
     383 |  # node_Constant_265
            %"val_267"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     384 |  # node_Constant_266
            %"val_268"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     385 |  # node_Constant_267
            %"val_269"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     386 |  # node_Constant_268
            %"val_270"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     387 |  # node_Concat_269
            %"val_271"<?,?> ⬅️ ::Concat(%"val_268", %"val_269", %"val_270") {axis=0}
     388 |  # node_expand_7
            %"expand_7"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_25", %"val_271")
     389 |  # node_Cast_270
            %"val_272"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     390 |  # node_Constant_271
            %"val_273"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     391 |  # node_Reshape_272
            %"val_274"<?,?> ⬅️ ::Reshape(%"val_272", %"val_273") {allowzero=0}
     392 |  # node_Cast_273
            %"val_275"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     393 |  # node_Constant_274
            %"val_276"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     394 |  # node_Reshape_275
            %"val_277"<?,?> ⬅️ ::Reshape(%"val_275", %"val_276") {allowzero=0}
     395 |  # node_Cast_276
            %"val_278"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     396 |  # node_Constant_277
            %"val_279"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     397 |  # node_Reshape_278
            %"val_280"<?,?> ⬅️ ::Reshape(%"val_278", %"val_279") {allowzero=0}
     398 |  # node_Constant_279
            %"val_281"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     399 |  # node_slice_22
            %"slice_22"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_274", %"val_277", %"val_280", %"val_281")
     400 |  # node_unsqueeze_26
            %"unsqueeze_26"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_22", %"val_18")
     401 |  # node_Cast_280
            %"val_282"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     402 |  # node_Constant_281
            %"val_283"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     403 |  # node_Reshape_282
            %"val_284"<?,?> ⬅️ ::Reshape(%"val_282", %"val_283") {allowzero=0}
     404 |  # node_Cast_283
            %"val_285"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     405 |  # node_Constant_284
            %"val_286"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     406 |  # node_Reshape_285
            %"val_287"<?,?> ⬅️ ::Reshape(%"val_285", %"val_286") {allowzero=0}
     407 |  # node_Cast_286
            %"val_288"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     408 |  # node_Constant_287
            %"val_289"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     409 |  # node_Reshape_288
            %"val_290"<?,?> ⬅️ ::Reshape(%"val_288", %"val_289") {allowzero=0}
     410 |  # node_Constant_289
            %"val_291"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     411 |  # node_slice_23
            %"slice_23"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_26", %"val_284", %"val_287", %"val_290", %"val_291")
     412 |  # node__to_copy_8
            %"_to_copy_8"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_23") {to=1}
     413 |  # node_matmul_6
            %"matmul_6"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_7", %"_to_copy_8")
     414 |  # node_transpose_6
            %"transpose_6"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_6") {perm=(0, 2, 1)}
     415 |  # node_cat_6
            %"cat_6"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_6", %"transpose_6") {axis=-1}
     416 |  # node_cos_6
            %"cos_6"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_6")
     417 |  # node_mul_12
            %"mul_12"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_6", %"val_3")
     418 |  # node_sin_6
            %"sin_6"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_6")
     419 |  # node_mul_13
            %"mul_13"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_6", %"val_3")
     420 |  # node_unsqueeze_27
            %"unsqueeze_27"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     421 |  # node_Cast_290
            %"val_292"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     422 |  # node_Constant_291
            %"val_293"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     423 |  # node_Reshape_292
            %"val_294"<?,?> ⬅️ ::Reshape(%"val_292", %"val_293") {allowzero=0}
     424 |  # node_Cast_293
            %"val_295"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     425 |  # node_Constant_294
            %"val_296"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     426 |  # node_Reshape_295
            %"val_297"<?,?> ⬅️ ::Reshape(%"val_295", %"val_296") {allowzero=0}
     427 |  # node_Cast_296
            %"val_298"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     428 |  # node_Constant_297
            %"val_299"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     429 |  # node_Reshape_298
            %"val_300"<?,?> ⬅️ ::Reshape(%"val_298", %"val_299") {allowzero=0}
     430 |  # node_Constant_299
            %"val_301"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     431 |  # node_slice_24
            %"slice_24"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_27", %"val_294", %"val_297", %"val_300", %"val_301")
     432 |  # node_unsqueeze_28
            %"unsqueeze_28"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_24", %"val_19")
     433 |  # node_Constant_300
            %"val_302"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     434 |  # node_Constant_301
            %"val_303"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     435 |  # node_Constant_302
            %"val_304"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     436 |  # node_Constant_303
            %"val_305"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     437 |  # node_Concat_304
            %"val_306"<?,?> ⬅️ ::Concat(%"val_303", %"val_304", %"val_305") {axis=0}
     438 |  # node_expand_8
            %"expand_8"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_28", %"val_306")
     439 |  # node_Cast_305
            %"val_307"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     440 |  # node_Constant_306
            %"val_308"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     441 |  # node_Reshape_307
            %"val_309"<?,?> ⬅️ ::Reshape(%"val_307", %"val_308") {allowzero=0}
     442 |  # node_Cast_308
            %"val_310"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     443 |  # node_Constant_309
            %"val_311"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     444 |  # node_Reshape_310
            %"val_312"<?,?> ⬅️ ::Reshape(%"val_310", %"val_311") {allowzero=0}
     445 |  # node_Cast_311
            %"val_313"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     446 |  # node_Constant_312
            %"val_314"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     447 |  # node_Reshape_313
            %"val_315"<?,?> ⬅️ ::Reshape(%"val_313", %"val_314") {allowzero=0}
     448 |  # node_Constant_314
            %"val_316"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     449 |  # node_slice_25
            %"slice_25"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_309", %"val_312", %"val_315", %"val_316")
     450 |  # node_unsqueeze_29
            %"unsqueeze_29"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_25", %"val_18")
     451 |  # node_Cast_315
            %"val_317"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     452 |  # node_Constant_316
            %"val_318"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     453 |  # node_Reshape_317
            %"val_319"<?,?> ⬅️ ::Reshape(%"val_317", %"val_318") {allowzero=0}
     454 |  # node_Cast_318
            %"val_320"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     455 |  # node_Constant_319
            %"val_321"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     456 |  # node_Reshape_320
            %"val_322"<?,?> ⬅️ ::Reshape(%"val_320", %"val_321") {allowzero=0}
     457 |  # node_Cast_321
            %"val_323"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     458 |  # node_Constant_322
            %"val_324"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     459 |  # node_Reshape_323
            %"val_325"<?,?> ⬅️ ::Reshape(%"val_323", %"val_324") {allowzero=0}
     460 |  # node_Constant_324
            %"val_326"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     461 |  # node_slice_26
            %"slice_26"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_29", %"val_319", %"val_322", %"val_325", %"val_326")
     462 |  # node__to_copy_9
            %"_to_copy_9"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_26") {to=1}
     463 |  # node_matmul_7
            %"matmul_7"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_8", %"_to_copy_9")
     464 |  # node_transpose_7
            %"transpose_7"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_7") {perm=(0, 2, 1)}
     465 |  # node_cat_7
            %"cat_7"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_7", %"transpose_7") {axis=-1}
     466 |  # node_cos_7
            %"cos_7"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_7")
     467 |  # node_mul_14
            %"mul_14"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_7", %"val_3")
     468 |  # node_sin_7
            %"sin_7"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_7")
     469 |  # node_mul_15
            %"mul_15"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_7", %"val_3")
     470 |  # node_unsqueeze_30
            %"unsqueeze_30"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     471 |  # node_Cast_325
            %"val_327"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     472 |  # node_Constant_326
            %"val_328"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     473 |  # node_Reshape_327
            %"val_329"<?,?> ⬅️ ::Reshape(%"val_327", %"val_328") {allowzero=0}
     474 |  # node_Cast_328
            %"val_330"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     475 |  # node_Constant_329
            %"val_331"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     476 |  # node_Reshape_330
            %"val_332"<?,?> ⬅️ ::Reshape(%"val_330", %"val_331") {allowzero=0}
     477 |  # node_Cast_331
            %"val_333"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     478 |  # node_Constant_332
            %"val_334"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     479 |  # node_Reshape_333
            %"val_335"<?,?> ⬅️ ::Reshape(%"val_333", %"val_334") {allowzero=0}
     480 |  # node_Constant_334
            %"val_336"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     481 |  # node_slice_27
            %"slice_27"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_30", %"val_329", %"val_332", %"val_335", %"val_336")
     482 |  # node_unsqueeze_31
            %"unsqueeze_31"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_27", %"val_19")
     483 |  # node_Constant_335
            %"val_337"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     484 |  # node_Constant_336
            %"val_338"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     485 |  # node_Constant_337
            %"val_339"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     486 |  # node_Constant_338
            %"val_340"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     487 |  # node_Concat_339
            %"val_341"<?,?> ⬅️ ::Concat(%"val_338", %"val_339", %"val_340") {axis=0}
     488 |  # node_expand_9
            %"expand_9"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_31", %"val_341")
     489 |  # node_Cast_340
            %"val_342"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     490 |  # node_Constant_341
            %"val_343"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     491 |  # node_Reshape_342
            %"val_344"<?,?> ⬅️ ::Reshape(%"val_342", %"val_343") {allowzero=0}
     492 |  # node_Cast_343
            %"val_345"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     493 |  # node_Constant_344
            %"val_346"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     494 |  # node_Reshape_345
            %"val_347"<?,?> ⬅️ ::Reshape(%"val_345", %"val_346") {allowzero=0}
     495 |  # node_Cast_346
            %"val_348"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     496 |  # node_Constant_347
            %"val_349"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     497 |  # node_Reshape_348
            %"val_350"<?,?> ⬅️ ::Reshape(%"val_348", %"val_349") {allowzero=0}
     498 |  # node_Constant_349
            %"val_351"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     499 |  # node_slice_28
            %"slice_28"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_344", %"val_347", %"val_350", %"val_351")
     500 |  # node_unsqueeze_32
            %"unsqueeze_32"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_28", %"val_18")
     501 |  # node_Cast_350
            %"val_352"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     502 |  # node_Constant_351
            %"val_353"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     503 |  # node_Reshape_352
            %"val_354"<?,?> ⬅️ ::Reshape(%"val_352", %"val_353") {allowzero=0}
     504 |  # node_Cast_353
            %"val_355"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     505 |  # node_Constant_354
            %"val_356"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     506 |  # node_Reshape_355
            %"val_357"<?,?> ⬅️ ::Reshape(%"val_355", %"val_356") {allowzero=0}
     507 |  # node_Cast_356
            %"val_358"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     508 |  # node_Constant_357
            %"val_359"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     509 |  # node_Reshape_358
            %"val_360"<?,?> ⬅️ ::Reshape(%"val_358", %"val_359") {allowzero=0}
     510 |  # node_Constant_359
            %"val_361"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     511 |  # node_slice_29
            %"slice_29"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_32", %"val_354", %"val_357", %"val_360", %"val_361")
     512 |  # node__to_copy_10
            %"_to_copy_10"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_29") {to=1}
     513 |  # node_matmul_8
            %"matmul_8"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_9", %"_to_copy_10")
     514 |  # node_transpose_8
            %"transpose_8"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_8") {perm=(0, 2, 1)}
     515 |  # node_cat_8
            %"cat_8"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_8", %"transpose_8") {axis=-1}
     516 |  # node_cos_8
            %"cos_8"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_8")
     517 |  # node_mul_16
            %"mul_16"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_8", %"val_3")
     518 |  # node_sin_8
            %"sin_8"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_8")
     519 |  # node_mul_17
            %"mul_17"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_8", %"val_3")
     520 |  # node_unsqueeze_33
            %"unsqueeze_33"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     521 |  # node_Cast_360
            %"val_362"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     522 |  # node_Constant_361
            %"val_363"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     523 |  # node_Reshape_362
            %"val_364"<?,?> ⬅️ ::Reshape(%"val_362", %"val_363") {allowzero=0}
     524 |  # node_Cast_363
            %"val_365"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     525 |  # node_Constant_364
            %"val_366"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     526 |  # node_Reshape_365
            %"val_367"<?,?> ⬅️ ::Reshape(%"val_365", %"val_366") {allowzero=0}
     527 |  # node_Cast_366
            %"val_368"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     528 |  # node_Constant_367
            %"val_369"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     529 |  # node_Reshape_368
            %"val_370"<?,?> ⬅️ ::Reshape(%"val_368", %"val_369") {allowzero=0}
     530 |  # node_Constant_369
            %"val_371"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     531 |  # node_slice_30
            %"slice_30"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_33", %"val_364", %"val_367", %"val_370", %"val_371")
     532 |  # node_unsqueeze_34
            %"unsqueeze_34"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_30", %"val_19")
     533 |  # node_Constant_370
            %"val_372"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     534 |  # node_Constant_371
            %"val_373"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     535 |  # node_Constant_372
            %"val_374"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     536 |  # node_Constant_373
            %"val_375"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     537 |  # node_Concat_374
            %"val_376"<?,?> ⬅️ ::Concat(%"val_373", %"val_374", %"val_375") {axis=0}
     538 |  # node_expand_10
            %"expand_10"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_34", %"val_376")
     539 |  # node_Cast_375
            %"val_377"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     540 |  # node_Constant_376
            %"val_378"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     541 |  # node_Reshape_377
            %"val_379"<?,?> ⬅️ ::Reshape(%"val_377", %"val_378") {allowzero=0}
     542 |  # node_Cast_378
            %"val_380"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     543 |  # node_Constant_379
            %"val_381"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     544 |  # node_Reshape_380
            %"val_382"<?,?> ⬅️ ::Reshape(%"val_380", %"val_381") {allowzero=0}
     545 |  # node_Cast_381
            %"val_383"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     546 |  # node_Constant_382
            %"val_384"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     547 |  # node_Reshape_383
            %"val_385"<?,?> ⬅️ ::Reshape(%"val_383", %"val_384") {allowzero=0}
     548 |  # node_Constant_384
            %"val_386"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     549 |  # node_slice_31
            %"slice_31"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_379", %"val_382", %"val_385", %"val_386")
     550 |  # node_unsqueeze_35
            %"unsqueeze_35"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_31", %"val_18")
     551 |  # node_Cast_385
            %"val_387"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     552 |  # node_Constant_386
            %"val_388"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     553 |  # node_Reshape_387
            %"val_389"<?,?> ⬅️ ::Reshape(%"val_387", %"val_388") {allowzero=0}
     554 |  # node_Cast_388
            %"val_390"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     555 |  # node_Constant_389
            %"val_391"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     556 |  # node_Reshape_390
            %"val_392"<?,?> ⬅️ ::Reshape(%"val_390", %"val_391") {allowzero=0}
     557 |  # node_Cast_391
            %"val_393"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     558 |  # node_Constant_392
            %"val_394"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     559 |  # node_Reshape_393
            %"val_395"<?,?> ⬅️ ::Reshape(%"val_393", %"val_394") {allowzero=0}
     560 |  # node_Constant_394
            %"val_396"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     561 |  # node_slice_32
            %"slice_32"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_35", %"val_389", %"val_392", %"val_395", %"val_396")
     562 |  # node__to_copy_11
            %"_to_copy_11"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_32") {to=1}
     563 |  # node_matmul_9
            %"matmul_9"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_10", %"_to_copy_11")
     564 |  # node_transpose_9
            %"transpose_9"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_9") {perm=(0, 2, 1)}
     565 |  # node_cat_9
            %"cat_9"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_9", %"transpose_9") {axis=-1}
     566 |  # node_cos_9
            %"cos_9"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_9")
     567 |  # node_mul_18
            %"mul_18"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_9", %"val_3")
     568 |  # node_sin_9
            %"sin_9"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_9")
     569 |  # node_mul_19
            %"mul_19"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_9", %"val_3")
     570 |  # node_unsqueeze_36
            %"unsqueeze_36"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     571 |  # node_Cast_395
            %"val_397"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     572 |  # node_Constant_396
            %"val_398"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     573 |  # node_Reshape_397
            %"val_399"<?,?> ⬅️ ::Reshape(%"val_397", %"val_398") {allowzero=0}
     574 |  # node_Cast_398
            %"val_400"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     575 |  # node_Constant_399
            %"val_401"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     576 |  # node_Reshape_400
            %"val_402"<?,?> ⬅️ ::Reshape(%"val_400", %"val_401") {allowzero=0}
     577 |  # node_Cast_401
            %"val_403"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     578 |  # node_Constant_402
            %"val_404"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     579 |  # node_Reshape_403
            %"val_405"<?,?> ⬅️ ::Reshape(%"val_403", %"val_404") {allowzero=0}
     580 |  # node_Constant_404
            %"val_406"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     581 |  # node_slice_33
            %"slice_33"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_36", %"val_399", %"val_402", %"val_405", %"val_406")
     582 |  # node_unsqueeze_37
            %"unsqueeze_37"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_33", %"val_19")
     583 |  # node_Constant_405
            %"val_407"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     584 |  # node_Constant_406
            %"val_408"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     585 |  # node_Constant_407
            %"val_409"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     586 |  # node_Constant_408
            %"val_410"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     587 |  # node_Concat_409
            %"val_411"<?,?> ⬅️ ::Concat(%"val_408", %"val_409", %"val_410") {axis=0}
     588 |  # node_expand_11
            %"expand_11"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_37", %"val_411")
     589 |  # node_Cast_410
            %"val_412"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     590 |  # node_Constant_411
            %"val_413"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     591 |  # node_Reshape_412
            %"val_414"<?,?> ⬅️ ::Reshape(%"val_412", %"val_413") {allowzero=0}
     592 |  # node_Cast_413
            %"val_415"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     593 |  # node_Constant_414
            %"val_416"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     594 |  # node_Reshape_415
            %"val_417"<?,?> ⬅️ ::Reshape(%"val_415", %"val_416") {allowzero=0}
     595 |  # node_Cast_416
            %"val_418"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     596 |  # node_Constant_417
            %"val_419"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     597 |  # node_Reshape_418
            %"val_420"<?,?> ⬅️ ::Reshape(%"val_418", %"val_419") {allowzero=0}
     598 |  # node_Constant_419
            %"val_421"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     599 |  # node_slice_34
            %"slice_34"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_414", %"val_417", %"val_420", %"val_421")
     600 |  # node_unsqueeze_38
            %"unsqueeze_38"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_34", %"val_18")
     601 |  # node_Cast_420
            %"val_422"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     602 |  # node_Constant_421
            %"val_423"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     603 |  # node_Reshape_422
            %"val_424"<?,?> ⬅️ ::Reshape(%"val_422", %"val_423") {allowzero=0}
     604 |  # node_Cast_423
            %"val_425"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     605 |  # node_Constant_424
            %"val_426"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     606 |  # node_Reshape_425
            %"val_427"<?,?> ⬅️ ::Reshape(%"val_425", %"val_426") {allowzero=0}
     607 |  # node_Cast_426
            %"val_428"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     608 |  # node_Constant_427
            %"val_429"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     609 |  # node_Reshape_428
            %"val_430"<?,?> ⬅️ ::Reshape(%"val_428", %"val_429") {allowzero=0}
     610 |  # node_Constant_429
            %"val_431"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     611 |  # node_slice_35
            %"slice_35"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_38", %"val_424", %"val_427", %"val_430", %"val_431")
     612 |  # node__to_copy_12
            %"_to_copy_12"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_35") {to=1}
     613 |  # node_matmul_10
            %"matmul_10"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_11", %"_to_copy_12")
     614 |  # node_transpose_10
            %"transpose_10"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_10") {perm=(0, 2, 1)}
     615 |  # node_cat_10
            %"cat_10"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_10", %"transpose_10") {axis=-1}
     616 |  # node_cos_10
            %"cos_10"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_10")
     617 |  # node_mul_20
            %"mul_20"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_10", %"val_3")
     618 |  # node_sin_10
            %"sin_10"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_10")
     619 |  # node_mul_21
            %"mul_21"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_10", %"val_3")
     620 |  # node_unsqueeze_39
            %"unsqueeze_39"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     621 |  # node_Cast_430
            %"val_432"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     622 |  # node_Constant_431
            %"val_433"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     623 |  # node_Reshape_432
            %"val_434"<?,?> ⬅️ ::Reshape(%"val_432", %"val_433") {allowzero=0}
     624 |  # node_Cast_433
            %"val_435"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     625 |  # node_Constant_434
            %"val_436"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     626 |  # node_Reshape_435
            %"val_437"<?,?> ⬅️ ::Reshape(%"val_435", %"val_436") {allowzero=0}
     627 |  # node_Cast_436
            %"val_438"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     628 |  # node_Constant_437
            %"val_439"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     629 |  # node_Reshape_438
            %"val_440"<?,?> ⬅️ ::Reshape(%"val_438", %"val_439") {allowzero=0}
     630 |  # node_Constant_439
            %"val_441"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     631 |  # node_slice_36
            %"slice_36"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_39", %"val_434", %"val_437", %"val_440", %"val_441")
     632 |  # node_unsqueeze_40
            %"unsqueeze_40"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_36", %"val_19")
     633 |  # node_Constant_440
            %"val_442"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     634 |  # node_Constant_441
            %"val_443"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     635 |  # node_Constant_442
            %"val_444"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     636 |  # node_Constant_443
            %"val_445"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     637 |  # node_Concat_444
            %"val_446"<?,?> ⬅️ ::Concat(%"val_443", %"val_444", %"val_445") {axis=0}
     638 |  # node_expand_12
            %"expand_12"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_40", %"val_446")
     639 |  # node_Cast_445
            %"val_447"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     640 |  # node_Constant_446
            %"val_448"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     641 |  # node_Reshape_447
            %"val_449"<?,?> ⬅️ ::Reshape(%"val_447", %"val_448") {allowzero=0}
     642 |  # node_Cast_448
            %"val_450"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     643 |  # node_Constant_449
            %"val_451"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     644 |  # node_Reshape_450
            %"val_452"<?,?> ⬅️ ::Reshape(%"val_450", %"val_451") {allowzero=0}
     645 |  # node_Cast_451
            %"val_453"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     646 |  # node_Constant_452
            %"val_454"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     647 |  # node_Reshape_453
            %"val_455"<?,?> ⬅️ ::Reshape(%"val_453", %"val_454") {allowzero=0}
     648 |  # node_Constant_454
            %"val_456"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     649 |  # node_slice_37
            %"slice_37"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_449", %"val_452", %"val_455", %"val_456")
     650 |  # node_unsqueeze_41
            %"unsqueeze_41"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_37", %"val_18")
     651 |  # node_Cast_455
            %"val_457"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     652 |  # node_Constant_456
            %"val_458"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     653 |  # node_Reshape_457
            %"val_459"<?,?> ⬅️ ::Reshape(%"val_457", %"val_458") {allowzero=0}
     654 |  # node_Cast_458
            %"val_460"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     655 |  # node_Constant_459
            %"val_461"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     656 |  # node_Reshape_460
            %"val_462"<?,?> ⬅️ ::Reshape(%"val_460", %"val_461") {allowzero=0}
     657 |  # node_Cast_461
            %"val_463"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     658 |  # node_Constant_462
            %"val_464"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     659 |  # node_Reshape_463
            %"val_465"<?,?> ⬅️ ::Reshape(%"val_463", %"val_464") {allowzero=0}
     660 |  # node_Constant_464
            %"val_466"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     661 |  # node_slice_38
            %"slice_38"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_41", %"val_459", %"val_462", %"val_465", %"val_466")
     662 |  # node__to_copy_13
            %"_to_copy_13"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_38") {to=1}
     663 |  # node_matmul_11
            %"matmul_11"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_12", %"_to_copy_13")
     664 |  # node_transpose_11
            %"transpose_11"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_11") {perm=(0, 2, 1)}
     665 |  # node_cat_11
            %"cat_11"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_11", %"transpose_11") {axis=-1}
     666 |  # node_cos_11
            %"cos_11"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_11")
     667 |  # node_mul_22
            %"mul_22"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_11", %"val_3")
     668 |  # node_sin_11
            %"sin_11"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_11")
     669 |  # node_mul_23
            %"mul_23"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_11", %"val_3")
     670 |  # node_unsqueeze_42
            %"unsqueeze_42"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     671 |  # node_Cast_465
            %"val_467"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     672 |  # node_Constant_466
            %"val_468"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     673 |  # node_Reshape_467
            %"val_469"<?,?> ⬅️ ::Reshape(%"val_467", %"val_468") {allowzero=0}
     674 |  # node_Cast_468
            %"val_470"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     675 |  # node_Constant_469
            %"val_471"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     676 |  # node_Reshape_470
            %"val_472"<?,?> ⬅️ ::Reshape(%"val_470", %"val_471") {allowzero=0}
     677 |  # node_Cast_471
            %"val_473"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     678 |  # node_Constant_472
            %"val_474"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     679 |  # node_Reshape_473
            %"val_475"<?,?> ⬅️ ::Reshape(%"val_473", %"val_474") {allowzero=0}
     680 |  # node_Constant_474
            %"val_476"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     681 |  # node_slice_39
            %"slice_39"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_42", %"val_469", %"val_472", %"val_475", %"val_476")
     682 |  # node_unsqueeze_43
            %"unsqueeze_43"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_39", %"val_19")
     683 |  # node_Constant_475
            %"val_477"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     684 |  # node_Constant_476
            %"val_478"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     685 |  # node_Constant_477
            %"val_479"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     686 |  # node_Constant_478
            %"val_480"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     687 |  # node_Concat_479
            %"val_481"<?,?> ⬅️ ::Concat(%"val_478", %"val_479", %"val_480") {axis=0}
     688 |  # node_expand_13
            %"expand_13"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_43", %"val_481")
     689 |  # node_Cast_480
            %"val_482"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     690 |  # node_Constant_481
            %"val_483"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     691 |  # node_Reshape_482
            %"val_484"<?,?> ⬅️ ::Reshape(%"val_482", %"val_483") {allowzero=0}
     692 |  # node_Cast_483
            %"val_485"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     693 |  # node_Constant_484
            %"val_486"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     694 |  # node_Reshape_485
            %"val_487"<?,?> ⬅️ ::Reshape(%"val_485", %"val_486") {allowzero=0}
     695 |  # node_Cast_486
            %"val_488"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     696 |  # node_Constant_487
            %"val_489"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     697 |  # node_Reshape_488
            %"val_490"<?,?> ⬅️ ::Reshape(%"val_488", %"val_489") {allowzero=0}
     698 |  # node_Constant_489
            %"val_491"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     699 |  # node_slice_40
            %"slice_40"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_484", %"val_487", %"val_490", %"val_491")
     700 |  # node_unsqueeze_44
            %"unsqueeze_44"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_40", %"val_18")
     701 |  # node_Cast_490
            %"val_492"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     702 |  # node_Constant_491
            %"val_493"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     703 |  # node_Reshape_492
            %"val_494"<?,?> ⬅️ ::Reshape(%"val_492", %"val_493") {allowzero=0}
     704 |  # node_Cast_493
            %"val_495"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     705 |  # node_Constant_494
            %"val_496"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     706 |  # node_Reshape_495
            %"val_497"<?,?> ⬅️ ::Reshape(%"val_495", %"val_496") {allowzero=0}
     707 |  # node_Cast_496
            %"val_498"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     708 |  # node_Constant_497
            %"val_499"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     709 |  # node_Reshape_498
            %"val_500"<?,?> ⬅️ ::Reshape(%"val_498", %"val_499") {allowzero=0}
     710 |  # node_Constant_499
            %"val_501"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     711 |  # node_slice_41
            %"slice_41"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_44", %"val_494", %"val_497", %"val_500", %"val_501")
     712 |  # node__to_copy_14
            %"_to_copy_14"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_41") {to=1}
     713 |  # node_matmul_12
            %"matmul_12"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_13", %"_to_copy_14")
     714 |  # node_transpose_12
            %"transpose_12"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_12") {perm=(0, 2, 1)}
     715 |  # node_cat_12
            %"cat_12"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_12", %"transpose_12") {axis=-1}
     716 |  # node_cos_12
            %"cos_12"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_12")
     717 |  # node_mul_24
            %"mul_24"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_12", %"val_3")
     718 |  # node_sin_12
            %"sin_12"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_12")
     719 |  # node_mul_25
            %"mul_25"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_12", %"val_3")
     720 |  # node_unsqueeze_45
            %"unsqueeze_45"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     721 |  # node_Cast_500
            %"val_502"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     722 |  # node_Constant_501
            %"val_503"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     723 |  # node_Reshape_502
            %"val_504"<?,?> ⬅️ ::Reshape(%"val_502", %"val_503") {allowzero=0}
     724 |  # node_Cast_503
            %"val_505"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     725 |  # node_Constant_504
            %"val_506"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     726 |  # node_Reshape_505
            %"val_507"<?,?> ⬅️ ::Reshape(%"val_505", %"val_506") {allowzero=0}
     727 |  # node_Cast_506
            %"val_508"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     728 |  # node_Constant_507
            %"val_509"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     729 |  # node_Reshape_508
            %"val_510"<?,?> ⬅️ ::Reshape(%"val_508", %"val_509") {allowzero=0}
     730 |  # node_Constant_509
            %"val_511"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     731 |  # node_slice_42
            %"slice_42"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_45", %"val_504", %"val_507", %"val_510", %"val_511")
     732 |  # node_unsqueeze_46
            %"unsqueeze_46"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_42", %"val_19")
     733 |  # node_Constant_510
            %"val_512"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     734 |  # node_Constant_511
            %"val_513"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     735 |  # node_Constant_512
            %"val_514"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     736 |  # node_Constant_513
            %"val_515"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     737 |  # node_Concat_514
            %"val_516"<?,?> ⬅️ ::Concat(%"val_513", %"val_514", %"val_515") {axis=0}
     738 |  # node_expand_14
            %"expand_14"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_46", %"val_516")
     739 |  # node_Cast_515
            %"val_517"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     740 |  # node_Constant_516
            %"val_518"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     741 |  # node_Reshape_517
            %"val_519"<?,?> ⬅️ ::Reshape(%"val_517", %"val_518") {allowzero=0}
     742 |  # node_Cast_518
            %"val_520"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     743 |  # node_Constant_519
            %"val_521"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     744 |  # node_Reshape_520
            %"val_522"<?,?> ⬅️ ::Reshape(%"val_520", %"val_521") {allowzero=0}
     745 |  # node_Cast_521
            %"val_523"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     746 |  # node_Constant_522
            %"val_524"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     747 |  # node_Reshape_523
            %"val_525"<?,?> ⬅️ ::Reshape(%"val_523", %"val_524") {allowzero=0}
     748 |  # node_Constant_524
            %"val_526"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     749 |  # node_slice_43
            %"slice_43"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_519", %"val_522", %"val_525", %"val_526")
     750 |  # node_unsqueeze_47
            %"unsqueeze_47"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_43", %"val_18")
     751 |  # node_Cast_525
            %"val_527"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     752 |  # node_Constant_526
            %"val_528"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     753 |  # node_Reshape_527
            %"val_529"<?,?> ⬅️ ::Reshape(%"val_527", %"val_528") {allowzero=0}
     754 |  # node_Cast_528
            %"val_530"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     755 |  # node_Constant_529
            %"val_531"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     756 |  # node_Reshape_530
            %"val_532"<?,?> ⬅️ ::Reshape(%"val_530", %"val_531") {allowzero=0}
     757 |  # node_Cast_531
            %"val_533"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     758 |  # node_Constant_532
            %"val_534"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     759 |  # node_Reshape_533
            %"val_535"<?,?> ⬅️ ::Reshape(%"val_533", %"val_534") {allowzero=0}
     760 |  # node_Constant_534
            %"val_536"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     761 |  # node_slice_44
            %"slice_44"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_47", %"val_529", %"val_532", %"val_535", %"val_536")
     762 |  # node__to_copy_15
            %"_to_copy_15"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_44") {to=1}
     763 |  # node_matmul_13
            %"matmul_13"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_14", %"_to_copy_15")
     764 |  # node_transpose_13
            %"transpose_13"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_13") {perm=(0, 2, 1)}
     765 |  # node_cat_13
            %"cat_13"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_13", %"transpose_13") {axis=-1}
     766 |  # node_cos_13
            %"cos_13"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_13")
     767 |  # node_mul_26
            %"mul_26"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_13", %"val_3")
     768 |  # node_sin_13
            %"sin_13"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_13")
     769 |  # node_mul_27
            %"mul_27"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_13", %"val_3")
     770 |  # node_unsqueeze_48
            %"unsqueeze_48"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     771 |  # node_Cast_535
            %"val_537"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     772 |  # node_Constant_536
            %"val_538"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     773 |  # node_Reshape_537
            %"val_539"<?,?> ⬅️ ::Reshape(%"val_537", %"val_538") {allowzero=0}
     774 |  # node_Cast_538
            %"val_540"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     775 |  # node_Constant_539
            %"val_541"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     776 |  # node_Reshape_540
            %"val_542"<?,?> ⬅️ ::Reshape(%"val_540", %"val_541") {allowzero=0}
     777 |  # node_Cast_541
            %"val_543"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     778 |  # node_Constant_542
            %"val_544"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     779 |  # node_Reshape_543
            %"val_545"<?,?> ⬅️ ::Reshape(%"val_543", %"val_544") {allowzero=0}
     780 |  # node_Constant_544
            %"val_546"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     781 |  # node_slice_45
            %"slice_45"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_48", %"val_539", %"val_542", %"val_545", %"val_546")
     782 |  # node_unsqueeze_49
            %"unsqueeze_49"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_45", %"val_19")
     783 |  # node_Constant_545
            %"val_547"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     784 |  # node_Constant_546
            %"val_548"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     785 |  # node_Constant_547
            %"val_549"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     786 |  # node_Constant_548
            %"val_550"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     787 |  # node_Concat_549
            %"val_551"<?,?> ⬅️ ::Concat(%"val_548", %"val_549", %"val_550") {axis=0}
     788 |  # node_expand_15
            %"expand_15"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_49", %"val_551")
     789 |  # node_Cast_550
            %"val_552"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     790 |  # node_Constant_551
            %"val_553"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     791 |  # node_Reshape_552
            %"val_554"<?,?> ⬅️ ::Reshape(%"val_552", %"val_553") {allowzero=0}
     792 |  # node_Cast_553
            %"val_555"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     793 |  # node_Constant_554
            %"val_556"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     794 |  # node_Reshape_555
            %"val_557"<?,?> ⬅️ ::Reshape(%"val_555", %"val_556") {allowzero=0}
     795 |  # node_Cast_556
            %"val_558"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     796 |  # node_Constant_557
            %"val_559"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     797 |  # node_Reshape_558
            %"val_560"<?,?> ⬅️ ::Reshape(%"val_558", %"val_559") {allowzero=0}
     798 |  # node_Constant_559
            %"val_561"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     799 |  # node_slice_46
            %"slice_46"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_554", %"val_557", %"val_560", %"val_561")
     800 |  # node_unsqueeze_50
            %"unsqueeze_50"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_46", %"val_18")
     801 |  # node_Cast_560
            %"val_562"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     802 |  # node_Constant_561
            %"val_563"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     803 |  # node_Reshape_562
            %"val_564"<?,?> ⬅️ ::Reshape(%"val_562", %"val_563") {allowzero=0}
     804 |  # node_Cast_563
            %"val_565"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     805 |  # node_Constant_564
            %"val_566"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     806 |  # node_Reshape_565
            %"val_567"<?,?> ⬅️ ::Reshape(%"val_565", %"val_566") {allowzero=0}
     807 |  # node_Cast_566
            %"val_568"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     808 |  # node_Constant_567
            %"val_569"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     809 |  # node_Reshape_568
            %"val_570"<?,?> ⬅️ ::Reshape(%"val_568", %"val_569") {allowzero=0}
     810 |  # node_Constant_569
            %"val_571"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     811 |  # node_slice_47
            %"slice_47"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_50", %"val_564", %"val_567", %"val_570", %"val_571")
     812 |  # node__to_copy_16
            %"_to_copy_16"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_47") {to=1}
     813 |  # node_matmul_14
            %"matmul_14"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_15", %"_to_copy_16")
     814 |  # node_transpose_14
            %"transpose_14"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_14") {perm=(0, 2, 1)}
     815 |  # node_cat_14
            %"cat_14"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_14", %"transpose_14") {axis=-1}
     816 |  # node_cos_14
            %"cos_14"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_14")
     817 |  # node_mul_28
            %"mul_28"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_14", %"val_3")
     818 |  # node_sin_14
            %"sin_14"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_14")
     819 |  # node_mul_29
            %"mul_29"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_14", %"val_3")
     820 |  # node_unsqueeze_51
            %"unsqueeze_51"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     821 |  # node_Cast_570
            %"val_572"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     822 |  # node_Constant_571
            %"val_573"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     823 |  # node_Reshape_572
            %"val_574"<?,?> ⬅️ ::Reshape(%"val_572", %"val_573") {allowzero=0}
     824 |  # node_Cast_573
            %"val_575"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     825 |  # node_Constant_574
            %"val_576"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     826 |  # node_Reshape_575
            %"val_577"<?,?> ⬅️ ::Reshape(%"val_575", %"val_576") {allowzero=0}
     827 |  # node_Cast_576
            %"val_578"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     828 |  # node_Constant_577
            %"val_579"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     829 |  # node_Reshape_578
            %"val_580"<?,?> ⬅️ ::Reshape(%"val_578", %"val_579") {allowzero=0}
     830 |  # node_Constant_579
            %"val_581"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     831 |  # node_slice_48
            %"slice_48"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_51", %"val_574", %"val_577", %"val_580", %"val_581")
     832 |  # node_unsqueeze_52
            %"unsqueeze_52"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_48", %"val_19")
     833 |  # node_Constant_580
            %"val_582"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     834 |  # node_Constant_581
            %"val_583"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     835 |  # node_Constant_582
            %"val_584"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     836 |  # node_Constant_583
            %"val_585"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     837 |  # node_Concat_584
            %"val_586"<?,?> ⬅️ ::Concat(%"val_583", %"val_584", %"val_585") {axis=0}
     838 |  # node_expand_16
            %"expand_16"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_52", %"val_586")
     839 |  # node_Cast_585
            %"val_587"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     840 |  # node_Constant_586
            %"val_588"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     841 |  # node_Reshape_587
            %"val_589"<?,?> ⬅️ ::Reshape(%"val_587", %"val_588") {allowzero=0}
     842 |  # node_Cast_588
            %"val_590"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     843 |  # node_Constant_589
            %"val_591"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     844 |  # node_Reshape_590
            %"val_592"<?,?> ⬅️ ::Reshape(%"val_590", %"val_591") {allowzero=0}
     845 |  # node_Cast_591
            %"val_593"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     846 |  # node_Constant_592
            %"val_594"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     847 |  # node_Reshape_593
            %"val_595"<?,?> ⬅️ ::Reshape(%"val_593", %"val_594") {allowzero=0}
     848 |  # node_Constant_594
            %"val_596"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     849 |  # node_slice_49
            %"slice_49"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_589", %"val_592", %"val_595", %"val_596")
     850 |  # node_unsqueeze_53
            %"unsqueeze_53"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_49", %"val_18")
     851 |  # node_Cast_595
            %"val_597"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     852 |  # node_Constant_596
            %"val_598"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     853 |  # node_Reshape_597
            %"val_599"<?,?> ⬅️ ::Reshape(%"val_597", %"val_598") {allowzero=0}
     854 |  # node_Cast_598
            %"val_600"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     855 |  # node_Constant_599
            %"val_601"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     856 |  # node_Reshape_600
            %"val_602"<?,?> ⬅️ ::Reshape(%"val_600", %"val_601") {allowzero=0}
     857 |  # node_Cast_601
            %"val_603"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     858 |  # node_Constant_602
            %"val_604"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     859 |  # node_Reshape_603
            %"val_605"<?,?> ⬅️ ::Reshape(%"val_603", %"val_604") {allowzero=0}
     860 |  # node_Constant_604
            %"val_606"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     861 |  # node_slice_50
            %"slice_50"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_53", %"val_599", %"val_602", %"val_605", %"val_606")
     862 |  # node__to_copy_17
            %"_to_copy_17"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_50") {to=1}
     863 |  # node_matmul_15
            %"matmul_15"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_16", %"_to_copy_17")
     864 |  # node_transpose_15
            %"transpose_15"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_15") {perm=(0, 2, 1)}
     865 |  # node_cat_15
            %"cat_15"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_15", %"transpose_15") {axis=-1}
     866 |  # node_cos_15
            %"cos_15"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_15")
     867 |  # node_mul_30
            %"mul_30"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_15", %"val_3")
     868 |  # node_sin_15
            %"sin_15"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_15")
     869 |  # node_mul_31
            %"mul_31"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_15", %"val_3")
     870 |  # node_unsqueeze_54
            %"unsqueeze_54"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     871 |  # node_Cast_605
            %"val_607"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     872 |  # node_Constant_606
            %"val_608"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     873 |  # node_Reshape_607
            %"val_609"<?,?> ⬅️ ::Reshape(%"val_607", %"val_608") {allowzero=0}
     874 |  # node_Cast_608
            %"val_610"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     875 |  # node_Constant_609
            %"val_611"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     876 |  # node_Reshape_610
            %"val_612"<?,?> ⬅️ ::Reshape(%"val_610", %"val_611") {allowzero=0}
     877 |  # node_Cast_611
            %"val_613"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     878 |  # node_Constant_612
            %"val_614"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     879 |  # node_Reshape_613
            %"val_615"<?,?> ⬅️ ::Reshape(%"val_613", %"val_614") {allowzero=0}
     880 |  # node_Constant_614
            %"val_616"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     881 |  # node_slice_51
            %"slice_51"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_54", %"val_609", %"val_612", %"val_615", %"val_616")
     882 |  # node_unsqueeze_55
            %"unsqueeze_55"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_51", %"val_19")
     883 |  # node_Constant_615
            %"val_617"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     884 |  # node_Constant_616
            %"val_618"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     885 |  # node_Constant_617
            %"val_619"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     886 |  # node_Constant_618
            %"val_620"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     887 |  # node_Concat_619
            %"val_621"<?,?> ⬅️ ::Concat(%"val_618", %"val_619", %"val_620") {axis=0}
     888 |  # node_expand_17
            %"expand_17"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_55", %"val_621")
     889 |  # node_Cast_620
            %"val_622"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     890 |  # node_Constant_621
            %"val_623"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     891 |  # node_Reshape_622
            %"val_624"<?,?> ⬅️ ::Reshape(%"val_622", %"val_623") {allowzero=0}
     892 |  # node_Cast_623
            %"val_625"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     893 |  # node_Constant_624
            %"val_626"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     894 |  # node_Reshape_625
            %"val_627"<?,?> ⬅️ ::Reshape(%"val_625", %"val_626") {allowzero=0}
     895 |  # node_Cast_626
            %"val_628"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     896 |  # node_Constant_627
            %"val_629"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     897 |  # node_Reshape_628
            %"val_630"<?,?> ⬅️ ::Reshape(%"val_628", %"val_629") {allowzero=0}
     898 |  # node_Constant_629
            %"val_631"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     899 |  # node_slice_52
            %"slice_52"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_624", %"val_627", %"val_630", %"val_631")
     900 |  # node_unsqueeze_56
            %"unsqueeze_56"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_52", %"val_18")
     901 |  # node_Cast_630
            %"val_632"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     902 |  # node_Constant_631
            %"val_633"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     903 |  # node_Reshape_632
            %"val_634"<?,?> ⬅️ ::Reshape(%"val_632", %"val_633") {allowzero=0}
     904 |  # node_Cast_633
            %"val_635"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     905 |  # node_Constant_634
            %"val_636"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     906 |  # node_Reshape_635
            %"val_637"<?,?> ⬅️ ::Reshape(%"val_635", %"val_636") {allowzero=0}
     907 |  # node_Cast_636
            %"val_638"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     908 |  # node_Constant_637
            %"val_639"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     909 |  # node_Reshape_638
            %"val_640"<?,?> ⬅️ ::Reshape(%"val_638", %"val_639") {allowzero=0}
     910 |  # node_Constant_639
            %"val_641"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     911 |  # node_slice_53
            %"slice_53"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_56", %"val_634", %"val_637", %"val_640", %"val_641")
     912 |  # node__to_copy_18
            %"_to_copy_18"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_53") {to=1}
     913 |  # node_matmul_16
            %"matmul_16"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_17", %"_to_copy_18")
     914 |  # node_transpose_16
            %"transpose_16"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_16") {perm=(0, 2, 1)}
     915 |  # node_cat_16
            %"cat_16"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_16", %"transpose_16") {axis=-1}
     916 |  # node_cos_16
            %"cos_16"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_16")
     917 |  # node_mul_32
            %"mul_32"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_16", %"val_3")
     918 |  # node_sin_16
            %"sin_16"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_16")
     919 |  # node_mul_33
            %"mul_33"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_16", %"val_3")
     920 |  # node_unsqueeze_57
            %"unsqueeze_57"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
     921 |  # node_Cast_640
            %"val_642"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     922 |  # node_Constant_641
            %"val_643"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     923 |  # node_Reshape_642
            %"val_644"<?,?> ⬅️ ::Reshape(%"val_642", %"val_643") {allowzero=0}
     924 |  # node_Cast_643
            %"val_645"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     925 |  # node_Constant_644
            %"val_646"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     926 |  # node_Reshape_645
            %"val_647"<?,?> ⬅️ ::Reshape(%"val_645", %"val_646") {allowzero=0}
     927 |  # node_Cast_646
            %"val_648"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     928 |  # node_Constant_647
            %"val_649"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     929 |  # node_Reshape_648
            %"val_650"<?,?> ⬅️ ::Reshape(%"val_648", %"val_649") {allowzero=0}
     930 |  # node_Constant_649
            %"val_651"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     931 |  # node_slice_54
            %"slice_54"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_57", %"val_644", %"val_647", %"val_650", %"val_651")
     932 |  # node_unsqueeze_58
            %"unsqueeze_58"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_54", %"val_19")
     933 |  # node_Constant_650
            %"val_652"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     934 |  # node_Constant_651
            %"val_653"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     935 |  # node_Constant_652
            %"val_654"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     936 |  # node_Constant_653
            %"val_655"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     937 |  # node_Concat_654
            %"val_656"<?,?> ⬅️ ::Concat(%"val_653", %"val_654", %"val_655") {axis=0}
     938 |  # node_expand_18
            %"expand_18"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_58", %"val_656")
     939 |  # node_Cast_655
            %"val_657"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     940 |  # node_Constant_656
            %"val_658"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     941 |  # node_Reshape_657
            %"val_659"<?,?> ⬅️ ::Reshape(%"val_657", %"val_658") {allowzero=0}
     942 |  # node_Cast_658
            %"val_660"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     943 |  # node_Constant_659
            %"val_661"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     944 |  # node_Reshape_660
            %"val_662"<?,?> ⬅️ ::Reshape(%"val_660", %"val_661") {allowzero=0}
     945 |  # node_Cast_661
            %"val_663"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     946 |  # node_Constant_662
            %"val_664"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     947 |  # node_Reshape_663
            %"val_665"<?,?> ⬅️ ::Reshape(%"val_663", %"val_664") {allowzero=0}
     948 |  # node_Constant_664
            %"val_666"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     949 |  # node_slice_55
            %"slice_55"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_659", %"val_662", %"val_665", %"val_666")
     950 |  # node_unsqueeze_59
            %"unsqueeze_59"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_55", %"val_18")
     951 |  # node_Cast_665
            %"val_667"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     952 |  # node_Constant_666
            %"val_668"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     953 |  # node_Reshape_667
            %"val_669"<?,?> ⬅️ ::Reshape(%"val_667", %"val_668") {allowzero=0}
     954 |  # node_Cast_668
            %"val_670"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     955 |  # node_Constant_669
            %"val_671"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     956 |  # node_Reshape_670
            %"val_672"<?,?> ⬅️ ::Reshape(%"val_670", %"val_671") {allowzero=0}
     957 |  # node_Cast_671
            %"val_673"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
     958 |  # node_Constant_672
            %"val_674"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     959 |  # node_Reshape_673
            %"val_675"<?,?> ⬅️ ::Reshape(%"val_673", %"val_674") {allowzero=0}
     960 |  # node_Constant_674
            %"val_676"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     961 |  # node_slice_56
            %"slice_56"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_59", %"val_669", %"val_672", %"val_675", %"val_676")
     962 |  # node__to_copy_19
            %"_to_copy_19"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_56") {to=1}
     963 |  # node_matmul_17
            %"matmul_17"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_18", %"_to_copy_19")
     964 |  # node_transpose_17
            %"transpose_17"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_17") {perm=(0, 2, 1)}
     965 |  # node_cat_17
            %"cat_17"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_17", %"transpose_17") {axis=-1}
     966 |  # node_cos_17
            %"cos_17"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_17")
     967 |  # node_mul_34
            %"mul_34"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_17", %"val_3")
     968 |  # node_sin_17
            %"sin_17"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_17")
     969 |  # node_mul_35
            %"mul_35"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_17", %"val_3")
     970 |  # node_unsqueeze_60
            %"unsqueeze_60"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
     971 |  # node_Cast_675
            %"val_677"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     972 |  # node_Constant_676
            %"val_678"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     973 |  # node_Reshape_677
            %"val_679"<?,?> ⬅️ ::Reshape(%"val_677", %"val_678") {allowzero=0}
     974 |  # node_Cast_678
            %"val_680"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     975 |  # node_Constant_679
            %"val_681"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     976 |  # node_Reshape_680
            %"val_682"<?,?> ⬅️ ::Reshape(%"val_680", %"val_681") {allowzero=0}
     977 |  # node_Cast_681
            %"val_683"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
     978 |  # node_Constant_682
            %"val_684"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     979 |  # node_Reshape_683
            %"val_685"<?,?> ⬅️ ::Reshape(%"val_683", %"val_684") {allowzero=0}
     980 |  # node_Constant_684
            %"val_686"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     981 |  # node_slice_57
            %"slice_57"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_60", %"val_679", %"val_682", %"val_685", %"val_686")
     982 |  # node_unsqueeze_61
            %"unsqueeze_61"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_57", %"val_19")
     983 |  # node_Constant_685
            %"val_687"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     984 |  # node_Constant_686
            %"val_688"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     985 |  # node_Constant_687
            %"val_689"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     986 |  # node_Constant_688
            %"val_690"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
     987 |  # node_Concat_689
            %"val_691"<?,?> ⬅️ ::Concat(%"val_688", %"val_689", %"val_690") {axis=0}
     988 |  # node_expand_19
            %"expand_19"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_61", %"val_691")
     989 |  # node_Cast_690
            %"val_692"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     990 |  # node_Constant_691
            %"val_693"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     991 |  # node_Reshape_692
            %"val_694"<?,?> ⬅️ ::Reshape(%"val_692", %"val_693") {allowzero=0}
     992 |  # node_Cast_693
            %"val_695"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
     993 |  # node_Constant_694
            %"val_696"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     994 |  # node_Reshape_695
            %"val_697"<?,?> ⬅️ ::Reshape(%"val_695", %"val_696") {allowzero=0}
     995 |  # node_Cast_696
            %"val_698"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
     996 |  # node_Constant_697
            %"val_699"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
     997 |  # node_Reshape_698
            %"val_700"<?,?> ⬅️ ::Reshape(%"val_698", %"val_699") {allowzero=0}
     998 |  # node_Constant_699
            %"val_701"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
     999 |  # node_slice_58
            %"slice_58"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_694", %"val_697", %"val_700", %"val_701")
    1000 |  # node_unsqueeze_62
            %"unsqueeze_62"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_58", %"val_18")
    1001 |  # node_Cast_700
            %"val_702"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1002 |  # node_Constant_701
            %"val_703"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1003 |  # node_Reshape_702
            %"val_704"<?,?> ⬅️ ::Reshape(%"val_702", %"val_703") {allowzero=0}
    1004 |  # node_Cast_703
            %"val_705"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1005 |  # node_Constant_704
            %"val_706"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1006 |  # node_Reshape_705
            %"val_707"<?,?> ⬅️ ::Reshape(%"val_705", %"val_706") {allowzero=0}
    1007 |  # node_Cast_706
            %"val_708"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
    1008 |  # node_Constant_707
            %"val_709"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1009 |  # node_Reshape_708
            %"val_710"<?,?> ⬅️ ::Reshape(%"val_708", %"val_709") {allowzero=0}
    1010 |  # node_Constant_709
            %"val_711"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1011 |  # node_slice_59
            %"slice_59"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_62", %"val_704", %"val_707", %"val_710", %"val_711")
    1012 |  # node__to_copy_20
            %"_to_copy_20"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_59") {to=1}
    1013 |  # node_matmul_18
            %"matmul_18"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_19", %"_to_copy_20")
    1014 |  # node_transpose_18
            %"transpose_18"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_18") {perm=(0, 2, 1)}
    1015 |  # node_cat_18
            %"cat_18"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_18", %"transpose_18") {axis=-1}
    1016 |  # node_cos_18
            %"cos_18"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_18")
    1017 |  # node_mul_36
            %"mul_36"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_18", %"val_3")
    1018 |  # node_sin_18
            %"sin_18"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_18")
    1019 |  # node_mul_37
            %"mul_37"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_18", %"val_3")
    1020 |  # node_unsqueeze_63
            %"unsqueeze_63"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
    1021 |  # node_Cast_710
            %"val_712"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1022 |  # node_Constant_711
            %"val_713"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1023 |  # node_Reshape_712
            %"val_714"<?,?> ⬅️ ::Reshape(%"val_712", %"val_713") {allowzero=0}
    1024 |  # node_Cast_713
            %"val_715"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1025 |  # node_Constant_714
            %"val_716"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1026 |  # node_Reshape_715
            %"val_717"<?,?> ⬅️ ::Reshape(%"val_715", %"val_716") {allowzero=0}
    1027 |  # node_Cast_716
            %"val_718"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
    1028 |  # node_Constant_717
            %"val_719"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1029 |  # node_Reshape_718
            %"val_720"<?,?> ⬅️ ::Reshape(%"val_718", %"val_719") {allowzero=0}
    1030 |  # node_Constant_719
            %"val_721"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1031 |  # node_slice_60
            %"slice_60"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_63", %"val_714", %"val_717", %"val_720", %"val_721")
    1032 |  # node_unsqueeze_64
            %"unsqueeze_64"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_60", %"val_19")
    1033 |  # node_Constant_720
            %"val_722"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1034 |  # node_Constant_721
            %"val_723"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1035 |  # node_Constant_722
            %"val_724"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1036 |  # node_Constant_723
            %"val_725"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1037 |  # node_Concat_724
            %"val_726"<?,?> ⬅️ ::Concat(%"val_723", %"val_724", %"val_725") {axis=0}
    1038 |  # node_expand_20
            %"expand_20"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_64", %"val_726")
    1039 |  # node_Cast_725
            %"val_727"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1040 |  # node_Constant_726
            %"val_728"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1041 |  # node_Reshape_727
            %"val_729"<?,?> ⬅️ ::Reshape(%"val_727", %"val_728") {allowzero=0}
    1042 |  # node_Cast_728
            %"val_730"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1043 |  # node_Constant_729
            %"val_731"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1044 |  # node_Reshape_730
            %"val_732"<?,?> ⬅️ ::Reshape(%"val_730", %"val_731") {allowzero=0}
    1045 |  # node_Cast_731
            %"val_733"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1046 |  # node_Constant_732
            %"val_734"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1047 |  # node_Reshape_733
            %"val_735"<?,?> ⬅️ ::Reshape(%"val_733", %"val_734") {allowzero=0}
    1048 |  # node_Constant_734
            %"val_736"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1049 |  # node_slice_61
            %"slice_61"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_729", %"val_732", %"val_735", %"val_736")
    1050 |  # node_unsqueeze_65
            %"unsqueeze_65"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_61", %"val_18")
    1051 |  # node_Cast_735
            %"val_737"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1052 |  # node_Constant_736
            %"val_738"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1053 |  # node_Reshape_737
            %"val_739"<?,?> ⬅️ ::Reshape(%"val_737", %"val_738") {allowzero=0}
    1054 |  # node_Cast_738
            %"val_740"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1055 |  # node_Constant_739
            %"val_741"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1056 |  # node_Reshape_740
            %"val_742"<?,?> ⬅️ ::Reshape(%"val_740", %"val_741") {allowzero=0}
    1057 |  # node_Cast_741
            %"val_743"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
    1058 |  # node_Constant_742
            %"val_744"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1059 |  # node_Reshape_743
            %"val_745"<?,?> ⬅️ ::Reshape(%"val_743", %"val_744") {allowzero=0}
    1060 |  # node_Constant_744
            %"val_746"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1061 |  # node_slice_62
            %"slice_62"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_65", %"val_739", %"val_742", %"val_745", %"val_746")
    1062 |  # node__to_copy_21
            %"_to_copy_21"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_62") {to=1}
    1063 |  # node_matmul_19
            %"matmul_19"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_20", %"_to_copy_21")
    1064 |  # node_transpose_19
            %"transpose_19"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_19") {perm=(0, 2, 1)}
    1065 |  # node_cat_19
            %"cat_19"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_19", %"transpose_19") {axis=-1}
    1066 |  # node_cos_19
            %"cos_19"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_19")
    1067 |  # node_mul_38
            %"mul_38"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_19", %"val_3")
    1068 |  # node_sin_19
            %"sin_19"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_19")
    1069 |  # node_mul_39
            %"mul_39"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_19", %"val_3")
    1070 |  # node_unsqueeze_66
            %"unsqueeze_66"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.sliding_attention_inv_freq"{...}, %"val_5")
    1071 |  # node_Cast_745
            %"val_747"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1072 |  # node_Constant_746
            %"val_748"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1073 |  # node_Reshape_747
            %"val_749"<?,?> ⬅️ ::Reshape(%"val_747", %"val_748") {allowzero=0}
    1074 |  # node_Cast_748
            %"val_750"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1075 |  # node_Constant_749
            %"val_751"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1076 |  # node_Reshape_750
            %"val_752"<?,?> ⬅️ ::Reshape(%"val_750", %"val_751") {allowzero=0}
    1077 |  # node_Cast_751
            %"val_753"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
    1078 |  # node_Constant_752
            %"val_754"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1079 |  # node_Reshape_753
            %"val_755"<?,?> ⬅️ ::Reshape(%"val_753", %"val_754") {allowzero=0}
    1080 |  # node_Constant_754
            %"val_756"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1081 |  # node_slice_63
            %"slice_63"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_66", %"val_749", %"val_752", %"val_755", %"val_756")
    1082 |  # node_unsqueeze_67
            %"unsqueeze_67"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_63", %"val_19")
    1083 |  # node_Constant_755
            %"val_757"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1084 |  # node_Constant_756
            %"val_758"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1085 |  # node_Constant_757
            %"val_759"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1086 |  # node_Constant_758
            %"val_760"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1087 |  # node_Concat_759
            %"val_761"<?,?> ⬅️ ::Concat(%"val_758", %"val_759", %"val_760") {axis=0}
    1088 |  # node_expand_21
            %"expand_21"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_67", %"val_761")
    1089 |  # node_Cast_760
            %"val_762"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1090 |  # node_Constant_761
            %"val_763"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1091 |  # node_Reshape_762
            %"val_764"<?,?> ⬅️ ::Reshape(%"val_762", %"val_763") {allowzero=0}
    1092 |  # node_Cast_763
            %"val_765"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1093 |  # node_Constant_764
            %"val_766"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1094 |  # node_Reshape_765
            %"val_767"<?,?> ⬅️ ::Reshape(%"val_765", %"val_766") {allowzero=0}
    1095 |  # node_Cast_766
            %"val_768"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1096 |  # node_Constant_767
            %"val_769"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1097 |  # node_Reshape_768
            %"val_770"<?,?> ⬅️ ::Reshape(%"val_768", %"val_769") {allowzero=0}
    1098 |  # node_Constant_769
            %"val_771"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1099 |  # node_slice_64
            %"slice_64"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_764", %"val_767", %"val_770", %"val_771")
    1100 |  # node_unsqueeze_68
            %"unsqueeze_68"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_64", %"val_18")
    1101 |  # node_Cast_770
            %"val_772"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1102 |  # node_Constant_771
            %"val_773"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1103 |  # node_Reshape_772
            %"val_774"<?,?> ⬅️ ::Reshape(%"val_772", %"val_773") {allowzero=0}
    1104 |  # node_Cast_773
            %"val_775"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1105 |  # node_Constant_774
            %"val_776"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1106 |  # node_Reshape_775
            %"val_777"<?,?> ⬅️ ::Reshape(%"val_775", %"val_776") {allowzero=0}
    1107 |  # node_Cast_776
            %"val_778"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
    1108 |  # node_Constant_777
            %"val_779"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1109 |  # node_Reshape_778
            %"val_780"<?,?> ⬅️ ::Reshape(%"val_778", %"val_779") {allowzero=0}
    1110 |  # node_Constant_779
            %"val_781"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1111 |  # node_slice_65
            %"slice_65"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_68", %"val_774", %"val_777", %"val_780", %"val_781")
    1112 |  # node__to_copy_22
            %"_to_copy_22"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_65") {to=1}
    1113 |  # node_matmul_20
            %"matmul_20"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_21", %"_to_copy_22")
    1114 |  # node_transpose_20
            %"transpose_20"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_20") {perm=(0, 2, 1)}
    1115 |  # node_cat_20
            %"cat_20"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_20", %"transpose_20") {axis=-1}
    1116 |  # node_cos_20
            %"cos_20"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_20")
    1117 |  # node_mul_40
            %"mul_40"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_20", %"val_3")
    1118 |  # node_sin_20
            %"sin_20"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_20")
    1119 |  # node_mul_41
            %"mul_41"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_20", %"val_3")
    1120 |  # node_unsqueeze_69
            %"unsqueeze_69"<FLOAT,[1,32]> ⬅️ ::Unsqueeze(%"encoder.rotary_emb.full_attention_inv_freq"{...}, %"val_5")
    1121 |  # node_Cast_780
            %"val_782"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1122 |  # node_Constant_781
            %"val_783"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1123 |  # node_Reshape_782
            %"val_784"<?,?> ⬅️ ::Reshape(%"val_782", %"val_783") {allowzero=0}
    1124 |  # node_Cast_783
            %"val_785"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1125 |  # node_Constant_784
            %"val_786"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1126 |  # node_Reshape_785
            %"val_787"<?,?> ⬅️ ::Reshape(%"val_785", %"val_786") {allowzero=0}
    1127 |  # node_Cast_786
            %"val_788"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
    1128 |  # node_Constant_787
            %"val_789"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1129 |  # node_Reshape_788
            %"val_790"<?,?> ⬅️ ::Reshape(%"val_788", %"val_789") {allowzero=0}
    1130 |  # node_Constant_789
            %"val_791"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1131 |  # node_slice_66
            %"slice_66"<FLOAT,[1,32]> ⬅️ ::Slice(%"unsqueeze_69", %"val_784", %"val_787", %"val_790", %"val_791")
    1132 |  # node_unsqueeze_70
            %"unsqueeze_70"<FLOAT,[1,32,1]> ⬅️ ::Unsqueeze(%"slice_66", %"val_19")
    1133 |  # node_Constant_790
            %"val_792"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1134 |  # node_Constant_791
            %"val_793"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1135 |  # node_Constant_792
            %"val_794"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1136 |  # node_Constant_793
            %"val_795"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1137 |  # node_Concat_794
            %"val_796"<?,?> ⬅️ ::Concat(%"val_793", %"val_794", %"val_795") {axis=0}
    1138 |  # node_expand_22
            %"expand_22"<FLOAT,[1,32,1]> ⬅️ ::Expand(%"unsqueeze_70", %"val_796")
    1139 |  # node_Cast_795
            %"val_797"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1140 |  # node_Constant_796
            %"val_798"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1141 |  # node_Reshape_797
            %"val_799"<?,?> ⬅️ ::Reshape(%"val_797", %"val_798") {allowzero=0}
    1142 |  # node_Cast_798
            %"val_800"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1143 |  # node_Constant_799
            %"val_801"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1144 |  # node_Reshape_800
            %"val_802"<?,?> ⬅️ ::Reshape(%"val_800", %"val_801") {allowzero=0}
    1145 |  # node_Cast_801
            %"val_803"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1146 |  # node_Constant_802
            %"val_804"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1147 |  # node_Reshape_803
            %"val_805"<?,?> ⬅️ ::Reshape(%"val_803", %"val_804") {allowzero=0}
    1148 |  # node_Constant_804
            %"val_806"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1149 |  # node_slice_67
            %"slice_67"<INT64,[1,97]> ⬅️ ::Slice(%"unsqueeze", %"val_799", %"val_802", %"val_805", %"val_806")
    1150 |  # node_unsqueeze_71
            %"unsqueeze_71"<INT64,[1,1,97]> ⬅️ ::Unsqueeze(%"slice_67", %"val_18")
    1151 |  # node_Cast_805
            %"val_807"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1152 |  # node_Constant_806
            %"val_808"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1153 |  # node_Reshape_807
            %"val_809"<?,?> ⬅️ ::Reshape(%"val_807", %"val_808") {allowzero=0}
    1154 |  # node_Cast_808
            %"val_810"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1155 |  # node_Constant_809
            %"val_811"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1156 |  # node_Reshape_810
            %"val_812"<?,?> ⬅️ ::Reshape(%"val_810", %"val_811") {allowzero=0}
    1157 |  # node_Cast_811
            %"val_813"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
    1158 |  # node_Constant_812
            %"val_814"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1159 |  # node_Reshape_813
            %"val_815"<?,?> ⬅️ ::Reshape(%"val_813", %"val_814") {allowzero=0}
    1160 |  # node_Constant_814
            %"val_816"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1161 |  # node_slice_68
            %"slice_68"<INT64,[1,1,97]> ⬅️ ::Slice(%"unsqueeze_71", %"val_809", %"val_812", %"val_815", %"val_816")
    1162 |  # node__to_copy_23
            %"_to_copy_23"<FLOAT,[1,1,97]> ⬅️ ::Cast(%"slice_68") {to=1}
    1163 |  # node_matmul_21
            %"matmul_21"<FLOAT,[1,32,97]> ⬅️ ::MatMul(%"expand_22", %"_to_copy_23")
    1164 |  # node_transpose_21
            %"transpose_21"<FLOAT,[1,97,32]> ⬅️ ::Transpose(%"matmul_21") {perm=(0, 2, 1)}
    1165 |  # node_cat_21
            %"cat_21"<FLOAT,[1,97,64]> ⬅️ ::Concat(%"transpose_21", %"transpose_21") {axis=-1}
    1166 |  # node_cos_21
            %"cos_21"<FLOAT,[1,97,64]> ⬅️ ::Cos(%"cat_21")
    1167 |  # node_mul_42
            %"mul_42"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"cos_21", %"val_3")
    1168 |  # node_sin_21
            %"sin_21"<FLOAT,[1,97,64]> ⬅️ ::Sin(%"cat_21")
    1169 |  # node_mul_43
            %"mul_43"<FLOAT,[1,97,64]> ⬅️ ::Mul(%"sin_21", %"val_3")
    1170 |  # node_Transpose_815
            %"val_817"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1171 |  # node_linear
            %"linear"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"clone_1", %"val_817")
    1172 |  # node_Constant_816
            %"val_818"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1173 |  # node_Constant_817
            %"val_819"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1174 |  # node_Constant_818
            %"val_820"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1175 |  # node_Constant_819
            %"val_821"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    1176 |  # node_Constant_820
            %"val_822"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    1177 |  # node_Constant_821
            %"val_823"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    1178 |  # node_Concat_822
            %"val_824"<?,?> ⬅️ ::Concat(%"val_819", %"val_820", %"val_821", %"val_822", %"val_823") {axis=0}
    1179 |  # node_view
            %"view"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear", %"val_824") {allowzero=1}
    1180 |  # node_transpose_22
            %"transpose_22"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view") {perm=(0, 3, 2, 1, 4)}
    1181 |  # node_Constant_823
            %"val_825"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    1182 |  # node_Constant_824
            %"val_826"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1183 |  # node_Constant_825
            %"val_827"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1184 |  # node_Slice_826
            %"val_828"<?,?> ⬅️ ::Slice(%"transpose_22", %"val_825", %"val_826", %"val_827")
    1185 |  # node_unbind__0
            %"getitem"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_828", %"val_19")
    1186 |  # node_Constant_827
            %"val_829"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1187 |  # node_Constant_828
            %"val_830"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1188 |  # node_Constant_829
            %"val_831"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1189 |  # node_Slice_830
            %"val_832"<?,?> ⬅️ ::Slice(%"transpose_22", %"val_829", %"val_830", %"val_831")
    1190 |  # node_unbind__1
            %"getitem_1"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_832", %"val_19")
    1191 |  # node_Constant_831
            %"val_833"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1192 |  # node_Constant_832
            %"val_834"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    1193 |  # node_Constant_833
            %"val_835"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1194 |  # node_Slice_834
            %"val_836"<?,?> ⬅️ ::Slice(%"transpose_22", %"val_833", %"val_834", %"val_835")
    1195 |  # node_unbind__2
            %"getitem_2"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_836", %"val_19")
    1196 |  # node_unsqueeze_72
            %"unsqueeze_72"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    1197 |  # node_unsqueeze_73
            %"unsqueeze_73"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    1198 |  # node_mul_44
            %"mul_44"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem", %"unsqueeze_72")
    1199 |  # node_Cast_835
            %"val_837"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1200 |  # node_Constant_836
            %"val_838"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1201 |  # node_Reshape_837
            %"val_839"<?,?> ⬅️ ::Reshape(%"val_837", %"val_838") {allowzero=0}
    1202 |  # node_Constant_838
            %"val_840"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(32), name=None)}
    1203 |  # node_Cast_839
            %"val_841"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1204 |  # node_Constant_840
            %"val_842"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1205 |  # node_Reshape_841
            %"val_843"<?,?> ⬅️ ::Reshape(%"val_841", %"val_842") {allowzero=0}
    1206 |  # node_Cast_842
            %"val_844"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1207 |  # node_Constant_843
            %"val_845"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1208 |  # node_Reshape_844
            %"val_846"<?,?> ⬅️ ::Reshape(%"val_844", %"val_845") {allowzero=0}
    1209 |  # node_Constant_845
            %"val_847"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1210 |  # node_slice_69
            %"slice_69"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem", %"val_839", %"val_843", %"val_846", %"val_847")
    1211 |  # node_Cast_846
            %"val_848"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1212 |  # node_Constant_847
            %"val_849"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1213 |  # node_Reshape_848
            %"val_850"<?,?> ⬅️ ::Reshape(%"val_848", %"val_849") {allowzero=0}
    1214 |  # node_Cast_849
            %"val_851"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1215 |  # node_Constant_850
            %"val_852"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1216 |  # node_Reshape_851
            %"val_853"<?,?> ⬅️ ::Reshape(%"val_851", %"val_852") {allowzero=0}
    1217 |  # node_Cast_852
            %"val_854"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1218 |  # node_Constant_853
            %"val_855"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1219 |  # node_Reshape_854
            %"val_856"<?,?> ⬅️ ::Reshape(%"val_854", %"val_855") {allowzero=0}
    1220 |  # node_Constant_855
            %"val_857"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1221 |  # node_slice_70
            %"slice_70"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem", %"val_850", %"val_853", %"val_856", %"val_857")
    1222 |  # node_neg
            %"neg"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_70")
    1223 |  # node_cat_22
            %"cat_22"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg", %"slice_69") {axis=-1}
    1224 |  # node_mul_45
            %"mul_45"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_22", %"unsqueeze_73")
    1225 |  # node_add
            %"add"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_44", %"mul_45")
    1226 |  # node_mul_46
            %"mul_46"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_1", %"unsqueeze_72")
    1227 |  # node_Cast_856
            %"val_858"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1228 |  # node_Constant_857
            %"val_859"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1229 |  # node_Reshape_858
            %"val_860"<?,?> ⬅️ ::Reshape(%"val_858", %"val_859") {allowzero=0}
    1230 |  # node_Cast_859
            %"val_861"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1231 |  # node_Constant_860
            %"val_862"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1232 |  # node_Reshape_861
            %"val_863"<?,?> ⬅️ ::Reshape(%"val_861", %"val_862") {allowzero=0}
    1233 |  # node_Cast_862
            %"val_864"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1234 |  # node_Constant_863
            %"val_865"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1235 |  # node_Reshape_864
            %"val_866"<?,?> ⬅️ ::Reshape(%"val_864", %"val_865") {allowzero=0}
    1236 |  # node_Constant_865
            %"val_867"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1237 |  # node_slice_71
            %"slice_71"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_1", %"val_860", %"val_863", %"val_866", %"val_867")
    1238 |  # node_Cast_866
            %"val_868"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1239 |  # node_Constant_867
            %"val_869"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1240 |  # node_Reshape_868
            %"val_870"<?,?> ⬅️ ::Reshape(%"val_868", %"val_869") {allowzero=0}
    1241 |  # node_Cast_869
            %"val_871"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1242 |  # node_Constant_870
            %"val_872"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1243 |  # node_Reshape_871
            %"val_873"<?,?> ⬅️ ::Reshape(%"val_871", %"val_872") {allowzero=0}
    1244 |  # node_Cast_872
            %"val_874"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1245 |  # node_Constant_873
            %"val_875"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1246 |  # node_Reshape_874
            %"val_876"<?,?> ⬅️ ::Reshape(%"val_874", %"val_875") {allowzero=0}
    1247 |  # node_Constant_875
            %"val_877"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1248 |  # node_slice_72
            %"slice_72"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_1", %"val_870", %"val_873", %"val_876", %"val_877")
    1249 |  # node_neg_1
            %"neg_1"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_72")
    1250 |  # node_cat_23
            %"cat_23"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_1", %"slice_71") {axis=-1}
    1251 |  # node_mul_47
            %"mul_47"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_23", %"unsqueeze_73")
    1252 |  # node_add_1
            %"add_1"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_46", %"mul_47")
    1253 |  # node_Shape_876
            %"val_878"<?,?> ⬅️ ::Shape(%"add") {start=0}
    1254 |  # node_Constant_877
            %"val_879"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1255 |  # node_Gather_878
            %"val_880"<?,?> ⬅️ ::Gather(%"val_878", %"val_879") {axis=0}
    1256 |  # node_CastLike_879
            %"val_881"<?,?> ⬅️ ::CastLike(%"val_880", %"add")
    1257 |  # node_Constant_880
            %"val_882"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1258 |  # node_CastLike_881
            %"val_883"<?,?> ⬅️ ::CastLike(%"val_882", %"add")
    1259 |  # node_Sqrt_882
            %"val_884"<?,?> ⬅️ ::Sqrt(%"val_881")
    1260 |  # node_Div_883
            %"val_885"<?,?> ⬅️ ::Div(%"val_883", %"val_884")
    1261 |  # node_CastLike_884
            %"val_886"<?,?> ⬅️ ::CastLike(%"val_885", %"add")
    1262 |  # node_Shape_885
            %"val_887"<?,?> ⬅️ ::Shape(%"add_1") {start=0}
    1263 |  # node_Constant_886
            %"val_888"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1264 |  # node_Constant_887
            %"val_889"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([-1]), name=None)}
    1265 |  # node_Slice_888
            %"val_890"<?,?> ⬅️ ::Slice(%"val_887", %"val_889", %"val_888")
    1266 |  # node_Constant_889
            %"val_891"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([-2]), name=None)}
    1267 |  # node_Slice_890
            %"val_892"<?,?> ⬅️ ::Slice(%"val_887", %"val_891", %"val_889")
    1268 |  # node_Constant_891
            %"val_893"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1269 |  # node_Slice_892
            %"val_894"<?,?> ⬅️ ::Slice(%"val_887", %"val_893", %"val_891")
    1270 |  # node_Constant_893
            %"val_895"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1271 |  # node_Concat_894
            %"val_896"<?,?> ⬅️ ::Concat(%"val_895", %"val_892", %"val_890") {axis=0}
    1272 |  # node_Reshape_895
            %"val_897"<?,?> ⬅️ ::Reshape(%"add_1", %"val_896") {allowzero=0}
    1273 |  # node_Transpose_896
            %"val_898"<?,?> ⬅️ ::Transpose(%"val_897") {perm=(0, 2, 1)}
    1274 |  # node_Concat_897
            %"val_899"<?,?> ⬅️ ::Concat(%"val_894", %"val_890", %"val_892") {axis=0}
    1275 |  # node_Reshape_898
            %"val_900"<?,?> ⬅️ ::Reshape(%"val_898", %"val_899") {allowzero=0}
    1276 |  # node_Sqrt_899
            %"val_901"<?,?> ⬅️ ::Sqrt(%"val_886")
    1277 |  # node_Mul_900
            %"val_902"<?,?> ⬅️ ::Mul(%"add", %"val_901")
    1278 |  # node_Sqrt_901
            %"val_903"<?,?> ⬅️ ::Sqrt(%"val_886")
    1279 |  # node_Mul_902
            %"val_904"<?,?> ⬅️ ::Mul(%"val_900", %"val_903")
    1280 |  # node_MatMul_903
            %"val_905"<?,?> ⬅️ ::MatMul(%"val_902", %"val_904")
    1281 |  # node_Add_904
            %"val_906"<?,?> ⬅️ ::Add(%"val_905", %"masked_fill")
    1282 |  # node_Softmax_905
            %"val_907"<?,?> ⬅️ ::Softmax(%"val_906") {axis=-1}
    1283 |  # node_scaled_dot_product_attention
            %"scaled_dot_product_attention"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_907", %"getitem_2")
    1284 |  # node_transpose_23
            %"transpose_23"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention") {perm=(0, 2, 1, 3)}
    1285 |  # node_Constant_906
            %"val_908"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1286 |  # node_Constant_907
            %"val_909"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1287 |  # node_Constant_908
            %"val_910"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1288 |  # node_Constant_909
            %"val_911"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    1289 |  # node_Concat_910
            %"val_912"<?,?> ⬅️ ::Concat(%"val_909", %"val_910", %"val_911") {axis=0}
    1290 |  # node_view_1
            %"view_1"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_23", %"val_912") {allowzero=1}
    1291 |  # node_Transpose_911
            %"val_913"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.attn.Wo.weight"{...}) {perm=(1, 0)}
    1292 |  # node_linear_1
            %"linear_1"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_1", %"val_913")
    1293 |  # node_add_2
            %"add_2"<FLOAT,[1,97,768]> ⬅️ ::Add(%"clone_1", %"linear_1")
    1294 |  # node_layer_norm_1
            %"layer_norm_1"<FLOAT,[1,97,768]>, %"val_914"<?,?>, %"val_915"<?,?> ⬅️ ::LayerNormalization(%"add_2", %"encoder.layers.0.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1295 |  # node_Transpose_912
            %"val_916"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1296 |  # node_linear_2
            %"linear_2"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_1", %"val_916")
    1297 |  # node_Constant_913
            %"val_917"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[]>(array(1152), name=None)}
    1298 |  # node_split
            %"split"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_2", %"val_917") {dim=-1}
    1299 |  # node_getitem_3
            %"getitem_3"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split", %"val_6")
    1300 |  # node_getitem_4
            %"getitem_4"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split", %"val_51")
    1301 |  # node_Constant_914
            %"val_918"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1302 |  # node_Div_915
            %"val_919"<?,?> ⬅️ ::Div(%"getitem_3", %"val_918")
    1303 |  # node_Erf_916
            %"val_920"<?,?> ⬅️ ::Erf(%"val_919")
    1304 |  # node_Constant_917
            %"val_921"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1305 |  # node_Add_918
            %"val_922"<?,?> ⬅️ ::Add(%"val_920", %"val_921")
    1306 |  # node_Constant_919
            %"val_923"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1307 |  # node_Mul_920
            %"val_924"<?,?> ⬅️ ::Mul(%"val_923", %"val_922")
    1308 |  # node_gelu
            %"gelu"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_3", %"val_924")
    1309 |  # node_mul_48
            %"mul_48"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu", %"getitem_4")
    1310 |  # node_clone_2
            %"clone_2"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_48")
    1311 |  # node_Transpose_921
            %"val_925"<?,?> ⬅️ ::Transpose(%"encoder.layers.0.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1312 |  # node_linear_3
            %"linear_3"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_2", %"val_925")
    1313 |  # node_add_3
            %"add_3"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_2", %"linear_3")
    1314 |  # node_layer_norm_2
            %"layer_norm_2"<FLOAT,[1,97,768]>, %"val_926"<?,?>, %"val_927"<?,?> ⬅️ ::LayerNormalization(%"add_3", %"encoder.layers.1.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1315 |  # node_Transpose_922
            %"val_928"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1316 |  # node_linear_4
            %"linear_4"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_2", %"val_928")
    1317 |  # node_Constant_923
            %"val_929"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1318 |  # node_Constant_924
            %"val_930"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1319 |  # node_Constant_925
            %"val_931"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1320 |  # node_Constant_926
            %"val_932"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    1321 |  # node_Constant_927
            %"val_933"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    1322 |  # node_Constant_928
            %"val_934"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    1323 |  # node_Concat_929
            %"val_935"<?,?> ⬅️ ::Concat(%"val_930", %"val_931", %"val_932", %"val_933", %"val_934") {axis=0}
    1324 |  # node_view_2
            %"view_2"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_4", %"val_935") {allowzero=1}
    1325 |  # node_transpose_24
            %"transpose_24"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_2") {perm=(0, 3, 2, 1, 4)}
    1326 |  # node_Constant_930
            %"val_936"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    1327 |  # node_Constant_931
            %"val_937"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1328 |  # node_Constant_932
            %"val_938"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1329 |  # node_Slice_933
            %"val_939"<?,?> ⬅️ ::Slice(%"transpose_24", %"val_936", %"val_937", %"val_938")
    1330 |  # node_unbind_1__0
            %"getitem_5"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_939", %"val_19")
    1331 |  # node_Constant_934
            %"val_940"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1332 |  # node_Constant_935
            %"val_941"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1333 |  # node_Constant_936
            %"val_942"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1334 |  # node_Slice_937
            %"val_943"<?,?> ⬅️ ::Slice(%"transpose_24", %"val_940", %"val_941", %"val_942")
    1335 |  # node_unbind_1__1
            %"getitem_6"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_943", %"val_19")
    1336 |  # node_Constant_938
            %"val_944"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1337 |  # node_Constant_939
            %"val_945"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    1338 |  # node_Constant_940
            %"val_946"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1339 |  # node_Slice_941
            %"val_947"<?,?> ⬅️ ::Slice(%"transpose_24", %"val_944", %"val_945", %"val_946")
    1340 |  # node_unbind_1__2
            %"getitem_7"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_947", %"val_19")
    1341 |  # node_unsqueeze_74
            %"unsqueeze_74"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1342 |  # node_unsqueeze_75
            %"unsqueeze_75"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1343 |  # node_mul_49
            %"mul_49"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_5", %"unsqueeze_74")
    1344 |  # node_Cast_942
            %"val_948"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1345 |  # node_Constant_943
            %"val_949"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1346 |  # node_Reshape_944
            %"val_950"<?,?> ⬅️ ::Reshape(%"val_948", %"val_949") {allowzero=0}
    1347 |  # node_Cast_945
            %"val_951"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1348 |  # node_Constant_946
            %"val_952"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1349 |  # node_Reshape_947
            %"val_953"<?,?> ⬅️ ::Reshape(%"val_951", %"val_952") {allowzero=0}
    1350 |  # node_Cast_948
            %"val_954"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1351 |  # node_Constant_949
            %"val_955"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1352 |  # node_Reshape_950
            %"val_956"<?,?> ⬅️ ::Reshape(%"val_954", %"val_955") {allowzero=0}
    1353 |  # node_Constant_951
            %"val_957"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1354 |  # node_slice_73
            %"slice_73"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_5", %"val_950", %"val_953", %"val_956", %"val_957")
    1355 |  # node_Cast_952
            %"val_958"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1356 |  # node_Constant_953
            %"val_959"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1357 |  # node_Reshape_954
            %"val_960"<?,?> ⬅️ ::Reshape(%"val_958", %"val_959") {allowzero=0}
    1358 |  # node_Cast_955
            %"val_961"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1359 |  # node_Constant_956
            %"val_962"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1360 |  # node_Reshape_957
            %"val_963"<?,?> ⬅️ ::Reshape(%"val_961", %"val_962") {allowzero=0}
    1361 |  # node_Cast_958
            %"val_964"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1362 |  # node_Constant_959
            %"val_965"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1363 |  # node_Reshape_960
            %"val_966"<?,?> ⬅️ ::Reshape(%"val_964", %"val_965") {allowzero=0}
    1364 |  # node_Constant_961
            %"val_967"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1365 |  # node_slice_74
            %"slice_74"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_5", %"val_960", %"val_963", %"val_966", %"val_967")
    1366 |  # node_neg_2
            %"neg_2"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_74")
    1367 |  # node_cat_24
            %"cat_24"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_2", %"slice_73") {axis=-1}
    1368 |  # node_mul_50
            %"mul_50"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_24", %"unsqueeze_75")
    1369 |  # node_add_4
            %"add_4"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_49", %"mul_50")
    1370 |  # node_mul_51
            %"mul_51"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_6", %"unsqueeze_74")
    1371 |  # node_Cast_962
            %"val_968"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1372 |  # node_Constant_963
            %"val_969"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1373 |  # node_Reshape_964
            %"val_970"<?,?> ⬅️ ::Reshape(%"val_968", %"val_969") {allowzero=0}
    1374 |  # node_Cast_965
            %"val_971"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1375 |  # node_Constant_966
            %"val_972"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1376 |  # node_Reshape_967
            %"val_973"<?,?> ⬅️ ::Reshape(%"val_971", %"val_972") {allowzero=0}
    1377 |  # node_Cast_968
            %"val_974"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1378 |  # node_Constant_969
            %"val_975"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1379 |  # node_Reshape_970
            %"val_976"<?,?> ⬅️ ::Reshape(%"val_974", %"val_975") {allowzero=0}
    1380 |  # node_Constant_971
            %"val_977"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1381 |  # node_slice_75
            %"slice_75"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_6", %"val_970", %"val_973", %"val_976", %"val_977")
    1382 |  # node_Cast_972
            %"val_978"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1383 |  # node_Constant_973
            %"val_979"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1384 |  # node_Reshape_974
            %"val_980"<?,?> ⬅️ ::Reshape(%"val_978", %"val_979") {allowzero=0}
    1385 |  # node_Cast_975
            %"val_981"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1386 |  # node_Constant_976
            %"val_982"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1387 |  # node_Reshape_977
            %"val_983"<?,?> ⬅️ ::Reshape(%"val_981", %"val_982") {allowzero=0}
    1388 |  # node_Cast_978
            %"val_984"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1389 |  # node_Constant_979
            %"val_985"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1390 |  # node_Reshape_980
            %"val_986"<?,?> ⬅️ ::Reshape(%"val_984", %"val_985") {allowzero=0}
    1391 |  # node_Constant_981
            %"val_987"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1392 |  # node_slice_76
            %"slice_76"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_6", %"val_980", %"val_983", %"val_986", %"val_987")
    1393 |  # node_neg_3
            %"neg_3"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_76")
    1394 |  # node_cat_25
            %"cat_25"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_3", %"slice_75") {axis=-1}
    1395 |  # node_mul_52
            %"mul_52"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_25", %"unsqueeze_75")
    1396 |  # node_add_5
            %"add_5"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_51", %"mul_52")
    1397 |  # node_Shape_982
            %"val_988"<?,?> ⬅️ ::Shape(%"add_4") {start=0}
    1398 |  # node_Constant_983
            %"val_989"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1399 |  # node_Gather_984
            %"val_990"<?,?> ⬅️ ::Gather(%"val_988", %"val_989") {axis=0}
    1400 |  # node_CastLike_985
            %"val_991"<?,?> ⬅️ ::CastLike(%"val_990", %"add_4")
    1401 |  # node_Constant_986
            %"val_992"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1402 |  # node_CastLike_987
            %"val_993"<?,?> ⬅️ ::CastLike(%"val_992", %"add_4")
    1403 |  # node_Sqrt_988
            %"val_994"<?,?> ⬅️ ::Sqrt(%"val_991")
    1404 |  # node_Div_989
            %"val_995"<?,?> ⬅️ ::Div(%"val_993", %"val_994")
    1405 |  # node_CastLike_990
            %"val_996"<?,?> ⬅️ ::CastLike(%"val_995", %"add_4")
    1406 |  # node_Shape_991
            %"val_997"<?,?> ⬅️ ::Shape(%"add_5") {start=0}
    1407 |  # node_Constant_992
            %"val_998"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1408 |  # node_Slice_993
            %"val_999"<?,?> ⬅️ ::Slice(%"val_997", %"val_889", %"val_998")
    1409 |  # node_Slice_994
            %"val_1000"<?,?> ⬅️ ::Slice(%"val_997", %"val_891", %"val_889")
    1410 |  # node_Constant_995
            %"val_1001"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1411 |  # node_Slice_996
            %"val_1002"<?,?> ⬅️ ::Slice(%"val_997", %"val_1001", %"val_891")
    1412 |  # node_Constant_997
            %"val_1003"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1413 |  # node_Concat_998
            %"val_1004"<?,?> ⬅️ ::Concat(%"val_1003", %"val_1000", %"val_999") {axis=0}
    1414 |  # node_Reshape_999
            %"val_1005"<?,?> ⬅️ ::Reshape(%"add_5", %"val_1004") {allowzero=0}
    1415 |  # node_Transpose_1000
            %"val_1006"<?,?> ⬅️ ::Transpose(%"val_1005") {perm=(0, 2, 1)}
    1416 |  # node_Concat_1001
            %"val_1007"<?,?> ⬅️ ::Concat(%"val_1002", %"val_999", %"val_1000") {axis=0}
    1417 |  # node_Reshape_1002
            %"val_1008"<?,?> ⬅️ ::Reshape(%"val_1006", %"val_1007") {allowzero=0}
    1418 |  # node_Sqrt_1003
            %"val_1009"<?,?> ⬅️ ::Sqrt(%"val_996")
    1419 |  # node_Mul_1004
            %"val_1010"<?,?> ⬅️ ::Mul(%"add_4", %"val_1009")
    1420 |  # node_Sqrt_1005
            %"val_1011"<?,?> ⬅️ ::Sqrt(%"val_996")
    1421 |  # node_Mul_1006
            %"val_1012"<?,?> ⬅️ ::Mul(%"val_1008", %"val_1011")
    1422 |  # node_MatMul_1007
            %"val_1013"<?,?> ⬅️ ::MatMul(%"val_1010", %"val_1012")
    1423 |  # node_Add_1008
            %"val_1014"<?,?> ⬅️ ::Add(%"val_1013", %"masked_fill_1")
    1424 |  # node_Softmax_1009
            %"val_1015"<?,?> ⬅️ ::Softmax(%"val_1014") {axis=-1}
    1425 |  # node_scaled_dot_product_attention_1
            %"scaled_dot_product_attention_1"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1015", %"getitem_7")
    1426 |  # node_transpose_25
            %"transpose_25"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_1") {perm=(0, 2, 1, 3)}
    1427 |  # node_Constant_1010
            %"val_1016"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1428 |  # node_Constant_1011
            %"val_1017"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1429 |  # node_Constant_1012
            %"val_1018"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1430 |  # node_Constant_1013
            %"val_1019"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    1431 |  # node_Concat_1014
            %"val_1020"<?,?> ⬅️ ::Concat(%"val_1017", %"val_1018", %"val_1019") {axis=0}
    1432 |  # node_view_3
            %"view_3"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_25", %"val_1020") {allowzero=1}
    1433 |  # node_Transpose_1015
            %"val_1021"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.attn.Wo.weight"{...}) {perm=(1, 0)}
    1434 |  # node_linear_5
            %"linear_5"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_3", %"val_1021")
    1435 |  # node_add_6
            %"add_6"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_3", %"linear_5")
    1436 |  # node_layer_norm_3
            %"layer_norm_3"<FLOAT,[1,97,768]>, %"val_1022"<?,?>, %"val_1023"<?,?> ⬅️ ::LayerNormalization(%"add_6", %"encoder.layers.1.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1437 |  # node_Transpose_1016
            %"val_1024"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1438 |  # node_linear_6
            %"linear_6"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_3", %"val_1024")
    1439 |  # node_split_1
            %"split_1"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_6", %"val_917") {dim=-1}
    1440 |  # node_getitem_8
            %"getitem_8"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_1", %"val_6")
    1441 |  # node_getitem_9
            %"getitem_9"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_1", %"val_51")
    1442 |  # node_Constant_1017
            %"val_1025"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1443 |  # node_Div_1018
            %"val_1026"<?,?> ⬅️ ::Div(%"getitem_8", %"val_1025")
    1444 |  # node_Erf_1019
            %"val_1027"<?,?> ⬅️ ::Erf(%"val_1026")
    1445 |  # node_Constant_1020
            %"val_1028"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1446 |  # node_Add_1021
            %"val_1029"<?,?> ⬅️ ::Add(%"val_1027", %"val_1028")
    1447 |  # node_Constant_1022
            %"val_1030"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1448 |  # node_Mul_1023
            %"val_1031"<?,?> ⬅️ ::Mul(%"val_1030", %"val_1029")
    1449 |  # node_gelu_1
            %"gelu_1"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_8", %"val_1031")
    1450 |  # node_mul_53
            %"mul_53"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_1", %"getitem_9")
    1451 |  # node_clone_3
            %"clone_3"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_53")
    1452 |  # node_Transpose_1024
            %"val_1032"<?,?> ⬅️ ::Transpose(%"encoder.layers.1.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1453 |  # node_linear_7
            %"linear_7"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_3", %"val_1032")
    1454 |  # node_add_7
            %"add_7"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_6", %"linear_7")
    1455 |  # node_layer_norm_4
            %"layer_norm_4"<FLOAT,[1,97,768]>, %"val_1033"<?,?>, %"val_1034"<?,?> ⬅️ ::LayerNormalization(%"add_7", %"encoder.layers.2.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1456 |  # node_Transpose_1025
            %"val_1035"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1457 |  # node_linear_8
            %"linear_8"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_4", %"val_1035")
    1458 |  # node_Constant_1026
            %"val_1036"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1459 |  # node_Constant_1027
            %"val_1037"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1460 |  # node_Constant_1028
            %"val_1038"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1461 |  # node_Constant_1029
            %"val_1039"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    1462 |  # node_Constant_1030
            %"val_1040"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    1463 |  # node_Constant_1031
            %"val_1041"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    1464 |  # node_Concat_1032
            %"val_1042"<?,?> ⬅️ ::Concat(%"val_1037", %"val_1038", %"val_1039", %"val_1040", %"val_1041") {axis=0}
    1465 |  # node_view_4
            %"view_4"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_8", %"val_1042") {allowzero=1}
    1466 |  # node_transpose_26
            %"transpose_26"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_4") {perm=(0, 3, 2, 1, 4)}
    1467 |  # node_Constant_1033
            %"val_1043"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    1468 |  # node_Constant_1034
            %"val_1044"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1469 |  # node_Constant_1035
            %"val_1045"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1470 |  # node_Slice_1036
            %"val_1046"<?,?> ⬅️ ::Slice(%"transpose_26", %"val_1043", %"val_1044", %"val_1045")
    1471 |  # node_unbind_2__0
            %"getitem_10"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1046", %"val_19")
    1472 |  # node_Constant_1037
            %"val_1047"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1473 |  # node_Constant_1038
            %"val_1048"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1474 |  # node_Constant_1039
            %"val_1049"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1475 |  # node_Slice_1040
            %"val_1050"<?,?> ⬅️ ::Slice(%"transpose_26", %"val_1047", %"val_1048", %"val_1049")
    1476 |  # node_unbind_2__1
            %"getitem_11"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1050", %"val_19")
    1477 |  # node_Constant_1041
            %"val_1051"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1478 |  # node_Constant_1042
            %"val_1052"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    1479 |  # node_Constant_1043
            %"val_1053"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1480 |  # node_Slice_1044
            %"val_1054"<?,?> ⬅️ ::Slice(%"transpose_26", %"val_1051", %"val_1052", %"val_1053")
    1481 |  # node_unbind_2__2
            %"getitem_12"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1054", %"val_19")
    1482 |  # node_unsqueeze_76
            %"unsqueeze_76"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1483 |  # node_unsqueeze_77
            %"unsqueeze_77"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1484 |  # node_mul_54
            %"mul_54"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_10", %"unsqueeze_76")
    1485 |  # node_Cast_1045
            %"val_1055"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1486 |  # node_Constant_1046
            %"val_1056"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1487 |  # node_Reshape_1047
            %"val_1057"<?,?> ⬅️ ::Reshape(%"val_1055", %"val_1056") {allowzero=0}
    1488 |  # node_Cast_1048
            %"val_1058"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1489 |  # node_Constant_1049
            %"val_1059"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1490 |  # node_Reshape_1050
            %"val_1060"<?,?> ⬅️ ::Reshape(%"val_1058", %"val_1059") {allowzero=0}
    1491 |  # node_Cast_1051
            %"val_1061"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1492 |  # node_Constant_1052
            %"val_1062"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1493 |  # node_Reshape_1053
            %"val_1063"<?,?> ⬅️ ::Reshape(%"val_1061", %"val_1062") {allowzero=0}
    1494 |  # node_Constant_1054
            %"val_1064"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1495 |  # node_slice_77
            %"slice_77"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_10", %"val_1057", %"val_1060", %"val_1063", %"val_1064")
    1496 |  # node_Cast_1055
            %"val_1065"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1497 |  # node_Constant_1056
            %"val_1066"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1498 |  # node_Reshape_1057
            %"val_1067"<?,?> ⬅️ ::Reshape(%"val_1065", %"val_1066") {allowzero=0}
    1499 |  # node_Cast_1058
            %"val_1068"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1500 |  # node_Constant_1059
            %"val_1069"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1501 |  # node_Reshape_1060
            %"val_1070"<?,?> ⬅️ ::Reshape(%"val_1068", %"val_1069") {allowzero=0}
    1502 |  # node_Cast_1061
            %"val_1071"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1503 |  # node_Constant_1062
            %"val_1072"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1504 |  # node_Reshape_1063
            %"val_1073"<?,?> ⬅️ ::Reshape(%"val_1071", %"val_1072") {allowzero=0}
    1505 |  # node_Constant_1064
            %"val_1074"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1506 |  # node_slice_78
            %"slice_78"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_10", %"val_1067", %"val_1070", %"val_1073", %"val_1074")
    1507 |  # node_neg_4
            %"neg_4"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_78")
    1508 |  # node_cat_26
            %"cat_26"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_4", %"slice_77") {axis=-1}
    1509 |  # node_mul_55
            %"mul_55"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_26", %"unsqueeze_77")
    1510 |  # node_add_8
            %"add_8"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_54", %"mul_55")
    1511 |  # node_mul_56
            %"mul_56"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_11", %"unsqueeze_76")
    1512 |  # node_Cast_1065
            %"val_1075"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1513 |  # node_Constant_1066
            %"val_1076"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1514 |  # node_Reshape_1067
            %"val_1077"<?,?> ⬅️ ::Reshape(%"val_1075", %"val_1076") {allowzero=0}
    1515 |  # node_Cast_1068
            %"val_1078"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1516 |  # node_Constant_1069
            %"val_1079"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1517 |  # node_Reshape_1070
            %"val_1080"<?,?> ⬅️ ::Reshape(%"val_1078", %"val_1079") {allowzero=0}
    1518 |  # node_Cast_1071
            %"val_1081"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1519 |  # node_Constant_1072
            %"val_1082"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1520 |  # node_Reshape_1073
            %"val_1083"<?,?> ⬅️ ::Reshape(%"val_1081", %"val_1082") {allowzero=0}
    1521 |  # node_Constant_1074
            %"val_1084"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1522 |  # node_slice_79
            %"slice_79"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_11", %"val_1077", %"val_1080", %"val_1083", %"val_1084")
    1523 |  # node_Cast_1075
            %"val_1085"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1524 |  # node_Constant_1076
            %"val_1086"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1525 |  # node_Reshape_1077
            %"val_1087"<?,?> ⬅️ ::Reshape(%"val_1085", %"val_1086") {allowzero=0}
    1526 |  # node_Cast_1078
            %"val_1088"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1527 |  # node_Constant_1079
            %"val_1089"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1528 |  # node_Reshape_1080
            %"val_1090"<?,?> ⬅️ ::Reshape(%"val_1088", %"val_1089") {allowzero=0}
    1529 |  # node_Cast_1081
            %"val_1091"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1530 |  # node_Constant_1082
            %"val_1092"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1531 |  # node_Reshape_1083
            %"val_1093"<?,?> ⬅️ ::Reshape(%"val_1091", %"val_1092") {allowzero=0}
    1532 |  # node_Constant_1084
            %"val_1094"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1533 |  # node_slice_80
            %"slice_80"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_11", %"val_1087", %"val_1090", %"val_1093", %"val_1094")
    1534 |  # node_neg_5
            %"neg_5"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_80")
    1535 |  # node_cat_27
            %"cat_27"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_5", %"slice_79") {axis=-1}
    1536 |  # node_mul_57
            %"mul_57"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_27", %"unsqueeze_77")
    1537 |  # node_add_9
            %"add_9"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_56", %"mul_57")
    1538 |  # node_Shape_1085
            %"val_1095"<?,?> ⬅️ ::Shape(%"add_8") {start=0}
    1539 |  # node_Constant_1086
            %"val_1096"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1540 |  # node_Gather_1087
            %"val_1097"<?,?> ⬅️ ::Gather(%"val_1095", %"val_1096") {axis=0}
    1541 |  # node_CastLike_1088
            %"val_1098"<?,?> ⬅️ ::CastLike(%"val_1097", %"add_8")
    1542 |  # node_Constant_1089
            %"val_1099"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1543 |  # node_CastLike_1090
            %"val_1100"<?,?> ⬅️ ::CastLike(%"val_1099", %"add_8")
    1544 |  # node_Sqrt_1091
            %"val_1101"<?,?> ⬅️ ::Sqrt(%"val_1098")
    1545 |  # node_Div_1092
            %"val_1102"<?,?> ⬅️ ::Div(%"val_1100", %"val_1101")
    1546 |  # node_CastLike_1093
            %"val_1103"<?,?> ⬅️ ::CastLike(%"val_1102", %"add_8")
    1547 |  # node_Shape_1094
            %"val_1104"<?,?> ⬅️ ::Shape(%"add_9") {start=0}
    1548 |  # node_Constant_1095
            %"val_1105"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1549 |  # node_Slice_1096
            %"val_1106"<?,?> ⬅️ ::Slice(%"val_1104", %"val_889", %"val_1105")
    1550 |  # node_Slice_1097
            %"val_1107"<?,?> ⬅️ ::Slice(%"val_1104", %"val_891", %"val_889")
    1551 |  # node_Constant_1098
            %"val_1108"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1552 |  # node_Slice_1099
            %"val_1109"<?,?> ⬅️ ::Slice(%"val_1104", %"val_1108", %"val_891")
    1553 |  # node_Constant_1100
            %"val_1110"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1554 |  # node_Concat_1101
            %"val_1111"<?,?> ⬅️ ::Concat(%"val_1110", %"val_1107", %"val_1106") {axis=0}
    1555 |  # node_Reshape_1102
            %"val_1112"<?,?> ⬅️ ::Reshape(%"add_9", %"val_1111") {allowzero=0}
    1556 |  # node_Transpose_1103
            %"val_1113"<?,?> ⬅️ ::Transpose(%"val_1112") {perm=(0, 2, 1)}
    1557 |  # node_Concat_1104
            %"val_1114"<?,?> ⬅️ ::Concat(%"val_1109", %"val_1106", %"val_1107") {axis=0}
    1558 |  # node_Reshape_1105
            %"val_1115"<?,?> ⬅️ ::Reshape(%"val_1113", %"val_1114") {allowzero=0}
    1559 |  # node_Sqrt_1106
            %"val_1116"<?,?> ⬅️ ::Sqrt(%"val_1103")
    1560 |  # node_Mul_1107
            %"val_1117"<?,?> ⬅️ ::Mul(%"add_8", %"val_1116")
    1561 |  # node_Sqrt_1108
            %"val_1118"<?,?> ⬅️ ::Sqrt(%"val_1103")
    1562 |  # node_Mul_1109
            %"val_1119"<?,?> ⬅️ ::Mul(%"val_1115", %"val_1118")
    1563 |  # node_MatMul_1110
            %"val_1120"<?,?> ⬅️ ::MatMul(%"val_1117", %"val_1119")
    1564 |  # node_Add_1111
            %"val_1121"<?,?> ⬅️ ::Add(%"val_1120", %"masked_fill_1")
    1565 |  # node_Softmax_1112
            %"val_1122"<?,?> ⬅️ ::Softmax(%"val_1121") {axis=-1}
    1566 |  # node_scaled_dot_product_attention_2
            %"scaled_dot_product_attention_2"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1122", %"getitem_12")
    1567 |  # node_transpose_27
            %"transpose_27"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_2") {perm=(0, 2, 1, 3)}
    1568 |  # node_Constant_1113
            %"val_1123"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1569 |  # node_Constant_1114
            %"val_1124"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1570 |  # node_Constant_1115
            %"val_1125"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1571 |  # node_Constant_1116
            %"val_1126"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    1572 |  # node_Concat_1117
            %"val_1127"<?,?> ⬅️ ::Concat(%"val_1124", %"val_1125", %"val_1126") {axis=0}
    1573 |  # node_view_5
            %"view_5"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_27", %"val_1127") {allowzero=1}
    1574 |  # node_Transpose_1118
            %"val_1128"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.attn.Wo.weight"{...}) {perm=(1, 0)}
    1575 |  # node_linear_9
            %"linear_9"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_5", %"val_1128")
    1576 |  # node_add_10
            %"add_10"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_7", %"linear_9")
    1577 |  # node_layer_norm_5
            %"layer_norm_5"<FLOAT,[1,97,768]>, %"val_1129"<?,?>, %"val_1130"<?,?> ⬅️ ::LayerNormalization(%"add_10", %"encoder.layers.2.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1578 |  # node_Transpose_1119
            %"val_1131"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1579 |  # node_linear_10
            %"linear_10"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_5", %"val_1131")
    1580 |  # node_split_2
            %"split_2"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_10", %"val_917") {dim=-1}
    1581 |  # node_getitem_13
            %"getitem_13"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_2", %"val_6")
    1582 |  # node_getitem_14
            %"getitem_14"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_2", %"val_51")
    1583 |  # node_Constant_1120
            %"val_1132"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1584 |  # node_Div_1121
            %"val_1133"<?,?> ⬅️ ::Div(%"getitem_13", %"val_1132")
    1585 |  # node_Erf_1122
            %"val_1134"<?,?> ⬅️ ::Erf(%"val_1133")
    1586 |  # node_Constant_1123
            %"val_1135"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1587 |  # node_Add_1124
            %"val_1136"<?,?> ⬅️ ::Add(%"val_1134", %"val_1135")
    1588 |  # node_Constant_1125
            %"val_1137"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1589 |  # node_Mul_1126
            %"val_1138"<?,?> ⬅️ ::Mul(%"val_1137", %"val_1136")
    1590 |  # node_gelu_2
            %"gelu_2"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_13", %"val_1138")
    1591 |  # node_mul_58
            %"mul_58"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_2", %"getitem_14")
    1592 |  # node_clone_4
            %"clone_4"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_58")
    1593 |  # node_Transpose_1127
            %"val_1139"<?,?> ⬅️ ::Transpose(%"encoder.layers.2.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1594 |  # node_linear_11
            %"linear_11"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_4", %"val_1139")
    1595 |  # node_add_11
            %"add_11"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_10", %"linear_11")
    1596 |  # node_layer_norm_6
            %"layer_norm_6"<FLOAT,[1,97,768]>, %"val_1140"<?,?>, %"val_1141"<?,?> ⬅️ ::LayerNormalization(%"add_11", %"encoder.layers.3.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1597 |  # node_Transpose_1128
            %"val_1142"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1598 |  # node_linear_12
            %"linear_12"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_6", %"val_1142")
    1599 |  # node_Constant_1129
            %"val_1143"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1600 |  # node_Constant_1130
            %"val_1144"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1601 |  # node_Constant_1131
            %"val_1145"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1602 |  # node_Constant_1132
            %"val_1146"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    1603 |  # node_Constant_1133
            %"val_1147"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    1604 |  # node_Constant_1134
            %"val_1148"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    1605 |  # node_Concat_1135
            %"val_1149"<?,?> ⬅️ ::Concat(%"val_1144", %"val_1145", %"val_1146", %"val_1147", %"val_1148") {axis=0}
    1606 |  # node_view_6
            %"view_6"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_12", %"val_1149") {allowzero=1}
    1607 |  # node_transpose_28
            %"transpose_28"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_6") {perm=(0, 3, 2, 1, 4)}
    1608 |  # node_Constant_1136
            %"val_1150"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    1609 |  # node_Constant_1137
            %"val_1151"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1610 |  # node_Constant_1138
            %"val_1152"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1611 |  # node_Slice_1139
            %"val_1153"<?,?> ⬅️ ::Slice(%"transpose_28", %"val_1150", %"val_1151", %"val_1152")
    1612 |  # node_unbind_3__0
            %"getitem_15"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1153", %"val_19")
    1613 |  # node_Constant_1140
            %"val_1154"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1614 |  # node_Constant_1141
            %"val_1155"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1615 |  # node_Constant_1142
            %"val_1156"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1616 |  # node_Slice_1143
            %"val_1157"<?,?> ⬅️ ::Slice(%"transpose_28", %"val_1154", %"val_1155", %"val_1156")
    1617 |  # node_unbind_3__1
            %"getitem_16"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1157", %"val_19")
    1618 |  # node_Constant_1144
            %"val_1158"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1619 |  # node_Constant_1145
            %"val_1159"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    1620 |  # node_Constant_1146
            %"val_1160"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1621 |  # node_Slice_1147
            %"val_1161"<?,?> ⬅️ ::Slice(%"transpose_28", %"val_1158", %"val_1159", %"val_1160")
    1622 |  # node_unbind_3__2
            %"getitem_17"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1161", %"val_19")
    1623 |  # node_unsqueeze_78
            %"unsqueeze_78"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    1624 |  # node_unsqueeze_79
            %"unsqueeze_79"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    1625 |  # node_mul_59
            %"mul_59"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_15", %"unsqueeze_78")
    1626 |  # node_Cast_1148
            %"val_1162"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1627 |  # node_Constant_1149
            %"val_1163"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1628 |  # node_Reshape_1150
            %"val_1164"<?,?> ⬅️ ::Reshape(%"val_1162", %"val_1163") {allowzero=0}
    1629 |  # node_Cast_1151
            %"val_1165"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1630 |  # node_Constant_1152
            %"val_1166"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1631 |  # node_Reshape_1153
            %"val_1167"<?,?> ⬅️ ::Reshape(%"val_1165", %"val_1166") {allowzero=0}
    1632 |  # node_Cast_1154
            %"val_1168"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1633 |  # node_Constant_1155
            %"val_1169"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1634 |  # node_Reshape_1156
            %"val_1170"<?,?> ⬅️ ::Reshape(%"val_1168", %"val_1169") {allowzero=0}
    1635 |  # node_Constant_1157
            %"val_1171"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1636 |  # node_slice_81
            %"slice_81"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_15", %"val_1164", %"val_1167", %"val_1170", %"val_1171")
    1637 |  # node_Cast_1158
            %"val_1172"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1638 |  # node_Constant_1159
            %"val_1173"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1639 |  # node_Reshape_1160
            %"val_1174"<?,?> ⬅️ ::Reshape(%"val_1172", %"val_1173") {allowzero=0}
    1640 |  # node_Cast_1161
            %"val_1175"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1641 |  # node_Constant_1162
            %"val_1176"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1642 |  # node_Reshape_1163
            %"val_1177"<?,?> ⬅️ ::Reshape(%"val_1175", %"val_1176") {allowzero=0}
    1643 |  # node_Cast_1164
            %"val_1178"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1644 |  # node_Constant_1165
            %"val_1179"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1645 |  # node_Reshape_1166
            %"val_1180"<?,?> ⬅️ ::Reshape(%"val_1178", %"val_1179") {allowzero=0}
    1646 |  # node_Constant_1167
            %"val_1181"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1647 |  # node_slice_82
            %"slice_82"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_15", %"val_1174", %"val_1177", %"val_1180", %"val_1181")
    1648 |  # node_neg_6
            %"neg_6"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_82")
    1649 |  # node_cat_28
            %"cat_28"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_6", %"slice_81") {axis=-1}
    1650 |  # node_mul_60
            %"mul_60"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_28", %"unsqueeze_79")
    1651 |  # node_add_12
            %"add_12"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_59", %"mul_60")
    1652 |  # node_mul_61
            %"mul_61"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_16", %"unsqueeze_78")
    1653 |  # node_Cast_1168
            %"val_1182"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1654 |  # node_Constant_1169
            %"val_1183"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1655 |  # node_Reshape_1170
            %"val_1184"<?,?> ⬅️ ::Reshape(%"val_1182", %"val_1183") {allowzero=0}
    1656 |  # node_Cast_1171
            %"val_1185"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1657 |  # node_Constant_1172
            %"val_1186"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1658 |  # node_Reshape_1173
            %"val_1187"<?,?> ⬅️ ::Reshape(%"val_1185", %"val_1186") {allowzero=0}
    1659 |  # node_Cast_1174
            %"val_1188"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1660 |  # node_Constant_1175
            %"val_1189"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1661 |  # node_Reshape_1176
            %"val_1190"<?,?> ⬅️ ::Reshape(%"val_1188", %"val_1189") {allowzero=0}
    1662 |  # node_Constant_1177
            %"val_1191"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1663 |  # node_slice_83
            %"slice_83"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_16", %"val_1184", %"val_1187", %"val_1190", %"val_1191")
    1664 |  # node_Cast_1178
            %"val_1192"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1665 |  # node_Constant_1179
            %"val_1193"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1666 |  # node_Reshape_1180
            %"val_1194"<?,?> ⬅️ ::Reshape(%"val_1192", %"val_1193") {allowzero=0}
    1667 |  # node_Cast_1181
            %"val_1195"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1668 |  # node_Constant_1182
            %"val_1196"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1669 |  # node_Reshape_1183
            %"val_1197"<?,?> ⬅️ ::Reshape(%"val_1195", %"val_1196") {allowzero=0}
    1670 |  # node_Cast_1184
            %"val_1198"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1671 |  # node_Constant_1185
            %"val_1199"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1672 |  # node_Reshape_1186
            %"val_1200"<?,?> ⬅️ ::Reshape(%"val_1198", %"val_1199") {allowzero=0}
    1673 |  # node_Constant_1187
            %"val_1201"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1674 |  # node_slice_84
            %"slice_84"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_16", %"val_1194", %"val_1197", %"val_1200", %"val_1201")
    1675 |  # node_neg_7
            %"neg_7"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_84")
    1676 |  # node_cat_29
            %"cat_29"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_7", %"slice_83") {axis=-1}
    1677 |  # node_mul_62
            %"mul_62"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_29", %"unsqueeze_79")
    1678 |  # node_add_13
            %"add_13"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_61", %"mul_62")
    1679 |  # node_Shape_1188
            %"val_1202"<?,?> ⬅️ ::Shape(%"add_12") {start=0}
    1680 |  # node_Constant_1189
            %"val_1203"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1681 |  # node_Gather_1190
            %"val_1204"<?,?> ⬅️ ::Gather(%"val_1202", %"val_1203") {axis=0}
    1682 |  # node_CastLike_1191
            %"val_1205"<?,?> ⬅️ ::CastLike(%"val_1204", %"add_12")
    1683 |  # node_Constant_1192
            %"val_1206"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1684 |  # node_CastLike_1193
            %"val_1207"<?,?> ⬅️ ::CastLike(%"val_1206", %"add_12")
    1685 |  # node_Sqrt_1194
            %"val_1208"<?,?> ⬅️ ::Sqrt(%"val_1205")
    1686 |  # node_Div_1195
            %"val_1209"<?,?> ⬅️ ::Div(%"val_1207", %"val_1208")
    1687 |  # node_CastLike_1196
            %"val_1210"<?,?> ⬅️ ::CastLike(%"val_1209", %"add_12")
    1688 |  # node_Shape_1197
            %"val_1211"<?,?> ⬅️ ::Shape(%"add_13") {start=0}
    1689 |  # node_Constant_1198
            %"val_1212"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1690 |  # node_Slice_1199
            %"val_1213"<?,?> ⬅️ ::Slice(%"val_1211", %"val_889", %"val_1212")
    1691 |  # node_Slice_1200
            %"val_1214"<?,?> ⬅️ ::Slice(%"val_1211", %"val_891", %"val_889")
    1692 |  # node_Constant_1201
            %"val_1215"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1693 |  # node_Slice_1202
            %"val_1216"<?,?> ⬅️ ::Slice(%"val_1211", %"val_1215", %"val_891")
    1694 |  # node_Constant_1203
            %"val_1217"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1695 |  # node_Concat_1204
            %"val_1218"<?,?> ⬅️ ::Concat(%"val_1217", %"val_1214", %"val_1213") {axis=0}
    1696 |  # node_Reshape_1205
            %"val_1219"<?,?> ⬅️ ::Reshape(%"add_13", %"val_1218") {allowzero=0}
    1697 |  # node_Transpose_1206
            %"val_1220"<?,?> ⬅️ ::Transpose(%"val_1219") {perm=(0, 2, 1)}
    1698 |  # node_Concat_1207
            %"val_1221"<?,?> ⬅️ ::Concat(%"val_1216", %"val_1213", %"val_1214") {axis=0}
    1699 |  # node_Reshape_1208
            %"val_1222"<?,?> ⬅️ ::Reshape(%"val_1220", %"val_1221") {allowzero=0}
    1700 |  # node_Sqrt_1209
            %"val_1223"<?,?> ⬅️ ::Sqrt(%"val_1210")
    1701 |  # node_Mul_1210
            %"val_1224"<?,?> ⬅️ ::Mul(%"add_12", %"val_1223")
    1702 |  # node_Sqrt_1211
            %"val_1225"<?,?> ⬅️ ::Sqrt(%"val_1210")
    1703 |  # node_Mul_1212
            %"val_1226"<?,?> ⬅️ ::Mul(%"val_1222", %"val_1225")
    1704 |  # node_MatMul_1213
            %"val_1227"<?,?> ⬅️ ::MatMul(%"val_1224", %"val_1226")
    1705 |  # node_Add_1214
            %"val_1228"<?,?> ⬅️ ::Add(%"val_1227", %"masked_fill")
    1706 |  # node_Softmax_1215
            %"val_1229"<?,?> ⬅️ ::Softmax(%"val_1228") {axis=-1}
    1707 |  # node_scaled_dot_product_attention_3
            %"scaled_dot_product_attention_3"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1229", %"getitem_17")
    1708 |  # node_transpose_29
            %"transpose_29"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_3") {perm=(0, 2, 1, 3)}
    1709 |  # node_Constant_1216
            %"val_1230"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1710 |  # node_Constant_1217
            %"val_1231"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1711 |  # node_Constant_1218
            %"val_1232"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1712 |  # node_Constant_1219
            %"val_1233"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    1713 |  # node_Concat_1220
            %"val_1234"<?,?> ⬅️ ::Concat(%"val_1231", %"val_1232", %"val_1233") {axis=0}
    1714 |  # node_view_7
            %"view_7"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_29", %"val_1234") {allowzero=1}
    1715 |  # node_Transpose_1221
            %"val_1235"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.attn.Wo.weight"{...}) {perm=(1, 0)}
    1716 |  # node_linear_13
            %"linear_13"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_7", %"val_1235")
    1717 |  # node_add_14
            %"add_14"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_11", %"linear_13")
    1718 |  # node_layer_norm_7
            %"layer_norm_7"<FLOAT,[1,97,768]>, %"val_1236"<?,?>, %"val_1237"<?,?> ⬅️ ::LayerNormalization(%"add_14", %"encoder.layers.3.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1719 |  # node_Transpose_1222
            %"val_1238"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1720 |  # node_linear_14
            %"linear_14"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_7", %"val_1238")
    1721 |  # node_split_3
            %"split_3"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_14", %"val_917") {dim=-1}
    1722 |  # node_getitem_18
            %"getitem_18"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_3", %"val_6")
    1723 |  # node_getitem_19
            %"getitem_19"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_3", %"val_51")
    1724 |  # node_Constant_1223
            %"val_1239"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1725 |  # node_Div_1224
            %"val_1240"<?,?> ⬅️ ::Div(%"getitem_18", %"val_1239")
    1726 |  # node_Erf_1225
            %"val_1241"<?,?> ⬅️ ::Erf(%"val_1240")
    1727 |  # node_Constant_1226
            %"val_1242"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1728 |  # node_Add_1227
            %"val_1243"<?,?> ⬅️ ::Add(%"val_1241", %"val_1242")
    1729 |  # node_Constant_1228
            %"val_1244"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1730 |  # node_Mul_1229
            %"val_1245"<?,?> ⬅️ ::Mul(%"val_1244", %"val_1243")
    1731 |  # node_gelu_3
            %"gelu_3"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_18", %"val_1245")
    1732 |  # node_mul_63
            %"mul_63"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_3", %"getitem_19")
    1733 |  # node_clone_5
            %"clone_5"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_63")
    1734 |  # node_Transpose_1230
            %"val_1246"<?,?> ⬅️ ::Transpose(%"encoder.layers.3.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1735 |  # node_linear_15
            %"linear_15"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_5", %"val_1246")
    1736 |  # node_add_15
            %"add_15"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_14", %"linear_15")
    1737 |  # node_layer_norm_8
            %"layer_norm_8"<FLOAT,[1,97,768]>, %"val_1247"<?,?>, %"val_1248"<?,?> ⬅️ ::LayerNormalization(%"add_15", %"encoder.layers.4.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1738 |  # node_Transpose_1231
            %"val_1249"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1739 |  # node_linear_16
            %"linear_16"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_8", %"val_1249")
    1740 |  # node_Constant_1232
            %"val_1250"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1741 |  # node_Constant_1233
            %"val_1251"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1742 |  # node_Constant_1234
            %"val_1252"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1743 |  # node_Constant_1235
            %"val_1253"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    1744 |  # node_Constant_1236
            %"val_1254"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    1745 |  # node_Constant_1237
            %"val_1255"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    1746 |  # node_Concat_1238
            %"val_1256"<?,?> ⬅️ ::Concat(%"val_1251", %"val_1252", %"val_1253", %"val_1254", %"val_1255") {axis=0}
    1747 |  # node_view_8
            %"view_8"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_16", %"val_1256") {allowzero=1}
    1748 |  # node_transpose_30
            %"transpose_30"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_8") {perm=(0, 3, 2, 1, 4)}
    1749 |  # node_Constant_1239
            %"val_1257"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    1750 |  # node_Constant_1240
            %"val_1258"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1751 |  # node_Constant_1241
            %"val_1259"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1752 |  # node_Slice_1242
            %"val_1260"<?,?> ⬅️ ::Slice(%"transpose_30", %"val_1257", %"val_1258", %"val_1259")
    1753 |  # node_unbind_4__0
            %"getitem_20"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1260", %"val_19")
    1754 |  # node_Constant_1243
            %"val_1261"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1755 |  # node_Constant_1244
            %"val_1262"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1756 |  # node_Constant_1245
            %"val_1263"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1757 |  # node_Slice_1246
            %"val_1264"<?,?> ⬅️ ::Slice(%"transpose_30", %"val_1261", %"val_1262", %"val_1263")
    1758 |  # node_unbind_4__1
            %"getitem_21"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1264", %"val_19")
    1759 |  # node_Constant_1247
            %"val_1265"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1760 |  # node_Constant_1248
            %"val_1266"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    1761 |  # node_Constant_1249
            %"val_1267"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1762 |  # node_Slice_1250
            %"val_1268"<?,?> ⬅️ ::Slice(%"transpose_30", %"val_1265", %"val_1266", %"val_1267")
    1763 |  # node_unbind_4__2
            %"getitem_22"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1268", %"val_19")
    1764 |  # node_unsqueeze_80
            %"unsqueeze_80"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1765 |  # node_unsqueeze_81
            %"unsqueeze_81"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1766 |  # node_mul_64
            %"mul_64"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_20", %"unsqueeze_80")
    1767 |  # node_Cast_1251
            %"val_1269"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1768 |  # node_Constant_1252
            %"val_1270"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1769 |  # node_Reshape_1253
            %"val_1271"<?,?> ⬅️ ::Reshape(%"val_1269", %"val_1270") {allowzero=0}
    1770 |  # node_Cast_1254
            %"val_1272"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1771 |  # node_Constant_1255
            %"val_1273"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1772 |  # node_Reshape_1256
            %"val_1274"<?,?> ⬅️ ::Reshape(%"val_1272", %"val_1273") {allowzero=0}
    1773 |  # node_Cast_1257
            %"val_1275"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1774 |  # node_Constant_1258
            %"val_1276"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1775 |  # node_Reshape_1259
            %"val_1277"<?,?> ⬅️ ::Reshape(%"val_1275", %"val_1276") {allowzero=0}
    1776 |  # node_Constant_1260
            %"val_1278"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1777 |  # node_slice_85
            %"slice_85"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_20", %"val_1271", %"val_1274", %"val_1277", %"val_1278")
    1778 |  # node_Cast_1261
            %"val_1279"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1779 |  # node_Constant_1262
            %"val_1280"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1780 |  # node_Reshape_1263
            %"val_1281"<?,?> ⬅️ ::Reshape(%"val_1279", %"val_1280") {allowzero=0}
    1781 |  # node_Cast_1264
            %"val_1282"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1782 |  # node_Constant_1265
            %"val_1283"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1783 |  # node_Reshape_1266
            %"val_1284"<?,?> ⬅️ ::Reshape(%"val_1282", %"val_1283") {allowzero=0}
    1784 |  # node_Cast_1267
            %"val_1285"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1785 |  # node_Constant_1268
            %"val_1286"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1786 |  # node_Reshape_1269
            %"val_1287"<?,?> ⬅️ ::Reshape(%"val_1285", %"val_1286") {allowzero=0}
    1787 |  # node_Constant_1270
            %"val_1288"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1788 |  # node_slice_86
            %"slice_86"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_20", %"val_1281", %"val_1284", %"val_1287", %"val_1288")
    1789 |  # node_neg_8
            %"neg_8"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_86")
    1790 |  # node_cat_30
            %"cat_30"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_8", %"slice_85") {axis=-1}
    1791 |  # node_mul_65
            %"mul_65"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_30", %"unsqueeze_81")
    1792 |  # node_add_16
            %"add_16"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_64", %"mul_65")
    1793 |  # node_mul_66
            %"mul_66"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_21", %"unsqueeze_80")
    1794 |  # node_Cast_1271
            %"val_1289"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1795 |  # node_Constant_1272
            %"val_1290"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1796 |  # node_Reshape_1273
            %"val_1291"<?,?> ⬅️ ::Reshape(%"val_1289", %"val_1290") {allowzero=0}
    1797 |  # node_Cast_1274
            %"val_1292"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1798 |  # node_Constant_1275
            %"val_1293"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1799 |  # node_Reshape_1276
            %"val_1294"<?,?> ⬅️ ::Reshape(%"val_1292", %"val_1293") {allowzero=0}
    1800 |  # node_Cast_1277
            %"val_1295"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1801 |  # node_Constant_1278
            %"val_1296"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1802 |  # node_Reshape_1279
            %"val_1297"<?,?> ⬅️ ::Reshape(%"val_1295", %"val_1296") {allowzero=0}
    1803 |  # node_Constant_1280
            %"val_1298"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1804 |  # node_slice_87
            %"slice_87"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_21", %"val_1291", %"val_1294", %"val_1297", %"val_1298")
    1805 |  # node_Cast_1281
            %"val_1299"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1806 |  # node_Constant_1282
            %"val_1300"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1807 |  # node_Reshape_1283
            %"val_1301"<?,?> ⬅️ ::Reshape(%"val_1299", %"val_1300") {allowzero=0}
    1808 |  # node_Cast_1284
            %"val_1302"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1809 |  # node_Constant_1285
            %"val_1303"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1810 |  # node_Reshape_1286
            %"val_1304"<?,?> ⬅️ ::Reshape(%"val_1302", %"val_1303") {allowzero=0}
    1811 |  # node_Cast_1287
            %"val_1305"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1812 |  # node_Constant_1288
            %"val_1306"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1813 |  # node_Reshape_1289
            %"val_1307"<?,?> ⬅️ ::Reshape(%"val_1305", %"val_1306") {allowzero=0}
    1814 |  # node_Constant_1290
            %"val_1308"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1815 |  # node_slice_88
            %"slice_88"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_21", %"val_1301", %"val_1304", %"val_1307", %"val_1308")
    1816 |  # node_neg_9
            %"neg_9"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_88")
    1817 |  # node_cat_31
            %"cat_31"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_9", %"slice_87") {axis=-1}
    1818 |  # node_mul_67
            %"mul_67"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_31", %"unsqueeze_81")
    1819 |  # node_add_17
            %"add_17"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_66", %"mul_67")
    1820 |  # node_Shape_1291
            %"val_1309"<?,?> ⬅️ ::Shape(%"add_16") {start=0}
    1821 |  # node_Constant_1292
            %"val_1310"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1822 |  # node_Gather_1293
            %"val_1311"<?,?> ⬅️ ::Gather(%"val_1309", %"val_1310") {axis=0}
    1823 |  # node_CastLike_1294
            %"val_1312"<?,?> ⬅️ ::CastLike(%"val_1311", %"add_16")
    1824 |  # node_Constant_1295
            %"val_1313"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1825 |  # node_CastLike_1296
            %"val_1314"<?,?> ⬅️ ::CastLike(%"val_1313", %"add_16")
    1826 |  # node_Sqrt_1297
            %"val_1315"<?,?> ⬅️ ::Sqrt(%"val_1312")
    1827 |  # node_Div_1298
            %"val_1316"<?,?> ⬅️ ::Div(%"val_1314", %"val_1315")
    1828 |  # node_CastLike_1299
            %"val_1317"<?,?> ⬅️ ::CastLike(%"val_1316", %"add_16")
    1829 |  # node_Shape_1300
            %"val_1318"<?,?> ⬅️ ::Shape(%"add_17") {start=0}
    1830 |  # node_Constant_1301
            %"val_1319"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1831 |  # node_Slice_1302
            %"val_1320"<?,?> ⬅️ ::Slice(%"val_1318", %"val_889", %"val_1319")
    1832 |  # node_Slice_1303
            %"val_1321"<?,?> ⬅️ ::Slice(%"val_1318", %"val_891", %"val_889")
    1833 |  # node_Constant_1304
            %"val_1322"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1834 |  # node_Slice_1305
            %"val_1323"<?,?> ⬅️ ::Slice(%"val_1318", %"val_1322", %"val_891")
    1835 |  # node_Constant_1306
            %"val_1324"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1836 |  # node_Concat_1307
            %"val_1325"<?,?> ⬅️ ::Concat(%"val_1324", %"val_1321", %"val_1320") {axis=0}
    1837 |  # node_Reshape_1308
            %"val_1326"<?,?> ⬅️ ::Reshape(%"add_17", %"val_1325") {allowzero=0}
    1838 |  # node_Transpose_1309
            %"val_1327"<?,?> ⬅️ ::Transpose(%"val_1326") {perm=(0, 2, 1)}
    1839 |  # node_Concat_1310
            %"val_1328"<?,?> ⬅️ ::Concat(%"val_1323", %"val_1320", %"val_1321") {axis=0}
    1840 |  # node_Reshape_1311
            %"val_1329"<?,?> ⬅️ ::Reshape(%"val_1327", %"val_1328") {allowzero=0}
    1841 |  # node_Sqrt_1312
            %"val_1330"<?,?> ⬅️ ::Sqrt(%"val_1317")
    1842 |  # node_Mul_1313
            %"val_1331"<?,?> ⬅️ ::Mul(%"add_16", %"val_1330")
    1843 |  # node_Sqrt_1314
            %"val_1332"<?,?> ⬅️ ::Sqrt(%"val_1317")
    1844 |  # node_Mul_1315
            %"val_1333"<?,?> ⬅️ ::Mul(%"val_1329", %"val_1332")
    1845 |  # node_MatMul_1316
            %"val_1334"<?,?> ⬅️ ::MatMul(%"val_1331", %"val_1333")
    1846 |  # node_Add_1317
            %"val_1335"<?,?> ⬅️ ::Add(%"val_1334", %"masked_fill_1")
    1847 |  # node_Softmax_1318
            %"val_1336"<?,?> ⬅️ ::Softmax(%"val_1335") {axis=-1}
    1848 |  # node_scaled_dot_product_attention_4
            %"scaled_dot_product_attention_4"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1336", %"getitem_22")
    1849 |  # node_transpose_31
            %"transpose_31"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_4") {perm=(0, 2, 1, 3)}
    1850 |  # node_Constant_1319
            %"val_1337"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1851 |  # node_Constant_1320
            %"val_1338"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1852 |  # node_Constant_1321
            %"val_1339"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1853 |  # node_Constant_1322
            %"val_1340"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    1854 |  # node_Concat_1323
            %"val_1341"<?,?> ⬅️ ::Concat(%"val_1338", %"val_1339", %"val_1340") {axis=0}
    1855 |  # node_view_9
            %"view_9"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_31", %"val_1341") {allowzero=1}
    1856 |  # node_Transpose_1324
            %"val_1342"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.attn.Wo.weight"{...}) {perm=(1, 0)}
    1857 |  # node_linear_17
            %"linear_17"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_9", %"val_1342")
    1858 |  # node_add_18
            %"add_18"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_15", %"linear_17")
    1859 |  # node_layer_norm_9
            %"layer_norm_9"<FLOAT,[1,97,768]>, %"val_1343"<?,?>, %"val_1344"<?,?> ⬅️ ::LayerNormalization(%"add_18", %"encoder.layers.4.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1860 |  # node_Transpose_1325
            %"val_1345"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.mlp.Wi.weight"{...}) {perm=(1, 0)}
    1861 |  # node_linear_18
            %"linear_18"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_9", %"val_1345")
    1862 |  # node_split_4
            %"split_4"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_18", %"val_917") {dim=-1}
    1863 |  # node_getitem_23
            %"getitem_23"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_4", %"val_6")
    1864 |  # node_getitem_24
            %"getitem_24"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_4", %"val_51")
    1865 |  # node_Constant_1326
            %"val_1346"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    1866 |  # node_Div_1327
            %"val_1347"<?,?> ⬅️ ::Div(%"getitem_23", %"val_1346")
    1867 |  # node_Erf_1328
            %"val_1348"<?,?> ⬅️ ::Erf(%"val_1347")
    1868 |  # node_Constant_1329
            %"val_1349"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    1869 |  # node_Add_1330
            %"val_1350"<?,?> ⬅️ ::Add(%"val_1348", %"val_1349")
    1870 |  # node_Constant_1331
            %"val_1351"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    1871 |  # node_Mul_1332
            %"val_1352"<?,?> ⬅️ ::Mul(%"val_1351", %"val_1350")
    1872 |  # node_gelu_4
            %"gelu_4"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_23", %"val_1352")
    1873 |  # node_mul_68
            %"mul_68"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_4", %"getitem_24")
    1874 |  # node_clone_6
            %"clone_6"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_68")
    1875 |  # node_Transpose_1333
            %"val_1353"<?,?> ⬅️ ::Transpose(%"encoder.layers.4.mlp.Wo.weight"{...}) {perm=(1, 0)}
    1876 |  # node_linear_19
            %"linear_19"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_6", %"val_1353")
    1877 |  # node_add_19
            %"add_19"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_18", %"linear_19")
    1878 |  # node_layer_norm_10
            %"layer_norm_10"<FLOAT,[1,97,768]>, %"val_1354"<?,?>, %"val_1355"<?,?> ⬅️ ::LayerNormalization(%"add_19", %"encoder.layers.5.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    1879 |  # node_Transpose_1334
            %"val_1356"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    1880 |  # node_linear_20
            %"linear_20"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_10", %"val_1356")
    1881 |  # node_Constant_1335
            %"val_1357"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1882 |  # node_Constant_1336
            %"val_1358"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1883 |  # node_Constant_1337
            %"val_1359"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1884 |  # node_Constant_1338
            %"val_1360"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    1885 |  # node_Constant_1339
            %"val_1361"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    1886 |  # node_Constant_1340
            %"val_1362"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    1887 |  # node_Concat_1341
            %"val_1363"<?,?> ⬅️ ::Concat(%"val_1358", %"val_1359", %"val_1360", %"val_1361", %"val_1362") {axis=0}
    1888 |  # node_view_10
            %"view_10"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_20", %"val_1363") {allowzero=1}
    1889 |  # node_transpose_32
            %"transpose_32"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_10") {perm=(0, 3, 2, 1, 4)}
    1890 |  # node_Constant_1342
            %"val_1364"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    1891 |  # node_Constant_1343
            %"val_1365"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1892 |  # node_Constant_1344
            %"val_1366"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1893 |  # node_Slice_1345
            %"val_1367"<?,?> ⬅️ ::Slice(%"transpose_32", %"val_1364", %"val_1365", %"val_1366")
    1894 |  # node_unbind_5__0
            %"getitem_25"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1367", %"val_19")
    1895 |  # node_Constant_1346
            %"val_1368"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1896 |  # node_Constant_1347
            %"val_1369"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1897 |  # node_Constant_1348
            %"val_1370"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1898 |  # node_Slice_1349
            %"val_1371"<?,?> ⬅️ ::Slice(%"transpose_32", %"val_1368", %"val_1369", %"val_1370")
    1899 |  # node_unbind_5__1
            %"getitem_26"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1371", %"val_19")
    1900 |  # node_Constant_1350
            %"val_1372"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1901 |  # node_Constant_1351
            %"val_1373"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    1902 |  # node_Constant_1352
            %"val_1374"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    1903 |  # node_Slice_1353
            %"val_1375"<?,?> ⬅️ ::Slice(%"transpose_32", %"val_1372", %"val_1373", %"val_1374")
    1904 |  # node_unbind_5__2
            %"getitem_27"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1375", %"val_19")
    1905 |  # node_unsqueeze_82
            %"unsqueeze_82"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    1906 |  # node_unsqueeze_83
            %"unsqueeze_83"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    1907 |  # node_mul_69
            %"mul_69"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_25", %"unsqueeze_82")
    1908 |  # node_Cast_1354
            %"val_1376"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1909 |  # node_Constant_1355
            %"val_1377"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1910 |  # node_Reshape_1356
            %"val_1378"<?,?> ⬅️ ::Reshape(%"val_1376", %"val_1377") {allowzero=0}
    1911 |  # node_Cast_1357
            %"val_1379"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1912 |  # node_Constant_1358
            %"val_1380"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1913 |  # node_Reshape_1359
            %"val_1381"<?,?> ⬅️ ::Reshape(%"val_1379", %"val_1380") {allowzero=0}
    1914 |  # node_Cast_1360
            %"val_1382"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1915 |  # node_Constant_1361
            %"val_1383"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1916 |  # node_Reshape_1362
            %"val_1384"<?,?> ⬅️ ::Reshape(%"val_1382", %"val_1383") {allowzero=0}
    1917 |  # node_Constant_1363
            %"val_1385"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1918 |  # node_slice_89
            %"slice_89"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_25", %"val_1378", %"val_1381", %"val_1384", %"val_1385")
    1919 |  # node_Cast_1364
            %"val_1386"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1920 |  # node_Constant_1365
            %"val_1387"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1921 |  # node_Reshape_1366
            %"val_1388"<?,?> ⬅️ ::Reshape(%"val_1386", %"val_1387") {allowzero=0}
    1922 |  # node_Cast_1367
            %"val_1389"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1923 |  # node_Constant_1368
            %"val_1390"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1924 |  # node_Reshape_1369
            %"val_1391"<?,?> ⬅️ ::Reshape(%"val_1389", %"val_1390") {allowzero=0}
    1925 |  # node_Cast_1370
            %"val_1392"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1926 |  # node_Constant_1371
            %"val_1393"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1927 |  # node_Reshape_1372
            %"val_1394"<?,?> ⬅️ ::Reshape(%"val_1392", %"val_1393") {allowzero=0}
    1928 |  # node_Constant_1373
            %"val_1395"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1929 |  # node_slice_90
            %"slice_90"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_25", %"val_1388", %"val_1391", %"val_1394", %"val_1395")
    1930 |  # node_neg_10
            %"neg_10"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_90")
    1931 |  # node_cat_32
            %"cat_32"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_10", %"slice_89") {axis=-1}
    1932 |  # node_mul_70
            %"mul_70"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_32", %"unsqueeze_83")
    1933 |  # node_add_20
            %"add_20"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_69", %"mul_70")
    1934 |  # node_mul_71
            %"mul_71"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_26", %"unsqueeze_82")
    1935 |  # node_Cast_1374
            %"val_1396"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    1936 |  # node_Constant_1375
            %"val_1397"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1937 |  # node_Reshape_1376
            %"val_1398"<?,?> ⬅️ ::Reshape(%"val_1396", %"val_1397") {allowzero=0}
    1938 |  # node_Cast_1377
            %"val_1399"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1939 |  # node_Constant_1378
            %"val_1400"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1940 |  # node_Reshape_1379
            %"val_1401"<?,?> ⬅️ ::Reshape(%"val_1399", %"val_1400") {allowzero=0}
    1941 |  # node_Cast_1380
            %"val_1402"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1942 |  # node_Constant_1381
            %"val_1403"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1943 |  # node_Reshape_1382
            %"val_1404"<?,?> ⬅️ ::Reshape(%"val_1402", %"val_1403") {allowzero=0}
    1944 |  # node_Constant_1383
            %"val_1405"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1945 |  # node_slice_91
            %"slice_91"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_26", %"val_1398", %"val_1401", %"val_1404", %"val_1405")
    1946 |  # node_Cast_1384
            %"val_1406"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    1947 |  # node_Constant_1385
            %"val_1407"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1948 |  # node_Reshape_1386
            %"val_1408"<?,?> ⬅️ ::Reshape(%"val_1406", %"val_1407") {allowzero=0}
    1949 |  # node_Cast_1387
            %"val_1409"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    1950 |  # node_Constant_1388
            %"val_1410"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1951 |  # node_Reshape_1389
            %"val_1411"<?,?> ⬅️ ::Reshape(%"val_1409", %"val_1410") {allowzero=0}
    1952 |  # node_Cast_1390
            %"val_1412"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    1953 |  # node_Constant_1391
            %"val_1413"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1954 |  # node_Reshape_1392
            %"val_1414"<?,?> ⬅️ ::Reshape(%"val_1412", %"val_1413") {allowzero=0}
    1955 |  # node_Constant_1393
            %"val_1415"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    1956 |  # node_slice_92
            %"slice_92"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_26", %"val_1408", %"val_1411", %"val_1414", %"val_1415")
    1957 |  # node_neg_11
            %"neg_11"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_92")
    1958 |  # node_cat_33
            %"cat_33"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_11", %"slice_91") {axis=-1}
    1959 |  # node_mul_72
            %"mul_72"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_33", %"unsqueeze_83")
    1960 |  # node_add_21
            %"add_21"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_71", %"mul_72")
    1961 |  # node_Shape_1394
            %"val_1416"<?,?> ⬅️ ::Shape(%"add_20") {start=0}
    1962 |  # node_Constant_1395
            %"val_1417"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1963 |  # node_Gather_1396
            %"val_1418"<?,?> ⬅️ ::Gather(%"val_1416", %"val_1417") {axis=0}
    1964 |  # node_CastLike_1397
            %"val_1419"<?,?> ⬅️ ::CastLike(%"val_1418", %"add_20")
    1965 |  # node_Constant_1398
            %"val_1420"<?,?> ⬅️ ::Constant() {value_float=1.0}
    1966 |  # node_CastLike_1399
            %"val_1421"<?,?> ⬅️ ::CastLike(%"val_1420", %"add_20")
    1967 |  # node_Sqrt_1400
            %"val_1422"<?,?> ⬅️ ::Sqrt(%"val_1419")
    1968 |  # node_Div_1401
            %"val_1423"<?,?> ⬅️ ::Div(%"val_1421", %"val_1422")
    1969 |  # node_CastLike_1402
            %"val_1424"<?,?> ⬅️ ::CastLike(%"val_1423", %"add_20")
    1970 |  # node_Shape_1403
            %"val_1425"<?,?> ⬅️ ::Shape(%"add_21") {start=0}
    1971 |  # node_Constant_1404
            %"val_1426"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    1972 |  # node_Slice_1405
            %"val_1427"<?,?> ⬅️ ::Slice(%"val_1425", %"val_889", %"val_1426")
    1973 |  # node_Slice_1406
            %"val_1428"<?,?> ⬅️ ::Slice(%"val_1425", %"val_891", %"val_889")
    1974 |  # node_Constant_1407
            %"val_1429"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    1975 |  # node_Slice_1408
            %"val_1430"<?,?> ⬅️ ::Slice(%"val_1425", %"val_1429", %"val_891")
    1976 |  # node_Constant_1409
            %"val_1431"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1977 |  # node_Concat_1410
            %"val_1432"<?,?> ⬅️ ::Concat(%"val_1431", %"val_1428", %"val_1427") {axis=0}
    1978 |  # node_Reshape_1411
            %"val_1433"<?,?> ⬅️ ::Reshape(%"add_21", %"val_1432") {allowzero=0}
    1979 |  # node_Transpose_1412
            %"val_1434"<?,?> ⬅️ ::Transpose(%"val_1433") {perm=(0, 2, 1)}
    1980 |  # node_Concat_1413
            %"val_1435"<?,?> ⬅️ ::Concat(%"val_1430", %"val_1427", %"val_1428") {axis=0}
    1981 |  # node_Reshape_1414
            %"val_1436"<?,?> ⬅️ ::Reshape(%"val_1434", %"val_1435") {allowzero=0}
    1982 |  # node_Sqrt_1415
            %"val_1437"<?,?> ⬅️ ::Sqrt(%"val_1424")
    1983 |  # node_Mul_1416
            %"val_1438"<?,?> ⬅️ ::Mul(%"add_20", %"val_1437")
    1984 |  # node_Sqrt_1417
            %"val_1439"<?,?> ⬅️ ::Sqrt(%"val_1424")
    1985 |  # node_Mul_1418
            %"val_1440"<?,?> ⬅️ ::Mul(%"val_1436", %"val_1439")
    1986 |  # node_MatMul_1419
            %"val_1441"<?,?> ⬅️ ::MatMul(%"val_1438", %"val_1440")
    1987 |  # node_Add_1420
            %"val_1442"<?,?> ⬅️ ::Add(%"val_1441", %"masked_fill_1")
    1988 |  # node_Softmax_1421
            %"val_1443"<?,?> ⬅️ ::Softmax(%"val_1442") {axis=-1}
    1989 |  # node_scaled_dot_product_attention_5
            %"scaled_dot_product_attention_5"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1443", %"getitem_27")
    1990 |  # node_transpose_33
            %"transpose_33"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_5") {perm=(0, 2, 1, 3)}
    1991 |  # node_Constant_1422
            %"val_1444"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1992 |  # node_Constant_1423
            %"val_1445"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    1993 |  # node_Constant_1424
            %"val_1446"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    1994 |  # node_Constant_1425
            %"val_1447"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    1995 |  # node_Concat_1426
            %"val_1448"<?,?> ⬅️ ::Concat(%"val_1445", %"val_1446", %"val_1447") {axis=0}
    1996 |  # node_view_11
            %"view_11"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_33", %"val_1448") {allowzero=1}
    1997 |  # node_Transpose_1427
            %"val_1449"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.attn.Wo.weight"{...}) {perm=(1, 0)}
    1998 |  # node_linear_21
            %"linear_21"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_11", %"val_1449")
    1999 |  # node_add_22
            %"add_22"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_19", %"linear_21")
    2000 |  # node_layer_norm_11
            %"layer_norm_11"<FLOAT,[1,97,768]>, %"val_1450"<?,?>, %"val_1451"<?,?> ⬅️ ::LayerNormalization(%"add_22", %"encoder.layers.5.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2001 |  # node_Transpose_1428
            %"val_1452"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2002 |  # node_linear_22
            %"linear_22"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_11", %"val_1452")
    2003 |  # node_split_5
            %"split_5"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_22", %"val_917") {dim=-1}
    2004 |  # node_getitem_28
            %"getitem_28"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_5", %"val_6")
    2005 |  # node_getitem_29
            %"getitem_29"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_5", %"val_51")
    2006 |  # node_Constant_1429
            %"val_1453"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2007 |  # node_Div_1430
            %"val_1454"<?,?> ⬅️ ::Div(%"getitem_28", %"val_1453")
    2008 |  # node_Erf_1431
            %"val_1455"<?,?> ⬅️ ::Erf(%"val_1454")
    2009 |  # node_Constant_1432
            %"val_1456"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2010 |  # node_Add_1433
            %"val_1457"<?,?> ⬅️ ::Add(%"val_1455", %"val_1456")
    2011 |  # node_Constant_1434
            %"val_1458"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2012 |  # node_Mul_1435
            %"val_1459"<?,?> ⬅️ ::Mul(%"val_1458", %"val_1457")
    2013 |  # node_gelu_5
            %"gelu_5"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_28", %"val_1459")
    2014 |  # node_mul_73
            %"mul_73"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_5", %"getitem_29")
    2015 |  # node_clone_7
            %"clone_7"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_73")
    2016 |  # node_Transpose_1436
            %"val_1460"<?,?> ⬅️ ::Transpose(%"encoder.layers.5.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2017 |  # node_linear_23
            %"linear_23"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_7", %"val_1460")
    2018 |  # node_add_23
            %"add_23"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_22", %"linear_23")
    2019 |  # node_layer_norm_12
            %"layer_norm_12"<FLOAT,[1,97,768]>, %"val_1461"<?,?>, %"val_1462"<?,?> ⬅️ ::LayerNormalization(%"add_23", %"encoder.layers.6.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2020 |  # node_Transpose_1437
            %"val_1463"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2021 |  # node_linear_24
            %"linear_24"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_12", %"val_1463")
    2022 |  # node_Constant_1438
            %"val_1464"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2023 |  # node_Constant_1439
            %"val_1465"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2024 |  # node_Constant_1440
            %"val_1466"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2025 |  # node_Constant_1441
            %"val_1467"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2026 |  # node_Constant_1442
            %"val_1468"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2027 |  # node_Constant_1443
            %"val_1469"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2028 |  # node_Concat_1444
            %"val_1470"<?,?> ⬅️ ::Concat(%"val_1465", %"val_1466", %"val_1467", %"val_1468", %"val_1469") {axis=0}
    2029 |  # node_view_12
            %"view_12"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_24", %"val_1470") {allowzero=1}
    2030 |  # node_transpose_34
            %"transpose_34"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_12") {perm=(0, 3, 2, 1, 4)}
    2031 |  # node_Constant_1445
            %"val_1471"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2032 |  # node_Constant_1446
            %"val_1472"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2033 |  # node_Constant_1447
            %"val_1473"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2034 |  # node_Slice_1448
            %"val_1474"<?,?> ⬅️ ::Slice(%"transpose_34", %"val_1471", %"val_1472", %"val_1473")
    2035 |  # node_unbind_6__0
            %"getitem_30"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1474", %"val_19")
    2036 |  # node_Constant_1449
            %"val_1475"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2037 |  # node_Constant_1450
            %"val_1476"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2038 |  # node_Constant_1451
            %"val_1477"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2039 |  # node_Slice_1452
            %"val_1478"<?,?> ⬅️ ::Slice(%"transpose_34", %"val_1475", %"val_1476", %"val_1477")
    2040 |  # node_unbind_6__1
            %"getitem_31"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1478", %"val_19")
    2041 |  # node_Constant_1453
            %"val_1479"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2042 |  # node_Constant_1454
            %"val_1480"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2043 |  # node_Constant_1455
            %"val_1481"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2044 |  # node_Slice_1456
            %"val_1482"<?,?> ⬅️ ::Slice(%"transpose_34", %"val_1479", %"val_1480", %"val_1481")
    2045 |  # node_unbind_6__2
            %"getitem_32"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1482", %"val_19")
    2046 |  # node_unsqueeze_84
            %"unsqueeze_84"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    2047 |  # node_unsqueeze_85
            %"unsqueeze_85"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    2048 |  # node_mul_74
            %"mul_74"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_30", %"unsqueeze_84")
    2049 |  # node_Cast_1457
            %"val_1483"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2050 |  # node_Constant_1458
            %"val_1484"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2051 |  # node_Reshape_1459
            %"val_1485"<?,?> ⬅️ ::Reshape(%"val_1483", %"val_1484") {allowzero=0}
    2052 |  # node_Cast_1460
            %"val_1486"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2053 |  # node_Constant_1461
            %"val_1487"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2054 |  # node_Reshape_1462
            %"val_1488"<?,?> ⬅️ ::Reshape(%"val_1486", %"val_1487") {allowzero=0}
    2055 |  # node_Cast_1463
            %"val_1489"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2056 |  # node_Constant_1464
            %"val_1490"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2057 |  # node_Reshape_1465
            %"val_1491"<?,?> ⬅️ ::Reshape(%"val_1489", %"val_1490") {allowzero=0}
    2058 |  # node_Constant_1466
            %"val_1492"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2059 |  # node_slice_93
            %"slice_93"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_30", %"val_1485", %"val_1488", %"val_1491", %"val_1492")
    2060 |  # node_Cast_1467
            %"val_1493"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2061 |  # node_Constant_1468
            %"val_1494"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2062 |  # node_Reshape_1469
            %"val_1495"<?,?> ⬅️ ::Reshape(%"val_1493", %"val_1494") {allowzero=0}
    2063 |  # node_Cast_1470
            %"val_1496"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2064 |  # node_Constant_1471
            %"val_1497"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2065 |  # node_Reshape_1472
            %"val_1498"<?,?> ⬅️ ::Reshape(%"val_1496", %"val_1497") {allowzero=0}
    2066 |  # node_Cast_1473
            %"val_1499"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2067 |  # node_Constant_1474
            %"val_1500"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2068 |  # node_Reshape_1475
            %"val_1501"<?,?> ⬅️ ::Reshape(%"val_1499", %"val_1500") {allowzero=0}
    2069 |  # node_Constant_1476
            %"val_1502"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2070 |  # node_slice_94
            %"slice_94"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_30", %"val_1495", %"val_1498", %"val_1501", %"val_1502")
    2071 |  # node_neg_12
            %"neg_12"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_94")
    2072 |  # node_cat_34
            %"cat_34"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_12", %"slice_93") {axis=-1}
    2073 |  # node_mul_75
            %"mul_75"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_34", %"unsqueeze_85")
    2074 |  # node_add_24
            %"add_24"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_74", %"mul_75")
    2075 |  # node_mul_76
            %"mul_76"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_31", %"unsqueeze_84")
    2076 |  # node_Cast_1477
            %"val_1503"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2077 |  # node_Constant_1478
            %"val_1504"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2078 |  # node_Reshape_1479
            %"val_1505"<?,?> ⬅️ ::Reshape(%"val_1503", %"val_1504") {allowzero=0}
    2079 |  # node_Cast_1480
            %"val_1506"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2080 |  # node_Constant_1481
            %"val_1507"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2081 |  # node_Reshape_1482
            %"val_1508"<?,?> ⬅️ ::Reshape(%"val_1506", %"val_1507") {allowzero=0}
    2082 |  # node_Cast_1483
            %"val_1509"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2083 |  # node_Constant_1484
            %"val_1510"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2084 |  # node_Reshape_1485
            %"val_1511"<?,?> ⬅️ ::Reshape(%"val_1509", %"val_1510") {allowzero=0}
    2085 |  # node_Constant_1486
            %"val_1512"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2086 |  # node_slice_95
            %"slice_95"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_31", %"val_1505", %"val_1508", %"val_1511", %"val_1512")
    2087 |  # node_Cast_1487
            %"val_1513"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2088 |  # node_Constant_1488
            %"val_1514"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2089 |  # node_Reshape_1489
            %"val_1515"<?,?> ⬅️ ::Reshape(%"val_1513", %"val_1514") {allowzero=0}
    2090 |  # node_Cast_1490
            %"val_1516"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2091 |  # node_Constant_1491
            %"val_1517"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2092 |  # node_Reshape_1492
            %"val_1518"<?,?> ⬅️ ::Reshape(%"val_1516", %"val_1517") {allowzero=0}
    2093 |  # node_Cast_1493
            %"val_1519"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2094 |  # node_Constant_1494
            %"val_1520"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2095 |  # node_Reshape_1495
            %"val_1521"<?,?> ⬅️ ::Reshape(%"val_1519", %"val_1520") {allowzero=0}
    2096 |  # node_Constant_1496
            %"val_1522"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2097 |  # node_slice_96
            %"slice_96"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_31", %"val_1515", %"val_1518", %"val_1521", %"val_1522")
    2098 |  # node_neg_13
            %"neg_13"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_96")
    2099 |  # node_cat_35
            %"cat_35"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_13", %"slice_95") {axis=-1}
    2100 |  # node_mul_77
            %"mul_77"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_35", %"unsqueeze_85")
    2101 |  # node_add_25
            %"add_25"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_76", %"mul_77")
    2102 |  # node_Shape_1497
            %"val_1523"<?,?> ⬅️ ::Shape(%"add_24") {start=0}
    2103 |  # node_Constant_1498
            %"val_1524"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2104 |  # node_Gather_1499
            %"val_1525"<?,?> ⬅️ ::Gather(%"val_1523", %"val_1524") {axis=0}
    2105 |  # node_CastLike_1500
            %"val_1526"<?,?> ⬅️ ::CastLike(%"val_1525", %"add_24")
    2106 |  # node_Constant_1501
            %"val_1527"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2107 |  # node_CastLike_1502
            %"val_1528"<?,?> ⬅️ ::CastLike(%"val_1527", %"add_24")
    2108 |  # node_Sqrt_1503
            %"val_1529"<?,?> ⬅️ ::Sqrt(%"val_1526")
    2109 |  # node_Div_1504
            %"val_1530"<?,?> ⬅️ ::Div(%"val_1528", %"val_1529")
    2110 |  # node_CastLike_1505
            %"val_1531"<?,?> ⬅️ ::CastLike(%"val_1530", %"add_24")
    2111 |  # node_Shape_1506
            %"val_1532"<?,?> ⬅️ ::Shape(%"add_25") {start=0}
    2112 |  # node_Constant_1507
            %"val_1533"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2113 |  # node_Slice_1508
            %"val_1534"<?,?> ⬅️ ::Slice(%"val_1532", %"val_889", %"val_1533")
    2114 |  # node_Slice_1509
            %"val_1535"<?,?> ⬅️ ::Slice(%"val_1532", %"val_891", %"val_889")
    2115 |  # node_Constant_1510
            %"val_1536"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2116 |  # node_Slice_1511
            %"val_1537"<?,?> ⬅️ ::Slice(%"val_1532", %"val_1536", %"val_891")
    2117 |  # node_Constant_1512
            %"val_1538"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2118 |  # node_Concat_1513
            %"val_1539"<?,?> ⬅️ ::Concat(%"val_1538", %"val_1535", %"val_1534") {axis=0}
    2119 |  # node_Reshape_1514
            %"val_1540"<?,?> ⬅️ ::Reshape(%"add_25", %"val_1539") {allowzero=0}
    2120 |  # node_Transpose_1515
            %"val_1541"<?,?> ⬅️ ::Transpose(%"val_1540") {perm=(0, 2, 1)}
    2121 |  # node_Concat_1516
            %"val_1542"<?,?> ⬅️ ::Concat(%"val_1537", %"val_1534", %"val_1535") {axis=0}
    2122 |  # node_Reshape_1517
            %"val_1543"<?,?> ⬅️ ::Reshape(%"val_1541", %"val_1542") {allowzero=0}
    2123 |  # node_Sqrt_1518
            %"val_1544"<?,?> ⬅️ ::Sqrt(%"val_1531")
    2124 |  # node_Mul_1519
            %"val_1545"<?,?> ⬅️ ::Mul(%"add_24", %"val_1544")
    2125 |  # node_Sqrt_1520
            %"val_1546"<?,?> ⬅️ ::Sqrt(%"val_1531")
    2126 |  # node_Mul_1521
            %"val_1547"<?,?> ⬅️ ::Mul(%"val_1543", %"val_1546")
    2127 |  # node_MatMul_1522
            %"val_1548"<?,?> ⬅️ ::MatMul(%"val_1545", %"val_1547")
    2128 |  # node_Add_1523
            %"val_1549"<?,?> ⬅️ ::Add(%"val_1548", %"masked_fill")
    2129 |  # node_Softmax_1524
            %"val_1550"<?,?> ⬅️ ::Softmax(%"val_1549") {axis=-1}
    2130 |  # node_scaled_dot_product_attention_6
            %"scaled_dot_product_attention_6"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1550", %"getitem_32")
    2131 |  # node_transpose_35
            %"transpose_35"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_6") {perm=(0, 2, 1, 3)}
    2132 |  # node_Constant_1525
            %"val_1551"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2133 |  # node_Constant_1526
            %"val_1552"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2134 |  # node_Constant_1527
            %"val_1553"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2135 |  # node_Constant_1528
            %"val_1554"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2136 |  # node_Concat_1529
            %"val_1555"<?,?> ⬅️ ::Concat(%"val_1552", %"val_1553", %"val_1554") {axis=0}
    2137 |  # node_view_13
            %"view_13"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_35", %"val_1555") {allowzero=1}
    2138 |  # node_Transpose_1530
            %"val_1556"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.attn.Wo.weight"{...}) {perm=(1, 0)}
    2139 |  # node_linear_25
            %"linear_25"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_13", %"val_1556")
    2140 |  # node_add_26
            %"add_26"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_23", %"linear_25")
    2141 |  # node_layer_norm_13
            %"layer_norm_13"<FLOAT,[1,97,768]>, %"val_1557"<?,?>, %"val_1558"<?,?> ⬅️ ::LayerNormalization(%"add_26", %"encoder.layers.6.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2142 |  # node_Transpose_1531
            %"val_1559"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2143 |  # node_linear_26
            %"linear_26"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_13", %"val_1559")
    2144 |  # node_split_6
            %"split_6"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_26", %"val_917") {dim=-1}
    2145 |  # node_getitem_33
            %"getitem_33"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_6", %"val_6")
    2146 |  # node_getitem_34
            %"getitem_34"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_6", %"val_51")
    2147 |  # node_Constant_1532
            %"val_1560"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2148 |  # node_Div_1533
            %"val_1561"<?,?> ⬅️ ::Div(%"getitem_33", %"val_1560")
    2149 |  # node_Erf_1534
            %"val_1562"<?,?> ⬅️ ::Erf(%"val_1561")
    2150 |  # node_Constant_1535
            %"val_1563"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2151 |  # node_Add_1536
            %"val_1564"<?,?> ⬅️ ::Add(%"val_1562", %"val_1563")
    2152 |  # node_Constant_1537
            %"val_1565"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2153 |  # node_Mul_1538
            %"val_1566"<?,?> ⬅️ ::Mul(%"val_1565", %"val_1564")
    2154 |  # node_gelu_6
            %"gelu_6"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_33", %"val_1566")
    2155 |  # node_mul_78
            %"mul_78"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_6", %"getitem_34")
    2156 |  # node_clone_8
            %"clone_8"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_78")
    2157 |  # node_Transpose_1539
            %"val_1567"<?,?> ⬅️ ::Transpose(%"encoder.layers.6.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2158 |  # node_linear_27
            %"linear_27"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_8", %"val_1567")
    2159 |  # node_add_27
            %"add_27"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_26", %"linear_27")
    2160 |  # node_layer_norm_14
            %"layer_norm_14"<FLOAT,[1,97,768]>, %"val_1568"<?,?>, %"val_1569"<?,?> ⬅️ ::LayerNormalization(%"add_27", %"encoder.layers.7.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2161 |  # node_Transpose_1540
            %"val_1570"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2162 |  # node_linear_28
            %"linear_28"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_14", %"val_1570")
    2163 |  # node_Constant_1541
            %"val_1571"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2164 |  # node_Constant_1542
            %"val_1572"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2165 |  # node_Constant_1543
            %"val_1573"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2166 |  # node_Constant_1544
            %"val_1574"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2167 |  # node_Constant_1545
            %"val_1575"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2168 |  # node_Constant_1546
            %"val_1576"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2169 |  # node_Concat_1547
            %"val_1577"<?,?> ⬅️ ::Concat(%"val_1572", %"val_1573", %"val_1574", %"val_1575", %"val_1576") {axis=0}
    2170 |  # node_view_14
            %"view_14"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_28", %"val_1577") {allowzero=1}
    2171 |  # node_transpose_36
            %"transpose_36"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_14") {perm=(0, 3, 2, 1, 4)}
    2172 |  # node_Constant_1548
            %"val_1578"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2173 |  # node_Constant_1549
            %"val_1579"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2174 |  # node_Constant_1550
            %"val_1580"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2175 |  # node_Slice_1551
            %"val_1581"<?,?> ⬅️ ::Slice(%"transpose_36", %"val_1578", %"val_1579", %"val_1580")
    2176 |  # node_unbind_7__0
            %"getitem_35"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1581", %"val_19")
    2177 |  # node_Constant_1552
            %"val_1582"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2178 |  # node_Constant_1553
            %"val_1583"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2179 |  # node_Constant_1554
            %"val_1584"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2180 |  # node_Slice_1555
            %"val_1585"<?,?> ⬅️ ::Slice(%"transpose_36", %"val_1582", %"val_1583", %"val_1584")
    2181 |  # node_unbind_7__1
            %"getitem_36"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1585", %"val_19")
    2182 |  # node_Constant_1556
            %"val_1586"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2183 |  # node_Constant_1557
            %"val_1587"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2184 |  # node_Constant_1558
            %"val_1588"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2185 |  # node_Slice_1559
            %"val_1589"<?,?> ⬅️ ::Slice(%"transpose_36", %"val_1586", %"val_1587", %"val_1588")
    2186 |  # node_unbind_7__2
            %"getitem_37"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1589", %"val_19")
    2187 |  # node_unsqueeze_86
            %"unsqueeze_86"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2188 |  # node_unsqueeze_87
            %"unsqueeze_87"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2189 |  # node_mul_79
            %"mul_79"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_35", %"unsqueeze_86")
    2190 |  # node_Cast_1560
            %"val_1590"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2191 |  # node_Constant_1561
            %"val_1591"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2192 |  # node_Reshape_1562
            %"val_1592"<?,?> ⬅️ ::Reshape(%"val_1590", %"val_1591") {allowzero=0}
    2193 |  # node_Cast_1563
            %"val_1593"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2194 |  # node_Constant_1564
            %"val_1594"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2195 |  # node_Reshape_1565
            %"val_1595"<?,?> ⬅️ ::Reshape(%"val_1593", %"val_1594") {allowzero=0}
    2196 |  # node_Cast_1566
            %"val_1596"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2197 |  # node_Constant_1567
            %"val_1597"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2198 |  # node_Reshape_1568
            %"val_1598"<?,?> ⬅️ ::Reshape(%"val_1596", %"val_1597") {allowzero=0}
    2199 |  # node_Constant_1569
            %"val_1599"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2200 |  # node_slice_97
            %"slice_97"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_35", %"val_1592", %"val_1595", %"val_1598", %"val_1599")
    2201 |  # node_Cast_1570
            %"val_1600"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2202 |  # node_Constant_1571
            %"val_1601"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2203 |  # node_Reshape_1572
            %"val_1602"<?,?> ⬅️ ::Reshape(%"val_1600", %"val_1601") {allowzero=0}
    2204 |  # node_Cast_1573
            %"val_1603"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2205 |  # node_Constant_1574
            %"val_1604"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2206 |  # node_Reshape_1575
            %"val_1605"<?,?> ⬅️ ::Reshape(%"val_1603", %"val_1604") {allowzero=0}
    2207 |  # node_Cast_1576
            %"val_1606"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2208 |  # node_Constant_1577
            %"val_1607"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2209 |  # node_Reshape_1578
            %"val_1608"<?,?> ⬅️ ::Reshape(%"val_1606", %"val_1607") {allowzero=0}
    2210 |  # node_Constant_1579
            %"val_1609"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2211 |  # node_slice_98
            %"slice_98"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_35", %"val_1602", %"val_1605", %"val_1608", %"val_1609")
    2212 |  # node_neg_14
            %"neg_14"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_98")
    2213 |  # node_cat_36
            %"cat_36"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_14", %"slice_97") {axis=-1}
    2214 |  # node_mul_80
            %"mul_80"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_36", %"unsqueeze_87")
    2215 |  # node_add_28
            %"add_28"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_79", %"mul_80")
    2216 |  # node_mul_81
            %"mul_81"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_36", %"unsqueeze_86")
    2217 |  # node_Cast_1580
            %"val_1610"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2218 |  # node_Constant_1581
            %"val_1611"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2219 |  # node_Reshape_1582
            %"val_1612"<?,?> ⬅️ ::Reshape(%"val_1610", %"val_1611") {allowzero=0}
    2220 |  # node_Cast_1583
            %"val_1613"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2221 |  # node_Constant_1584
            %"val_1614"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2222 |  # node_Reshape_1585
            %"val_1615"<?,?> ⬅️ ::Reshape(%"val_1613", %"val_1614") {allowzero=0}
    2223 |  # node_Cast_1586
            %"val_1616"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2224 |  # node_Constant_1587
            %"val_1617"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2225 |  # node_Reshape_1588
            %"val_1618"<?,?> ⬅️ ::Reshape(%"val_1616", %"val_1617") {allowzero=0}
    2226 |  # node_Constant_1589
            %"val_1619"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2227 |  # node_slice_99
            %"slice_99"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_36", %"val_1612", %"val_1615", %"val_1618", %"val_1619")
    2228 |  # node_Cast_1590
            %"val_1620"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2229 |  # node_Constant_1591
            %"val_1621"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2230 |  # node_Reshape_1592
            %"val_1622"<?,?> ⬅️ ::Reshape(%"val_1620", %"val_1621") {allowzero=0}
    2231 |  # node_Cast_1593
            %"val_1623"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2232 |  # node_Constant_1594
            %"val_1624"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2233 |  # node_Reshape_1595
            %"val_1625"<?,?> ⬅️ ::Reshape(%"val_1623", %"val_1624") {allowzero=0}
    2234 |  # node_Cast_1596
            %"val_1626"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2235 |  # node_Constant_1597
            %"val_1627"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2236 |  # node_Reshape_1598
            %"val_1628"<?,?> ⬅️ ::Reshape(%"val_1626", %"val_1627") {allowzero=0}
    2237 |  # node_Constant_1599
            %"val_1629"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2238 |  # node_slice_100
            %"slice_100"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_36", %"val_1622", %"val_1625", %"val_1628", %"val_1629")
    2239 |  # node_neg_15
            %"neg_15"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_100")
    2240 |  # node_cat_37
            %"cat_37"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_15", %"slice_99") {axis=-1}
    2241 |  # node_mul_82
            %"mul_82"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_37", %"unsqueeze_87")
    2242 |  # node_add_29
            %"add_29"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_81", %"mul_82")
    2243 |  # node_Shape_1600
            %"val_1630"<?,?> ⬅️ ::Shape(%"add_28") {start=0}
    2244 |  # node_Constant_1601
            %"val_1631"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2245 |  # node_Gather_1602
            %"val_1632"<?,?> ⬅️ ::Gather(%"val_1630", %"val_1631") {axis=0}
    2246 |  # node_CastLike_1603
            %"val_1633"<?,?> ⬅️ ::CastLike(%"val_1632", %"add_28")
    2247 |  # node_Constant_1604
            %"val_1634"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2248 |  # node_CastLike_1605
            %"val_1635"<?,?> ⬅️ ::CastLike(%"val_1634", %"add_28")
    2249 |  # node_Sqrt_1606
            %"val_1636"<?,?> ⬅️ ::Sqrt(%"val_1633")
    2250 |  # node_Div_1607
            %"val_1637"<?,?> ⬅️ ::Div(%"val_1635", %"val_1636")
    2251 |  # node_CastLike_1608
            %"val_1638"<?,?> ⬅️ ::CastLike(%"val_1637", %"add_28")
    2252 |  # node_Shape_1609
            %"val_1639"<?,?> ⬅️ ::Shape(%"add_29") {start=0}
    2253 |  # node_Constant_1610
            %"val_1640"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2254 |  # node_Slice_1611
            %"val_1641"<?,?> ⬅️ ::Slice(%"val_1639", %"val_889", %"val_1640")
    2255 |  # node_Slice_1612
            %"val_1642"<?,?> ⬅️ ::Slice(%"val_1639", %"val_891", %"val_889")
    2256 |  # node_Constant_1613
            %"val_1643"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2257 |  # node_Slice_1614
            %"val_1644"<?,?> ⬅️ ::Slice(%"val_1639", %"val_1643", %"val_891")
    2258 |  # node_Constant_1615
            %"val_1645"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2259 |  # node_Concat_1616
            %"val_1646"<?,?> ⬅️ ::Concat(%"val_1645", %"val_1642", %"val_1641") {axis=0}
    2260 |  # node_Reshape_1617
            %"val_1647"<?,?> ⬅️ ::Reshape(%"add_29", %"val_1646") {allowzero=0}
    2261 |  # node_Transpose_1618
            %"val_1648"<?,?> ⬅️ ::Transpose(%"val_1647") {perm=(0, 2, 1)}
    2262 |  # node_Concat_1619
            %"val_1649"<?,?> ⬅️ ::Concat(%"val_1644", %"val_1641", %"val_1642") {axis=0}
    2263 |  # node_Reshape_1620
            %"val_1650"<?,?> ⬅️ ::Reshape(%"val_1648", %"val_1649") {allowzero=0}
    2264 |  # node_Sqrt_1621
            %"val_1651"<?,?> ⬅️ ::Sqrt(%"val_1638")
    2265 |  # node_Mul_1622
            %"val_1652"<?,?> ⬅️ ::Mul(%"add_28", %"val_1651")
    2266 |  # node_Sqrt_1623
            %"val_1653"<?,?> ⬅️ ::Sqrt(%"val_1638")
    2267 |  # node_Mul_1624
            %"val_1654"<?,?> ⬅️ ::Mul(%"val_1650", %"val_1653")
    2268 |  # node_MatMul_1625
            %"val_1655"<?,?> ⬅️ ::MatMul(%"val_1652", %"val_1654")
    2269 |  # node_Add_1626
            %"val_1656"<?,?> ⬅️ ::Add(%"val_1655", %"masked_fill_1")
    2270 |  # node_Softmax_1627
            %"val_1657"<?,?> ⬅️ ::Softmax(%"val_1656") {axis=-1}
    2271 |  # node_scaled_dot_product_attention_7
            %"scaled_dot_product_attention_7"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1657", %"getitem_37")
    2272 |  # node_transpose_37
            %"transpose_37"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_7") {perm=(0, 2, 1, 3)}
    2273 |  # node_Constant_1628
            %"val_1658"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2274 |  # node_Constant_1629
            %"val_1659"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2275 |  # node_Constant_1630
            %"val_1660"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2276 |  # node_Constant_1631
            %"val_1661"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2277 |  # node_Concat_1632
            %"val_1662"<?,?> ⬅️ ::Concat(%"val_1659", %"val_1660", %"val_1661") {axis=0}
    2278 |  # node_view_15
            %"view_15"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_37", %"val_1662") {allowzero=1}
    2279 |  # node_Transpose_1633
            %"val_1663"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.attn.Wo.weight"{...}) {perm=(1, 0)}
    2280 |  # node_linear_29
            %"linear_29"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_15", %"val_1663")
    2281 |  # node_add_30
            %"add_30"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_27", %"linear_29")
    2282 |  # node_layer_norm_15
            %"layer_norm_15"<FLOAT,[1,97,768]>, %"val_1664"<?,?>, %"val_1665"<?,?> ⬅️ ::LayerNormalization(%"add_30", %"encoder.layers.7.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2283 |  # node_Transpose_1634
            %"val_1666"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2284 |  # node_linear_30
            %"linear_30"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_15", %"val_1666")
    2285 |  # node_split_7
            %"split_7"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_30", %"val_917") {dim=-1}
    2286 |  # node_getitem_38
            %"getitem_38"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_7", %"val_6")
    2287 |  # node_getitem_39
            %"getitem_39"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_7", %"val_51")
    2288 |  # node_Constant_1635
            %"val_1667"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2289 |  # node_Div_1636
            %"val_1668"<?,?> ⬅️ ::Div(%"getitem_38", %"val_1667")
    2290 |  # node_Erf_1637
            %"val_1669"<?,?> ⬅️ ::Erf(%"val_1668")
    2291 |  # node_Constant_1638
            %"val_1670"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2292 |  # node_Add_1639
            %"val_1671"<?,?> ⬅️ ::Add(%"val_1669", %"val_1670")
    2293 |  # node_Constant_1640
            %"val_1672"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2294 |  # node_Mul_1641
            %"val_1673"<?,?> ⬅️ ::Mul(%"val_1672", %"val_1671")
    2295 |  # node_gelu_7
            %"gelu_7"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_38", %"val_1673")
    2296 |  # node_mul_83
            %"mul_83"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_7", %"getitem_39")
    2297 |  # node_clone_9
            %"clone_9"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_83")
    2298 |  # node_Transpose_1642
            %"val_1674"<?,?> ⬅️ ::Transpose(%"encoder.layers.7.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2299 |  # node_linear_31
            %"linear_31"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_9", %"val_1674")
    2300 |  # node_add_31
            %"add_31"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_30", %"linear_31")
    2301 |  # node_layer_norm_16
            %"layer_norm_16"<FLOAT,[1,97,768]>, %"val_1675"<?,?>, %"val_1676"<?,?> ⬅️ ::LayerNormalization(%"add_31", %"encoder.layers.8.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2302 |  # node_Transpose_1643
            %"val_1677"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2303 |  # node_linear_32
            %"linear_32"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_16", %"val_1677")
    2304 |  # node_Constant_1644
            %"val_1678"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2305 |  # node_Constant_1645
            %"val_1679"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2306 |  # node_Constant_1646
            %"val_1680"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2307 |  # node_Constant_1647
            %"val_1681"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2308 |  # node_Constant_1648
            %"val_1682"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2309 |  # node_Constant_1649
            %"val_1683"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2310 |  # node_Concat_1650
            %"val_1684"<?,?> ⬅️ ::Concat(%"val_1679", %"val_1680", %"val_1681", %"val_1682", %"val_1683") {axis=0}
    2311 |  # node_view_16
            %"view_16"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_32", %"val_1684") {allowzero=1}
    2312 |  # node_transpose_38
            %"transpose_38"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_16") {perm=(0, 3, 2, 1, 4)}
    2313 |  # node_Constant_1651
            %"val_1685"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2314 |  # node_Constant_1652
            %"val_1686"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2315 |  # node_Constant_1653
            %"val_1687"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2316 |  # node_Slice_1654
            %"val_1688"<?,?> ⬅️ ::Slice(%"transpose_38", %"val_1685", %"val_1686", %"val_1687")
    2317 |  # node_unbind_8__0
            %"getitem_40"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1688", %"val_19")
    2318 |  # node_Constant_1655
            %"val_1689"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2319 |  # node_Constant_1656
            %"val_1690"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2320 |  # node_Constant_1657
            %"val_1691"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2321 |  # node_Slice_1658
            %"val_1692"<?,?> ⬅️ ::Slice(%"transpose_38", %"val_1689", %"val_1690", %"val_1691")
    2322 |  # node_unbind_8__1
            %"getitem_41"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1692", %"val_19")
    2323 |  # node_Constant_1659
            %"val_1693"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2324 |  # node_Constant_1660
            %"val_1694"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2325 |  # node_Constant_1661
            %"val_1695"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2326 |  # node_Slice_1662
            %"val_1696"<?,?> ⬅️ ::Slice(%"transpose_38", %"val_1693", %"val_1694", %"val_1695")
    2327 |  # node_unbind_8__2
            %"getitem_42"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1696", %"val_19")
    2328 |  # node_unsqueeze_88
            %"unsqueeze_88"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2329 |  # node_unsqueeze_89
            %"unsqueeze_89"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2330 |  # node_mul_84
            %"mul_84"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_40", %"unsqueeze_88")
    2331 |  # node_Cast_1663
            %"val_1697"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2332 |  # node_Constant_1664
            %"val_1698"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2333 |  # node_Reshape_1665
            %"val_1699"<?,?> ⬅️ ::Reshape(%"val_1697", %"val_1698") {allowzero=0}
    2334 |  # node_Cast_1666
            %"val_1700"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2335 |  # node_Constant_1667
            %"val_1701"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2336 |  # node_Reshape_1668
            %"val_1702"<?,?> ⬅️ ::Reshape(%"val_1700", %"val_1701") {allowzero=0}
    2337 |  # node_Cast_1669
            %"val_1703"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2338 |  # node_Constant_1670
            %"val_1704"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2339 |  # node_Reshape_1671
            %"val_1705"<?,?> ⬅️ ::Reshape(%"val_1703", %"val_1704") {allowzero=0}
    2340 |  # node_Constant_1672
            %"val_1706"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2341 |  # node_slice_101
            %"slice_101"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_40", %"val_1699", %"val_1702", %"val_1705", %"val_1706")
    2342 |  # node_Cast_1673
            %"val_1707"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2343 |  # node_Constant_1674
            %"val_1708"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2344 |  # node_Reshape_1675
            %"val_1709"<?,?> ⬅️ ::Reshape(%"val_1707", %"val_1708") {allowzero=0}
    2345 |  # node_Cast_1676
            %"val_1710"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2346 |  # node_Constant_1677
            %"val_1711"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2347 |  # node_Reshape_1678
            %"val_1712"<?,?> ⬅️ ::Reshape(%"val_1710", %"val_1711") {allowzero=0}
    2348 |  # node_Cast_1679
            %"val_1713"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2349 |  # node_Constant_1680
            %"val_1714"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2350 |  # node_Reshape_1681
            %"val_1715"<?,?> ⬅️ ::Reshape(%"val_1713", %"val_1714") {allowzero=0}
    2351 |  # node_Constant_1682
            %"val_1716"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2352 |  # node_slice_102
            %"slice_102"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_40", %"val_1709", %"val_1712", %"val_1715", %"val_1716")
    2353 |  # node_neg_16
            %"neg_16"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_102")
    2354 |  # node_cat_38
            %"cat_38"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_16", %"slice_101") {axis=-1}
    2355 |  # node_mul_85
            %"mul_85"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_38", %"unsqueeze_89")
    2356 |  # node_add_32
            %"add_32"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_84", %"mul_85")
    2357 |  # node_mul_86
            %"mul_86"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_41", %"unsqueeze_88")
    2358 |  # node_Cast_1683
            %"val_1717"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2359 |  # node_Constant_1684
            %"val_1718"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2360 |  # node_Reshape_1685
            %"val_1719"<?,?> ⬅️ ::Reshape(%"val_1717", %"val_1718") {allowzero=0}
    2361 |  # node_Cast_1686
            %"val_1720"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2362 |  # node_Constant_1687
            %"val_1721"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2363 |  # node_Reshape_1688
            %"val_1722"<?,?> ⬅️ ::Reshape(%"val_1720", %"val_1721") {allowzero=0}
    2364 |  # node_Cast_1689
            %"val_1723"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2365 |  # node_Constant_1690
            %"val_1724"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2366 |  # node_Reshape_1691
            %"val_1725"<?,?> ⬅️ ::Reshape(%"val_1723", %"val_1724") {allowzero=0}
    2367 |  # node_Constant_1692
            %"val_1726"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2368 |  # node_slice_103
            %"slice_103"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_41", %"val_1719", %"val_1722", %"val_1725", %"val_1726")
    2369 |  # node_Cast_1693
            %"val_1727"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2370 |  # node_Constant_1694
            %"val_1728"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2371 |  # node_Reshape_1695
            %"val_1729"<?,?> ⬅️ ::Reshape(%"val_1727", %"val_1728") {allowzero=0}
    2372 |  # node_Cast_1696
            %"val_1730"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2373 |  # node_Constant_1697
            %"val_1731"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2374 |  # node_Reshape_1698
            %"val_1732"<?,?> ⬅️ ::Reshape(%"val_1730", %"val_1731") {allowzero=0}
    2375 |  # node_Cast_1699
            %"val_1733"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2376 |  # node_Constant_1700
            %"val_1734"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2377 |  # node_Reshape_1701
            %"val_1735"<?,?> ⬅️ ::Reshape(%"val_1733", %"val_1734") {allowzero=0}
    2378 |  # node_Constant_1702
            %"val_1736"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2379 |  # node_slice_104
            %"slice_104"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_41", %"val_1729", %"val_1732", %"val_1735", %"val_1736")
    2380 |  # node_neg_17
            %"neg_17"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_104")
    2381 |  # node_cat_39
            %"cat_39"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_17", %"slice_103") {axis=-1}
    2382 |  # node_mul_87
            %"mul_87"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_39", %"unsqueeze_89")
    2383 |  # node_add_33
            %"add_33"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_86", %"mul_87")
    2384 |  # node_Shape_1703
            %"val_1737"<?,?> ⬅️ ::Shape(%"add_32") {start=0}
    2385 |  # node_Constant_1704
            %"val_1738"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2386 |  # node_Gather_1705
            %"val_1739"<?,?> ⬅️ ::Gather(%"val_1737", %"val_1738") {axis=0}
    2387 |  # node_CastLike_1706
            %"val_1740"<?,?> ⬅️ ::CastLike(%"val_1739", %"add_32")
    2388 |  # node_Constant_1707
            %"val_1741"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2389 |  # node_CastLike_1708
            %"val_1742"<?,?> ⬅️ ::CastLike(%"val_1741", %"add_32")
    2390 |  # node_Sqrt_1709
            %"val_1743"<?,?> ⬅️ ::Sqrt(%"val_1740")
    2391 |  # node_Div_1710
            %"val_1744"<?,?> ⬅️ ::Div(%"val_1742", %"val_1743")
    2392 |  # node_CastLike_1711
            %"val_1745"<?,?> ⬅️ ::CastLike(%"val_1744", %"add_32")
    2393 |  # node_Shape_1712
            %"val_1746"<?,?> ⬅️ ::Shape(%"add_33") {start=0}
    2394 |  # node_Constant_1713
            %"val_1747"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2395 |  # node_Slice_1714
            %"val_1748"<?,?> ⬅️ ::Slice(%"val_1746", %"val_889", %"val_1747")
    2396 |  # node_Slice_1715
            %"val_1749"<?,?> ⬅️ ::Slice(%"val_1746", %"val_891", %"val_889")
    2397 |  # node_Constant_1716
            %"val_1750"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2398 |  # node_Slice_1717
            %"val_1751"<?,?> ⬅️ ::Slice(%"val_1746", %"val_1750", %"val_891")
    2399 |  # node_Constant_1718
            %"val_1752"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2400 |  # node_Concat_1719
            %"val_1753"<?,?> ⬅️ ::Concat(%"val_1752", %"val_1749", %"val_1748") {axis=0}
    2401 |  # node_Reshape_1720
            %"val_1754"<?,?> ⬅️ ::Reshape(%"add_33", %"val_1753") {allowzero=0}
    2402 |  # node_Transpose_1721
            %"val_1755"<?,?> ⬅️ ::Transpose(%"val_1754") {perm=(0, 2, 1)}
    2403 |  # node_Concat_1722
            %"val_1756"<?,?> ⬅️ ::Concat(%"val_1751", %"val_1748", %"val_1749") {axis=0}
    2404 |  # node_Reshape_1723
            %"val_1757"<?,?> ⬅️ ::Reshape(%"val_1755", %"val_1756") {allowzero=0}
    2405 |  # node_Sqrt_1724
            %"val_1758"<?,?> ⬅️ ::Sqrt(%"val_1745")
    2406 |  # node_Mul_1725
            %"val_1759"<?,?> ⬅️ ::Mul(%"add_32", %"val_1758")
    2407 |  # node_Sqrt_1726
            %"val_1760"<?,?> ⬅️ ::Sqrt(%"val_1745")
    2408 |  # node_Mul_1727
            %"val_1761"<?,?> ⬅️ ::Mul(%"val_1757", %"val_1760")
    2409 |  # node_MatMul_1728
            %"val_1762"<?,?> ⬅️ ::MatMul(%"val_1759", %"val_1761")
    2410 |  # node_Add_1729
            %"val_1763"<?,?> ⬅️ ::Add(%"val_1762", %"masked_fill_1")
    2411 |  # node_Softmax_1730
            %"val_1764"<?,?> ⬅️ ::Softmax(%"val_1763") {axis=-1}
    2412 |  # node_scaled_dot_product_attention_8
            %"scaled_dot_product_attention_8"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1764", %"getitem_42")
    2413 |  # node_transpose_39
            %"transpose_39"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_8") {perm=(0, 2, 1, 3)}
    2414 |  # node_Constant_1731
            %"val_1765"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2415 |  # node_Constant_1732
            %"val_1766"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2416 |  # node_Constant_1733
            %"val_1767"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2417 |  # node_Constant_1734
            %"val_1768"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2418 |  # node_Concat_1735
            %"val_1769"<?,?> ⬅️ ::Concat(%"val_1766", %"val_1767", %"val_1768") {axis=0}
    2419 |  # node_view_17
            %"view_17"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_39", %"val_1769") {allowzero=1}
    2420 |  # node_Transpose_1736
            %"val_1770"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.attn.Wo.weight"{...}) {perm=(1, 0)}
    2421 |  # node_linear_33
            %"linear_33"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_17", %"val_1770")
    2422 |  # node_add_34
            %"add_34"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_31", %"linear_33")
    2423 |  # node_layer_norm_17
            %"layer_norm_17"<FLOAT,[1,97,768]>, %"val_1771"<?,?>, %"val_1772"<?,?> ⬅️ ::LayerNormalization(%"add_34", %"encoder.layers.8.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2424 |  # node_Transpose_1737
            %"val_1773"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2425 |  # node_linear_34
            %"linear_34"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_17", %"val_1773")
    2426 |  # node_split_8
            %"split_8"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_34", %"val_917") {dim=-1}
    2427 |  # node_getitem_43
            %"getitem_43"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_8", %"val_6")
    2428 |  # node_getitem_44
            %"getitem_44"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_8", %"val_51")
    2429 |  # node_Constant_1738
            %"val_1774"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2430 |  # node_Div_1739
            %"val_1775"<?,?> ⬅️ ::Div(%"getitem_43", %"val_1774")
    2431 |  # node_Erf_1740
            %"val_1776"<?,?> ⬅️ ::Erf(%"val_1775")
    2432 |  # node_Constant_1741
            %"val_1777"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2433 |  # node_Add_1742
            %"val_1778"<?,?> ⬅️ ::Add(%"val_1776", %"val_1777")
    2434 |  # node_Constant_1743
            %"val_1779"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2435 |  # node_Mul_1744
            %"val_1780"<?,?> ⬅️ ::Mul(%"val_1779", %"val_1778")
    2436 |  # node_gelu_8
            %"gelu_8"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_43", %"val_1780")
    2437 |  # node_mul_88
            %"mul_88"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_8", %"getitem_44")
    2438 |  # node_clone_10
            %"clone_10"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_88")
    2439 |  # node_Transpose_1745
            %"val_1781"<?,?> ⬅️ ::Transpose(%"encoder.layers.8.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2440 |  # node_linear_35
            %"linear_35"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_10", %"val_1781")
    2441 |  # node_add_35
            %"add_35"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_34", %"linear_35")
    2442 |  # node_layer_norm_18
            %"layer_norm_18"<FLOAT,[1,97,768]>, %"val_1782"<?,?>, %"val_1783"<?,?> ⬅️ ::LayerNormalization(%"add_35", %"encoder.layers.9.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2443 |  # node_Transpose_1746
            %"val_1784"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2444 |  # node_linear_36
            %"linear_36"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_18", %"val_1784")
    2445 |  # node_Constant_1747
            %"val_1785"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2446 |  # node_Constant_1748
            %"val_1786"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2447 |  # node_Constant_1749
            %"val_1787"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2448 |  # node_Constant_1750
            %"val_1788"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2449 |  # node_Constant_1751
            %"val_1789"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2450 |  # node_Constant_1752
            %"val_1790"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2451 |  # node_Concat_1753
            %"val_1791"<?,?> ⬅️ ::Concat(%"val_1786", %"val_1787", %"val_1788", %"val_1789", %"val_1790") {axis=0}
    2452 |  # node_view_18
            %"view_18"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_36", %"val_1791") {allowzero=1}
    2453 |  # node_transpose_40
            %"transpose_40"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_18") {perm=(0, 3, 2, 1, 4)}
    2454 |  # node_Constant_1754
            %"val_1792"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2455 |  # node_Constant_1755
            %"val_1793"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2456 |  # node_Constant_1756
            %"val_1794"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2457 |  # node_Slice_1757
            %"val_1795"<?,?> ⬅️ ::Slice(%"transpose_40", %"val_1792", %"val_1793", %"val_1794")
    2458 |  # node_unbind_9__0
            %"getitem_45"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1795", %"val_19")
    2459 |  # node_Constant_1758
            %"val_1796"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2460 |  # node_Constant_1759
            %"val_1797"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2461 |  # node_Constant_1760
            %"val_1798"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2462 |  # node_Slice_1761
            %"val_1799"<?,?> ⬅️ ::Slice(%"transpose_40", %"val_1796", %"val_1797", %"val_1798")
    2463 |  # node_unbind_9__1
            %"getitem_46"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1799", %"val_19")
    2464 |  # node_Constant_1762
            %"val_1800"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2465 |  # node_Constant_1763
            %"val_1801"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2466 |  # node_Constant_1764
            %"val_1802"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2467 |  # node_Slice_1765
            %"val_1803"<?,?> ⬅️ ::Slice(%"transpose_40", %"val_1800", %"val_1801", %"val_1802")
    2468 |  # node_unbind_9__2
            %"getitem_47"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1803", %"val_19")
    2469 |  # node_unsqueeze_90
            %"unsqueeze_90"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    2470 |  # node_unsqueeze_91
            %"unsqueeze_91"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    2471 |  # node_mul_89
            %"mul_89"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_45", %"unsqueeze_90")
    2472 |  # node_Cast_1766
            %"val_1804"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2473 |  # node_Constant_1767
            %"val_1805"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2474 |  # node_Reshape_1768
            %"val_1806"<?,?> ⬅️ ::Reshape(%"val_1804", %"val_1805") {allowzero=0}
    2475 |  # node_Cast_1769
            %"val_1807"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2476 |  # node_Constant_1770
            %"val_1808"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2477 |  # node_Reshape_1771
            %"val_1809"<?,?> ⬅️ ::Reshape(%"val_1807", %"val_1808") {allowzero=0}
    2478 |  # node_Cast_1772
            %"val_1810"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2479 |  # node_Constant_1773
            %"val_1811"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2480 |  # node_Reshape_1774
            %"val_1812"<?,?> ⬅️ ::Reshape(%"val_1810", %"val_1811") {allowzero=0}
    2481 |  # node_Constant_1775
            %"val_1813"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2482 |  # node_slice_105
            %"slice_105"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_45", %"val_1806", %"val_1809", %"val_1812", %"val_1813")
    2483 |  # node_Cast_1776
            %"val_1814"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2484 |  # node_Constant_1777
            %"val_1815"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2485 |  # node_Reshape_1778
            %"val_1816"<?,?> ⬅️ ::Reshape(%"val_1814", %"val_1815") {allowzero=0}
    2486 |  # node_Cast_1779
            %"val_1817"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2487 |  # node_Constant_1780
            %"val_1818"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2488 |  # node_Reshape_1781
            %"val_1819"<?,?> ⬅️ ::Reshape(%"val_1817", %"val_1818") {allowzero=0}
    2489 |  # node_Cast_1782
            %"val_1820"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2490 |  # node_Constant_1783
            %"val_1821"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2491 |  # node_Reshape_1784
            %"val_1822"<?,?> ⬅️ ::Reshape(%"val_1820", %"val_1821") {allowzero=0}
    2492 |  # node_Constant_1785
            %"val_1823"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2493 |  # node_slice_106
            %"slice_106"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_45", %"val_1816", %"val_1819", %"val_1822", %"val_1823")
    2494 |  # node_neg_18
            %"neg_18"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_106")
    2495 |  # node_cat_40
            %"cat_40"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_18", %"slice_105") {axis=-1}
    2496 |  # node_mul_90
            %"mul_90"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_40", %"unsqueeze_91")
    2497 |  # node_add_36
            %"add_36"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_89", %"mul_90")
    2498 |  # node_mul_91
            %"mul_91"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_46", %"unsqueeze_90")
    2499 |  # node_Cast_1786
            %"val_1824"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2500 |  # node_Constant_1787
            %"val_1825"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2501 |  # node_Reshape_1788
            %"val_1826"<?,?> ⬅️ ::Reshape(%"val_1824", %"val_1825") {allowzero=0}
    2502 |  # node_Cast_1789
            %"val_1827"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2503 |  # node_Constant_1790
            %"val_1828"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2504 |  # node_Reshape_1791
            %"val_1829"<?,?> ⬅️ ::Reshape(%"val_1827", %"val_1828") {allowzero=0}
    2505 |  # node_Cast_1792
            %"val_1830"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2506 |  # node_Constant_1793
            %"val_1831"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2507 |  # node_Reshape_1794
            %"val_1832"<?,?> ⬅️ ::Reshape(%"val_1830", %"val_1831") {allowzero=0}
    2508 |  # node_Constant_1795
            %"val_1833"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2509 |  # node_slice_107
            %"slice_107"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_46", %"val_1826", %"val_1829", %"val_1832", %"val_1833")
    2510 |  # node_Cast_1796
            %"val_1834"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2511 |  # node_Constant_1797
            %"val_1835"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2512 |  # node_Reshape_1798
            %"val_1836"<?,?> ⬅️ ::Reshape(%"val_1834", %"val_1835") {allowzero=0}
    2513 |  # node_Cast_1799
            %"val_1837"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2514 |  # node_Constant_1800
            %"val_1838"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2515 |  # node_Reshape_1801
            %"val_1839"<?,?> ⬅️ ::Reshape(%"val_1837", %"val_1838") {allowzero=0}
    2516 |  # node_Cast_1802
            %"val_1840"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2517 |  # node_Constant_1803
            %"val_1841"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2518 |  # node_Reshape_1804
            %"val_1842"<?,?> ⬅️ ::Reshape(%"val_1840", %"val_1841") {allowzero=0}
    2519 |  # node_Constant_1805
            %"val_1843"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2520 |  # node_slice_108
            %"slice_108"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_46", %"val_1836", %"val_1839", %"val_1842", %"val_1843")
    2521 |  # node_neg_19
            %"neg_19"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_108")
    2522 |  # node_cat_41
            %"cat_41"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_19", %"slice_107") {axis=-1}
    2523 |  # node_mul_92
            %"mul_92"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_41", %"unsqueeze_91")
    2524 |  # node_add_37
            %"add_37"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_91", %"mul_92")
    2525 |  # node_Shape_1806
            %"val_1844"<?,?> ⬅️ ::Shape(%"add_36") {start=0}
    2526 |  # node_Constant_1807
            %"val_1845"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2527 |  # node_Gather_1808
            %"val_1846"<?,?> ⬅️ ::Gather(%"val_1844", %"val_1845") {axis=0}
    2528 |  # node_CastLike_1809
            %"val_1847"<?,?> ⬅️ ::CastLike(%"val_1846", %"add_36")
    2529 |  # node_Constant_1810
            %"val_1848"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2530 |  # node_CastLike_1811
            %"val_1849"<?,?> ⬅️ ::CastLike(%"val_1848", %"add_36")
    2531 |  # node_Sqrt_1812
            %"val_1850"<?,?> ⬅️ ::Sqrt(%"val_1847")
    2532 |  # node_Div_1813
            %"val_1851"<?,?> ⬅️ ::Div(%"val_1849", %"val_1850")
    2533 |  # node_CastLike_1814
            %"val_1852"<?,?> ⬅️ ::CastLike(%"val_1851", %"add_36")
    2534 |  # node_Shape_1815
            %"val_1853"<?,?> ⬅️ ::Shape(%"add_37") {start=0}
    2535 |  # node_Constant_1816
            %"val_1854"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2536 |  # node_Slice_1817
            %"val_1855"<?,?> ⬅️ ::Slice(%"val_1853", %"val_889", %"val_1854")
    2537 |  # node_Slice_1818
            %"val_1856"<?,?> ⬅️ ::Slice(%"val_1853", %"val_891", %"val_889")
    2538 |  # node_Constant_1819
            %"val_1857"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2539 |  # node_Slice_1820
            %"val_1858"<?,?> ⬅️ ::Slice(%"val_1853", %"val_1857", %"val_891")
    2540 |  # node_Constant_1821
            %"val_1859"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2541 |  # node_Concat_1822
            %"val_1860"<?,?> ⬅️ ::Concat(%"val_1859", %"val_1856", %"val_1855") {axis=0}
    2542 |  # node_Reshape_1823
            %"val_1861"<?,?> ⬅️ ::Reshape(%"add_37", %"val_1860") {allowzero=0}
    2543 |  # node_Transpose_1824
            %"val_1862"<?,?> ⬅️ ::Transpose(%"val_1861") {perm=(0, 2, 1)}
    2544 |  # node_Concat_1825
            %"val_1863"<?,?> ⬅️ ::Concat(%"val_1858", %"val_1855", %"val_1856") {axis=0}
    2545 |  # node_Reshape_1826
            %"val_1864"<?,?> ⬅️ ::Reshape(%"val_1862", %"val_1863") {allowzero=0}
    2546 |  # node_Sqrt_1827
            %"val_1865"<?,?> ⬅️ ::Sqrt(%"val_1852")
    2547 |  # node_Mul_1828
            %"val_1866"<?,?> ⬅️ ::Mul(%"add_36", %"val_1865")
    2548 |  # node_Sqrt_1829
            %"val_1867"<?,?> ⬅️ ::Sqrt(%"val_1852")
    2549 |  # node_Mul_1830
            %"val_1868"<?,?> ⬅️ ::Mul(%"val_1864", %"val_1867")
    2550 |  # node_MatMul_1831
            %"val_1869"<?,?> ⬅️ ::MatMul(%"val_1866", %"val_1868")
    2551 |  # node_Add_1832
            %"val_1870"<?,?> ⬅️ ::Add(%"val_1869", %"masked_fill")
    2552 |  # node_Softmax_1833
            %"val_1871"<?,?> ⬅️ ::Softmax(%"val_1870") {axis=-1}
    2553 |  # node_scaled_dot_product_attention_9
            %"scaled_dot_product_attention_9"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1871", %"getitem_47")
    2554 |  # node_transpose_41
            %"transpose_41"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_9") {perm=(0, 2, 1, 3)}
    2555 |  # node_Constant_1834
            %"val_1872"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2556 |  # node_Constant_1835
            %"val_1873"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2557 |  # node_Constant_1836
            %"val_1874"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2558 |  # node_Constant_1837
            %"val_1875"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2559 |  # node_Concat_1838
            %"val_1876"<?,?> ⬅️ ::Concat(%"val_1873", %"val_1874", %"val_1875") {axis=0}
    2560 |  # node_view_19
            %"view_19"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_41", %"val_1876") {allowzero=1}
    2561 |  # node_Transpose_1839
            %"val_1877"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.attn.Wo.weight"{...}) {perm=(1, 0)}
    2562 |  # node_linear_37
            %"linear_37"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_19", %"val_1877")
    2563 |  # node_add_38
            %"add_38"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_35", %"linear_37")
    2564 |  # node_layer_norm_19
            %"layer_norm_19"<FLOAT,[1,97,768]>, %"val_1878"<?,?>, %"val_1879"<?,?> ⬅️ ::LayerNormalization(%"add_38", %"encoder.layers.9.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2565 |  # node_Transpose_1840
            %"val_1880"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2566 |  # node_linear_38
            %"linear_38"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_19", %"val_1880")
    2567 |  # node_split_9
            %"split_9"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_38", %"val_917") {dim=-1}
    2568 |  # node_getitem_48
            %"getitem_48"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_9", %"val_6")
    2569 |  # node_getitem_49
            %"getitem_49"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_9", %"val_51")
    2570 |  # node_Constant_1841
            %"val_1881"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2571 |  # node_Div_1842
            %"val_1882"<?,?> ⬅️ ::Div(%"getitem_48", %"val_1881")
    2572 |  # node_Erf_1843
            %"val_1883"<?,?> ⬅️ ::Erf(%"val_1882")
    2573 |  # node_Constant_1844
            %"val_1884"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2574 |  # node_Add_1845
            %"val_1885"<?,?> ⬅️ ::Add(%"val_1883", %"val_1884")
    2575 |  # node_Constant_1846
            %"val_1886"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2576 |  # node_Mul_1847
            %"val_1887"<?,?> ⬅️ ::Mul(%"val_1886", %"val_1885")
    2577 |  # node_gelu_9
            %"gelu_9"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_48", %"val_1887")
    2578 |  # node_mul_93
            %"mul_93"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_9", %"getitem_49")
    2579 |  # node_clone_11
            %"clone_11"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_93")
    2580 |  # node_Transpose_1848
            %"val_1888"<?,?> ⬅️ ::Transpose(%"encoder.layers.9.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2581 |  # node_linear_39
            %"linear_39"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_11", %"val_1888")
    2582 |  # node_add_39
            %"add_39"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_38", %"linear_39")
    2583 |  # node_layer_norm_20
            %"layer_norm_20"<FLOAT,[1,97,768]>, %"val_1889"<?,?>, %"val_1890"<?,?> ⬅️ ::LayerNormalization(%"add_39", %"encoder.layers.10.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2584 |  # node_Transpose_1849
            %"val_1891"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2585 |  # node_linear_40
            %"linear_40"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_20", %"val_1891")
    2586 |  # node_Constant_1850
            %"val_1892"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2587 |  # node_Constant_1851
            %"val_1893"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2588 |  # node_Constant_1852
            %"val_1894"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2589 |  # node_Constant_1853
            %"val_1895"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2590 |  # node_Constant_1854
            %"val_1896"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2591 |  # node_Constant_1855
            %"val_1897"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2592 |  # node_Concat_1856
            %"val_1898"<?,?> ⬅️ ::Concat(%"val_1893", %"val_1894", %"val_1895", %"val_1896", %"val_1897") {axis=0}
    2593 |  # node_view_20
            %"view_20"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_40", %"val_1898") {allowzero=1}
    2594 |  # node_transpose_42
            %"transpose_42"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_20") {perm=(0, 3, 2, 1, 4)}
    2595 |  # node_Constant_1857
            %"val_1899"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2596 |  # node_Constant_1858
            %"val_1900"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2597 |  # node_Constant_1859
            %"val_1901"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2598 |  # node_Slice_1860
            %"val_1902"<?,?> ⬅️ ::Slice(%"transpose_42", %"val_1899", %"val_1900", %"val_1901")
    2599 |  # node_unbind_10__0
            %"getitem_50"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1902", %"val_19")
    2600 |  # node_Constant_1861
            %"val_1903"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2601 |  # node_Constant_1862
            %"val_1904"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2602 |  # node_Constant_1863
            %"val_1905"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2603 |  # node_Slice_1864
            %"val_1906"<?,?> ⬅️ ::Slice(%"transpose_42", %"val_1903", %"val_1904", %"val_1905")
    2604 |  # node_unbind_10__1
            %"getitem_51"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1906", %"val_19")
    2605 |  # node_Constant_1865
            %"val_1907"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2606 |  # node_Constant_1866
            %"val_1908"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2607 |  # node_Constant_1867
            %"val_1909"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2608 |  # node_Slice_1868
            %"val_1910"<?,?> ⬅️ ::Slice(%"transpose_42", %"val_1907", %"val_1908", %"val_1909")
    2609 |  # node_unbind_10__2
            %"getitem_52"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_1910", %"val_19")
    2610 |  # node_unsqueeze_92
            %"unsqueeze_92"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2611 |  # node_unsqueeze_93
            %"unsqueeze_93"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2612 |  # node_mul_94
            %"mul_94"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_50", %"unsqueeze_92")
    2613 |  # node_Cast_1869
            %"val_1911"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2614 |  # node_Constant_1870
            %"val_1912"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2615 |  # node_Reshape_1871
            %"val_1913"<?,?> ⬅️ ::Reshape(%"val_1911", %"val_1912") {allowzero=0}
    2616 |  # node_Cast_1872
            %"val_1914"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2617 |  # node_Constant_1873
            %"val_1915"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2618 |  # node_Reshape_1874
            %"val_1916"<?,?> ⬅️ ::Reshape(%"val_1914", %"val_1915") {allowzero=0}
    2619 |  # node_Cast_1875
            %"val_1917"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2620 |  # node_Constant_1876
            %"val_1918"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2621 |  # node_Reshape_1877
            %"val_1919"<?,?> ⬅️ ::Reshape(%"val_1917", %"val_1918") {allowzero=0}
    2622 |  # node_Constant_1878
            %"val_1920"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2623 |  # node_slice_109
            %"slice_109"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_50", %"val_1913", %"val_1916", %"val_1919", %"val_1920")
    2624 |  # node_Cast_1879
            %"val_1921"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2625 |  # node_Constant_1880
            %"val_1922"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2626 |  # node_Reshape_1881
            %"val_1923"<?,?> ⬅️ ::Reshape(%"val_1921", %"val_1922") {allowzero=0}
    2627 |  # node_Cast_1882
            %"val_1924"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2628 |  # node_Constant_1883
            %"val_1925"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2629 |  # node_Reshape_1884
            %"val_1926"<?,?> ⬅️ ::Reshape(%"val_1924", %"val_1925") {allowzero=0}
    2630 |  # node_Cast_1885
            %"val_1927"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2631 |  # node_Constant_1886
            %"val_1928"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2632 |  # node_Reshape_1887
            %"val_1929"<?,?> ⬅️ ::Reshape(%"val_1927", %"val_1928") {allowzero=0}
    2633 |  # node_Constant_1888
            %"val_1930"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2634 |  # node_slice_110
            %"slice_110"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_50", %"val_1923", %"val_1926", %"val_1929", %"val_1930")
    2635 |  # node_neg_20
            %"neg_20"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_110")
    2636 |  # node_cat_42
            %"cat_42"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_20", %"slice_109") {axis=-1}
    2637 |  # node_mul_95
            %"mul_95"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_42", %"unsqueeze_93")
    2638 |  # node_add_40
            %"add_40"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_94", %"mul_95")
    2639 |  # node_mul_96
            %"mul_96"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_51", %"unsqueeze_92")
    2640 |  # node_Cast_1889
            %"val_1931"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2641 |  # node_Constant_1890
            %"val_1932"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2642 |  # node_Reshape_1891
            %"val_1933"<?,?> ⬅️ ::Reshape(%"val_1931", %"val_1932") {allowzero=0}
    2643 |  # node_Cast_1892
            %"val_1934"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2644 |  # node_Constant_1893
            %"val_1935"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2645 |  # node_Reshape_1894
            %"val_1936"<?,?> ⬅️ ::Reshape(%"val_1934", %"val_1935") {allowzero=0}
    2646 |  # node_Cast_1895
            %"val_1937"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2647 |  # node_Constant_1896
            %"val_1938"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2648 |  # node_Reshape_1897
            %"val_1939"<?,?> ⬅️ ::Reshape(%"val_1937", %"val_1938") {allowzero=0}
    2649 |  # node_Constant_1898
            %"val_1940"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2650 |  # node_slice_111
            %"slice_111"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_51", %"val_1933", %"val_1936", %"val_1939", %"val_1940")
    2651 |  # node_Cast_1899
            %"val_1941"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2652 |  # node_Constant_1900
            %"val_1942"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2653 |  # node_Reshape_1901
            %"val_1943"<?,?> ⬅️ ::Reshape(%"val_1941", %"val_1942") {allowzero=0}
    2654 |  # node_Cast_1902
            %"val_1944"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2655 |  # node_Constant_1903
            %"val_1945"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2656 |  # node_Reshape_1904
            %"val_1946"<?,?> ⬅️ ::Reshape(%"val_1944", %"val_1945") {allowzero=0}
    2657 |  # node_Cast_1905
            %"val_1947"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2658 |  # node_Constant_1906
            %"val_1948"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2659 |  # node_Reshape_1907
            %"val_1949"<?,?> ⬅️ ::Reshape(%"val_1947", %"val_1948") {allowzero=0}
    2660 |  # node_Constant_1908
            %"val_1950"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2661 |  # node_slice_112
            %"slice_112"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_51", %"val_1943", %"val_1946", %"val_1949", %"val_1950")
    2662 |  # node_neg_21
            %"neg_21"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_112")
    2663 |  # node_cat_43
            %"cat_43"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_21", %"slice_111") {axis=-1}
    2664 |  # node_mul_97
            %"mul_97"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_43", %"unsqueeze_93")
    2665 |  # node_add_41
            %"add_41"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_96", %"mul_97")
    2666 |  # node_Shape_1909
            %"val_1951"<?,?> ⬅️ ::Shape(%"add_40") {start=0}
    2667 |  # node_Constant_1910
            %"val_1952"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2668 |  # node_Gather_1911
            %"val_1953"<?,?> ⬅️ ::Gather(%"val_1951", %"val_1952") {axis=0}
    2669 |  # node_CastLike_1912
            %"val_1954"<?,?> ⬅️ ::CastLike(%"val_1953", %"add_40")
    2670 |  # node_Constant_1913
            %"val_1955"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2671 |  # node_CastLike_1914
            %"val_1956"<?,?> ⬅️ ::CastLike(%"val_1955", %"add_40")
    2672 |  # node_Sqrt_1915
            %"val_1957"<?,?> ⬅️ ::Sqrt(%"val_1954")
    2673 |  # node_Div_1916
            %"val_1958"<?,?> ⬅️ ::Div(%"val_1956", %"val_1957")
    2674 |  # node_CastLike_1917
            %"val_1959"<?,?> ⬅️ ::CastLike(%"val_1958", %"add_40")
    2675 |  # node_Shape_1918
            %"val_1960"<?,?> ⬅️ ::Shape(%"add_41") {start=0}
    2676 |  # node_Constant_1919
            %"val_1961"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2677 |  # node_Slice_1920
            %"val_1962"<?,?> ⬅️ ::Slice(%"val_1960", %"val_889", %"val_1961")
    2678 |  # node_Slice_1921
            %"val_1963"<?,?> ⬅️ ::Slice(%"val_1960", %"val_891", %"val_889")
    2679 |  # node_Constant_1922
            %"val_1964"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2680 |  # node_Slice_1923
            %"val_1965"<?,?> ⬅️ ::Slice(%"val_1960", %"val_1964", %"val_891")
    2681 |  # node_Constant_1924
            %"val_1966"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2682 |  # node_Concat_1925
            %"val_1967"<?,?> ⬅️ ::Concat(%"val_1966", %"val_1963", %"val_1962") {axis=0}
    2683 |  # node_Reshape_1926
            %"val_1968"<?,?> ⬅️ ::Reshape(%"add_41", %"val_1967") {allowzero=0}
    2684 |  # node_Transpose_1927
            %"val_1969"<?,?> ⬅️ ::Transpose(%"val_1968") {perm=(0, 2, 1)}
    2685 |  # node_Concat_1928
            %"val_1970"<?,?> ⬅️ ::Concat(%"val_1965", %"val_1962", %"val_1963") {axis=0}
    2686 |  # node_Reshape_1929
            %"val_1971"<?,?> ⬅️ ::Reshape(%"val_1969", %"val_1970") {allowzero=0}
    2687 |  # node_Sqrt_1930
            %"val_1972"<?,?> ⬅️ ::Sqrt(%"val_1959")
    2688 |  # node_Mul_1931
            %"val_1973"<?,?> ⬅️ ::Mul(%"add_40", %"val_1972")
    2689 |  # node_Sqrt_1932
            %"val_1974"<?,?> ⬅️ ::Sqrt(%"val_1959")
    2690 |  # node_Mul_1933
            %"val_1975"<?,?> ⬅️ ::Mul(%"val_1971", %"val_1974")
    2691 |  # node_MatMul_1934
            %"val_1976"<?,?> ⬅️ ::MatMul(%"val_1973", %"val_1975")
    2692 |  # node_Add_1935
            %"val_1977"<?,?> ⬅️ ::Add(%"val_1976", %"masked_fill_1")
    2693 |  # node_Softmax_1936
            %"val_1978"<?,?> ⬅️ ::Softmax(%"val_1977") {axis=-1}
    2694 |  # node_scaled_dot_product_attention_10
            %"scaled_dot_product_attention_10"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_1978", %"getitem_52")
    2695 |  # node_transpose_43
            %"transpose_43"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_10") {perm=(0, 2, 1, 3)}
    2696 |  # node_Constant_1937
            %"val_1979"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2697 |  # node_Constant_1938
            %"val_1980"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2698 |  # node_Constant_1939
            %"val_1981"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2699 |  # node_Constant_1940
            %"val_1982"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2700 |  # node_Concat_1941
            %"val_1983"<?,?> ⬅️ ::Concat(%"val_1980", %"val_1981", %"val_1982") {axis=0}
    2701 |  # node_view_21
            %"view_21"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_43", %"val_1983") {allowzero=1}
    2702 |  # node_Transpose_1942
            %"val_1984"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.attn.Wo.weight"{...}) {perm=(1, 0)}
    2703 |  # node_linear_41
            %"linear_41"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_21", %"val_1984")
    2704 |  # node_add_42
            %"add_42"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_39", %"linear_41")
    2705 |  # node_layer_norm_21
            %"layer_norm_21"<FLOAT,[1,97,768]>, %"val_1985"<?,?>, %"val_1986"<?,?> ⬅️ ::LayerNormalization(%"add_42", %"encoder.layers.10.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2706 |  # node_Transpose_1943
            %"val_1987"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2707 |  # node_linear_42
            %"linear_42"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_21", %"val_1987")
    2708 |  # node_split_10
            %"split_10"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_42", %"val_917") {dim=-1}
    2709 |  # node_getitem_53
            %"getitem_53"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_10", %"val_6")
    2710 |  # node_getitem_54
            %"getitem_54"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_10", %"val_51")
    2711 |  # node_Constant_1944
            %"val_1988"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2712 |  # node_Div_1945
            %"val_1989"<?,?> ⬅️ ::Div(%"getitem_53", %"val_1988")
    2713 |  # node_Erf_1946
            %"val_1990"<?,?> ⬅️ ::Erf(%"val_1989")
    2714 |  # node_Constant_1947
            %"val_1991"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2715 |  # node_Add_1948
            %"val_1992"<?,?> ⬅️ ::Add(%"val_1990", %"val_1991")
    2716 |  # node_Constant_1949
            %"val_1993"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2717 |  # node_Mul_1950
            %"val_1994"<?,?> ⬅️ ::Mul(%"val_1993", %"val_1992")
    2718 |  # node_gelu_10
            %"gelu_10"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_53", %"val_1994")
    2719 |  # node_mul_98
            %"mul_98"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_10", %"getitem_54")
    2720 |  # node_clone_12
            %"clone_12"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_98")
    2721 |  # node_Transpose_1951
            %"val_1995"<?,?> ⬅️ ::Transpose(%"encoder.layers.10.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2722 |  # node_linear_43
            %"linear_43"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_12", %"val_1995")
    2723 |  # node_add_43
            %"add_43"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_42", %"linear_43")
    2724 |  # node_layer_norm_22
            %"layer_norm_22"<FLOAT,[1,97,768]>, %"val_1996"<?,?>, %"val_1997"<?,?> ⬅️ ::LayerNormalization(%"add_43", %"encoder.layers.11.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2725 |  # node_Transpose_1952
            %"val_1998"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2726 |  # node_linear_44
            %"linear_44"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_22", %"val_1998")
    2727 |  # node_Constant_1953
            %"val_1999"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2728 |  # node_Constant_1954
            %"val_2000"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2729 |  # node_Constant_1955
            %"val_2001"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2730 |  # node_Constant_1956
            %"val_2002"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2731 |  # node_Constant_1957
            %"val_2003"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2732 |  # node_Constant_1958
            %"val_2004"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2733 |  # node_Concat_1959
            %"val_2005"<?,?> ⬅️ ::Concat(%"val_2000", %"val_2001", %"val_2002", %"val_2003", %"val_2004") {axis=0}
    2734 |  # node_view_22
            %"view_22"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_44", %"val_2005") {allowzero=1}
    2735 |  # node_transpose_44
            %"transpose_44"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_22") {perm=(0, 3, 2, 1, 4)}
    2736 |  # node_Constant_1960
            %"val_2006"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2737 |  # node_Constant_1961
            %"val_2007"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2738 |  # node_Constant_1962
            %"val_2008"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2739 |  # node_Slice_1963
            %"val_2009"<?,?> ⬅️ ::Slice(%"transpose_44", %"val_2006", %"val_2007", %"val_2008")
    2740 |  # node_unbind_11__0
            %"getitem_55"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2009", %"val_19")
    2741 |  # node_Constant_1964
            %"val_2010"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2742 |  # node_Constant_1965
            %"val_2011"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2743 |  # node_Constant_1966
            %"val_2012"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2744 |  # node_Slice_1967
            %"val_2013"<?,?> ⬅️ ::Slice(%"transpose_44", %"val_2010", %"val_2011", %"val_2012")
    2745 |  # node_unbind_11__1
            %"getitem_56"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2013", %"val_19")
    2746 |  # node_Constant_1968
            %"val_2014"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2747 |  # node_Constant_1969
            %"val_2015"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2748 |  # node_Constant_1970
            %"val_2016"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2749 |  # node_Slice_1971
            %"val_2017"<?,?> ⬅️ ::Slice(%"transpose_44", %"val_2014", %"val_2015", %"val_2016")
    2750 |  # node_unbind_11__2
            %"getitem_57"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2017", %"val_19")
    2751 |  # node_unsqueeze_94
            %"unsqueeze_94"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    2752 |  # node_unsqueeze_95
            %"unsqueeze_95"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    2753 |  # node_mul_99
            %"mul_99"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_55", %"unsqueeze_94")
    2754 |  # node_Cast_1972
            %"val_2018"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2755 |  # node_Constant_1973
            %"val_2019"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2756 |  # node_Reshape_1974
            %"val_2020"<?,?> ⬅️ ::Reshape(%"val_2018", %"val_2019") {allowzero=0}
    2757 |  # node_Cast_1975
            %"val_2021"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2758 |  # node_Constant_1976
            %"val_2022"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2759 |  # node_Reshape_1977
            %"val_2023"<?,?> ⬅️ ::Reshape(%"val_2021", %"val_2022") {allowzero=0}
    2760 |  # node_Cast_1978
            %"val_2024"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2761 |  # node_Constant_1979
            %"val_2025"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2762 |  # node_Reshape_1980
            %"val_2026"<?,?> ⬅️ ::Reshape(%"val_2024", %"val_2025") {allowzero=0}
    2763 |  # node_Constant_1981
            %"val_2027"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2764 |  # node_slice_113
            %"slice_113"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_55", %"val_2020", %"val_2023", %"val_2026", %"val_2027")
    2765 |  # node_Cast_1982
            %"val_2028"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2766 |  # node_Constant_1983
            %"val_2029"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2767 |  # node_Reshape_1984
            %"val_2030"<?,?> ⬅️ ::Reshape(%"val_2028", %"val_2029") {allowzero=0}
    2768 |  # node_Cast_1985
            %"val_2031"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2769 |  # node_Constant_1986
            %"val_2032"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2770 |  # node_Reshape_1987
            %"val_2033"<?,?> ⬅️ ::Reshape(%"val_2031", %"val_2032") {allowzero=0}
    2771 |  # node_Cast_1988
            %"val_2034"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2772 |  # node_Constant_1989
            %"val_2035"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2773 |  # node_Reshape_1990
            %"val_2036"<?,?> ⬅️ ::Reshape(%"val_2034", %"val_2035") {allowzero=0}
    2774 |  # node_Constant_1991
            %"val_2037"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2775 |  # node_slice_114
            %"slice_114"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_55", %"val_2030", %"val_2033", %"val_2036", %"val_2037")
    2776 |  # node_neg_22
            %"neg_22"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_114")
    2777 |  # node_cat_44
            %"cat_44"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_22", %"slice_113") {axis=-1}
    2778 |  # node_mul_100
            %"mul_100"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_44", %"unsqueeze_95")
    2779 |  # node_add_44
            %"add_44"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_99", %"mul_100")
    2780 |  # node_mul_101
            %"mul_101"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_56", %"unsqueeze_94")
    2781 |  # node_Cast_1992
            %"val_2038"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2782 |  # node_Constant_1993
            %"val_2039"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2783 |  # node_Reshape_1994
            %"val_2040"<?,?> ⬅️ ::Reshape(%"val_2038", %"val_2039") {allowzero=0}
    2784 |  # node_Cast_1995
            %"val_2041"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2785 |  # node_Constant_1996
            %"val_2042"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2786 |  # node_Reshape_1997
            %"val_2043"<?,?> ⬅️ ::Reshape(%"val_2041", %"val_2042") {allowzero=0}
    2787 |  # node_Cast_1998
            %"val_2044"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2788 |  # node_Constant_1999
            %"val_2045"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2789 |  # node_Reshape_2000
            %"val_2046"<?,?> ⬅️ ::Reshape(%"val_2044", %"val_2045") {allowzero=0}
    2790 |  # node_Constant_2001
            %"val_2047"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2791 |  # node_slice_115
            %"slice_115"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_56", %"val_2040", %"val_2043", %"val_2046", %"val_2047")
    2792 |  # node_Cast_2002
            %"val_2048"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2793 |  # node_Constant_2003
            %"val_2049"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2794 |  # node_Reshape_2004
            %"val_2050"<?,?> ⬅️ ::Reshape(%"val_2048", %"val_2049") {allowzero=0}
    2795 |  # node_Cast_2005
            %"val_2051"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2796 |  # node_Constant_2006
            %"val_2052"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2797 |  # node_Reshape_2007
            %"val_2053"<?,?> ⬅️ ::Reshape(%"val_2051", %"val_2052") {allowzero=0}
    2798 |  # node_Cast_2008
            %"val_2054"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2799 |  # node_Constant_2009
            %"val_2055"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2800 |  # node_Reshape_2010
            %"val_2056"<?,?> ⬅️ ::Reshape(%"val_2054", %"val_2055") {allowzero=0}
    2801 |  # node_Constant_2011
            %"val_2057"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2802 |  # node_slice_116
            %"slice_116"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_56", %"val_2050", %"val_2053", %"val_2056", %"val_2057")
    2803 |  # node_neg_23
            %"neg_23"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_116")
    2804 |  # node_cat_45
            %"cat_45"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_23", %"slice_115") {axis=-1}
    2805 |  # node_mul_102
            %"mul_102"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_45", %"unsqueeze_95")
    2806 |  # node_add_45
            %"add_45"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_101", %"mul_102")
    2807 |  # node_Shape_2012
            %"val_2058"<?,?> ⬅️ ::Shape(%"add_44") {start=0}
    2808 |  # node_Constant_2013
            %"val_2059"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2809 |  # node_Gather_2014
            %"val_2060"<?,?> ⬅️ ::Gather(%"val_2058", %"val_2059") {axis=0}
    2810 |  # node_CastLike_2015
            %"val_2061"<?,?> ⬅️ ::CastLike(%"val_2060", %"add_44")
    2811 |  # node_Constant_2016
            %"val_2062"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2812 |  # node_CastLike_2017
            %"val_2063"<?,?> ⬅️ ::CastLike(%"val_2062", %"add_44")
    2813 |  # node_Sqrt_2018
            %"val_2064"<?,?> ⬅️ ::Sqrt(%"val_2061")
    2814 |  # node_Div_2019
            %"val_2065"<?,?> ⬅️ ::Div(%"val_2063", %"val_2064")
    2815 |  # node_CastLike_2020
            %"val_2066"<?,?> ⬅️ ::CastLike(%"val_2065", %"add_44")
    2816 |  # node_Shape_2021
            %"val_2067"<?,?> ⬅️ ::Shape(%"add_45") {start=0}
    2817 |  # node_Constant_2022
            %"val_2068"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2818 |  # node_Slice_2023
            %"val_2069"<?,?> ⬅️ ::Slice(%"val_2067", %"val_889", %"val_2068")
    2819 |  # node_Slice_2024
            %"val_2070"<?,?> ⬅️ ::Slice(%"val_2067", %"val_891", %"val_889")
    2820 |  # node_Constant_2025
            %"val_2071"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2821 |  # node_Slice_2026
            %"val_2072"<?,?> ⬅️ ::Slice(%"val_2067", %"val_2071", %"val_891")
    2822 |  # node_Constant_2027
            %"val_2073"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2823 |  # node_Concat_2028
            %"val_2074"<?,?> ⬅️ ::Concat(%"val_2073", %"val_2070", %"val_2069") {axis=0}
    2824 |  # node_Reshape_2029
            %"val_2075"<?,?> ⬅️ ::Reshape(%"add_45", %"val_2074") {allowzero=0}
    2825 |  # node_Transpose_2030
            %"val_2076"<?,?> ⬅️ ::Transpose(%"val_2075") {perm=(0, 2, 1)}
    2826 |  # node_Concat_2031
            %"val_2077"<?,?> ⬅️ ::Concat(%"val_2072", %"val_2069", %"val_2070") {axis=0}
    2827 |  # node_Reshape_2032
            %"val_2078"<?,?> ⬅️ ::Reshape(%"val_2076", %"val_2077") {allowzero=0}
    2828 |  # node_Sqrt_2033
            %"val_2079"<?,?> ⬅️ ::Sqrt(%"val_2066")
    2829 |  # node_Mul_2034
            %"val_2080"<?,?> ⬅️ ::Mul(%"add_44", %"val_2079")
    2830 |  # node_Sqrt_2035
            %"val_2081"<?,?> ⬅️ ::Sqrt(%"val_2066")
    2831 |  # node_Mul_2036
            %"val_2082"<?,?> ⬅️ ::Mul(%"val_2078", %"val_2081")
    2832 |  # node_MatMul_2037
            %"val_2083"<?,?> ⬅️ ::MatMul(%"val_2080", %"val_2082")
    2833 |  # node_Add_2038
            %"val_2084"<?,?> ⬅️ ::Add(%"val_2083", %"masked_fill_1")
    2834 |  # node_Softmax_2039
            %"val_2085"<?,?> ⬅️ ::Softmax(%"val_2084") {axis=-1}
    2835 |  # node_scaled_dot_product_attention_11
            %"scaled_dot_product_attention_11"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2085", %"getitem_57")
    2836 |  # node_transpose_45
            %"transpose_45"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_11") {perm=(0, 2, 1, 3)}
    2837 |  # node_Constant_2040
            %"val_2086"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2838 |  # node_Constant_2041
            %"val_2087"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2839 |  # node_Constant_2042
            %"val_2088"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2840 |  # node_Constant_2043
            %"val_2089"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2841 |  # node_Concat_2044
            %"val_2090"<?,?> ⬅️ ::Concat(%"val_2087", %"val_2088", %"val_2089") {axis=0}
    2842 |  # node_view_23
            %"view_23"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_45", %"val_2090") {allowzero=1}
    2843 |  # node_Transpose_2045
            %"val_2091"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.attn.Wo.weight"{...}) {perm=(1, 0)}
    2844 |  # node_linear_45
            %"linear_45"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_23", %"val_2091")
    2845 |  # node_add_46
            %"add_46"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_43", %"linear_45")
    2846 |  # node_layer_norm_23
            %"layer_norm_23"<FLOAT,[1,97,768]>, %"val_2092"<?,?>, %"val_2093"<?,?> ⬅️ ::LayerNormalization(%"add_46", %"encoder.layers.11.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2847 |  # node_Transpose_2046
            %"val_2094"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2848 |  # node_linear_46
            %"linear_46"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_23", %"val_2094")
    2849 |  # node_split_11
            %"split_11"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_46", %"val_917") {dim=-1}
    2850 |  # node_getitem_58
            %"getitem_58"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_11", %"val_6")
    2851 |  # node_getitem_59
            %"getitem_59"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_11", %"val_51")
    2852 |  # node_Constant_2047
            %"val_2095"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2853 |  # node_Div_2048
            %"val_2096"<?,?> ⬅️ ::Div(%"getitem_58", %"val_2095")
    2854 |  # node_Erf_2049
            %"val_2097"<?,?> ⬅️ ::Erf(%"val_2096")
    2855 |  # node_Constant_2050
            %"val_2098"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2856 |  # node_Add_2051
            %"val_2099"<?,?> ⬅️ ::Add(%"val_2097", %"val_2098")
    2857 |  # node_Constant_2052
            %"val_2100"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2858 |  # node_Mul_2053
            %"val_2101"<?,?> ⬅️ ::Mul(%"val_2100", %"val_2099")
    2859 |  # node_gelu_11
            %"gelu_11"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_58", %"val_2101")
    2860 |  # node_mul_103
            %"mul_103"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_11", %"getitem_59")
    2861 |  # node_clone_13
            %"clone_13"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_103")
    2862 |  # node_Transpose_2054
            %"val_2102"<?,?> ⬅️ ::Transpose(%"encoder.layers.11.mlp.Wo.weight"{...}) {perm=(1, 0)}
    2863 |  # node_linear_47
            %"linear_47"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_13", %"val_2102")
    2864 |  # node_add_47
            %"add_47"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_46", %"linear_47")
    2865 |  # node_layer_norm_24
            %"layer_norm_24"<FLOAT,[1,97,768]>, %"val_2103"<?,?>, %"val_2104"<?,?> ⬅️ ::LayerNormalization(%"add_47", %"encoder.layers.12.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2866 |  # node_Transpose_2055
            %"val_2105"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    2867 |  # node_linear_48
            %"linear_48"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_24", %"val_2105")
    2868 |  # node_Constant_2056
            %"val_2106"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2869 |  # node_Constant_2057
            %"val_2107"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2870 |  # node_Constant_2058
            %"val_2108"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2871 |  # node_Constant_2059
            %"val_2109"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    2872 |  # node_Constant_2060
            %"val_2110"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    2873 |  # node_Constant_2061
            %"val_2111"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    2874 |  # node_Concat_2062
            %"val_2112"<?,?> ⬅️ ::Concat(%"val_2107", %"val_2108", %"val_2109", %"val_2110", %"val_2111") {axis=0}
    2875 |  # node_view_24
            %"view_24"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_48", %"val_2112") {allowzero=1}
    2876 |  # node_transpose_46
            %"transpose_46"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_24") {perm=(0, 3, 2, 1, 4)}
    2877 |  # node_Constant_2063
            %"val_2113"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    2878 |  # node_Constant_2064
            %"val_2114"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2879 |  # node_Constant_2065
            %"val_2115"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2880 |  # node_Slice_2066
            %"val_2116"<?,?> ⬅️ ::Slice(%"transpose_46", %"val_2113", %"val_2114", %"val_2115")
    2881 |  # node_unbind_12__0
            %"getitem_60"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2116", %"val_19")
    2882 |  # node_Constant_2067
            %"val_2117"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2883 |  # node_Constant_2068
            %"val_2118"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2884 |  # node_Constant_2069
            %"val_2119"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2885 |  # node_Slice_2070
            %"val_2120"<?,?> ⬅️ ::Slice(%"transpose_46", %"val_2117", %"val_2118", %"val_2119")
    2886 |  # node_unbind_12__1
            %"getitem_61"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2120", %"val_19")
    2887 |  # node_Constant_2071
            %"val_2121"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2888 |  # node_Constant_2072
            %"val_2122"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    2889 |  # node_Constant_2073
            %"val_2123"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    2890 |  # node_Slice_2074
            %"val_2124"<?,?> ⬅️ ::Slice(%"transpose_46", %"val_2121", %"val_2122", %"val_2123")
    2891 |  # node_unbind_12__2
            %"getitem_62"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2124", %"val_19")
    2892 |  # node_unsqueeze_96
            %"unsqueeze_96"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    2893 |  # node_unsqueeze_97
            %"unsqueeze_97"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    2894 |  # node_mul_104
            %"mul_104"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_60", %"unsqueeze_96")
    2895 |  # node_Cast_2075
            %"val_2125"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2896 |  # node_Constant_2076
            %"val_2126"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2897 |  # node_Reshape_2077
            %"val_2127"<?,?> ⬅️ ::Reshape(%"val_2125", %"val_2126") {allowzero=0}
    2898 |  # node_Cast_2078
            %"val_2128"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2899 |  # node_Constant_2079
            %"val_2129"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2900 |  # node_Reshape_2080
            %"val_2130"<?,?> ⬅️ ::Reshape(%"val_2128", %"val_2129") {allowzero=0}
    2901 |  # node_Cast_2081
            %"val_2131"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2902 |  # node_Constant_2082
            %"val_2132"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2903 |  # node_Reshape_2083
            %"val_2133"<?,?> ⬅️ ::Reshape(%"val_2131", %"val_2132") {allowzero=0}
    2904 |  # node_Constant_2084
            %"val_2134"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2905 |  # node_slice_117
            %"slice_117"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_60", %"val_2127", %"val_2130", %"val_2133", %"val_2134")
    2906 |  # node_Cast_2085
            %"val_2135"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2907 |  # node_Constant_2086
            %"val_2136"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2908 |  # node_Reshape_2087
            %"val_2137"<?,?> ⬅️ ::Reshape(%"val_2135", %"val_2136") {allowzero=0}
    2909 |  # node_Cast_2088
            %"val_2138"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2910 |  # node_Constant_2089
            %"val_2139"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2911 |  # node_Reshape_2090
            %"val_2140"<?,?> ⬅️ ::Reshape(%"val_2138", %"val_2139") {allowzero=0}
    2912 |  # node_Cast_2091
            %"val_2141"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2913 |  # node_Constant_2092
            %"val_2142"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2914 |  # node_Reshape_2093
            %"val_2143"<?,?> ⬅️ ::Reshape(%"val_2141", %"val_2142") {allowzero=0}
    2915 |  # node_Constant_2094
            %"val_2144"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2916 |  # node_slice_118
            %"slice_118"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_60", %"val_2137", %"val_2140", %"val_2143", %"val_2144")
    2917 |  # node_neg_24
            %"neg_24"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_118")
    2918 |  # node_cat_46
            %"cat_46"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_24", %"slice_117") {axis=-1}
    2919 |  # node_mul_105
            %"mul_105"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_46", %"unsqueeze_97")
    2920 |  # node_add_48
            %"add_48"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_104", %"mul_105")
    2921 |  # node_mul_106
            %"mul_106"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_61", %"unsqueeze_96")
    2922 |  # node_Cast_2095
            %"val_2145"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    2923 |  # node_Constant_2096
            %"val_2146"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2924 |  # node_Reshape_2097
            %"val_2147"<?,?> ⬅️ ::Reshape(%"val_2145", %"val_2146") {allowzero=0}
    2925 |  # node_Cast_2098
            %"val_2148"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2926 |  # node_Constant_2099
            %"val_2149"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2927 |  # node_Reshape_2100
            %"val_2150"<?,?> ⬅️ ::Reshape(%"val_2148", %"val_2149") {allowzero=0}
    2928 |  # node_Cast_2101
            %"val_2151"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2929 |  # node_Constant_2102
            %"val_2152"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2930 |  # node_Reshape_2103
            %"val_2153"<?,?> ⬅️ ::Reshape(%"val_2151", %"val_2152") {allowzero=0}
    2931 |  # node_Constant_2104
            %"val_2154"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2932 |  # node_slice_119
            %"slice_119"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_61", %"val_2147", %"val_2150", %"val_2153", %"val_2154")
    2933 |  # node_Cast_2105
            %"val_2155"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    2934 |  # node_Constant_2106
            %"val_2156"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2935 |  # node_Reshape_2107
            %"val_2157"<?,?> ⬅️ ::Reshape(%"val_2155", %"val_2156") {allowzero=0}
    2936 |  # node_Cast_2108
            %"val_2158"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    2937 |  # node_Constant_2109
            %"val_2159"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2938 |  # node_Reshape_2110
            %"val_2160"<?,?> ⬅️ ::Reshape(%"val_2158", %"val_2159") {allowzero=0}
    2939 |  # node_Cast_2111
            %"val_2161"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    2940 |  # node_Constant_2112
            %"val_2162"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2941 |  # node_Reshape_2113
            %"val_2163"<?,?> ⬅️ ::Reshape(%"val_2161", %"val_2162") {allowzero=0}
    2942 |  # node_Constant_2114
            %"val_2164"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    2943 |  # node_slice_120
            %"slice_120"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_61", %"val_2157", %"val_2160", %"val_2163", %"val_2164")
    2944 |  # node_neg_25
            %"neg_25"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_120")
    2945 |  # node_cat_47
            %"cat_47"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_25", %"slice_119") {axis=-1}
    2946 |  # node_mul_107
            %"mul_107"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_47", %"unsqueeze_97")
    2947 |  # node_add_49
            %"add_49"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_106", %"mul_107")
    2948 |  # node_Shape_2115
            %"val_2165"<?,?> ⬅️ ::Shape(%"add_48") {start=0}
    2949 |  # node_Constant_2116
            %"val_2166"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2950 |  # node_Gather_2117
            %"val_2167"<?,?> ⬅️ ::Gather(%"val_2165", %"val_2166") {axis=0}
    2951 |  # node_CastLike_2118
            %"val_2168"<?,?> ⬅️ ::CastLike(%"val_2167", %"add_48")
    2952 |  # node_Constant_2119
            %"val_2169"<?,?> ⬅️ ::Constant() {value_float=1.0}
    2953 |  # node_CastLike_2120
            %"val_2170"<?,?> ⬅️ ::CastLike(%"val_2169", %"add_48")
    2954 |  # node_Sqrt_2121
            %"val_2171"<?,?> ⬅️ ::Sqrt(%"val_2168")
    2955 |  # node_Div_2122
            %"val_2172"<?,?> ⬅️ ::Div(%"val_2170", %"val_2171")
    2956 |  # node_CastLike_2123
            %"val_2173"<?,?> ⬅️ ::CastLike(%"val_2172", %"add_48")
    2957 |  # node_Shape_2124
            %"val_2174"<?,?> ⬅️ ::Shape(%"add_49") {start=0}
    2958 |  # node_Constant_2125
            %"val_2175"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    2959 |  # node_Slice_2126
            %"val_2176"<?,?> ⬅️ ::Slice(%"val_2174", %"val_889", %"val_2175")
    2960 |  # node_Slice_2127
            %"val_2177"<?,?> ⬅️ ::Slice(%"val_2174", %"val_891", %"val_889")
    2961 |  # node_Constant_2128
            %"val_2178"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    2962 |  # node_Slice_2129
            %"val_2179"<?,?> ⬅️ ::Slice(%"val_2174", %"val_2178", %"val_891")
    2963 |  # node_Constant_2130
            %"val_2180"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2964 |  # node_Concat_2131
            %"val_2181"<?,?> ⬅️ ::Concat(%"val_2180", %"val_2177", %"val_2176") {axis=0}
    2965 |  # node_Reshape_2132
            %"val_2182"<?,?> ⬅️ ::Reshape(%"add_49", %"val_2181") {allowzero=0}
    2966 |  # node_Transpose_2133
            %"val_2183"<?,?> ⬅️ ::Transpose(%"val_2182") {perm=(0, 2, 1)}
    2967 |  # node_Concat_2134
            %"val_2184"<?,?> ⬅️ ::Concat(%"val_2179", %"val_2176", %"val_2177") {axis=0}
    2968 |  # node_Reshape_2135
            %"val_2185"<?,?> ⬅️ ::Reshape(%"val_2183", %"val_2184") {allowzero=0}
    2969 |  # node_Sqrt_2136
            %"val_2186"<?,?> ⬅️ ::Sqrt(%"val_2173")
    2970 |  # node_Mul_2137
            %"val_2187"<?,?> ⬅️ ::Mul(%"add_48", %"val_2186")
    2971 |  # node_Sqrt_2138
            %"val_2188"<?,?> ⬅️ ::Sqrt(%"val_2173")
    2972 |  # node_Mul_2139
            %"val_2189"<?,?> ⬅️ ::Mul(%"val_2185", %"val_2188")
    2973 |  # node_MatMul_2140
            %"val_2190"<?,?> ⬅️ ::MatMul(%"val_2187", %"val_2189")
    2974 |  # node_Add_2141
            %"val_2191"<?,?> ⬅️ ::Add(%"val_2190", %"masked_fill")
    2975 |  # node_Softmax_2142
            %"val_2192"<?,?> ⬅️ ::Softmax(%"val_2191") {axis=-1}
    2976 |  # node_scaled_dot_product_attention_12
            %"scaled_dot_product_attention_12"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2192", %"getitem_62")
    2977 |  # node_transpose_47
            %"transpose_47"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_12") {perm=(0, 2, 1, 3)}
    2978 |  # node_Constant_2143
            %"val_2193"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2979 |  # node_Constant_2144
            %"val_2194"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    2980 |  # node_Constant_2145
            %"val_2195"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    2981 |  # node_Constant_2146
            %"val_2196"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    2982 |  # node_Concat_2147
            %"val_2197"<?,?> ⬅️ ::Concat(%"val_2194", %"val_2195", %"val_2196") {axis=0}
    2983 |  # node_view_25
            %"view_25"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_47", %"val_2197") {allowzero=1}
    2984 |  # node_Transpose_2148
            %"val_2198"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.attn.Wo.weight"{...}) {perm=(1, 0)}
    2985 |  # node_linear_49
            %"linear_49"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_25", %"val_2198")
    2986 |  # node_add_50
            %"add_50"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_47", %"linear_49")
    2987 |  # node_layer_norm_25
            %"layer_norm_25"<FLOAT,[1,97,768]>, %"val_2199"<?,?>, %"val_2200"<?,?> ⬅️ ::LayerNormalization(%"add_50", %"encoder.layers.12.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    2988 |  # node_Transpose_2149
            %"val_2201"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.mlp.Wi.weight"{...}) {perm=(1, 0)}
    2989 |  # node_linear_50
            %"linear_50"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_25", %"val_2201")
    2990 |  # node_split_12
            %"split_12"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_50", %"val_917") {dim=-1}
    2991 |  # node_getitem_63
            %"getitem_63"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_12", %"val_6")
    2992 |  # node_getitem_64
            %"getitem_64"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_12", %"val_51")
    2993 |  # node_Constant_2150
            %"val_2202"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    2994 |  # node_Div_2151
            %"val_2203"<?,?> ⬅️ ::Div(%"getitem_63", %"val_2202")
    2995 |  # node_Erf_2152
            %"val_2204"<?,?> ⬅️ ::Erf(%"val_2203")
    2996 |  # node_Constant_2153
            %"val_2205"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    2997 |  # node_Add_2154
            %"val_2206"<?,?> ⬅️ ::Add(%"val_2204", %"val_2205")
    2998 |  # node_Constant_2155
            %"val_2207"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    2999 |  # node_Mul_2156
            %"val_2208"<?,?> ⬅️ ::Mul(%"val_2207", %"val_2206")
    3000 |  # node_gelu_12
            %"gelu_12"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_63", %"val_2208")
    3001 |  # node_mul_108
            %"mul_108"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_12", %"getitem_64")
    3002 |  # node_clone_14
            %"clone_14"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_108")
    3003 |  # node_Transpose_2157
            %"val_2209"<?,?> ⬅️ ::Transpose(%"encoder.layers.12.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3004 |  # node_linear_51
            %"linear_51"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_14", %"val_2209")
    3005 |  # node_add_51
            %"add_51"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_50", %"linear_51")
    3006 |  # node_layer_norm_26
            %"layer_norm_26"<FLOAT,[1,97,768]>, %"val_2210"<?,?>, %"val_2211"<?,?> ⬅️ ::LayerNormalization(%"add_51", %"encoder.layers.13.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3007 |  # node_Transpose_2158
            %"val_2212"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3008 |  # node_linear_52
            %"linear_52"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_26", %"val_2212")
    3009 |  # node_Constant_2159
            %"val_2213"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3010 |  # node_Constant_2160
            %"val_2214"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3011 |  # node_Constant_2161
            %"val_2215"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3012 |  # node_Constant_2162
            %"val_2216"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3013 |  # node_Constant_2163
            %"val_2217"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3014 |  # node_Constant_2164
            %"val_2218"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3015 |  # node_Concat_2165
            %"val_2219"<?,?> ⬅️ ::Concat(%"val_2214", %"val_2215", %"val_2216", %"val_2217", %"val_2218") {axis=0}
    3016 |  # node_view_26
            %"view_26"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_52", %"val_2219") {allowzero=1}
    3017 |  # node_transpose_48
            %"transpose_48"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_26") {perm=(0, 3, 2, 1, 4)}
    3018 |  # node_Constant_2166
            %"val_2220"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3019 |  # node_Constant_2167
            %"val_2221"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3020 |  # node_Constant_2168
            %"val_2222"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3021 |  # node_Slice_2169
            %"val_2223"<?,?> ⬅️ ::Slice(%"transpose_48", %"val_2220", %"val_2221", %"val_2222")
    3022 |  # node_unbind_13__0
            %"getitem_65"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2223", %"val_19")
    3023 |  # node_Constant_2170
            %"val_2224"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3024 |  # node_Constant_2171
            %"val_2225"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3025 |  # node_Constant_2172
            %"val_2226"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3026 |  # node_Slice_2173
            %"val_2227"<?,?> ⬅️ ::Slice(%"transpose_48", %"val_2224", %"val_2225", %"val_2226")
    3027 |  # node_unbind_13__1
            %"getitem_66"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2227", %"val_19")
    3028 |  # node_Constant_2174
            %"val_2228"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3029 |  # node_Constant_2175
            %"val_2229"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3030 |  # node_Constant_2176
            %"val_2230"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3031 |  # node_Slice_2177
            %"val_2231"<?,?> ⬅️ ::Slice(%"transpose_48", %"val_2228", %"val_2229", %"val_2230")
    3032 |  # node_unbind_13__2
            %"getitem_67"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2231", %"val_19")
    3033 |  # node_unsqueeze_98
            %"unsqueeze_98"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3034 |  # node_unsqueeze_99
            %"unsqueeze_99"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3035 |  # node_mul_109
            %"mul_109"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_65", %"unsqueeze_98")
    3036 |  # node_Cast_2178
            %"val_2232"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3037 |  # node_Constant_2179
            %"val_2233"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3038 |  # node_Reshape_2180
            %"val_2234"<?,?> ⬅️ ::Reshape(%"val_2232", %"val_2233") {allowzero=0}
    3039 |  # node_Cast_2181
            %"val_2235"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3040 |  # node_Constant_2182
            %"val_2236"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3041 |  # node_Reshape_2183
            %"val_2237"<?,?> ⬅️ ::Reshape(%"val_2235", %"val_2236") {allowzero=0}
    3042 |  # node_Cast_2184
            %"val_2238"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3043 |  # node_Constant_2185
            %"val_2239"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3044 |  # node_Reshape_2186
            %"val_2240"<?,?> ⬅️ ::Reshape(%"val_2238", %"val_2239") {allowzero=0}
    3045 |  # node_Constant_2187
            %"val_2241"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3046 |  # node_slice_121
            %"slice_121"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_65", %"val_2234", %"val_2237", %"val_2240", %"val_2241")
    3047 |  # node_Cast_2188
            %"val_2242"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3048 |  # node_Constant_2189
            %"val_2243"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3049 |  # node_Reshape_2190
            %"val_2244"<?,?> ⬅️ ::Reshape(%"val_2242", %"val_2243") {allowzero=0}
    3050 |  # node_Cast_2191
            %"val_2245"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3051 |  # node_Constant_2192
            %"val_2246"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3052 |  # node_Reshape_2193
            %"val_2247"<?,?> ⬅️ ::Reshape(%"val_2245", %"val_2246") {allowzero=0}
    3053 |  # node_Cast_2194
            %"val_2248"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3054 |  # node_Constant_2195
            %"val_2249"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3055 |  # node_Reshape_2196
            %"val_2250"<?,?> ⬅️ ::Reshape(%"val_2248", %"val_2249") {allowzero=0}
    3056 |  # node_Constant_2197
            %"val_2251"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3057 |  # node_slice_122
            %"slice_122"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_65", %"val_2244", %"val_2247", %"val_2250", %"val_2251")
    3058 |  # node_neg_26
            %"neg_26"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_122")
    3059 |  # node_cat_48
            %"cat_48"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_26", %"slice_121") {axis=-1}
    3060 |  # node_mul_110
            %"mul_110"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_48", %"unsqueeze_99")
    3061 |  # node_add_52
            %"add_52"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_109", %"mul_110")
    3062 |  # node_mul_111
            %"mul_111"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_66", %"unsqueeze_98")
    3063 |  # node_Cast_2198
            %"val_2252"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3064 |  # node_Constant_2199
            %"val_2253"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3065 |  # node_Reshape_2200
            %"val_2254"<?,?> ⬅️ ::Reshape(%"val_2252", %"val_2253") {allowzero=0}
    3066 |  # node_Cast_2201
            %"val_2255"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3067 |  # node_Constant_2202
            %"val_2256"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3068 |  # node_Reshape_2203
            %"val_2257"<?,?> ⬅️ ::Reshape(%"val_2255", %"val_2256") {allowzero=0}
    3069 |  # node_Cast_2204
            %"val_2258"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3070 |  # node_Constant_2205
            %"val_2259"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3071 |  # node_Reshape_2206
            %"val_2260"<?,?> ⬅️ ::Reshape(%"val_2258", %"val_2259") {allowzero=0}
    3072 |  # node_Constant_2207
            %"val_2261"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3073 |  # node_slice_123
            %"slice_123"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_66", %"val_2254", %"val_2257", %"val_2260", %"val_2261")
    3074 |  # node_Cast_2208
            %"val_2262"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3075 |  # node_Constant_2209
            %"val_2263"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3076 |  # node_Reshape_2210
            %"val_2264"<?,?> ⬅️ ::Reshape(%"val_2262", %"val_2263") {allowzero=0}
    3077 |  # node_Cast_2211
            %"val_2265"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3078 |  # node_Constant_2212
            %"val_2266"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3079 |  # node_Reshape_2213
            %"val_2267"<?,?> ⬅️ ::Reshape(%"val_2265", %"val_2266") {allowzero=0}
    3080 |  # node_Cast_2214
            %"val_2268"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3081 |  # node_Constant_2215
            %"val_2269"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3082 |  # node_Reshape_2216
            %"val_2270"<?,?> ⬅️ ::Reshape(%"val_2268", %"val_2269") {allowzero=0}
    3083 |  # node_Constant_2217
            %"val_2271"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3084 |  # node_slice_124
            %"slice_124"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_66", %"val_2264", %"val_2267", %"val_2270", %"val_2271")
    3085 |  # node_neg_27
            %"neg_27"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_124")
    3086 |  # node_cat_49
            %"cat_49"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_27", %"slice_123") {axis=-1}
    3087 |  # node_mul_112
            %"mul_112"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_49", %"unsqueeze_99")
    3088 |  # node_add_53
            %"add_53"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_111", %"mul_112")
    3089 |  # node_Shape_2218
            %"val_2272"<?,?> ⬅️ ::Shape(%"add_52") {start=0}
    3090 |  # node_Constant_2219
            %"val_2273"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3091 |  # node_Gather_2220
            %"val_2274"<?,?> ⬅️ ::Gather(%"val_2272", %"val_2273") {axis=0}
    3092 |  # node_CastLike_2221
            %"val_2275"<?,?> ⬅️ ::CastLike(%"val_2274", %"add_52")
    3093 |  # node_Constant_2222
            %"val_2276"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3094 |  # node_CastLike_2223
            %"val_2277"<?,?> ⬅️ ::CastLike(%"val_2276", %"add_52")
    3095 |  # node_Sqrt_2224
            %"val_2278"<?,?> ⬅️ ::Sqrt(%"val_2275")
    3096 |  # node_Div_2225
            %"val_2279"<?,?> ⬅️ ::Div(%"val_2277", %"val_2278")
    3097 |  # node_CastLike_2226
            %"val_2280"<?,?> ⬅️ ::CastLike(%"val_2279", %"add_52")
    3098 |  # node_Shape_2227
            %"val_2281"<?,?> ⬅️ ::Shape(%"add_53") {start=0}
    3099 |  # node_Constant_2228
            %"val_2282"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3100 |  # node_Slice_2229
            %"val_2283"<?,?> ⬅️ ::Slice(%"val_2281", %"val_889", %"val_2282")
    3101 |  # node_Slice_2230
            %"val_2284"<?,?> ⬅️ ::Slice(%"val_2281", %"val_891", %"val_889")
    3102 |  # node_Constant_2231
            %"val_2285"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3103 |  # node_Slice_2232
            %"val_2286"<?,?> ⬅️ ::Slice(%"val_2281", %"val_2285", %"val_891")
    3104 |  # node_Constant_2233
            %"val_2287"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3105 |  # node_Concat_2234
            %"val_2288"<?,?> ⬅️ ::Concat(%"val_2287", %"val_2284", %"val_2283") {axis=0}
    3106 |  # node_Reshape_2235
            %"val_2289"<?,?> ⬅️ ::Reshape(%"add_53", %"val_2288") {allowzero=0}
    3107 |  # node_Transpose_2236
            %"val_2290"<?,?> ⬅️ ::Transpose(%"val_2289") {perm=(0, 2, 1)}
    3108 |  # node_Concat_2237
            %"val_2291"<?,?> ⬅️ ::Concat(%"val_2286", %"val_2283", %"val_2284") {axis=0}
    3109 |  # node_Reshape_2238
            %"val_2292"<?,?> ⬅️ ::Reshape(%"val_2290", %"val_2291") {allowzero=0}
    3110 |  # node_Sqrt_2239
            %"val_2293"<?,?> ⬅️ ::Sqrt(%"val_2280")
    3111 |  # node_Mul_2240
            %"val_2294"<?,?> ⬅️ ::Mul(%"add_52", %"val_2293")
    3112 |  # node_Sqrt_2241
            %"val_2295"<?,?> ⬅️ ::Sqrt(%"val_2280")
    3113 |  # node_Mul_2242
            %"val_2296"<?,?> ⬅️ ::Mul(%"val_2292", %"val_2295")
    3114 |  # node_MatMul_2243
            %"val_2297"<?,?> ⬅️ ::MatMul(%"val_2294", %"val_2296")
    3115 |  # node_Add_2244
            %"val_2298"<?,?> ⬅️ ::Add(%"val_2297", %"masked_fill_1")
    3116 |  # node_Softmax_2245
            %"val_2299"<?,?> ⬅️ ::Softmax(%"val_2298") {axis=-1}
    3117 |  # node_scaled_dot_product_attention_13
            %"scaled_dot_product_attention_13"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2299", %"getitem_67")
    3118 |  # node_transpose_49
            %"transpose_49"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_13") {perm=(0, 2, 1, 3)}
    3119 |  # node_Constant_2246
            %"val_2300"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3120 |  # node_Constant_2247
            %"val_2301"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3121 |  # node_Constant_2248
            %"val_2302"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3122 |  # node_Constant_2249
            %"val_2303"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3123 |  # node_Concat_2250
            %"val_2304"<?,?> ⬅️ ::Concat(%"val_2301", %"val_2302", %"val_2303") {axis=0}
    3124 |  # node_view_27
            %"view_27"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_49", %"val_2304") {allowzero=1}
    3125 |  # node_Transpose_2251
            %"val_2305"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.attn.Wo.weight"{...}) {perm=(1, 0)}
    3126 |  # node_linear_53
            %"linear_53"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_27", %"val_2305")
    3127 |  # node_add_54
            %"add_54"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_51", %"linear_53")
    3128 |  # node_layer_norm_27
            %"layer_norm_27"<FLOAT,[1,97,768]>, %"val_2306"<?,?>, %"val_2307"<?,?> ⬅️ ::LayerNormalization(%"add_54", %"encoder.layers.13.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3129 |  # node_Transpose_2252
            %"val_2308"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3130 |  # node_linear_54
            %"linear_54"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_27", %"val_2308")
    3131 |  # node_split_13
            %"split_13"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_54", %"val_917") {dim=-1}
    3132 |  # node_getitem_68
            %"getitem_68"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_13", %"val_6")
    3133 |  # node_getitem_69
            %"getitem_69"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_13", %"val_51")
    3134 |  # node_Constant_2253
            %"val_2309"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3135 |  # node_Div_2254
            %"val_2310"<?,?> ⬅️ ::Div(%"getitem_68", %"val_2309")
    3136 |  # node_Erf_2255
            %"val_2311"<?,?> ⬅️ ::Erf(%"val_2310")
    3137 |  # node_Constant_2256
            %"val_2312"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3138 |  # node_Add_2257
            %"val_2313"<?,?> ⬅️ ::Add(%"val_2311", %"val_2312")
    3139 |  # node_Constant_2258
            %"val_2314"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3140 |  # node_Mul_2259
            %"val_2315"<?,?> ⬅️ ::Mul(%"val_2314", %"val_2313")
    3141 |  # node_gelu_13
            %"gelu_13"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_68", %"val_2315")
    3142 |  # node_mul_113
            %"mul_113"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_13", %"getitem_69")
    3143 |  # node_clone_15
            %"clone_15"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_113")
    3144 |  # node_Transpose_2260
            %"val_2316"<?,?> ⬅️ ::Transpose(%"encoder.layers.13.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3145 |  # node_linear_55
            %"linear_55"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_15", %"val_2316")
    3146 |  # node_add_55
            %"add_55"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_54", %"linear_55")
    3147 |  # node_layer_norm_28
            %"layer_norm_28"<FLOAT,[1,97,768]>, %"val_2317"<?,?>, %"val_2318"<?,?> ⬅️ ::LayerNormalization(%"add_55", %"encoder.layers.14.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3148 |  # node_Transpose_2261
            %"val_2319"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3149 |  # node_linear_56
            %"linear_56"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_28", %"val_2319")
    3150 |  # node_Constant_2262
            %"val_2320"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3151 |  # node_Constant_2263
            %"val_2321"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3152 |  # node_Constant_2264
            %"val_2322"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3153 |  # node_Constant_2265
            %"val_2323"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3154 |  # node_Constant_2266
            %"val_2324"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3155 |  # node_Constant_2267
            %"val_2325"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3156 |  # node_Concat_2268
            %"val_2326"<?,?> ⬅️ ::Concat(%"val_2321", %"val_2322", %"val_2323", %"val_2324", %"val_2325") {axis=0}
    3157 |  # node_view_28
            %"view_28"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_56", %"val_2326") {allowzero=1}
    3158 |  # node_transpose_50
            %"transpose_50"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_28") {perm=(0, 3, 2, 1, 4)}
    3159 |  # node_Constant_2269
            %"val_2327"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3160 |  # node_Constant_2270
            %"val_2328"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3161 |  # node_Constant_2271
            %"val_2329"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3162 |  # node_Slice_2272
            %"val_2330"<?,?> ⬅️ ::Slice(%"transpose_50", %"val_2327", %"val_2328", %"val_2329")
    3163 |  # node_unbind_14__0
            %"getitem_70"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2330", %"val_19")
    3164 |  # node_Constant_2273
            %"val_2331"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3165 |  # node_Constant_2274
            %"val_2332"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3166 |  # node_Constant_2275
            %"val_2333"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3167 |  # node_Slice_2276
            %"val_2334"<?,?> ⬅️ ::Slice(%"transpose_50", %"val_2331", %"val_2332", %"val_2333")
    3168 |  # node_unbind_14__1
            %"getitem_71"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2334", %"val_19")
    3169 |  # node_Constant_2277
            %"val_2335"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3170 |  # node_Constant_2278
            %"val_2336"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3171 |  # node_Constant_2279
            %"val_2337"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3172 |  # node_Slice_2280
            %"val_2338"<?,?> ⬅️ ::Slice(%"transpose_50", %"val_2335", %"val_2336", %"val_2337")
    3173 |  # node_unbind_14__2
            %"getitem_72"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2338", %"val_19")
    3174 |  # node_unsqueeze_100
            %"unsqueeze_100"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3175 |  # node_unsqueeze_101
            %"unsqueeze_101"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3176 |  # node_mul_114
            %"mul_114"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_70", %"unsqueeze_100")
    3177 |  # node_Cast_2281
            %"val_2339"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3178 |  # node_Constant_2282
            %"val_2340"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3179 |  # node_Reshape_2283
            %"val_2341"<?,?> ⬅️ ::Reshape(%"val_2339", %"val_2340") {allowzero=0}
    3180 |  # node_Cast_2284
            %"val_2342"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3181 |  # node_Constant_2285
            %"val_2343"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3182 |  # node_Reshape_2286
            %"val_2344"<?,?> ⬅️ ::Reshape(%"val_2342", %"val_2343") {allowzero=0}
    3183 |  # node_Cast_2287
            %"val_2345"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3184 |  # node_Constant_2288
            %"val_2346"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3185 |  # node_Reshape_2289
            %"val_2347"<?,?> ⬅️ ::Reshape(%"val_2345", %"val_2346") {allowzero=0}
    3186 |  # node_Constant_2290
            %"val_2348"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3187 |  # node_slice_125
            %"slice_125"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_70", %"val_2341", %"val_2344", %"val_2347", %"val_2348")
    3188 |  # node_Cast_2291
            %"val_2349"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3189 |  # node_Constant_2292
            %"val_2350"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3190 |  # node_Reshape_2293
            %"val_2351"<?,?> ⬅️ ::Reshape(%"val_2349", %"val_2350") {allowzero=0}
    3191 |  # node_Cast_2294
            %"val_2352"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3192 |  # node_Constant_2295
            %"val_2353"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3193 |  # node_Reshape_2296
            %"val_2354"<?,?> ⬅️ ::Reshape(%"val_2352", %"val_2353") {allowzero=0}
    3194 |  # node_Cast_2297
            %"val_2355"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3195 |  # node_Constant_2298
            %"val_2356"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3196 |  # node_Reshape_2299
            %"val_2357"<?,?> ⬅️ ::Reshape(%"val_2355", %"val_2356") {allowzero=0}
    3197 |  # node_Constant_2300
            %"val_2358"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3198 |  # node_slice_126
            %"slice_126"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_70", %"val_2351", %"val_2354", %"val_2357", %"val_2358")
    3199 |  # node_neg_28
            %"neg_28"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_126")
    3200 |  # node_cat_50
            %"cat_50"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_28", %"slice_125") {axis=-1}
    3201 |  # node_mul_115
            %"mul_115"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_50", %"unsqueeze_101")
    3202 |  # node_add_56
            %"add_56"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_114", %"mul_115")
    3203 |  # node_mul_116
            %"mul_116"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_71", %"unsqueeze_100")
    3204 |  # node_Cast_2301
            %"val_2359"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3205 |  # node_Constant_2302
            %"val_2360"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3206 |  # node_Reshape_2303
            %"val_2361"<?,?> ⬅️ ::Reshape(%"val_2359", %"val_2360") {allowzero=0}
    3207 |  # node_Cast_2304
            %"val_2362"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3208 |  # node_Constant_2305
            %"val_2363"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3209 |  # node_Reshape_2306
            %"val_2364"<?,?> ⬅️ ::Reshape(%"val_2362", %"val_2363") {allowzero=0}
    3210 |  # node_Cast_2307
            %"val_2365"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3211 |  # node_Constant_2308
            %"val_2366"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3212 |  # node_Reshape_2309
            %"val_2367"<?,?> ⬅️ ::Reshape(%"val_2365", %"val_2366") {allowzero=0}
    3213 |  # node_Constant_2310
            %"val_2368"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3214 |  # node_slice_127
            %"slice_127"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_71", %"val_2361", %"val_2364", %"val_2367", %"val_2368")
    3215 |  # node_Cast_2311
            %"val_2369"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3216 |  # node_Constant_2312
            %"val_2370"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3217 |  # node_Reshape_2313
            %"val_2371"<?,?> ⬅️ ::Reshape(%"val_2369", %"val_2370") {allowzero=0}
    3218 |  # node_Cast_2314
            %"val_2372"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3219 |  # node_Constant_2315
            %"val_2373"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3220 |  # node_Reshape_2316
            %"val_2374"<?,?> ⬅️ ::Reshape(%"val_2372", %"val_2373") {allowzero=0}
    3221 |  # node_Cast_2317
            %"val_2375"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3222 |  # node_Constant_2318
            %"val_2376"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3223 |  # node_Reshape_2319
            %"val_2377"<?,?> ⬅️ ::Reshape(%"val_2375", %"val_2376") {allowzero=0}
    3224 |  # node_Constant_2320
            %"val_2378"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3225 |  # node_slice_128
            %"slice_128"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_71", %"val_2371", %"val_2374", %"val_2377", %"val_2378")
    3226 |  # node_neg_29
            %"neg_29"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_128")
    3227 |  # node_cat_51
            %"cat_51"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_29", %"slice_127") {axis=-1}
    3228 |  # node_mul_117
            %"mul_117"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_51", %"unsqueeze_101")
    3229 |  # node_add_57
            %"add_57"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_116", %"mul_117")
    3230 |  # node_Shape_2321
            %"val_2379"<?,?> ⬅️ ::Shape(%"add_56") {start=0}
    3231 |  # node_Constant_2322
            %"val_2380"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3232 |  # node_Gather_2323
            %"val_2381"<?,?> ⬅️ ::Gather(%"val_2379", %"val_2380") {axis=0}
    3233 |  # node_CastLike_2324
            %"val_2382"<?,?> ⬅️ ::CastLike(%"val_2381", %"add_56")
    3234 |  # node_Constant_2325
            %"val_2383"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3235 |  # node_CastLike_2326
            %"val_2384"<?,?> ⬅️ ::CastLike(%"val_2383", %"add_56")
    3236 |  # node_Sqrt_2327
            %"val_2385"<?,?> ⬅️ ::Sqrt(%"val_2382")
    3237 |  # node_Div_2328
            %"val_2386"<?,?> ⬅️ ::Div(%"val_2384", %"val_2385")
    3238 |  # node_CastLike_2329
            %"val_2387"<?,?> ⬅️ ::CastLike(%"val_2386", %"add_56")
    3239 |  # node_Shape_2330
            %"val_2388"<?,?> ⬅️ ::Shape(%"add_57") {start=0}
    3240 |  # node_Constant_2331
            %"val_2389"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3241 |  # node_Slice_2332
            %"val_2390"<?,?> ⬅️ ::Slice(%"val_2388", %"val_889", %"val_2389")
    3242 |  # node_Slice_2333
            %"val_2391"<?,?> ⬅️ ::Slice(%"val_2388", %"val_891", %"val_889")
    3243 |  # node_Constant_2334
            %"val_2392"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3244 |  # node_Slice_2335
            %"val_2393"<?,?> ⬅️ ::Slice(%"val_2388", %"val_2392", %"val_891")
    3245 |  # node_Constant_2336
            %"val_2394"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3246 |  # node_Concat_2337
            %"val_2395"<?,?> ⬅️ ::Concat(%"val_2394", %"val_2391", %"val_2390") {axis=0}
    3247 |  # node_Reshape_2338
            %"val_2396"<?,?> ⬅️ ::Reshape(%"add_57", %"val_2395") {allowzero=0}
    3248 |  # node_Transpose_2339
            %"val_2397"<?,?> ⬅️ ::Transpose(%"val_2396") {perm=(0, 2, 1)}
    3249 |  # node_Concat_2340
            %"val_2398"<?,?> ⬅️ ::Concat(%"val_2393", %"val_2390", %"val_2391") {axis=0}
    3250 |  # node_Reshape_2341
            %"val_2399"<?,?> ⬅️ ::Reshape(%"val_2397", %"val_2398") {allowzero=0}
    3251 |  # node_Sqrt_2342
            %"val_2400"<?,?> ⬅️ ::Sqrt(%"val_2387")
    3252 |  # node_Mul_2343
            %"val_2401"<?,?> ⬅️ ::Mul(%"add_56", %"val_2400")
    3253 |  # node_Sqrt_2344
            %"val_2402"<?,?> ⬅️ ::Sqrt(%"val_2387")
    3254 |  # node_Mul_2345
            %"val_2403"<?,?> ⬅️ ::Mul(%"val_2399", %"val_2402")
    3255 |  # node_MatMul_2346
            %"val_2404"<?,?> ⬅️ ::MatMul(%"val_2401", %"val_2403")
    3256 |  # node_Add_2347
            %"val_2405"<?,?> ⬅️ ::Add(%"val_2404", %"masked_fill_1")
    3257 |  # node_Softmax_2348
            %"val_2406"<?,?> ⬅️ ::Softmax(%"val_2405") {axis=-1}
    3258 |  # node_scaled_dot_product_attention_14
            %"scaled_dot_product_attention_14"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2406", %"getitem_72")
    3259 |  # node_transpose_51
            %"transpose_51"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_14") {perm=(0, 2, 1, 3)}
    3260 |  # node_Constant_2349
            %"val_2407"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3261 |  # node_Constant_2350
            %"val_2408"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3262 |  # node_Constant_2351
            %"val_2409"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3263 |  # node_Constant_2352
            %"val_2410"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3264 |  # node_Concat_2353
            %"val_2411"<?,?> ⬅️ ::Concat(%"val_2408", %"val_2409", %"val_2410") {axis=0}
    3265 |  # node_view_29
            %"view_29"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_51", %"val_2411") {allowzero=1}
    3266 |  # node_Transpose_2354
            %"val_2412"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.attn.Wo.weight"{...}) {perm=(1, 0)}
    3267 |  # node_linear_57
            %"linear_57"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_29", %"val_2412")
    3268 |  # node_add_58
            %"add_58"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_55", %"linear_57")
    3269 |  # node_layer_norm_29
            %"layer_norm_29"<FLOAT,[1,97,768]>, %"val_2413"<?,?>, %"val_2414"<?,?> ⬅️ ::LayerNormalization(%"add_58", %"encoder.layers.14.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3270 |  # node_Transpose_2355
            %"val_2415"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3271 |  # node_linear_58
            %"linear_58"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_29", %"val_2415")
    3272 |  # node_split_14
            %"split_14"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_58", %"val_917") {dim=-1}
    3273 |  # node_getitem_73
            %"getitem_73"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_14", %"val_6")
    3274 |  # node_getitem_74
            %"getitem_74"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_14", %"val_51")
    3275 |  # node_Constant_2356
            %"val_2416"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3276 |  # node_Div_2357
            %"val_2417"<?,?> ⬅️ ::Div(%"getitem_73", %"val_2416")
    3277 |  # node_Erf_2358
            %"val_2418"<?,?> ⬅️ ::Erf(%"val_2417")
    3278 |  # node_Constant_2359
            %"val_2419"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3279 |  # node_Add_2360
            %"val_2420"<?,?> ⬅️ ::Add(%"val_2418", %"val_2419")
    3280 |  # node_Constant_2361
            %"val_2421"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3281 |  # node_Mul_2362
            %"val_2422"<?,?> ⬅️ ::Mul(%"val_2421", %"val_2420")
    3282 |  # node_gelu_14
            %"gelu_14"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_73", %"val_2422")
    3283 |  # node_mul_118
            %"mul_118"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_14", %"getitem_74")
    3284 |  # node_clone_16
            %"clone_16"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_118")
    3285 |  # node_Transpose_2363
            %"val_2423"<?,?> ⬅️ ::Transpose(%"encoder.layers.14.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3286 |  # node_linear_59
            %"linear_59"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_16", %"val_2423")
    3287 |  # node_add_59
            %"add_59"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_58", %"linear_59")
    3288 |  # node_layer_norm_30
            %"layer_norm_30"<FLOAT,[1,97,768]>, %"val_2424"<?,?>, %"val_2425"<?,?> ⬅️ ::LayerNormalization(%"add_59", %"encoder.layers.15.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3289 |  # node_Transpose_2364
            %"val_2426"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3290 |  # node_linear_60
            %"linear_60"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_30", %"val_2426")
    3291 |  # node_Constant_2365
            %"val_2427"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3292 |  # node_Constant_2366
            %"val_2428"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3293 |  # node_Constant_2367
            %"val_2429"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3294 |  # node_Constant_2368
            %"val_2430"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3295 |  # node_Constant_2369
            %"val_2431"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3296 |  # node_Constant_2370
            %"val_2432"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3297 |  # node_Concat_2371
            %"val_2433"<?,?> ⬅️ ::Concat(%"val_2428", %"val_2429", %"val_2430", %"val_2431", %"val_2432") {axis=0}
    3298 |  # node_view_30
            %"view_30"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_60", %"val_2433") {allowzero=1}
    3299 |  # node_transpose_52
            %"transpose_52"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_30") {perm=(0, 3, 2, 1, 4)}
    3300 |  # node_Constant_2372
            %"val_2434"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3301 |  # node_Constant_2373
            %"val_2435"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3302 |  # node_Constant_2374
            %"val_2436"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3303 |  # node_Slice_2375
            %"val_2437"<?,?> ⬅️ ::Slice(%"transpose_52", %"val_2434", %"val_2435", %"val_2436")
    3304 |  # node_unbind_15__0
            %"getitem_75"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2437", %"val_19")
    3305 |  # node_Constant_2376
            %"val_2438"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3306 |  # node_Constant_2377
            %"val_2439"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3307 |  # node_Constant_2378
            %"val_2440"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3308 |  # node_Slice_2379
            %"val_2441"<?,?> ⬅️ ::Slice(%"transpose_52", %"val_2438", %"val_2439", %"val_2440")
    3309 |  # node_unbind_15__1
            %"getitem_76"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2441", %"val_19")
    3310 |  # node_Constant_2380
            %"val_2442"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3311 |  # node_Constant_2381
            %"val_2443"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3312 |  # node_Constant_2382
            %"val_2444"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3313 |  # node_Slice_2383
            %"val_2445"<?,?> ⬅️ ::Slice(%"transpose_52", %"val_2442", %"val_2443", %"val_2444")
    3314 |  # node_unbind_15__2
            %"getitem_77"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2445", %"val_19")
    3315 |  # node_unsqueeze_102
            %"unsqueeze_102"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    3316 |  # node_unsqueeze_103
            %"unsqueeze_103"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    3317 |  # node_mul_119
            %"mul_119"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_75", %"unsqueeze_102")
    3318 |  # node_Cast_2384
            %"val_2446"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3319 |  # node_Constant_2385
            %"val_2447"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3320 |  # node_Reshape_2386
            %"val_2448"<?,?> ⬅️ ::Reshape(%"val_2446", %"val_2447") {allowzero=0}
    3321 |  # node_Cast_2387
            %"val_2449"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3322 |  # node_Constant_2388
            %"val_2450"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3323 |  # node_Reshape_2389
            %"val_2451"<?,?> ⬅️ ::Reshape(%"val_2449", %"val_2450") {allowzero=0}
    3324 |  # node_Cast_2390
            %"val_2452"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3325 |  # node_Constant_2391
            %"val_2453"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3326 |  # node_Reshape_2392
            %"val_2454"<?,?> ⬅️ ::Reshape(%"val_2452", %"val_2453") {allowzero=0}
    3327 |  # node_Constant_2393
            %"val_2455"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3328 |  # node_slice_129
            %"slice_129"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_75", %"val_2448", %"val_2451", %"val_2454", %"val_2455")
    3329 |  # node_Cast_2394
            %"val_2456"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3330 |  # node_Constant_2395
            %"val_2457"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3331 |  # node_Reshape_2396
            %"val_2458"<?,?> ⬅️ ::Reshape(%"val_2456", %"val_2457") {allowzero=0}
    3332 |  # node_Cast_2397
            %"val_2459"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3333 |  # node_Constant_2398
            %"val_2460"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3334 |  # node_Reshape_2399
            %"val_2461"<?,?> ⬅️ ::Reshape(%"val_2459", %"val_2460") {allowzero=0}
    3335 |  # node_Cast_2400
            %"val_2462"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3336 |  # node_Constant_2401
            %"val_2463"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3337 |  # node_Reshape_2402
            %"val_2464"<?,?> ⬅️ ::Reshape(%"val_2462", %"val_2463") {allowzero=0}
    3338 |  # node_Constant_2403
            %"val_2465"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3339 |  # node_slice_130
            %"slice_130"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_75", %"val_2458", %"val_2461", %"val_2464", %"val_2465")
    3340 |  # node_neg_30
            %"neg_30"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_130")
    3341 |  # node_cat_52
            %"cat_52"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_30", %"slice_129") {axis=-1}
    3342 |  # node_mul_120
            %"mul_120"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_52", %"unsqueeze_103")
    3343 |  # node_add_60
            %"add_60"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_119", %"mul_120")
    3344 |  # node_mul_121
            %"mul_121"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_76", %"unsqueeze_102")
    3345 |  # node_Cast_2404
            %"val_2466"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3346 |  # node_Constant_2405
            %"val_2467"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3347 |  # node_Reshape_2406
            %"val_2468"<?,?> ⬅️ ::Reshape(%"val_2466", %"val_2467") {allowzero=0}
    3348 |  # node_Cast_2407
            %"val_2469"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3349 |  # node_Constant_2408
            %"val_2470"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3350 |  # node_Reshape_2409
            %"val_2471"<?,?> ⬅️ ::Reshape(%"val_2469", %"val_2470") {allowzero=0}
    3351 |  # node_Cast_2410
            %"val_2472"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3352 |  # node_Constant_2411
            %"val_2473"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3353 |  # node_Reshape_2412
            %"val_2474"<?,?> ⬅️ ::Reshape(%"val_2472", %"val_2473") {allowzero=0}
    3354 |  # node_Constant_2413
            %"val_2475"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3355 |  # node_slice_131
            %"slice_131"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_76", %"val_2468", %"val_2471", %"val_2474", %"val_2475")
    3356 |  # node_Cast_2414
            %"val_2476"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3357 |  # node_Constant_2415
            %"val_2477"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3358 |  # node_Reshape_2416
            %"val_2478"<?,?> ⬅️ ::Reshape(%"val_2476", %"val_2477") {allowzero=0}
    3359 |  # node_Cast_2417
            %"val_2479"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3360 |  # node_Constant_2418
            %"val_2480"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3361 |  # node_Reshape_2419
            %"val_2481"<?,?> ⬅️ ::Reshape(%"val_2479", %"val_2480") {allowzero=0}
    3362 |  # node_Cast_2420
            %"val_2482"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3363 |  # node_Constant_2421
            %"val_2483"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3364 |  # node_Reshape_2422
            %"val_2484"<?,?> ⬅️ ::Reshape(%"val_2482", %"val_2483") {allowzero=0}
    3365 |  # node_Constant_2423
            %"val_2485"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3366 |  # node_slice_132
            %"slice_132"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_76", %"val_2478", %"val_2481", %"val_2484", %"val_2485")
    3367 |  # node_neg_31
            %"neg_31"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_132")
    3368 |  # node_cat_53
            %"cat_53"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_31", %"slice_131") {axis=-1}
    3369 |  # node_mul_122
            %"mul_122"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_53", %"unsqueeze_103")
    3370 |  # node_add_61
            %"add_61"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_121", %"mul_122")
    3371 |  # node_Shape_2424
            %"val_2486"<?,?> ⬅️ ::Shape(%"add_60") {start=0}
    3372 |  # node_Constant_2425
            %"val_2487"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3373 |  # node_Gather_2426
            %"val_2488"<?,?> ⬅️ ::Gather(%"val_2486", %"val_2487") {axis=0}
    3374 |  # node_CastLike_2427
            %"val_2489"<?,?> ⬅️ ::CastLike(%"val_2488", %"add_60")
    3375 |  # node_Constant_2428
            %"val_2490"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3376 |  # node_CastLike_2429
            %"val_2491"<?,?> ⬅️ ::CastLike(%"val_2490", %"add_60")
    3377 |  # node_Sqrt_2430
            %"val_2492"<?,?> ⬅️ ::Sqrt(%"val_2489")
    3378 |  # node_Div_2431
            %"val_2493"<?,?> ⬅️ ::Div(%"val_2491", %"val_2492")
    3379 |  # node_CastLike_2432
            %"val_2494"<?,?> ⬅️ ::CastLike(%"val_2493", %"add_60")
    3380 |  # node_Shape_2433
            %"val_2495"<?,?> ⬅️ ::Shape(%"add_61") {start=0}
    3381 |  # node_Constant_2434
            %"val_2496"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3382 |  # node_Slice_2435
            %"val_2497"<?,?> ⬅️ ::Slice(%"val_2495", %"val_889", %"val_2496")
    3383 |  # node_Slice_2436
            %"val_2498"<?,?> ⬅️ ::Slice(%"val_2495", %"val_891", %"val_889")
    3384 |  # node_Constant_2437
            %"val_2499"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3385 |  # node_Slice_2438
            %"val_2500"<?,?> ⬅️ ::Slice(%"val_2495", %"val_2499", %"val_891")
    3386 |  # node_Constant_2439
            %"val_2501"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3387 |  # node_Concat_2440
            %"val_2502"<?,?> ⬅️ ::Concat(%"val_2501", %"val_2498", %"val_2497") {axis=0}
    3388 |  # node_Reshape_2441
            %"val_2503"<?,?> ⬅️ ::Reshape(%"add_61", %"val_2502") {allowzero=0}
    3389 |  # node_Transpose_2442
            %"val_2504"<?,?> ⬅️ ::Transpose(%"val_2503") {perm=(0, 2, 1)}
    3390 |  # node_Concat_2443
            %"val_2505"<?,?> ⬅️ ::Concat(%"val_2500", %"val_2497", %"val_2498") {axis=0}
    3391 |  # node_Reshape_2444
            %"val_2506"<?,?> ⬅️ ::Reshape(%"val_2504", %"val_2505") {allowzero=0}
    3392 |  # node_Sqrt_2445
            %"val_2507"<?,?> ⬅️ ::Sqrt(%"val_2494")
    3393 |  # node_Mul_2446
            %"val_2508"<?,?> ⬅️ ::Mul(%"add_60", %"val_2507")
    3394 |  # node_Sqrt_2447
            %"val_2509"<?,?> ⬅️ ::Sqrt(%"val_2494")
    3395 |  # node_Mul_2448
            %"val_2510"<?,?> ⬅️ ::Mul(%"val_2506", %"val_2509")
    3396 |  # node_MatMul_2449
            %"val_2511"<?,?> ⬅️ ::MatMul(%"val_2508", %"val_2510")
    3397 |  # node_Add_2450
            %"val_2512"<?,?> ⬅️ ::Add(%"val_2511", %"masked_fill")
    3398 |  # node_Softmax_2451
            %"val_2513"<?,?> ⬅️ ::Softmax(%"val_2512") {axis=-1}
    3399 |  # node_scaled_dot_product_attention_15
            %"scaled_dot_product_attention_15"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2513", %"getitem_77")
    3400 |  # node_transpose_53
            %"transpose_53"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_15") {perm=(0, 2, 1, 3)}
    3401 |  # node_Constant_2452
            %"val_2514"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3402 |  # node_Constant_2453
            %"val_2515"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3403 |  # node_Constant_2454
            %"val_2516"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3404 |  # node_Constant_2455
            %"val_2517"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3405 |  # node_Concat_2456
            %"val_2518"<?,?> ⬅️ ::Concat(%"val_2515", %"val_2516", %"val_2517") {axis=0}
    3406 |  # node_view_31
            %"view_31"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_53", %"val_2518") {allowzero=1}
    3407 |  # node_Transpose_2457
            %"val_2519"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.attn.Wo.weight"{...}) {perm=(1, 0)}
    3408 |  # node_linear_61
            %"linear_61"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_31", %"val_2519")
    3409 |  # node_add_62
            %"add_62"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_59", %"linear_61")
    3410 |  # node_layer_norm_31
            %"layer_norm_31"<FLOAT,[1,97,768]>, %"val_2520"<?,?>, %"val_2521"<?,?> ⬅️ ::LayerNormalization(%"add_62", %"encoder.layers.15.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3411 |  # node_Transpose_2458
            %"val_2522"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3412 |  # node_linear_62
            %"linear_62"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_31", %"val_2522")
    3413 |  # node_split_15
            %"split_15"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_62", %"val_917") {dim=-1}
    3414 |  # node_getitem_78
            %"getitem_78"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_15", %"val_6")
    3415 |  # node_getitem_79
            %"getitem_79"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_15", %"val_51")
    3416 |  # node_Constant_2459
            %"val_2523"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3417 |  # node_Div_2460
            %"val_2524"<?,?> ⬅️ ::Div(%"getitem_78", %"val_2523")
    3418 |  # node_Erf_2461
            %"val_2525"<?,?> ⬅️ ::Erf(%"val_2524")
    3419 |  # node_Constant_2462
            %"val_2526"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3420 |  # node_Add_2463
            %"val_2527"<?,?> ⬅️ ::Add(%"val_2525", %"val_2526")
    3421 |  # node_Constant_2464
            %"val_2528"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3422 |  # node_Mul_2465
            %"val_2529"<?,?> ⬅️ ::Mul(%"val_2528", %"val_2527")
    3423 |  # node_gelu_15
            %"gelu_15"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_78", %"val_2529")
    3424 |  # node_mul_123
            %"mul_123"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_15", %"getitem_79")
    3425 |  # node_clone_17
            %"clone_17"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_123")
    3426 |  # node_Transpose_2466
            %"val_2530"<?,?> ⬅️ ::Transpose(%"encoder.layers.15.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3427 |  # node_linear_63
            %"linear_63"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_17", %"val_2530")
    3428 |  # node_add_63
            %"add_63"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_62", %"linear_63")
    3429 |  # node_layer_norm_32
            %"layer_norm_32"<FLOAT,[1,97,768]>, %"val_2531"<?,?>, %"val_2532"<?,?> ⬅️ ::LayerNormalization(%"add_63", %"encoder.layers.16.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3430 |  # node_Transpose_2467
            %"val_2533"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3431 |  # node_linear_64
            %"linear_64"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_32", %"val_2533")
    3432 |  # node_Constant_2468
            %"val_2534"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3433 |  # node_Constant_2469
            %"val_2535"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3434 |  # node_Constant_2470
            %"val_2536"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3435 |  # node_Constant_2471
            %"val_2537"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3436 |  # node_Constant_2472
            %"val_2538"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3437 |  # node_Constant_2473
            %"val_2539"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3438 |  # node_Concat_2474
            %"val_2540"<?,?> ⬅️ ::Concat(%"val_2535", %"val_2536", %"val_2537", %"val_2538", %"val_2539") {axis=0}
    3439 |  # node_view_32
            %"view_32"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_64", %"val_2540") {allowzero=1}
    3440 |  # node_transpose_54
            %"transpose_54"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_32") {perm=(0, 3, 2, 1, 4)}
    3441 |  # node_Constant_2475
            %"val_2541"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3442 |  # node_Constant_2476
            %"val_2542"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3443 |  # node_Constant_2477
            %"val_2543"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3444 |  # node_Slice_2478
            %"val_2544"<?,?> ⬅️ ::Slice(%"transpose_54", %"val_2541", %"val_2542", %"val_2543")
    3445 |  # node_unbind_16__0
            %"getitem_80"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2544", %"val_19")
    3446 |  # node_Constant_2479
            %"val_2545"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3447 |  # node_Constant_2480
            %"val_2546"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3448 |  # node_Constant_2481
            %"val_2547"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3449 |  # node_Slice_2482
            %"val_2548"<?,?> ⬅️ ::Slice(%"transpose_54", %"val_2545", %"val_2546", %"val_2547")
    3450 |  # node_unbind_16__1
            %"getitem_81"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2548", %"val_19")
    3451 |  # node_Constant_2483
            %"val_2549"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3452 |  # node_Constant_2484
            %"val_2550"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3453 |  # node_Constant_2485
            %"val_2551"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3454 |  # node_Slice_2486
            %"val_2552"<?,?> ⬅️ ::Slice(%"transpose_54", %"val_2549", %"val_2550", %"val_2551")
    3455 |  # node_unbind_16__2
            %"getitem_82"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2552", %"val_19")
    3456 |  # node_unsqueeze_104
            %"unsqueeze_104"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3457 |  # node_unsqueeze_105
            %"unsqueeze_105"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3458 |  # node_mul_124
            %"mul_124"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_80", %"unsqueeze_104")
    3459 |  # node_Cast_2487
            %"val_2553"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3460 |  # node_Constant_2488
            %"val_2554"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3461 |  # node_Reshape_2489
            %"val_2555"<?,?> ⬅️ ::Reshape(%"val_2553", %"val_2554") {allowzero=0}
    3462 |  # node_Cast_2490
            %"val_2556"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3463 |  # node_Constant_2491
            %"val_2557"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3464 |  # node_Reshape_2492
            %"val_2558"<?,?> ⬅️ ::Reshape(%"val_2556", %"val_2557") {allowzero=0}
    3465 |  # node_Cast_2493
            %"val_2559"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3466 |  # node_Constant_2494
            %"val_2560"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3467 |  # node_Reshape_2495
            %"val_2561"<?,?> ⬅️ ::Reshape(%"val_2559", %"val_2560") {allowzero=0}
    3468 |  # node_Constant_2496
            %"val_2562"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3469 |  # node_slice_133
            %"slice_133"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_80", %"val_2555", %"val_2558", %"val_2561", %"val_2562")
    3470 |  # node_Cast_2497
            %"val_2563"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3471 |  # node_Constant_2498
            %"val_2564"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3472 |  # node_Reshape_2499
            %"val_2565"<?,?> ⬅️ ::Reshape(%"val_2563", %"val_2564") {allowzero=0}
    3473 |  # node_Cast_2500
            %"val_2566"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3474 |  # node_Constant_2501
            %"val_2567"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3475 |  # node_Reshape_2502
            %"val_2568"<?,?> ⬅️ ::Reshape(%"val_2566", %"val_2567") {allowzero=0}
    3476 |  # node_Cast_2503
            %"val_2569"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3477 |  # node_Constant_2504
            %"val_2570"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3478 |  # node_Reshape_2505
            %"val_2571"<?,?> ⬅️ ::Reshape(%"val_2569", %"val_2570") {allowzero=0}
    3479 |  # node_Constant_2506
            %"val_2572"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3480 |  # node_slice_134
            %"slice_134"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_80", %"val_2565", %"val_2568", %"val_2571", %"val_2572")
    3481 |  # node_neg_32
            %"neg_32"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_134")
    3482 |  # node_cat_54
            %"cat_54"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_32", %"slice_133") {axis=-1}
    3483 |  # node_mul_125
            %"mul_125"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_54", %"unsqueeze_105")
    3484 |  # node_add_64
            %"add_64"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_124", %"mul_125")
    3485 |  # node_mul_126
            %"mul_126"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_81", %"unsqueeze_104")
    3486 |  # node_Cast_2507
            %"val_2573"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3487 |  # node_Constant_2508
            %"val_2574"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3488 |  # node_Reshape_2509
            %"val_2575"<?,?> ⬅️ ::Reshape(%"val_2573", %"val_2574") {allowzero=0}
    3489 |  # node_Cast_2510
            %"val_2576"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3490 |  # node_Constant_2511
            %"val_2577"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3491 |  # node_Reshape_2512
            %"val_2578"<?,?> ⬅️ ::Reshape(%"val_2576", %"val_2577") {allowzero=0}
    3492 |  # node_Cast_2513
            %"val_2579"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3493 |  # node_Constant_2514
            %"val_2580"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3494 |  # node_Reshape_2515
            %"val_2581"<?,?> ⬅️ ::Reshape(%"val_2579", %"val_2580") {allowzero=0}
    3495 |  # node_Constant_2516
            %"val_2582"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3496 |  # node_slice_135
            %"slice_135"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_81", %"val_2575", %"val_2578", %"val_2581", %"val_2582")
    3497 |  # node_Cast_2517
            %"val_2583"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3498 |  # node_Constant_2518
            %"val_2584"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3499 |  # node_Reshape_2519
            %"val_2585"<?,?> ⬅️ ::Reshape(%"val_2583", %"val_2584") {allowzero=0}
    3500 |  # node_Cast_2520
            %"val_2586"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3501 |  # node_Constant_2521
            %"val_2587"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3502 |  # node_Reshape_2522
            %"val_2588"<?,?> ⬅️ ::Reshape(%"val_2586", %"val_2587") {allowzero=0}
    3503 |  # node_Cast_2523
            %"val_2589"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3504 |  # node_Constant_2524
            %"val_2590"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3505 |  # node_Reshape_2525
            %"val_2591"<?,?> ⬅️ ::Reshape(%"val_2589", %"val_2590") {allowzero=0}
    3506 |  # node_Constant_2526
            %"val_2592"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3507 |  # node_slice_136
            %"slice_136"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_81", %"val_2585", %"val_2588", %"val_2591", %"val_2592")
    3508 |  # node_neg_33
            %"neg_33"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_136")
    3509 |  # node_cat_55
            %"cat_55"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_33", %"slice_135") {axis=-1}
    3510 |  # node_mul_127
            %"mul_127"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_55", %"unsqueeze_105")
    3511 |  # node_add_65
            %"add_65"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_126", %"mul_127")
    3512 |  # node_Shape_2527
            %"val_2593"<?,?> ⬅️ ::Shape(%"add_64") {start=0}
    3513 |  # node_Constant_2528
            %"val_2594"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3514 |  # node_Gather_2529
            %"val_2595"<?,?> ⬅️ ::Gather(%"val_2593", %"val_2594") {axis=0}
    3515 |  # node_CastLike_2530
            %"val_2596"<?,?> ⬅️ ::CastLike(%"val_2595", %"add_64")
    3516 |  # node_Constant_2531
            %"val_2597"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3517 |  # node_CastLike_2532
            %"val_2598"<?,?> ⬅️ ::CastLike(%"val_2597", %"add_64")
    3518 |  # node_Sqrt_2533
            %"val_2599"<?,?> ⬅️ ::Sqrt(%"val_2596")
    3519 |  # node_Div_2534
            %"val_2600"<?,?> ⬅️ ::Div(%"val_2598", %"val_2599")
    3520 |  # node_CastLike_2535
            %"val_2601"<?,?> ⬅️ ::CastLike(%"val_2600", %"add_64")
    3521 |  # node_Shape_2536
            %"val_2602"<?,?> ⬅️ ::Shape(%"add_65") {start=0}
    3522 |  # node_Constant_2537
            %"val_2603"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3523 |  # node_Slice_2538
            %"val_2604"<?,?> ⬅️ ::Slice(%"val_2602", %"val_889", %"val_2603")
    3524 |  # node_Slice_2539
            %"val_2605"<?,?> ⬅️ ::Slice(%"val_2602", %"val_891", %"val_889")
    3525 |  # node_Constant_2540
            %"val_2606"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3526 |  # node_Slice_2541
            %"val_2607"<?,?> ⬅️ ::Slice(%"val_2602", %"val_2606", %"val_891")
    3527 |  # node_Constant_2542
            %"val_2608"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3528 |  # node_Concat_2543
            %"val_2609"<?,?> ⬅️ ::Concat(%"val_2608", %"val_2605", %"val_2604") {axis=0}
    3529 |  # node_Reshape_2544
            %"val_2610"<?,?> ⬅️ ::Reshape(%"add_65", %"val_2609") {allowzero=0}
    3530 |  # node_Transpose_2545
            %"val_2611"<?,?> ⬅️ ::Transpose(%"val_2610") {perm=(0, 2, 1)}
    3531 |  # node_Concat_2546
            %"val_2612"<?,?> ⬅️ ::Concat(%"val_2607", %"val_2604", %"val_2605") {axis=0}
    3532 |  # node_Reshape_2547
            %"val_2613"<?,?> ⬅️ ::Reshape(%"val_2611", %"val_2612") {allowzero=0}
    3533 |  # node_Sqrt_2548
            %"val_2614"<?,?> ⬅️ ::Sqrt(%"val_2601")
    3534 |  # node_Mul_2549
            %"val_2615"<?,?> ⬅️ ::Mul(%"add_64", %"val_2614")
    3535 |  # node_Sqrt_2550
            %"val_2616"<?,?> ⬅️ ::Sqrt(%"val_2601")
    3536 |  # node_Mul_2551
            %"val_2617"<?,?> ⬅️ ::Mul(%"val_2613", %"val_2616")
    3537 |  # node_MatMul_2552
            %"val_2618"<?,?> ⬅️ ::MatMul(%"val_2615", %"val_2617")
    3538 |  # node_Add_2553
            %"val_2619"<?,?> ⬅️ ::Add(%"val_2618", %"masked_fill_1")
    3539 |  # node_Softmax_2554
            %"val_2620"<?,?> ⬅️ ::Softmax(%"val_2619") {axis=-1}
    3540 |  # node_scaled_dot_product_attention_16
            %"scaled_dot_product_attention_16"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2620", %"getitem_82")
    3541 |  # node_transpose_55
            %"transpose_55"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_16") {perm=(0, 2, 1, 3)}
    3542 |  # node_Constant_2555
            %"val_2621"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3543 |  # node_Constant_2556
            %"val_2622"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3544 |  # node_Constant_2557
            %"val_2623"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3545 |  # node_Constant_2558
            %"val_2624"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3546 |  # node_Concat_2559
            %"val_2625"<?,?> ⬅️ ::Concat(%"val_2622", %"val_2623", %"val_2624") {axis=0}
    3547 |  # node_view_33
            %"view_33"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_55", %"val_2625") {allowzero=1}
    3548 |  # node_Transpose_2560
            %"val_2626"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.attn.Wo.weight"{...}) {perm=(1, 0)}
    3549 |  # node_linear_65
            %"linear_65"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_33", %"val_2626")
    3550 |  # node_add_66
            %"add_66"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_63", %"linear_65")
    3551 |  # node_layer_norm_33
            %"layer_norm_33"<FLOAT,[1,97,768]>, %"val_2627"<?,?>, %"val_2628"<?,?> ⬅️ ::LayerNormalization(%"add_66", %"encoder.layers.16.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3552 |  # node_Transpose_2561
            %"val_2629"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3553 |  # node_linear_66
            %"linear_66"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_33", %"val_2629")
    3554 |  # node_split_16
            %"split_16"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_66", %"val_917") {dim=-1}
    3555 |  # node_getitem_83
            %"getitem_83"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_16", %"val_6")
    3556 |  # node_getitem_84
            %"getitem_84"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_16", %"val_51")
    3557 |  # node_Constant_2562
            %"val_2630"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3558 |  # node_Div_2563
            %"val_2631"<?,?> ⬅️ ::Div(%"getitem_83", %"val_2630")
    3559 |  # node_Erf_2564
            %"val_2632"<?,?> ⬅️ ::Erf(%"val_2631")
    3560 |  # node_Constant_2565
            %"val_2633"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3561 |  # node_Add_2566
            %"val_2634"<?,?> ⬅️ ::Add(%"val_2632", %"val_2633")
    3562 |  # node_Constant_2567
            %"val_2635"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3563 |  # node_Mul_2568
            %"val_2636"<?,?> ⬅️ ::Mul(%"val_2635", %"val_2634")
    3564 |  # node_gelu_16
            %"gelu_16"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_83", %"val_2636")
    3565 |  # node_mul_128
            %"mul_128"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_16", %"getitem_84")
    3566 |  # node_clone_18
            %"clone_18"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_128")
    3567 |  # node_Transpose_2569
            %"val_2637"<?,?> ⬅️ ::Transpose(%"encoder.layers.16.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3568 |  # node_linear_67
            %"linear_67"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_18", %"val_2637")
    3569 |  # node_add_67
            %"add_67"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_66", %"linear_67")
    3570 |  # node_layer_norm_34
            %"layer_norm_34"<FLOAT,[1,97,768]>, %"val_2638"<?,?>, %"val_2639"<?,?> ⬅️ ::LayerNormalization(%"add_67", %"encoder.layers.17.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3571 |  # node_Transpose_2570
            %"val_2640"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3572 |  # node_linear_68
            %"linear_68"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_34", %"val_2640")
    3573 |  # node_Constant_2571
            %"val_2641"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3574 |  # node_Constant_2572
            %"val_2642"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3575 |  # node_Constant_2573
            %"val_2643"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3576 |  # node_Constant_2574
            %"val_2644"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3577 |  # node_Constant_2575
            %"val_2645"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3578 |  # node_Constant_2576
            %"val_2646"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3579 |  # node_Concat_2577
            %"val_2647"<?,?> ⬅️ ::Concat(%"val_2642", %"val_2643", %"val_2644", %"val_2645", %"val_2646") {axis=0}
    3580 |  # node_view_34
            %"view_34"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_68", %"val_2647") {allowzero=1}
    3581 |  # node_transpose_56
            %"transpose_56"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_34") {perm=(0, 3, 2, 1, 4)}
    3582 |  # node_Constant_2578
            %"val_2648"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3583 |  # node_Constant_2579
            %"val_2649"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3584 |  # node_Constant_2580
            %"val_2650"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3585 |  # node_Slice_2581
            %"val_2651"<?,?> ⬅️ ::Slice(%"transpose_56", %"val_2648", %"val_2649", %"val_2650")
    3586 |  # node_unbind_17__0
            %"getitem_85"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2651", %"val_19")
    3587 |  # node_Constant_2582
            %"val_2652"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3588 |  # node_Constant_2583
            %"val_2653"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3589 |  # node_Constant_2584
            %"val_2654"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3590 |  # node_Slice_2585
            %"val_2655"<?,?> ⬅️ ::Slice(%"transpose_56", %"val_2652", %"val_2653", %"val_2654")
    3591 |  # node_unbind_17__1
            %"getitem_86"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2655", %"val_19")
    3592 |  # node_Constant_2586
            %"val_2656"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3593 |  # node_Constant_2587
            %"val_2657"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3594 |  # node_Constant_2588
            %"val_2658"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3595 |  # node_Slice_2589
            %"val_2659"<?,?> ⬅️ ::Slice(%"transpose_56", %"val_2656", %"val_2657", %"val_2658")
    3596 |  # node_unbind_17__2
            %"getitem_87"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2659", %"val_19")
    3597 |  # node_unsqueeze_106
            %"unsqueeze_106"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3598 |  # node_unsqueeze_107
            %"unsqueeze_107"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3599 |  # node_mul_129
            %"mul_129"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_85", %"unsqueeze_106")
    3600 |  # node_Cast_2590
            %"val_2660"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3601 |  # node_Constant_2591
            %"val_2661"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3602 |  # node_Reshape_2592
            %"val_2662"<?,?> ⬅️ ::Reshape(%"val_2660", %"val_2661") {allowzero=0}
    3603 |  # node_Cast_2593
            %"val_2663"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3604 |  # node_Constant_2594
            %"val_2664"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3605 |  # node_Reshape_2595
            %"val_2665"<?,?> ⬅️ ::Reshape(%"val_2663", %"val_2664") {allowzero=0}
    3606 |  # node_Cast_2596
            %"val_2666"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3607 |  # node_Constant_2597
            %"val_2667"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3608 |  # node_Reshape_2598
            %"val_2668"<?,?> ⬅️ ::Reshape(%"val_2666", %"val_2667") {allowzero=0}
    3609 |  # node_Constant_2599
            %"val_2669"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3610 |  # node_slice_137
            %"slice_137"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_85", %"val_2662", %"val_2665", %"val_2668", %"val_2669")
    3611 |  # node_Cast_2600
            %"val_2670"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3612 |  # node_Constant_2601
            %"val_2671"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3613 |  # node_Reshape_2602
            %"val_2672"<?,?> ⬅️ ::Reshape(%"val_2670", %"val_2671") {allowzero=0}
    3614 |  # node_Cast_2603
            %"val_2673"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3615 |  # node_Constant_2604
            %"val_2674"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3616 |  # node_Reshape_2605
            %"val_2675"<?,?> ⬅️ ::Reshape(%"val_2673", %"val_2674") {allowzero=0}
    3617 |  # node_Cast_2606
            %"val_2676"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3618 |  # node_Constant_2607
            %"val_2677"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3619 |  # node_Reshape_2608
            %"val_2678"<?,?> ⬅️ ::Reshape(%"val_2676", %"val_2677") {allowzero=0}
    3620 |  # node_Constant_2609
            %"val_2679"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3621 |  # node_slice_138
            %"slice_138"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_85", %"val_2672", %"val_2675", %"val_2678", %"val_2679")
    3622 |  # node_neg_34
            %"neg_34"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_138")
    3623 |  # node_cat_56
            %"cat_56"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_34", %"slice_137") {axis=-1}
    3624 |  # node_mul_130
            %"mul_130"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_56", %"unsqueeze_107")
    3625 |  # node_add_68
            %"add_68"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_129", %"mul_130")
    3626 |  # node_mul_131
            %"mul_131"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_86", %"unsqueeze_106")
    3627 |  # node_Cast_2610
            %"val_2680"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3628 |  # node_Constant_2611
            %"val_2681"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3629 |  # node_Reshape_2612
            %"val_2682"<?,?> ⬅️ ::Reshape(%"val_2680", %"val_2681") {allowzero=0}
    3630 |  # node_Cast_2613
            %"val_2683"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3631 |  # node_Constant_2614
            %"val_2684"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3632 |  # node_Reshape_2615
            %"val_2685"<?,?> ⬅️ ::Reshape(%"val_2683", %"val_2684") {allowzero=0}
    3633 |  # node_Cast_2616
            %"val_2686"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3634 |  # node_Constant_2617
            %"val_2687"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3635 |  # node_Reshape_2618
            %"val_2688"<?,?> ⬅️ ::Reshape(%"val_2686", %"val_2687") {allowzero=0}
    3636 |  # node_Constant_2619
            %"val_2689"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3637 |  # node_slice_139
            %"slice_139"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_86", %"val_2682", %"val_2685", %"val_2688", %"val_2689")
    3638 |  # node_Cast_2620
            %"val_2690"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3639 |  # node_Constant_2621
            %"val_2691"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3640 |  # node_Reshape_2622
            %"val_2692"<?,?> ⬅️ ::Reshape(%"val_2690", %"val_2691") {allowzero=0}
    3641 |  # node_Cast_2623
            %"val_2693"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3642 |  # node_Constant_2624
            %"val_2694"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3643 |  # node_Reshape_2625
            %"val_2695"<?,?> ⬅️ ::Reshape(%"val_2693", %"val_2694") {allowzero=0}
    3644 |  # node_Cast_2626
            %"val_2696"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3645 |  # node_Constant_2627
            %"val_2697"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3646 |  # node_Reshape_2628
            %"val_2698"<?,?> ⬅️ ::Reshape(%"val_2696", %"val_2697") {allowzero=0}
    3647 |  # node_Constant_2629
            %"val_2699"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3648 |  # node_slice_140
            %"slice_140"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_86", %"val_2692", %"val_2695", %"val_2698", %"val_2699")
    3649 |  # node_neg_35
            %"neg_35"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_140")
    3650 |  # node_cat_57
            %"cat_57"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_35", %"slice_139") {axis=-1}
    3651 |  # node_mul_132
            %"mul_132"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_57", %"unsqueeze_107")
    3652 |  # node_add_69
            %"add_69"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_131", %"mul_132")
    3653 |  # node_Shape_2630
            %"val_2700"<?,?> ⬅️ ::Shape(%"add_68") {start=0}
    3654 |  # node_Constant_2631
            %"val_2701"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3655 |  # node_Gather_2632
            %"val_2702"<?,?> ⬅️ ::Gather(%"val_2700", %"val_2701") {axis=0}
    3656 |  # node_CastLike_2633
            %"val_2703"<?,?> ⬅️ ::CastLike(%"val_2702", %"add_68")
    3657 |  # node_Constant_2634
            %"val_2704"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3658 |  # node_CastLike_2635
            %"val_2705"<?,?> ⬅️ ::CastLike(%"val_2704", %"add_68")
    3659 |  # node_Sqrt_2636
            %"val_2706"<?,?> ⬅️ ::Sqrt(%"val_2703")
    3660 |  # node_Div_2637
            %"val_2707"<?,?> ⬅️ ::Div(%"val_2705", %"val_2706")
    3661 |  # node_CastLike_2638
            %"val_2708"<?,?> ⬅️ ::CastLike(%"val_2707", %"add_68")
    3662 |  # node_Shape_2639
            %"val_2709"<?,?> ⬅️ ::Shape(%"add_69") {start=0}
    3663 |  # node_Constant_2640
            %"val_2710"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3664 |  # node_Slice_2641
            %"val_2711"<?,?> ⬅️ ::Slice(%"val_2709", %"val_889", %"val_2710")
    3665 |  # node_Slice_2642
            %"val_2712"<?,?> ⬅️ ::Slice(%"val_2709", %"val_891", %"val_889")
    3666 |  # node_Constant_2643
            %"val_2713"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3667 |  # node_Slice_2644
            %"val_2714"<?,?> ⬅️ ::Slice(%"val_2709", %"val_2713", %"val_891")
    3668 |  # node_Constant_2645
            %"val_2715"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3669 |  # node_Concat_2646
            %"val_2716"<?,?> ⬅️ ::Concat(%"val_2715", %"val_2712", %"val_2711") {axis=0}
    3670 |  # node_Reshape_2647
            %"val_2717"<?,?> ⬅️ ::Reshape(%"add_69", %"val_2716") {allowzero=0}
    3671 |  # node_Transpose_2648
            %"val_2718"<?,?> ⬅️ ::Transpose(%"val_2717") {perm=(0, 2, 1)}
    3672 |  # node_Concat_2649
            %"val_2719"<?,?> ⬅️ ::Concat(%"val_2714", %"val_2711", %"val_2712") {axis=0}
    3673 |  # node_Reshape_2650
            %"val_2720"<?,?> ⬅️ ::Reshape(%"val_2718", %"val_2719") {allowzero=0}
    3674 |  # node_Sqrt_2651
            %"val_2721"<?,?> ⬅️ ::Sqrt(%"val_2708")
    3675 |  # node_Mul_2652
            %"val_2722"<?,?> ⬅️ ::Mul(%"add_68", %"val_2721")
    3676 |  # node_Sqrt_2653
            %"val_2723"<?,?> ⬅️ ::Sqrt(%"val_2708")
    3677 |  # node_Mul_2654
            %"val_2724"<?,?> ⬅️ ::Mul(%"val_2720", %"val_2723")
    3678 |  # node_MatMul_2655
            %"val_2725"<?,?> ⬅️ ::MatMul(%"val_2722", %"val_2724")
    3679 |  # node_Add_2656
            %"val_2726"<?,?> ⬅️ ::Add(%"val_2725", %"masked_fill_1")
    3680 |  # node_Softmax_2657
            %"val_2727"<?,?> ⬅️ ::Softmax(%"val_2726") {axis=-1}
    3681 |  # node_scaled_dot_product_attention_17
            %"scaled_dot_product_attention_17"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2727", %"getitem_87")
    3682 |  # node_transpose_57
            %"transpose_57"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_17") {perm=(0, 2, 1, 3)}
    3683 |  # node_Constant_2658
            %"val_2728"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3684 |  # node_Constant_2659
            %"val_2729"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3685 |  # node_Constant_2660
            %"val_2730"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3686 |  # node_Constant_2661
            %"val_2731"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3687 |  # node_Concat_2662
            %"val_2732"<?,?> ⬅️ ::Concat(%"val_2729", %"val_2730", %"val_2731") {axis=0}
    3688 |  # node_view_35
            %"view_35"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_57", %"val_2732") {allowzero=1}
    3689 |  # node_Transpose_2663
            %"val_2733"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.attn.Wo.weight"{...}) {perm=(1, 0)}
    3690 |  # node_linear_69
            %"linear_69"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_35", %"val_2733")
    3691 |  # node_add_70
            %"add_70"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_67", %"linear_69")
    3692 |  # node_layer_norm_35
            %"layer_norm_35"<FLOAT,[1,97,768]>, %"val_2734"<?,?>, %"val_2735"<?,?> ⬅️ ::LayerNormalization(%"add_70", %"encoder.layers.17.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3693 |  # node_Transpose_2664
            %"val_2736"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3694 |  # node_linear_70
            %"linear_70"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_35", %"val_2736")
    3695 |  # node_split_17
            %"split_17"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_70", %"val_917") {dim=-1}
    3696 |  # node_getitem_88
            %"getitem_88"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_17", %"val_6")
    3697 |  # node_getitem_89
            %"getitem_89"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_17", %"val_51")
    3698 |  # node_Constant_2665
            %"val_2737"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3699 |  # node_Div_2666
            %"val_2738"<?,?> ⬅️ ::Div(%"getitem_88", %"val_2737")
    3700 |  # node_Erf_2667
            %"val_2739"<?,?> ⬅️ ::Erf(%"val_2738")
    3701 |  # node_Constant_2668
            %"val_2740"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3702 |  # node_Add_2669
            %"val_2741"<?,?> ⬅️ ::Add(%"val_2739", %"val_2740")
    3703 |  # node_Constant_2670
            %"val_2742"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3704 |  # node_Mul_2671
            %"val_2743"<?,?> ⬅️ ::Mul(%"val_2742", %"val_2741")
    3705 |  # node_gelu_17
            %"gelu_17"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_88", %"val_2743")
    3706 |  # node_mul_133
            %"mul_133"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_17", %"getitem_89")
    3707 |  # node_clone_19
            %"clone_19"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_133")
    3708 |  # node_Transpose_2672
            %"val_2744"<?,?> ⬅️ ::Transpose(%"encoder.layers.17.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3709 |  # node_linear_71
            %"linear_71"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_19", %"val_2744")
    3710 |  # node_add_71
            %"add_71"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_70", %"linear_71")
    3711 |  # node_layer_norm_36
            %"layer_norm_36"<FLOAT,[1,97,768]>, %"val_2745"<?,?>, %"val_2746"<?,?> ⬅️ ::LayerNormalization(%"add_71", %"encoder.layers.18.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3712 |  # node_Transpose_2673
            %"val_2747"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3713 |  # node_linear_72
            %"linear_72"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_36", %"val_2747")
    3714 |  # node_Constant_2674
            %"val_2748"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3715 |  # node_Constant_2675
            %"val_2749"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3716 |  # node_Constant_2676
            %"val_2750"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3717 |  # node_Constant_2677
            %"val_2751"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3718 |  # node_Constant_2678
            %"val_2752"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3719 |  # node_Constant_2679
            %"val_2753"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3720 |  # node_Concat_2680
            %"val_2754"<?,?> ⬅️ ::Concat(%"val_2749", %"val_2750", %"val_2751", %"val_2752", %"val_2753") {axis=0}
    3721 |  # node_view_36
            %"view_36"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_72", %"val_2754") {allowzero=1}
    3722 |  # node_transpose_58
            %"transpose_58"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_36") {perm=(0, 3, 2, 1, 4)}
    3723 |  # node_Constant_2681
            %"val_2755"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3724 |  # node_Constant_2682
            %"val_2756"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3725 |  # node_Constant_2683
            %"val_2757"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3726 |  # node_Slice_2684
            %"val_2758"<?,?> ⬅️ ::Slice(%"transpose_58", %"val_2755", %"val_2756", %"val_2757")
    3727 |  # node_unbind_18__0
            %"getitem_90"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2758", %"val_19")
    3728 |  # node_Constant_2685
            %"val_2759"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3729 |  # node_Constant_2686
            %"val_2760"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3730 |  # node_Constant_2687
            %"val_2761"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3731 |  # node_Slice_2688
            %"val_2762"<?,?> ⬅️ ::Slice(%"transpose_58", %"val_2759", %"val_2760", %"val_2761")
    3732 |  # node_unbind_18__1
            %"getitem_91"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2762", %"val_19")
    3733 |  # node_Constant_2689
            %"val_2763"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3734 |  # node_Constant_2690
            %"val_2764"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3735 |  # node_Constant_2691
            %"val_2765"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3736 |  # node_Slice_2692
            %"val_2766"<?,?> ⬅️ ::Slice(%"transpose_58", %"val_2763", %"val_2764", %"val_2765")
    3737 |  # node_unbind_18__2
            %"getitem_92"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2766", %"val_19")
    3738 |  # node_unsqueeze_108
            %"unsqueeze_108"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    3739 |  # node_unsqueeze_109
            %"unsqueeze_109"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    3740 |  # node_mul_134
            %"mul_134"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_90", %"unsqueeze_108")
    3741 |  # node_Cast_2693
            %"val_2767"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3742 |  # node_Constant_2694
            %"val_2768"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3743 |  # node_Reshape_2695
            %"val_2769"<?,?> ⬅️ ::Reshape(%"val_2767", %"val_2768") {allowzero=0}
    3744 |  # node_Cast_2696
            %"val_2770"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3745 |  # node_Constant_2697
            %"val_2771"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3746 |  # node_Reshape_2698
            %"val_2772"<?,?> ⬅️ ::Reshape(%"val_2770", %"val_2771") {allowzero=0}
    3747 |  # node_Cast_2699
            %"val_2773"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3748 |  # node_Constant_2700
            %"val_2774"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3749 |  # node_Reshape_2701
            %"val_2775"<?,?> ⬅️ ::Reshape(%"val_2773", %"val_2774") {allowzero=0}
    3750 |  # node_Constant_2702
            %"val_2776"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3751 |  # node_slice_141
            %"slice_141"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_90", %"val_2769", %"val_2772", %"val_2775", %"val_2776")
    3752 |  # node_Cast_2703
            %"val_2777"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3753 |  # node_Constant_2704
            %"val_2778"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3754 |  # node_Reshape_2705
            %"val_2779"<?,?> ⬅️ ::Reshape(%"val_2777", %"val_2778") {allowzero=0}
    3755 |  # node_Cast_2706
            %"val_2780"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3756 |  # node_Constant_2707
            %"val_2781"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3757 |  # node_Reshape_2708
            %"val_2782"<?,?> ⬅️ ::Reshape(%"val_2780", %"val_2781") {allowzero=0}
    3758 |  # node_Cast_2709
            %"val_2783"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3759 |  # node_Constant_2710
            %"val_2784"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3760 |  # node_Reshape_2711
            %"val_2785"<?,?> ⬅️ ::Reshape(%"val_2783", %"val_2784") {allowzero=0}
    3761 |  # node_Constant_2712
            %"val_2786"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3762 |  # node_slice_142
            %"slice_142"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_90", %"val_2779", %"val_2782", %"val_2785", %"val_2786")
    3763 |  # node_neg_36
            %"neg_36"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_142")
    3764 |  # node_cat_58
            %"cat_58"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_36", %"slice_141") {axis=-1}
    3765 |  # node_mul_135
            %"mul_135"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_58", %"unsqueeze_109")
    3766 |  # node_add_72
            %"add_72"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_134", %"mul_135")
    3767 |  # node_mul_136
            %"mul_136"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_91", %"unsqueeze_108")
    3768 |  # node_Cast_2713
            %"val_2787"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3769 |  # node_Constant_2714
            %"val_2788"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3770 |  # node_Reshape_2715
            %"val_2789"<?,?> ⬅️ ::Reshape(%"val_2787", %"val_2788") {allowzero=0}
    3771 |  # node_Cast_2716
            %"val_2790"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3772 |  # node_Constant_2717
            %"val_2791"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3773 |  # node_Reshape_2718
            %"val_2792"<?,?> ⬅️ ::Reshape(%"val_2790", %"val_2791") {allowzero=0}
    3774 |  # node_Cast_2719
            %"val_2793"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3775 |  # node_Constant_2720
            %"val_2794"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3776 |  # node_Reshape_2721
            %"val_2795"<?,?> ⬅️ ::Reshape(%"val_2793", %"val_2794") {allowzero=0}
    3777 |  # node_Constant_2722
            %"val_2796"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3778 |  # node_slice_143
            %"slice_143"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_91", %"val_2789", %"val_2792", %"val_2795", %"val_2796")
    3779 |  # node_Cast_2723
            %"val_2797"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3780 |  # node_Constant_2724
            %"val_2798"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3781 |  # node_Reshape_2725
            %"val_2799"<?,?> ⬅️ ::Reshape(%"val_2797", %"val_2798") {allowzero=0}
    3782 |  # node_Cast_2726
            %"val_2800"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3783 |  # node_Constant_2727
            %"val_2801"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3784 |  # node_Reshape_2728
            %"val_2802"<?,?> ⬅️ ::Reshape(%"val_2800", %"val_2801") {allowzero=0}
    3785 |  # node_Cast_2729
            %"val_2803"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3786 |  # node_Constant_2730
            %"val_2804"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3787 |  # node_Reshape_2731
            %"val_2805"<?,?> ⬅️ ::Reshape(%"val_2803", %"val_2804") {allowzero=0}
    3788 |  # node_Constant_2732
            %"val_2806"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3789 |  # node_slice_144
            %"slice_144"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_91", %"val_2799", %"val_2802", %"val_2805", %"val_2806")
    3790 |  # node_neg_37
            %"neg_37"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_144")
    3791 |  # node_cat_59
            %"cat_59"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_37", %"slice_143") {axis=-1}
    3792 |  # node_mul_137
            %"mul_137"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_59", %"unsqueeze_109")
    3793 |  # node_add_73
            %"add_73"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_136", %"mul_137")
    3794 |  # node_Shape_2733
            %"val_2807"<?,?> ⬅️ ::Shape(%"add_72") {start=0}
    3795 |  # node_Constant_2734
            %"val_2808"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3796 |  # node_Gather_2735
            %"val_2809"<?,?> ⬅️ ::Gather(%"val_2807", %"val_2808") {axis=0}
    3797 |  # node_CastLike_2736
            %"val_2810"<?,?> ⬅️ ::CastLike(%"val_2809", %"add_72")
    3798 |  # node_Constant_2737
            %"val_2811"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3799 |  # node_CastLike_2738
            %"val_2812"<?,?> ⬅️ ::CastLike(%"val_2811", %"add_72")
    3800 |  # node_Sqrt_2739
            %"val_2813"<?,?> ⬅️ ::Sqrt(%"val_2810")
    3801 |  # node_Div_2740
            %"val_2814"<?,?> ⬅️ ::Div(%"val_2812", %"val_2813")
    3802 |  # node_CastLike_2741
            %"val_2815"<?,?> ⬅️ ::CastLike(%"val_2814", %"add_72")
    3803 |  # node_Shape_2742
            %"val_2816"<?,?> ⬅️ ::Shape(%"add_73") {start=0}
    3804 |  # node_Constant_2743
            %"val_2817"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3805 |  # node_Slice_2744
            %"val_2818"<?,?> ⬅️ ::Slice(%"val_2816", %"val_889", %"val_2817")
    3806 |  # node_Slice_2745
            %"val_2819"<?,?> ⬅️ ::Slice(%"val_2816", %"val_891", %"val_889")
    3807 |  # node_Constant_2746
            %"val_2820"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3808 |  # node_Slice_2747
            %"val_2821"<?,?> ⬅️ ::Slice(%"val_2816", %"val_2820", %"val_891")
    3809 |  # node_Constant_2748
            %"val_2822"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3810 |  # node_Concat_2749
            %"val_2823"<?,?> ⬅️ ::Concat(%"val_2822", %"val_2819", %"val_2818") {axis=0}
    3811 |  # node_Reshape_2750
            %"val_2824"<?,?> ⬅️ ::Reshape(%"add_73", %"val_2823") {allowzero=0}
    3812 |  # node_Transpose_2751
            %"val_2825"<?,?> ⬅️ ::Transpose(%"val_2824") {perm=(0, 2, 1)}
    3813 |  # node_Concat_2752
            %"val_2826"<?,?> ⬅️ ::Concat(%"val_2821", %"val_2818", %"val_2819") {axis=0}
    3814 |  # node_Reshape_2753
            %"val_2827"<?,?> ⬅️ ::Reshape(%"val_2825", %"val_2826") {allowzero=0}
    3815 |  # node_Sqrt_2754
            %"val_2828"<?,?> ⬅️ ::Sqrt(%"val_2815")
    3816 |  # node_Mul_2755
            %"val_2829"<?,?> ⬅️ ::Mul(%"add_72", %"val_2828")
    3817 |  # node_Sqrt_2756
            %"val_2830"<?,?> ⬅️ ::Sqrt(%"val_2815")
    3818 |  # node_Mul_2757
            %"val_2831"<?,?> ⬅️ ::Mul(%"val_2827", %"val_2830")
    3819 |  # node_MatMul_2758
            %"val_2832"<?,?> ⬅️ ::MatMul(%"val_2829", %"val_2831")
    3820 |  # node_Add_2759
            %"val_2833"<?,?> ⬅️ ::Add(%"val_2832", %"masked_fill")
    3821 |  # node_Softmax_2760
            %"val_2834"<?,?> ⬅️ ::Softmax(%"val_2833") {axis=-1}
    3822 |  # node_scaled_dot_product_attention_18
            %"scaled_dot_product_attention_18"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2834", %"getitem_92")
    3823 |  # node_transpose_59
            %"transpose_59"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_18") {perm=(0, 2, 1, 3)}
    3824 |  # node_Constant_2761
            %"val_2835"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3825 |  # node_Constant_2762
            %"val_2836"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3826 |  # node_Constant_2763
            %"val_2837"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3827 |  # node_Constant_2764
            %"val_2838"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3828 |  # node_Concat_2765
            %"val_2839"<?,?> ⬅️ ::Concat(%"val_2836", %"val_2837", %"val_2838") {axis=0}
    3829 |  # node_view_37
            %"view_37"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_59", %"val_2839") {allowzero=1}
    3830 |  # node_Transpose_2766
            %"val_2840"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.attn.Wo.weight"{...}) {perm=(1, 0)}
    3831 |  # node_linear_73
            %"linear_73"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_37", %"val_2840")
    3832 |  # node_add_74
            %"add_74"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_71", %"linear_73")
    3833 |  # node_layer_norm_37
            %"layer_norm_37"<FLOAT,[1,97,768]>, %"val_2841"<?,?>, %"val_2842"<?,?> ⬅️ ::LayerNormalization(%"add_74", %"encoder.layers.18.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3834 |  # node_Transpose_2767
            %"val_2843"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3835 |  # node_linear_74
            %"linear_74"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_37", %"val_2843")
    3836 |  # node_split_18
            %"split_18"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_74", %"val_917") {dim=-1}
    3837 |  # node_getitem_93
            %"getitem_93"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_18", %"val_6")
    3838 |  # node_getitem_94
            %"getitem_94"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_18", %"val_51")
    3839 |  # node_Constant_2768
            %"val_2844"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3840 |  # node_Div_2769
            %"val_2845"<?,?> ⬅️ ::Div(%"getitem_93", %"val_2844")
    3841 |  # node_Erf_2770
            %"val_2846"<?,?> ⬅️ ::Erf(%"val_2845")
    3842 |  # node_Constant_2771
            %"val_2847"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3843 |  # node_Add_2772
            %"val_2848"<?,?> ⬅️ ::Add(%"val_2846", %"val_2847")
    3844 |  # node_Constant_2773
            %"val_2849"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3845 |  # node_Mul_2774
            %"val_2850"<?,?> ⬅️ ::Mul(%"val_2849", %"val_2848")
    3846 |  # node_gelu_18
            %"gelu_18"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_93", %"val_2850")
    3847 |  # node_mul_138
            %"mul_138"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_18", %"getitem_94")
    3848 |  # node_clone_20
            %"clone_20"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_138")
    3849 |  # node_Transpose_2775
            %"val_2851"<?,?> ⬅️ ::Transpose(%"encoder.layers.18.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3850 |  # node_linear_75
            %"linear_75"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_20", %"val_2851")
    3851 |  # node_add_75
            %"add_75"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_74", %"linear_75")
    3852 |  # node_layer_norm_38
            %"layer_norm_38"<FLOAT,[1,97,768]>, %"val_2852"<?,?>, %"val_2853"<?,?> ⬅️ ::LayerNormalization(%"add_75", %"encoder.layers.19.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3853 |  # node_Transpose_2776
            %"val_2854"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3854 |  # node_linear_76
            %"linear_76"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_38", %"val_2854")
    3855 |  # node_Constant_2777
            %"val_2855"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3856 |  # node_Constant_2778
            %"val_2856"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3857 |  # node_Constant_2779
            %"val_2857"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3858 |  # node_Constant_2780
            %"val_2858"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    3859 |  # node_Constant_2781
            %"val_2859"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    3860 |  # node_Constant_2782
            %"val_2860"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    3861 |  # node_Concat_2783
            %"val_2861"<?,?> ⬅️ ::Concat(%"val_2856", %"val_2857", %"val_2858", %"val_2859", %"val_2860") {axis=0}
    3862 |  # node_view_38
            %"view_38"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_76", %"val_2861") {allowzero=1}
    3863 |  # node_transpose_60
            %"transpose_60"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_38") {perm=(0, 3, 2, 1, 4)}
    3864 |  # node_Constant_2784
            %"val_2862"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    3865 |  # node_Constant_2785
            %"val_2863"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3866 |  # node_Constant_2786
            %"val_2864"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3867 |  # node_Slice_2787
            %"val_2865"<?,?> ⬅️ ::Slice(%"transpose_60", %"val_2862", %"val_2863", %"val_2864")
    3868 |  # node_unbind_19__0
            %"getitem_95"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2865", %"val_19")
    3869 |  # node_Constant_2788
            %"val_2866"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3870 |  # node_Constant_2789
            %"val_2867"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3871 |  # node_Constant_2790
            %"val_2868"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3872 |  # node_Slice_2791
            %"val_2869"<?,?> ⬅️ ::Slice(%"transpose_60", %"val_2866", %"val_2867", %"val_2868")
    3873 |  # node_unbind_19__1
            %"getitem_96"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2869", %"val_19")
    3874 |  # node_Constant_2792
            %"val_2870"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3875 |  # node_Constant_2793
            %"val_2871"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    3876 |  # node_Constant_2794
            %"val_2872"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    3877 |  # node_Slice_2795
            %"val_2873"<?,?> ⬅️ ::Slice(%"transpose_60", %"val_2870", %"val_2871", %"val_2872")
    3878 |  # node_unbind_19__2
            %"getitem_97"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2873", %"val_19")
    3879 |  # node_unsqueeze_110
            %"unsqueeze_110"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    3880 |  # node_unsqueeze_111
            %"unsqueeze_111"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    3881 |  # node_mul_139
            %"mul_139"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_95", %"unsqueeze_110")
    3882 |  # node_Cast_2796
            %"val_2874"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3883 |  # node_Constant_2797
            %"val_2875"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3884 |  # node_Reshape_2798
            %"val_2876"<?,?> ⬅️ ::Reshape(%"val_2874", %"val_2875") {allowzero=0}
    3885 |  # node_Cast_2799
            %"val_2877"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3886 |  # node_Constant_2800
            %"val_2878"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3887 |  # node_Reshape_2801
            %"val_2879"<?,?> ⬅️ ::Reshape(%"val_2877", %"val_2878") {allowzero=0}
    3888 |  # node_Cast_2802
            %"val_2880"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3889 |  # node_Constant_2803
            %"val_2881"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3890 |  # node_Reshape_2804
            %"val_2882"<?,?> ⬅️ ::Reshape(%"val_2880", %"val_2881") {allowzero=0}
    3891 |  # node_Constant_2805
            %"val_2883"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3892 |  # node_slice_145
            %"slice_145"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_95", %"val_2876", %"val_2879", %"val_2882", %"val_2883")
    3893 |  # node_Cast_2806
            %"val_2884"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3894 |  # node_Constant_2807
            %"val_2885"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3895 |  # node_Reshape_2808
            %"val_2886"<?,?> ⬅️ ::Reshape(%"val_2884", %"val_2885") {allowzero=0}
    3896 |  # node_Cast_2809
            %"val_2887"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3897 |  # node_Constant_2810
            %"val_2888"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3898 |  # node_Reshape_2811
            %"val_2889"<?,?> ⬅️ ::Reshape(%"val_2887", %"val_2888") {allowzero=0}
    3899 |  # node_Cast_2812
            %"val_2890"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3900 |  # node_Constant_2813
            %"val_2891"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3901 |  # node_Reshape_2814
            %"val_2892"<?,?> ⬅️ ::Reshape(%"val_2890", %"val_2891") {allowzero=0}
    3902 |  # node_Constant_2815
            %"val_2893"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3903 |  # node_slice_146
            %"slice_146"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_95", %"val_2886", %"val_2889", %"val_2892", %"val_2893")
    3904 |  # node_neg_38
            %"neg_38"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_146")
    3905 |  # node_cat_60
            %"cat_60"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_38", %"slice_145") {axis=-1}
    3906 |  # node_mul_140
            %"mul_140"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_60", %"unsqueeze_111")
    3907 |  # node_add_76
            %"add_76"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_139", %"mul_140")
    3908 |  # node_mul_141
            %"mul_141"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_96", %"unsqueeze_110")
    3909 |  # node_Cast_2816
            %"val_2894"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    3910 |  # node_Constant_2817
            %"val_2895"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3911 |  # node_Reshape_2818
            %"val_2896"<?,?> ⬅️ ::Reshape(%"val_2894", %"val_2895") {allowzero=0}
    3912 |  # node_Cast_2819
            %"val_2897"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3913 |  # node_Constant_2820
            %"val_2898"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3914 |  # node_Reshape_2821
            %"val_2899"<?,?> ⬅️ ::Reshape(%"val_2897", %"val_2898") {allowzero=0}
    3915 |  # node_Cast_2822
            %"val_2900"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3916 |  # node_Constant_2823
            %"val_2901"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3917 |  # node_Reshape_2824
            %"val_2902"<?,?> ⬅️ ::Reshape(%"val_2900", %"val_2901") {allowzero=0}
    3918 |  # node_Constant_2825
            %"val_2903"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3919 |  # node_slice_147
            %"slice_147"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_96", %"val_2896", %"val_2899", %"val_2902", %"val_2903")
    3920 |  # node_Cast_2826
            %"val_2904"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    3921 |  # node_Constant_2827
            %"val_2905"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3922 |  # node_Reshape_2828
            %"val_2906"<?,?> ⬅️ ::Reshape(%"val_2904", %"val_2905") {allowzero=0}
    3923 |  # node_Cast_2829
            %"val_2907"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    3924 |  # node_Constant_2830
            %"val_2908"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3925 |  # node_Reshape_2831
            %"val_2909"<?,?> ⬅️ ::Reshape(%"val_2907", %"val_2908") {allowzero=0}
    3926 |  # node_Cast_2832
            %"val_2910"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    3927 |  # node_Constant_2833
            %"val_2911"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3928 |  # node_Reshape_2834
            %"val_2912"<?,?> ⬅️ ::Reshape(%"val_2910", %"val_2911") {allowzero=0}
    3929 |  # node_Constant_2835
            %"val_2913"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    3930 |  # node_slice_148
            %"slice_148"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_96", %"val_2906", %"val_2909", %"val_2912", %"val_2913")
    3931 |  # node_neg_39
            %"neg_39"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_148")
    3932 |  # node_cat_61
            %"cat_61"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_39", %"slice_147") {axis=-1}
    3933 |  # node_mul_142
            %"mul_142"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_61", %"unsqueeze_111")
    3934 |  # node_add_77
            %"add_77"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_141", %"mul_142")
    3935 |  # node_Shape_2836
            %"val_2914"<?,?> ⬅️ ::Shape(%"add_76") {start=0}
    3936 |  # node_Constant_2837
            %"val_2915"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3937 |  # node_Gather_2838
            %"val_2916"<?,?> ⬅️ ::Gather(%"val_2914", %"val_2915") {axis=0}
    3938 |  # node_CastLike_2839
            %"val_2917"<?,?> ⬅️ ::CastLike(%"val_2916", %"add_76")
    3939 |  # node_Constant_2840
            %"val_2918"<?,?> ⬅️ ::Constant() {value_float=1.0}
    3940 |  # node_CastLike_2841
            %"val_2919"<?,?> ⬅️ ::CastLike(%"val_2918", %"add_76")
    3941 |  # node_Sqrt_2842
            %"val_2920"<?,?> ⬅️ ::Sqrt(%"val_2917")
    3942 |  # node_Div_2843
            %"val_2921"<?,?> ⬅️ ::Div(%"val_2919", %"val_2920")
    3943 |  # node_CastLike_2844
            %"val_2922"<?,?> ⬅️ ::CastLike(%"val_2921", %"add_76")
    3944 |  # node_Shape_2845
            %"val_2923"<?,?> ⬅️ ::Shape(%"add_77") {start=0}
    3945 |  # node_Constant_2846
            %"val_2924"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    3946 |  # node_Slice_2847
            %"val_2925"<?,?> ⬅️ ::Slice(%"val_2923", %"val_889", %"val_2924")
    3947 |  # node_Slice_2848
            %"val_2926"<?,?> ⬅️ ::Slice(%"val_2923", %"val_891", %"val_889")
    3948 |  # node_Constant_2849
            %"val_2927"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    3949 |  # node_Slice_2850
            %"val_2928"<?,?> ⬅️ ::Slice(%"val_2923", %"val_2927", %"val_891")
    3950 |  # node_Constant_2851
            %"val_2929"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3951 |  # node_Concat_2852
            %"val_2930"<?,?> ⬅️ ::Concat(%"val_2929", %"val_2926", %"val_2925") {axis=0}
    3952 |  # node_Reshape_2853
            %"val_2931"<?,?> ⬅️ ::Reshape(%"add_77", %"val_2930") {allowzero=0}
    3953 |  # node_Transpose_2854
            %"val_2932"<?,?> ⬅️ ::Transpose(%"val_2931") {perm=(0, 2, 1)}
    3954 |  # node_Concat_2855
            %"val_2933"<?,?> ⬅️ ::Concat(%"val_2928", %"val_2925", %"val_2926") {axis=0}
    3955 |  # node_Reshape_2856
            %"val_2934"<?,?> ⬅️ ::Reshape(%"val_2932", %"val_2933") {allowzero=0}
    3956 |  # node_Sqrt_2857
            %"val_2935"<?,?> ⬅️ ::Sqrt(%"val_2922")
    3957 |  # node_Mul_2858
            %"val_2936"<?,?> ⬅️ ::Mul(%"add_76", %"val_2935")
    3958 |  # node_Sqrt_2859
            %"val_2937"<?,?> ⬅️ ::Sqrt(%"val_2922")
    3959 |  # node_Mul_2860
            %"val_2938"<?,?> ⬅️ ::Mul(%"val_2934", %"val_2937")
    3960 |  # node_MatMul_2861
            %"val_2939"<?,?> ⬅️ ::MatMul(%"val_2936", %"val_2938")
    3961 |  # node_Add_2862
            %"val_2940"<?,?> ⬅️ ::Add(%"val_2939", %"masked_fill_1")
    3962 |  # node_Softmax_2863
            %"val_2941"<?,?> ⬅️ ::Softmax(%"val_2940") {axis=-1}
    3963 |  # node_scaled_dot_product_attention_19
            %"scaled_dot_product_attention_19"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_2941", %"getitem_97")
    3964 |  # node_transpose_61
            %"transpose_61"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_19") {perm=(0, 2, 1, 3)}
    3965 |  # node_Constant_2864
            %"val_2942"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3966 |  # node_Constant_2865
            %"val_2943"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3967 |  # node_Constant_2866
            %"val_2944"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3968 |  # node_Constant_2867
            %"val_2945"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    3969 |  # node_Concat_2868
            %"val_2946"<?,?> ⬅️ ::Concat(%"val_2943", %"val_2944", %"val_2945") {axis=0}
    3970 |  # node_view_39
            %"view_39"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_61", %"val_2946") {allowzero=1}
    3971 |  # node_Transpose_2869
            %"val_2947"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.attn.Wo.weight"{...}) {perm=(1, 0)}
    3972 |  # node_linear_77
            %"linear_77"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_39", %"val_2947")
    3973 |  # node_add_78
            %"add_78"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_75", %"linear_77")
    3974 |  # node_layer_norm_39
            %"layer_norm_39"<FLOAT,[1,97,768]>, %"val_2948"<?,?>, %"val_2949"<?,?> ⬅️ ::LayerNormalization(%"add_78", %"encoder.layers.19.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3975 |  # node_Transpose_2870
            %"val_2950"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.mlp.Wi.weight"{...}) {perm=(1, 0)}
    3976 |  # node_linear_78
            %"linear_78"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_39", %"val_2950")
    3977 |  # node_split_19
            %"split_19"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_78", %"val_917") {dim=-1}
    3978 |  # node_getitem_98
            %"getitem_98"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_19", %"val_6")
    3979 |  # node_getitem_99
            %"getitem_99"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_19", %"val_51")
    3980 |  # node_Constant_2871
            %"val_2951"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    3981 |  # node_Div_2872
            %"val_2952"<?,?> ⬅️ ::Div(%"getitem_98", %"val_2951")
    3982 |  # node_Erf_2873
            %"val_2953"<?,?> ⬅️ ::Erf(%"val_2952")
    3983 |  # node_Constant_2874
            %"val_2954"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    3984 |  # node_Add_2875
            %"val_2955"<?,?> ⬅️ ::Add(%"val_2953", %"val_2954")
    3985 |  # node_Constant_2876
            %"val_2956"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    3986 |  # node_Mul_2877
            %"val_2957"<?,?> ⬅️ ::Mul(%"val_2956", %"val_2955")
    3987 |  # node_gelu_19
            %"gelu_19"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_98", %"val_2957")
    3988 |  # node_mul_143
            %"mul_143"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_19", %"getitem_99")
    3989 |  # node_clone_21
            %"clone_21"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_143")
    3990 |  # node_Transpose_2878
            %"val_2958"<?,?> ⬅️ ::Transpose(%"encoder.layers.19.mlp.Wo.weight"{...}) {perm=(1, 0)}
    3991 |  # node_linear_79
            %"linear_79"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_21", %"val_2958")
    3992 |  # node_add_79
            %"add_79"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_78", %"linear_79")
    3993 |  # node_layer_norm_40
            %"layer_norm_40"<FLOAT,[1,97,768]>, %"val_2959"<?,?>, %"val_2960"<?,?> ⬅️ ::LayerNormalization(%"add_79", %"encoder.layers.20.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    3994 |  # node_Transpose_2879
            %"val_2961"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    3995 |  # node_linear_80
            %"linear_80"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_40", %"val_2961")
    3996 |  # node_Constant_2880
            %"val_2962"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3997 |  # node_Constant_2881
            %"val_2963"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    3998 |  # node_Constant_2882
            %"val_2964"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    3999 |  # node_Constant_2883
            %"val_2965"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    4000 |  # node_Constant_2884
            %"val_2966"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4001 |  # node_Constant_2885
            %"val_2967"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4002 |  # node_Concat_2886
            %"val_2968"<?,?> ⬅️ ::Concat(%"val_2963", %"val_2964", %"val_2965", %"val_2966", %"val_2967") {axis=0}
    4003 |  # node_view_40
            %"view_40"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_80", %"val_2968") {allowzero=1}
    4004 |  # node_transpose_62
            %"transpose_62"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_40") {perm=(0, 3, 2, 1, 4)}
    4005 |  # node_Constant_2887
            %"val_2969"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4006 |  # node_Constant_2888
            %"val_2970"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4007 |  # node_Constant_2889
            %"val_2971"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4008 |  # node_Slice_2890
            %"val_2972"<?,?> ⬅️ ::Slice(%"transpose_62", %"val_2969", %"val_2970", %"val_2971")
    4009 |  # node_unbind_20__0
            %"getitem_100"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2972", %"val_19")
    4010 |  # node_Constant_2891
            %"val_2973"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4011 |  # node_Constant_2892
            %"val_2974"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4012 |  # node_Constant_2893
            %"val_2975"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4013 |  # node_Slice_2894
            %"val_2976"<?,?> ⬅️ ::Slice(%"transpose_62", %"val_2973", %"val_2974", %"val_2975")
    4014 |  # node_unbind_20__1
            %"getitem_101"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2976", %"val_19")
    4015 |  # node_Constant_2895
            %"val_2977"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4016 |  # node_Constant_2896
            %"val_2978"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    4017 |  # node_Constant_2897
            %"val_2979"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4018 |  # node_Slice_2898
            %"val_2980"<?,?> ⬅️ ::Slice(%"transpose_62", %"val_2977", %"val_2978", %"val_2979")
    4019 |  # node_unbind_20__2
            %"getitem_102"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_2980", %"val_19")
    4020 |  # node_unsqueeze_112
            %"unsqueeze_112"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_40", %"val_18")
    4021 |  # node_unsqueeze_113
            %"unsqueeze_113"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_41", %"val_18")
    4022 |  # node_mul_144
            %"mul_144"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_100", %"unsqueeze_112")
    4023 |  # node_Cast_2899
            %"val_2981"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4024 |  # node_Constant_2900
            %"val_2982"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4025 |  # node_Reshape_2901
            %"val_2983"<?,?> ⬅️ ::Reshape(%"val_2981", %"val_2982") {allowzero=0}
    4026 |  # node_Cast_2902
            %"val_2984"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4027 |  # node_Constant_2903
            %"val_2985"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4028 |  # node_Reshape_2904
            %"val_2986"<?,?> ⬅️ ::Reshape(%"val_2984", %"val_2985") {allowzero=0}
    4029 |  # node_Cast_2905
            %"val_2987"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4030 |  # node_Constant_2906
            %"val_2988"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4031 |  # node_Reshape_2907
            %"val_2989"<?,?> ⬅️ ::Reshape(%"val_2987", %"val_2988") {allowzero=0}
    4032 |  # node_Constant_2908
            %"val_2990"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4033 |  # node_slice_149
            %"slice_149"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_100", %"val_2983", %"val_2986", %"val_2989", %"val_2990")
    4034 |  # node_Cast_2909
            %"val_2991"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4035 |  # node_Constant_2910
            %"val_2992"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4036 |  # node_Reshape_2911
            %"val_2993"<?,?> ⬅️ ::Reshape(%"val_2991", %"val_2992") {allowzero=0}
    4037 |  # node_Cast_2912
            %"val_2994"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4038 |  # node_Constant_2913
            %"val_2995"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4039 |  # node_Reshape_2914
            %"val_2996"<?,?> ⬅️ ::Reshape(%"val_2994", %"val_2995") {allowzero=0}
    4040 |  # node_Cast_2915
            %"val_2997"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4041 |  # node_Constant_2916
            %"val_2998"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4042 |  # node_Reshape_2917
            %"val_2999"<?,?> ⬅️ ::Reshape(%"val_2997", %"val_2998") {allowzero=0}
    4043 |  # node_Constant_2918
            %"val_3000"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4044 |  # node_slice_150
            %"slice_150"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_100", %"val_2993", %"val_2996", %"val_2999", %"val_3000")
    4045 |  # node_neg_40
            %"neg_40"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_150")
    4046 |  # node_cat_62
            %"cat_62"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_40", %"slice_149") {axis=-1}
    4047 |  # node_mul_145
            %"mul_145"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_62", %"unsqueeze_113")
    4048 |  # node_add_80
            %"add_80"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_144", %"mul_145")
    4049 |  # node_mul_146
            %"mul_146"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_101", %"unsqueeze_112")
    4050 |  # node_Cast_2919
            %"val_3001"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4051 |  # node_Constant_2920
            %"val_3002"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4052 |  # node_Reshape_2921
            %"val_3003"<?,?> ⬅️ ::Reshape(%"val_3001", %"val_3002") {allowzero=0}
    4053 |  # node_Cast_2922
            %"val_3004"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4054 |  # node_Constant_2923
            %"val_3005"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4055 |  # node_Reshape_2924
            %"val_3006"<?,?> ⬅️ ::Reshape(%"val_3004", %"val_3005") {allowzero=0}
    4056 |  # node_Cast_2925
            %"val_3007"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4057 |  # node_Constant_2926
            %"val_3008"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4058 |  # node_Reshape_2927
            %"val_3009"<?,?> ⬅️ ::Reshape(%"val_3007", %"val_3008") {allowzero=0}
    4059 |  # node_Constant_2928
            %"val_3010"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4060 |  # node_slice_151
            %"slice_151"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_101", %"val_3003", %"val_3006", %"val_3009", %"val_3010")
    4061 |  # node_Cast_2929
            %"val_3011"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4062 |  # node_Constant_2930
            %"val_3012"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4063 |  # node_Reshape_2931
            %"val_3013"<?,?> ⬅️ ::Reshape(%"val_3011", %"val_3012") {allowzero=0}
    4064 |  # node_Cast_2932
            %"val_3014"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4065 |  # node_Constant_2933
            %"val_3015"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4066 |  # node_Reshape_2934
            %"val_3016"<?,?> ⬅️ ::Reshape(%"val_3014", %"val_3015") {allowzero=0}
    4067 |  # node_Cast_2935
            %"val_3017"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4068 |  # node_Constant_2936
            %"val_3018"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4069 |  # node_Reshape_2937
            %"val_3019"<?,?> ⬅️ ::Reshape(%"val_3017", %"val_3018") {allowzero=0}
    4070 |  # node_Constant_2938
            %"val_3020"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4071 |  # node_slice_152
            %"slice_152"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_101", %"val_3013", %"val_3016", %"val_3019", %"val_3020")
    4072 |  # node_neg_41
            %"neg_41"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_152")
    4073 |  # node_cat_63
            %"cat_63"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_41", %"slice_151") {axis=-1}
    4074 |  # node_mul_147
            %"mul_147"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_63", %"unsqueeze_113")
    4075 |  # node_add_81
            %"add_81"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_146", %"mul_147")
    4076 |  # node_Shape_2939
            %"val_3021"<?,?> ⬅️ ::Shape(%"add_80") {start=0}
    4077 |  # node_Constant_2940
            %"val_3022"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4078 |  # node_Gather_2941
            %"val_3023"<?,?> ⬅️ ::Gather(%"val_3021", %"val_3022") {axis=0}
    4079 |  # node_CastLike_2942
            %"val_3024"<?,?> ⬅️ ::CastLike(%"val_3023", %"add_80")
    4080 |  # node_Constant_2943
            %"val_3025"<?,?> ⬅️ ::Constant() {value_float=1.0}
    4081 |  # node_CastLike_2944
            %"val_3026"<?,?> ⬅️ ::CastLike(%"val_3025", %"add_80")
    4082 |  # node_Sqrt_2945
            %"val_3027"<?,?> ⬅️ ::Sqrt(%"val_3024")
    4083 |  # node_Div_2946
            %"val_3028"<?,?> ⬅️ ::Div(%"val_3026", %"val_3027")
    4084 |  # node_CastLike_2947
            %"val_3029"<?,?> ⬅️ ::CastLike(%"val_3028", %"add_80")
    4085 |  # node_Shape_2948
            %"val_3030"<?,?> ⬅️ ::Shape(%"add_81") {start=0}
    4086 |  # node_Constant_2949
            %"val_3031"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4087 |  # node_Slice_2950
            %"val_3032"<?,?> ⬅️ ::Slice(%"val_3030", %"val_889", %"val_3031")
    4088 |  # node_Slice_2951
            %"val_3033"<?,?> ⬅️ ::Slice(%"val_3030", %"val_891", %"val_889")
    4089 |  # node_Constant_2952
            %"val_3034"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    4090 |  # node_Slice_2953
            %"val_3035"<?,?> ⬅️ ::Slice(%"val_3030", %"val_3034", %"val_891")
    4091 |  # node_Constant_2954
            %"val_3036"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4092 |  # node_Concat_2955
            %"val_3037"<?,?> ⬅️ ::Concat(%"val_3036", %"val_3033", %"val_3032") {axis=0}
    4093 |  # node_Reshape_2956
            %"val_3038"<?,?> ⬅️ ::Reshape(%"add_81", %"val_3037") {allowzero=0}
    4094 |  # node_Transpose_2957
            %"val_3039"<?,?> ⬅️ ::Transpose(%"val_3038") {perm=(0, 2, 1)}
    4095 |  # node_Concat_2958
            %"val_3040"<?,?> ⬅️ ::Concat(%"val_3035", %"val_3032", %"val_3033") {axis=0}
    4096 |  # node_Reshape_2959
            %"val_3041"<?,?> ⬅️ ::Reshape(%"val_3039", %"val_3040") {allowzero=0}
    4097 |  # node_Sqrt_2960
            %"val_3042"<?,?> ⬅️ ::Sqrt(%"val_3029")
    4098 |  # node_Mul_2961
            %"val_3043"<?,?> ⬅️ ::Mul(%"add_80", %"val_3042")
    4099 |  # node_Sqrt_2962
            %"val_3044"<?,?> ⬅️ ::Sqrt(%"val_3029")
    4100 |  # node_Mul_2963
            %"val_3045"<?,?> ⬅️ ::Mul(%"val_3041", %"val_3044")
    4101 |  # node_MatMul_2964
            %"val_3046"<?,?> ⬅️ ::MatMul(%"val_3043", %"val_3045")
    4102 |  # node_Add_2965
            %"val_3047"<?,?> ⬅️ ::Add(%"val_3046", %"masked_fill_1")
    4103 |  # node_Softmax_2966
            %"val_3048"<?,?> ⬅️ ::Softmax(%"val_3047") {axis=-1}
    4104 |  # node_scaled_dot_product_attention_20
            %"scaled_dot_product_attention_20"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_3048", %"getitem_102")
    4105 |  # node_transpose_63
            %"transpose_63"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_20") {perm=(0, 2, 1, 3)}
    4106 |  # node_Constant_2967
            %"val_3049"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4107 |  # node_Constant_2968
            %"val_3050"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4108 |  # node_Constant_2969
            %"val_3051"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4109 |  # node_Constant_2970
            %"val_3052"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4110 |  # node_Concat_2971
            %"val_3053"<?,?> ⬅️ ::Concat(%"val_3050", %"val_3051", %"val_3052") {axis=0}
    4111 |  # node_view_41
            %"view_41"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_63", %"val_3053") {allowzero=1}
    4112 |  # node_Transpose_2972
            %"val_3054"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.attn.Wo.weight"{...}) {perm=(1, 0)}
    4113 |  # node_linear_81
            %"linear_81"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_41", %"val_3054")
    4114 |  # node_add_82
            %"add_82"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_79", %"linear_81")
    4115 |  # node_layer_norm_41
            %"layer_norm_41"<FLOAT,[1,97,768]>, %"val_3055"<?,?>, %"val_3056"<?,?> ⬅️ ::LayerNormalization(%"add_82", %"encoder.layers.20.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4116 |  # node_Transpose_2973
            %"val_3057"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.mlp.Wi.weight"{...}) {perm=(1, 0)}
    4117 |  # node_linear_82
            %"linear_82"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_41", %"val_3057")
    4118 |  # node_split_20
            %"split_20"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_82", %"val_917") {dim=-1}
    4119 |  # node_getitem_103
            %"getitem_103"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_20", %"val_6")
    4120 |  # node_getitem_104
            %"getitem_104"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_20", %"val_51")
    4121 |  # node_Constant_2974
            %"val_3058"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    4122 |  # node_Div_2975
            %"val_3059"<?,?> ⬅️ ::Div(%"getitem_103", %"val_3058")
    4123 |  # node_Erf_2976
            %"val_3060"<?,?> ⬅️ ::Erf(%"val_3059")
    4124 |  # node_Constant_2977
            %"val_3061"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    4125 |  # node_Add_2978
            %"val_3062"<?,?> ⬅️ ::Add(%"val_3060", %"val_3061")
    4126 |  # node_Constant_2979
            %"val_3063"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    4127 |  # node_Mul_2980
            %"val_3064"<?,?> ⬅️ ::Mul(%"val_3063", %"val_3062")
    4128 |  # node_gelu_20
            %"gelu_20"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_103", %"val_3064")
    4129 |  # node_mul_148
            %"mul_148"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_20", %"getitem_104")
    4130 |  # node_clone_22
            %"clone_22"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_148")
    4131 |  # node_Transpose_2981
            %"val_3065"<?,?> ⬅️ ::Transpose(%"encoder.layers.20.mlp.Wo.weight"{...}) {perm=(1, 0)}
    4132 |  # node_linear_83
            %"linear_83"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_22", %"val_3065")
    4133 |  # node_add_83
            %"add_83"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_82", %"linear_83")
    4134 |  # node_layer_norm_42
            %"layer_norm_42"<FLOAT,[1,97,768]>, %"val_3066"<?,?>, %"val_3067"<?,?> ⬅️ ::LayerNormalization(%"add_83", %"encoder.layers.21.attn_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4135 |  # node_Transpose_2982
            %"val_3068"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.attn.Wqkv.weight"{...}) {perm=(1, 0)}
    4136 |  # node_linear_84
            %"linear_84"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_42", %"val_3068")
    4137 |  # node_Constant_2983
            %"val_3069"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4138 |  # node_Constant_2984
            %"val_3070"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4139 |  # node_Constant_2985
            %"val_3071"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4140 |  # node_Constant_2986
            %"val_3072"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    4141 |  # node_Constant_2987
            %"val_3073"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4142 |  # node_Constant_2988
            %"val_3074"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4143 |  # node_Concat_2989
            %"val_3075"<?,?> ⬅️ ::Concat(%"val_3070", %"val_3071", %"val_3072", %"val_3073", %"val_3074") {axis=0}
    4144 |  # node_view_42
            %"view_42"<FLOAT,[1,97,3,12,64]> ⬅️ ::Reshape(%"linear_84", %"val_3075") {allowzero=1}
    4145 |  # node_transpose_64
            %"transpose_64"<FLOAT,[1,12,3,97,64]> ⬅️ ::Transpose(%"view_42") {perm=(0, 3, 2, 1, 4)}
    4146 |  # node_Constant_2990
            %"val_3076"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4147 |  # node_Constant_2991
            %"val_3077"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4148 |  # node_Constant_2992
            %"val_3078"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4149 |  # node_Slice_2993
            %"val_3079"<?,?> ⬅️ ::Slice(%"transpose_64", %"val_3076", %"val_3077", %"val_3078")
    4150 |  # node_unbind_21__0
            %"getitem_105"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_3079", %"val_19")
    4151 |  # node_Constant_2994
            %"val_3080"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4152 |  # node_Constant_2995
            %"val_3081"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4153 |  # node_Constant_2996
            %"val_3082"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4154 |  # node_Slice_2997
            %"val_3083"<?,?> ⬅️ ::Slice(%"transpose_64", %"val_3080", %"val_3081", %"val_3082")
    4155 |  # node_unbind_21__1
            %"getitem_106"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_3083", %"val_19")
    4156 |  # node_Constant_2998
            %"val_3084"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4157 |  # node_Constant_2999
            %"val_3085"<?,?> ⬅️ ::Constant() {value_ints=(3,)}
    4158 |  # node_Constant_3000
            %"val_3086"<?,?> ⬅️ ::Constant() {value_ints=(2,)}
    4159 |  # node_Slice_3001
            %"val_3087"<?,?> ⬅️ ::Slice(%"transpose_64", %"val_3084", %"val_3085", %"val_3086")
    4160 |  # node_unbind_21__2
            %"getitem_107"<FLOAT,[1,12,97,64]> ⬅️ ::Squeeze(%"val_3087", %"val_19")
    4161 |  # node_unsqueeze_114
            %"unsqueeze_114"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_42", %"val_18")
    4162 |  # node_unsqueeze_115
            %"unsqueeze_115"<FLOAT,[1,1,97,64]> ⬅️ ::Unsqueeze(%"mul_43", %"val_18")
    4163 |  # node_mul_149
            %"mul_149"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_105", %"unsqueeze_114")
    4164 |  # node_Cast_3002
            %"val_3088"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4165 |  # node_Constant_3003
            %"val_3089"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4166 |  # node_Reshape_3004
            %"val_3090"<?,?> ⬅️ ::Reshape(%"val_3088", %"val_3089") {allowzero=0}
    4167 |  # node_Cast_3005
            %"val_3091"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4168 |  # node_Constant_3006
            %"val_3092"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4169 |  # node_Reshape_3007
            %"val_3093"<?,?> ⬅️ ::Reshape(%"val_3091", %"val_3092") {allowzero=0}
    4170 |  # node_Cast_3008
            %"val_3094"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4171 |  # node_Constant_3009
            %"val_3095"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4172 |  # node_Reshape_3010
            %"val_3096"<?,?> ⬅️ ::Reshape(%"val_3094", %"val_3095") {allowzero=0}
    4173 |  # node_Constant_3011
            %"val_3097"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4174 |  # node_slice_153
            %"slice_153"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_105", %"val_3090", %"val_3093", %"val_3096", %"val_3097")
    4175 |  # node_Cast_3012
            %"val_3098"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4176 |  # node_Constant_3013
            %"val_3099"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4177 |  # node_Reshape_3014
            %"val_3100"<?,?> ⬅️ ::Reshape(%"val_3098", %"val_3099") {allowzero=0}
    4178 |  # node_Cast_3015
            %"val_3101"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4179 |  # node_Constant_3016
            %"val_3102"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4180 |  # node_Reshape_3017
            %"val_3103"<?,?> ⬅️ ::Reshape(%"val_3101", %"val_3102") {allowzero=0}
    4181 |  # node_Cast_3018
            %"val_3104"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4182 |  # node_Constant_3019
            %"val_3105"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4183 |  # node_Reshape_3020
            %"val_3106"<?,?> ⬅️ ::Reshape(%"val_3104", %"val_3105") {allowzero=0}
    4184 |  # node_Constant_3021
            %"val_3107"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4185 |  # node_slice_154
            %"slice_154"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_105", %"val_3100", %"val_3103", %"val_3106", %"val_3107")
    4186 |  # node_neg_42
            %"neg_42"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_154")
    4187 |  # node_cat_64
            %"cat_64"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_42", %"slice_153") {axis=-1}
    4188 |  # node_mul_150
            %"mul_150"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_64", %"unsqueeze_115")
    4189 |  # node_add_84
            %"add_84"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_149", %"mul_150")
    4190 |  # node_mul_151
            %"mul_151"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"getitem_106", %"unsqueeze_114")
    4191 |  # node_Cast_3022
            %"val_3108"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4192 |  # node_Constant_3023
            %"val_3109"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4193 |  # node_Reshape_3024
            %"val_3110"<?,?> ⬅️ ::Reshape(%"val_3108", %"val_3109") {allowzero=0}
    4194 |  # node_Cast_3025
            %"val_3111"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4195 |  # node_Constant_3026
            %"val_3112"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4196 |  # node_Reshape_3027
            %"val_3113"<?,?> ⬅️ ::Reshape(%"val_3111", %"val_3112") {allowzero=0}
    4197 |  # node_Cast_3028
            %"val_3114"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4198 |  # node_Constant_3029
            %"val_3115"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4199 |  # node_Reshape_3030
            %"val_3116"<?,?> ⬅️ ::Reshape(%"val_3114", %"val_3115") {allowzero=0}
    4200 |  # node_Constant_3031
            %"val_3117"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4201 |  # node_slice_155
            %"slice_155"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_106", %"val_3110", %"val_3113", %"val_3116", %"val_3117")
    4202 |  # node_Cast_3032
            %"val_3118"<?,?> ⬅️ ::Cast(%"val_840") {to=7}
    4203 |  # node_Constant_3033
            %"val_3119"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4204 |  # node_Reshape_3034
            %"val_3120"<?,?> ⬅️ ::Reshape(%"val_3118", %"val_3119") {allowzero=0}
    4205 |  # node_Cast_3035
            %"val_3121"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4206 |  # node_Constant_3036
            %"val_3122"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4207 |  # node_Reshape_3037
            %"val_3123"<?,?> ⬅️ ::Reshape(%"val_3121", %"val_3122") {allowzero=0}
    4208 |  # node_Cast_3038
            %"val_3124"<?,?> ⬅️ ::Cast(%"val_26") {to=7}
    4209 |  # node_Constant_3039
            %"val_3125"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4210 |  # node_Reshape_3040
            %"val_3126"<?,?> ⬅️ ::Reshape(%"val_3124", %"val_3125") {allowzero=0}
    4211 |  # node_Constant_3041
            %"val_3127"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4212 |  # node_slice_156
            %"slice_156"<FLOAT,[1,12,97,32]> ⬅️ ::Slice(%"getitem_106", %"val_3120", %"val_3123", %"val_3126", %"val_3127")
    4213 |  # node_neg_43
            %"neg_43"<FLOAT,[1,12,97,32]> ⬅️ ::Neg(%"slice_156")
    4214 |  # node_cat_65
            %"cat_65"<FLOAT,[1,12,97,64]> ⬅️ ::Concat(%"neg_43", %"slice_155") {axis=-1}
    4215 |  # node_mul_152
            %"mul_152"<FLOAT,[1,12,97,64]> ⬅️ ::Mul(%"cat_65", %"unsqueeze_115")
    4216 |  # node_add_85
            %"add_85"<FLOAT,[1,12,97,64]> ⬅️ ::Add(%"mul_151", %"mul_152")
    4217 |  # node_Shape_3042
            %"val_3128"<?,?> ⬅️ ::Shape(%"add_84") {start=0}
    4218 |  # node_Constant_3043
            %"val_3129"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4219 |  # node_Gather_3044
            %"val_3130"<?,?> ⬅️ ::Gather(%"val_3128", %"val_3129") {axis=0}
    4220 |  # node_CastLike_3045
            %"val_3131"<?,?> ⬅️ ::CastLike(%"val_3130", %"add_84")
    4221 |  # node_Constant_3046
            %"val_3132"<?,?> ⬅️ ::Constant() {value_float=1.0}
    4222 |  # node_CastLike_3047
            %"val_3133"<?,?> ⬅️ ::CastLike(%"val_3132", %"add_84")
    4223 |  # node_Sqrt_3048
            %"val_3134"<?,?> ⬅️ ::Sqrt(%"val_3131")
    4224 |  # node_Div_3049
            %"val_3135"<?,?> ⬅️ ::Div(%"val_3133", %"val_3134")
    4225 |  # node_CastLike_3050
            %"val_3136"<?,?> ⬅️ ::CastLike(%"val_3135", %"add_84")
    4226 |  # node_Shape_3051
            %"val_3137"<?,?> ⬅️ ::Shape(%"add_85") {start=0}
    4227 |  # node_Constant_3052
            %"val_3138"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4228 |  # node_Slice_3053
            %"val_3139"<?,?> ⬅️ ::Slice(%"val_3137", %"val_889", %"val_3138")
    4229 |  # node_Slice_3054
            %"val_3140"<?,?> ⬅️ ::Slice(%"val_3137", %"val_891", %"val_889")
    4230 |  # node_Constant_3055
            %"val_3141"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    4231 |  # node_Slice_3056
            %"val_3142"<?,?> ⬅️ ::Slice(%"val_3137", %"val_3141", %"val_891")
    4232 |  # node_Constant_3057
            %"val_3143"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4233 |  # node_Concat_3058
            %"val_3144"<?,?> ⬅️ ::Concat(%"val_3143", %"val_3140", %"val_3139") {axis=0}
    4234 |  # node_Reshape_3059
            %"val_3145"<?,?> ⬅️ ::Reshape(%"add_85", %"val_3144") {allowzero=0}
    4235 |  # node_Transpose_3060
            %"val_3146"<?,?> ⬅️ ::Transpose(%"val_3145") {perm=(0, 2, 1)}
    4236 |  # node_Concat_3061
            %"val_3147"<?,?> ⬅️ ::Concat(%"val_3142", %"val_3139", %"val_3140") {axis=0}
    4237 |  # node_Reshape_3062
            %"val_3148"<?,?> ⬅️ ::Reshape(%"val_3146", %"val_3147") {allowzero=0}
    4238 |  # node_Sqrt_3063
            %"val_3149"<?,?> ⬅️ ::Sqrt(%"val_3136")
    4239 |  # node_Mul_3064
            %"val_3150"<?,?> ⬅️ ::Mul(%"add_84", %"val_3149")
    4240 |  # node_Sqrt_3065
            %"val_3151"<?,?> ⬅️ ::Sqrt(%"val_3136")
    4241 |  # node_Mul_3066
            %"val_3152"<?,?> ⬅️ ::Mul(%"val_3148", %"val_3151")
    4242 |  # node_MatMul_3067
            %"val_3153"<?,?> ⬅️ ::MatMul(%"val_3150", %"val_3152")
    4243 |  # node_Add_3068
            %"val_3154"<?,?> ⬅️ ::Add(%"val_3153", %"masked_fill")
    4244 |  # node_Softmax_3069
            %"val_3155"<?,?> ⬅️ ::Softmax(%"val_3154") {axis=-1}
    4245 |  # node_scaled_dot_product_attention_21
            %"scaled_dot_product_attention_21"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_3155", %"getitem_107")
    4246 |  # node_transpose_65
            %"transpose_65"<FLOAT,[1,97,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_21") {perm=(0, 2, 1, 3)}
    4247 |  # node_Constant_3070
            %"val_3156"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4248 |  # node_Constant_3071
            %"val_3157"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4249 |  # node_Constant_3072
            %"val_3158"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4250 |  # node_Constant_3073
            %"val_3159"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4251 |  # node_Concat_3074
            %"val_3160"<?,?> ⬅️ ::Concat(%"val_3157", %"val_3158", %"val_3159") {axis=0}
    4252 |  # node_view_43
            %"view_43"<FLOAT,[1,97,768]> ⬅️ ::Reshape(%"transpose_65", %"val_3160") {allowzero=1}
    4253 |  # node_Transpose_3075
            %"val_3161"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.attn.Wo.weight"{...}) {perm=(1, 0)}
    4254 |  # node_linear_85
            %"linear_85"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"view_43", %"val_3161")
    4255 |  # node_add_86
            %"add_86"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_83", %"linear_85")
    4256 |  # node_layer_norm_43
            %"layer_norm_43"<FLOAT,[1,97,768]>, %"val_3162"<?,?>, %"val_3163"<?,?> ⬅️ ::LayerNormalization(%"add_86", %"encoder.layers.21.mlp_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4257 |  # node_Transpose_3076
            %"val_3164"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.mlp.Wi.weight"{...}) {perm=(1, 0)}
    4258 |  # node_linear_86
            %"linear_86"<FLOAT,[1,97,2304]> ⬅️ ::MatMul(%"layer_norm_43", %"val_3164")
    4259 |  # node_split_21
            %"split_21"<?,?> ⬅️ pkg.onnxscript.torch_lib::aten_split(%"linear_86", %"val_917") {dim=-1}
    4260 |  # node_getitem_108
            %"getitem_108"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_21", %"val_6")
    4261 |  # node_getitem_109
            %"getitem_109"<FLOAT,[1,97,1152]> ⬅️ pkg.onnxscript.torch_lib::aten_getitem(%"split_21", %"val_51")
    4262 |  # node_Constant_3077
            %"val_3165"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    4263 |  # node_Div_3078
            %"val_3166"<?,?> ⬅️ ::Div(%"getitem_108", %"val_3165")
    4264 |  # node_Erf_3079
            %"val_3167"<?,?> ⬅️ ::Erf(%"val_3166")
    4265 |  # node_Constant_3080
            %"val_3168"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    4266 |  # node_Add_3081
            %"val_3169"<?,?> ⬅️ ::Add(%"val_3167", %"val_3168")
    4267 |  # node_Constant_3082
            %"val_3170"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    4268 |  # node_Mul_3083
            %"val_3171"<?,?> ⬅️ ::Mul(%"val_3170", %"val_3169")
    4269 |  # node_gelu_21
            %"gelu_21"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"getitem_108", %"val_3171")
    4270 |  # node_mul_153
            %"mul_153"<FLOAT,[1,97,1152]> ⬅️ ::Mul(%"gelu_21", %"getitem_109")
    4271 |  # node_clone_23
            %"clone_23"<FLOAT,[1,97,1152]> ⬅️ ::Identity(%"mul_153")
    4272 |  # node_Transpose_3084
            %"val_3172"<?,?> ⬅️ ::Transpose(%"encoder.layers.21.mlp.Wo.weight"{...}) {perm=(1, 0)}
    4273 |  # node_linear_87
            %"linear_87"<FLOAT,[1,97,768]> ⬅️ ::MatMul(%"clone_23", %"val_3172")
    4274 |  # node_add_87
            %"add_87"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_86", %"linear_87")
    4275 |  # node_layer_norm_44
            %"layer_norm_44"<FLOAT,[1,97,768]>, %"val_3173"<?,?>, %"val_3174"<?,?> ⬅️ ::LayerNormalization(%"add_87", %"encoder.final_norm.weight"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4276 |  # node_embedding_1
            %"embedding_1"<FLOAT,[1,768]> ⬅️ ::Gather(%"type_emb.weight"{...}, %"qtype") {axis=0}
    4277 |  # node_Cast_3085
            %"val_3175"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4278 |  # node_Constant_3086
            %"val_3176"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4279 |  # node_Reshape_3087
            %"val_3177"<?,?> ⬅️ ::Reshape(%"val_3175", %"val_3176") {allowzero=0}
    4280 |  # node_Cast_3088
            %"val_3178"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4281 |  # node_Constant_3089
            %"val_3179"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4282 |  # node_Reshape_3090
            %"val_3180"<?,?> ⬅️ ::Reshape(%"val_3178", %"val_3179") {allowzero=0}
    4283 |  # node_Cast_3091
            %"val_3181"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4284 |  # node_Constant_3092
            %"val_3182"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4285 |  # node_Reshape_3093
            %"val_3183"<?,?> ⬅️ ::Reshape(%"val_3181", %"val_3182") {allowzero=0}
    4286 |  # node_Constant_3094
            %"val_3184"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4287 |  # node_slice_157
            %"slice_157"<FLOAT,[1,768]> ⬅️ ::Slice(%"embedding_1", %"val_3177", %"val_3180", %"val_3183", %"val_3184")
    4288 |  # node_unsqueeze_116
            %"unsqueeze_116"<FLOAT,[1,1,768]> ⬅️ ::Unsqueeze(%"slice_157", %"val_18")
    4289 |  # node_Cast_3095
            %"val_3185"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4290 |  # node_Constant_3096
            %"val_3186"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4291 |  # node_Reshape_3097
            %"val_3187"<?,?> ⬅️ ::Reshape(%"val_3185", %"val_3186") {allowzero=0}
    4292 |  # node_Cast_3098
            %"val_3188"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4293 |  # node_Constant_3099
            %"val_3189"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4294 |  # node_Reshape_3100
            %"val_3190"<?,?> ⬅️ ::Reshape(%"val_3188", %"val_3189") {allowzero=0}
    4295 |  # node_Cast_3101
            %"val_3191"<?,?> ⬅️ ::Cast(%"val_77") {to=7}
    4296 |  # node_Constant_3102
            %"val_3192"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4297 |  # node_Reshape_3103
            %"val_3193"<?,?> ⬅️ ::Reshape(%"val_3191", %"val_3192") {allowzero=0}
    4298 |  # node_Constant_3104
            %"val_3194"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4299 |  # node_slice_158
            %"slice_158"<FLOAT,[1,1,768]> ⬅️ ::Slice(%"unsqueeze_116", %"val_3187", %"val_3190", %"val_3193", %"val_3194")
    4300 |  # node_add_88
            %"add_88"<FLOAT,[1,97,768]> ⬅️ ::Add(%"layer_norm_44", %"slice_158")
    4301 |  # node__to_copy_24
            %"_to_copy_24"<BOOL,[1,97]> ⬅️ ::Cast(%"attention_mask") {to=9}
    4302 |  # node_bitwise_not
            %"bitwise_not"<BOOL,[1,97]> ⬅️ ::Not(%"_to_copy_24")
    4303 |  # node_Cast_3105
            %"val_3195"<?,?> ⬅️ ::Cast(%"val_6") {to=1}
    4304 |  # node_Shape_3106
            %"val_3196"<?,?> ⬅️ ::Shape(%"bitwise_not") {start=0}
    4305 |  # node_zeros_like
            %"zeros_like"<FLOAT,[1,97]> ⬅️ ::Expand(%"val_3195", %"val_3196")
    4306 |  # node_Constant_3107
            %"val_3197"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(-inf, dtype=float32), name=None)}
    4307 |  # node_CastLike_3108
            %"val_3198"<?,?> ⬅️ ::CastLike(%"val_3197", %"zeros_like")
    4308 |  # node_masked_fill_2
            %"masked_fill_2"<FLOAT,[1,97]> ⬅️ ::Where(%"bitwise_not", %"val_3198", %"zeros_like")
    4309 |  # node_layer_norm_45
            %"layer_norm_45"<FLOAT,[1,97,768]>, %"val_3199"<?,?>, %"val_3200"<?,?> ⬅️ ::LayerNormalization(%"add_88", %"head.layers.0.norm1.weight"{...}, %"head.layers.0.norm1.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4310 |  # node_transpose_66
            %"transpose_66"<FLOAT,[97,1,768]> ⬅️ ::Transpose(%"layer_norm_45") {perm=(1, 0, 2)}
    4311 |  # node_Transpose_3109
            %"val_3201"<?,?> ⬅️ ::Transpose(%"head.layers.0.self_attn.in_proj_weight"{...}) {perm=(1, 0)}
    4312 |  # node_MatMul_3110
            %"val_3202"<?,?> ⬅️ ::MatMul(%"transpose_66", %"val_3201")
    4313 |  # node_linear_88
            %"linear_88"<FLOAT,[97,1,2304]> ⬅️ ::Add(%"val_3202", %"head.layers.0.self_attn.in_proj_bias"{...})
    4314 |  # node_Constant_3111
            %"val_3203"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4315 |  # node_Constant_3112
            %"val_3204"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4316 |  # node_Constant_3113
            %"val_3205"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4317 |  # node_Constant_3114
            %"val_3206"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    4318 |  # node_Constant_3115
            %"val_3207"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4319 |  # node_Concat_3116
            %"val_3208"<?,?> ⬅️ ::Concat(%"val_3204", %"val_3205", %"val_3206", %"val_3207") {axis=0}
    4320 |  # node_view_44
            %"view_44"<FLOAT,[97,1,3,768]> ⬅️ ::Reshape(%"linear_88", %"val_3208") {allowzero=1}
    4321 |  # node_unsqueeze_117
            %"unsqueeze_117"<FLOAT,[1,97,1,3,768]> ⬅️ ::Unsqueeze(%"view_44", %"val_5")
    4322 |  # node_transpose_67
            %"transpose_67"<FLOAT,[3,97,1,1,768]> ⬅️ ::Transpose(%"unsqueeze_117") {perm=(3, 1, 2, 0, 4)}
    4323 |  # node_squeeze
            %"squeeze"<FLOAT,[3,97,1,768]> ⬅️ ::Squeeze(%"transpose_67", %"val_891")
    4324 |  # node_clone_24
            %"clone_24"<FLOAT,[3,97,1,768]> ⬅️ ::Identity(%"squeeze")
    4325 |  # node_select
            %"select"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_24", %"val_6") {axis=0}
    4326 |  # node_select_1
            %"select_1"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_24", %"val_51") {axis=0}
    4327 |  # node_select_2
            %"select_2"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_24", %"val_77") {axis=0}
    4328 |  # node_Constant_3117
            %"val_3209"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4329 |  # node_Constant_3118
            %"val_3210"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4330 |  # node_Constant_3119
            %"val_3211"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4331 |  # node_Constant_3120
            %"val_3212"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4332 |  # node_Concat_3121
            %"val_3213"<?,?> ⬅️ ::Concat(%"val_3210", %"val_3211", %"val_3212") {axis=0}
    4333 |  # node_view_45
            %"view_45"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select", %"val_3213") {allowzero=1}
    4334 |  # node_transpose_68
            %"transpose_68"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_45") {perm=(1, 0, 2)}
    4335 |  # node_Constant_3122
            %"val_3214"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4336 |  # node_Constant_3123
            %"val_3215"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4337 |  # node_Constant_3124
            %"val_3216"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4338 |  # node_Constant_3125
            %"val_3217"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4339 |  # node_Concat_3126
            %"val_3218"<?,?> ⬅️ ::Concat(%"val_3215", %"val_3216", %"val_3217") {axis=0}
    4340 |  # node_view_46
            %"view_46"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_1", %"val_3218") {allowzero=1}
    4341 |  # node_transpose_69
            %"transpose_69"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_46") {perm=(1, 0, 2)}
    4342 |  # node_Constant_3127
            %"val_3219"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4343 |  # node_Constant_3128
            %"val_3220"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4344 |  # node_Constant_3129
            %"val_3221"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4345 |  # node_Constant_3130
            %"val_3222"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4346 |  # node_Concat_3131
            %"val_3223"<?,?> ⬅️ ::Concat(%"val_3220", %"val_3221", %"val_3222") {axis=0}
    4347 |  # node_view_47
            %"view_47"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_2", %"val_3223") {allowzero=1}
    4348 |  # node_transpose_70
            %"transpose_70"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_47") {perm=(1, 0, 2)}
    4349 |  # node_Constant_3132
            %"val_3224"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4350 |  # node_Constant_3133
            %"val_3225"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4351 |  # node_Constant_3134
            %"val_3226"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4352 |  # node_Constant_3135
            %"val_3227"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4353 |  # node_Constant_3136
            %"val_3228"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4354 |  # node_Concat_3137
            %"val_3229"<?,?> ⬅️ ::Concat(%"val_3225", %"val_3226", %"val_3227", %"val_3228") {axis=0}
    4355 |  # node_view_51
            %"view_51"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_68", %"val_3229") {allowzero=1}
    4356 |  # node_Constant_3138
            %"val_3230"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4357 |  # node_Constant_3139
            %"val_3231"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4358 |  # node_Constant_3140
            %"val_3232"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4359 |  # node_Constant_3141
            %"val_3233"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4360 |  # node_Constant_3142
            %"val_3234"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4361 |  # node_Concat_3143
            %"val_3235"<?,?> ⬅️ ::Concat(%"val_3231", %"val_3232", %"val_3233", %"val_3234") {axis=0}
    4362 |  # node_view_52
            %"view_52"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_69", %"val_3235") {allowzero=1}
    4363 |  # node_Constant_3144
            %"val_3236"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4364 |  # node_Constant_3145
            %"val_3237"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4365 |  # node_Constant_3146
            %"val_3238"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4366 |  # node_Constant_3147
            %"val_3239"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4367 |  # node_Constant_3148
            %"val_3240"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4368 |  # node_Concat_3149
            %"val_3241"<?,?> ⬅️ ::Concat(%"val_3237", %"val_3238", %"val_3239", %"val_3240") {axis=0}
    4369 |  # node_view_53
            %"view_53"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_70", %"val_3241") {allowzero=1}
    4370 |  # node_Constant_3150
            %"val_3242"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4371 |  # node_Constant_3151
            %"val_3243"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4372 |  # node_Constant_3152
            %"val_3244"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4373 |  # node_Constant_3153
            %"val_3245"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4374 |  # node_Constant_3154
            %"val_3246"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4375 |  # node_Concat_3155
            %"val_3247"<?,?> ⬅️ ::Concat(%"val_3243", %"val_3244", %"val_3245", %"val_3246") {axis=0}
    4376 |  # node_view_54
            %"view_54"<FLOAT,[1,1,1,97]> ⬅️ ::Reshape(%"masked_fill_2", %"val_3247") {allowzero=1}
    4377 |  # node_Constant_3156
            %"val_3248"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4378 |  # node_Constant_3157
            %"val_3249"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4379 |  # node_Constant_3158
            %"val_3250"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4380 |  # node_Constant_3159
            %"val_3251"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4381 |  # node_Constant_3160
            %"val_3252"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4382 |  # node_Concat_3161
            %"val_3253"<?,?> ⬅️ ::Concat(%"val_3249", %"val_3250", %"val_3251", %"val_3252") {axis=0}
    4383 |  # node_expand_24
            %"expand_24"<FLOAT,[1,12,1,97]> ⬅️ ::Expand(%"view_54", %"val_3253")
    4384 |  # node_Constant_3162
            %"val_3254"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4385 |  # node_Constant_3163
            %"val_3255"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4386 |  # node_Constant_3164
            %"val_3256"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4387 |  # node_Constant_3165
            %"val_3257"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4388 |  # node_Concat_3166
            %"val_3258"<?,?> ⬅️ ::Concat(%"val_3255", %"val_3256", %"val_3257") {axis=0}
    4389 |  # node_view_55
            %"view_55"<FLOAT,[12,1,97]> ⬅️ ::Reshape(%"expand_24", %"val_3258") {allowzero=1}
    4390 |  # node_Constant_3167
            %"val_3259"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4391 |  # node_Constant_3168
            %"val_3260"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4392 |  # node_Constant_3169
            %"val_3261"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4393 |  # node_Constant_3170
            %"val_3262"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4394 |  # node_Constant_3171
            %"val_3263"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4395 |  # node_Concat_3172
            %"val_3264"<?,?> ⬅️ ::Concat(%"val_3260", %"val_3261", %"val_3262", %"val_3263") {axis=0}
    4396 |  # node_view_56
            %"view_56"<FLOAT,[1,12,1,97]> ⬅️ ::Reshape(%"view_55", %"val_3264") {allowzero=1}
    4397 |  # node_Shape_3173
            %"val_3265"<?,?> ⬅️ ::Shape(%"view_51") {start=0}
    4398 |  # node_Constant_3174
            %"val_3266"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4399 |  # node_Gather_3175
            %"val_3267"<?,?> ⬅️ ::Gather(%"val_3265", %"val_3266") {axis=0}
    4400 |  # node_CastLike_3176
            %"val_3268"<?,?> ⬅️ ::CastLike(%"val_3267", %"view_51")
    4401 |  # node_Constant_3177
            %"val_3269"<?,?> ⬅️ ::Constant() {value_float=1.0}
    4402 |  # node_CastLike_3178
            %"val_3270"<?,?> ⬅️ ::CastLike(%"val_3269", %"view_51")
    4403 |  # node_Sqrt_3179
            %"val_3271"<?,?> ⬅️ ::Sqrt(%"val_3268")
    4404 |  # node_Div_3180
            %"val_3272"<?,?> ⬅️ ::Div(%"val_3270", %"val_3271")
    4405 |  # node_CastLike_3181
            %"val_3273"<?,?> ⬅️ ::CastLike(%"val_3272", %"view_51")
    4406 |  # node_Shape_3182
            %"val_3274"<?,?> ⬅️ ::Shape(%"view_52") {start=0}
    4407 |  # node_Constant_3183
            %"val_3275"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4408 |  # node_Slice_3184
            %"val_3276"<?,?> ⬅️ ::Slice(%"val_3274", %"val_889", %"val_3275")
    4409 |  # node_Slice_3185
            %"val_3277"<?,?> ⬅️ ::Slice(%"val_3274", %"val_891", %"val_889")
    4410 |  # node_Constant_3186
            %"val_3278"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    4411 |  # node_Slice_3187
            %"val_3279"<?,?> ⬅️ ::Slice(%"val_3274", %"val_3278", %"val_891")
    4412 |  # node_Constant_3188
            %"val_3280"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4413 |  # node_Concat_3189
            %"val_3281"<?,?> ⬅️ ::Concat(%"val_3280", %"val_3277", %"val_3276") {axis=0}
    4414 |  # node_Reshape_3190
            %"val_3282"<?,?> ⬅️ ::Reshape(%"view_52", %"val_3281") {allowzero=0}
    4415 |  # node_Transpose_3191
            %"val_3283"<?,?> ⬅️ ::Transpose(%"val_3282") {perm=(0, 2, 1)}
    4416 |  # node_Concat_3192
            %"val_3284"<?,?> ⬅️ ::Concat(%"val_3279", %"val_3276", %"val_3277") {axis=0}
    4417 |  # node_Reshape_3193
            %"val_3285"<?,?> ⬅️ ::Reshape(%"val_3283", %"val_3284") {allowzero=0}
    4418 |  # node_Sqrt_3194
            %"val_3286"<?,?> ⬅️ ::Sqrt(%"val_3273")
    4419 |  # node_Mul_3195
            %"val_3287"<?,?> ⬅️ ::Mul(%"view_51", %"val_3286")
    4420 |  # node_Sqrt_3196
            %"val_3288"<?,?> ⬅️ ::Sqrt(%"val_3273")
    4421 |  # node_Mul_3197
            %"val_3289"<?,?> ⬅️ ::Mul(%"val_3285", %"val_3288")
    4422 |  # node_MatMul_3198
            %"val_3290"<?,?> ⬅️ ::MatMul(%"val_3287", %"val_3289")
    4423 |  # node_Add_3199
            %"val_3291"<?,?> ⬅️ ::Add(%"val_3290", %"view_56")
    4424 |  # node_Softmax_3200
            %"val_3292"<?,?> ⬅️ ::Softmax(%"val_3291") {axis=-1}
    4425 |  # node_scaled_dot_product_attention_22
            %"scaled_dot_product_attention_22"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_3292", %"view_53")
    4426 |  # node_permute_1
            %"permute_1"<FLOAT,[97,1,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_22") {perm=(2, 0, 1, 3)}
    4427 |  # node_Constant_3201
            %"val_3293"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4428 |  # node_Constant_3202
            %"val_3294"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4429 |  # node_Constant_3203
            %"val_3295"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4430 |  # node_Concat_3204
            %"val_3296"<?,?> ⬅️ ::Concat(%"val_3294", %"val_3295") {axis=0}
    4431 |  # node_view_57
            %"view_57"<FLOAT,[97,768]> ⬅️ ::Reshape(%"permute_1", %"val_3296") {allowzero=1}
    4432 |  # node_linear_89
            %"linear_89"<FLOAT,[97,768]> ⬅️ ::Gemm(%"view_57", %"head.layers.0.self_attn.out_proj.weight"{...}, %"head.layers.0.self_attn.out_proj.bias"{...}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    4433 |  # node_Constant_3205
            %"val_3297"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4434 |  # node_Constant_3206
            %"val_3298"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4435 |  # node_Constant_3207
            %"val_3299"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4436 |  # node_Constant_3208
            %"val_3300"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4437 |  # node_Concat_3209
            %"val_3301"<?,?> ⬅️ ::Concat(%"val_3298", %"val_3299", %"val_3300") {axis=0}
    4438 |  # node_view_58
            %"view_58"<FLOAT,[97,1,768]> ⬅️ ::Reshape(%"linear_89", %"val_3301") {allowzero=1}
    4439 |  # node_transpose_71
            %"transpose_71"<FLOAT,[1,97,768]> ⬅️ ::Transpose(%"view_58") {perm=(1, 0, 2)}
    4440 |  # node_clone_25
            %"clone_25"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"transpose_71")
    4441 |  # node_add_89
            %"add_89"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_88", %"clone_25")
    4442 |  # node_layer_norm_46
            %"layer_norm_46"<FLOAT,[1,97,768]>, %"val_3302"<?,?>, %"val_3303"<?,?> ⬅️ ::LayerNormalization(%"add_89", %"head.layers.0.norm2.weight"{...}, %"head.layers.0.norm2.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4443 |  # node_Transpose_3210
            %"val_3304"<?,?> ⬅️ ::Transpose(%"head.layers.0.linear1.weight"{...}) {perm=(1, 0)}
    4444 |  # node_MatMul_3211
            %"val_3305"<?,?> ⬅️ ::MatMul(%"layer_norm_46", %"val_3304")
    4445 |  # node_linear_90
            %"linear_90"<FLOAT,[1,97,3072]> ⬅️ ::Add(%"val_3305", %"head.layers.0.linear1.bias"{...})
    4446 |  # node_relu
            %"relu"<FLOAT,[1,97,3072]> ⬅️ ::Relu(%"linear_90")
    4447 |  # node_clone_26
            %"clone_26"<FLOAT,[1,97,3072]> ⬅️ ::Identity(%"relu")
    4448 |  # node_Transpose_3212
            %"val_3306"<?,?> ⬅️ ::Transpose(%"head.layers.0.linear2.weight"{...}) {perm=(1, 0)}
    4449 |  # node_MatMul_3213
            %"val_3307"<?,?> ⬅️ ::MatMul(%"clone_26", %"val_3306")
    4450 |  # node_linear_91
            %"linear_91"<FLOAT,[1,97,768]> ⬅️ ::Add(%"val_3307", %"head.layers.0.linear2.bias"{...})
    4451 |  # node_clone_27
            %"clone_27"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"linear_91")
    4452 |  # node_add_90
            %"add_90"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_89", %"clone_27")
    4453 |  # node_Cast_3214
            %"val_3308"<?,?> ⬅️ ::Cast(%"val_6") {to=1}
    4454 |  # node_Shape_3215
            %"val_3309"<?,?> ⬅️ ::Shape(%"bitwise_not") {start=0}
    4455 |  # node_zeros_like_1
            %"zeros_like_1"<FLOAT,[1,97]> ⬅️ ::Expand(%"val_3308", %"val_3309")
    4456 |  # node_CastLike_3216
            %"val_3310"<?,?> ⬅️ ::CastLike(%"val_3197", %"zeros_like_1")
    4457 |  # node_masked_fill_3
            %"masked_fill_3"<FLOAT,[1,97]> ⬅️ ::Where(%"bitwise_not", %"val_3310", %"zeros_like_1")
    4458 |  # node_layer_norm_47
            %"layer_norm_47"<FLOAT,[1,97,768]>, %"val_3311"<?,?>, %"val_3312"<?,?> ⬅️ ::LayerNormalization(%"add_90", %"head.layers.1.norm1.weight"{...}, %"head.layers.1.norm1.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4459 |  # node_transpose_72
            %"transpose_72"<FLOAT,[97,1,768]> ⬅️ ::Transpose(%"layer_norm_47") {perm=(1, 0, 2)}
    4460 |  # node_Transpose_3217
            %"val_3313"<?,?> ⬅️ ::Transpose(%"head.layers.1.self_attn.in_proj_weight"{...}) {perm=(1, 0)}
    4461 |  # node_MatMul_3218
            %"val_3314"<?,?> ⬅️ ::MatMul(%"transpose_72", %"val_3313")
    4462 |  # node_linear_92
            %"linear_92"<FLOAT,[97,1,2304]> ⬅️ ::Add(%"val_3314", %"head.layers.1.self_attn.in_proj_bias"{...})
    4463 |  # node_Constant_3219
            %"val_3315"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4464 |  # node_Constant_3220
            %"val_3316"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4465 |  # node_Constant_3221
            %"val_3317"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4466 |  # node_Constant_3222
            %"val_3318"<INT64,?> ⬅️ ::Constant() {value_ints=(3,)}
    4467 |  # node_Constant_3223
            %"val_3319"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4468 |  # node_Concat_3224
            %"val_3320"<?,?> ⬅️ ::Concat(%"val_3316", %"val_3317", %"val_3318", %"val_3319") {axis=0}
    4469 |  # node_view_59
            %"view_59"<FLOAT,[97,1,3,768]> ⬅️ ::Reshape(%"linear_92", %"val_3320") {allowzero=1}
    4470 |  # node_unsqueeze_118
            %"unsqueeze_118"<FLOAT,[1,97,1,3,768]> ⬅️ ::Unsqueeze(%"view_59", %"val_5")
    4471 |  # node_transpose_73
            %"transpose_73"<FLOAT,[3,97,1,1,768]> ⬅️ ::Transpose(%"unsqueeze_118") {perm=(3, 1, 2, 0, 4)}
    4472 |  # node_squeeze_1
            %"squeeze_1"<FLOAT,[3,97,1,768]> ⬅️ ::Squeeze(%"transpose_73", %"val_891")
    4473 |  # node_clone_28
            %"clone_28"<FLOAT,[3,97,1,768]> ⬅️ ::Identity(%"squeeze_1")
    4474 |  # node_select_3
            %"select_3"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_28", %"val_6") {axis=0}
    4475 |  # node_select_4
            %"select_4"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_28", %"val_51") {axis=0}
    4476 |  # node_select_5
            %"select_5"<FLOAT,[97,1,768]> ⬅️ ::Gather(%"clone_28", %"val_77") {axis=0}
    4477 |  # node_Constant_3225
            %"val_3321"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4478 |  # node_Constant_3226
            %"val_3322"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4479 |  # node_Constant_3227
            %"val_3323"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4480 |  # node_Constant_3228
            %"val_3324"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4481 |  # node_Concat_3229
            %"val_3325"<?,?> ⬅️ ::Concat(%"val_3322", %"val_3323", %"val_3324") {axis=0}
    4482 |  # node_view_60
            %"view_60"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_3", %"val_3325") {allowzero=1}
    4483 |  # node_transpose_74
            %"transpose_74"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_60") {perm=(1, 0, 2)}
    4484 |  # node_Constant_3230
            %"val_3326"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4485 |  # node_Constant_3231
            %"val_3327"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4486 |  # node_Constant_3232
            %"val_3328"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4487 |  # node_Constant_3233
            %"val_3329"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4488 |  # node_Concat_3234
            %"val_3330"<?,?> ⬅️ ::Concat(%"val_3327", %"val_3328", %"val_3329") {axis=0}
    4489 |  # node_view_61
            %"view_61"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_4", %"val_3330") {allowzero=1}
    4490 |  # node_transpose_75
            %"transpose_75"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_61") {perm=(1, 0, 2)}
    4491 |  # node_Constant_3235
            %"val_3331"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4492 |  # node_Constant_3236
            %"val_3332"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4493 |  # node_Constant_3237
            %"val_3333"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4494 |  # node_Constant_3238
            %"val_3334"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4495 |  # node_Concat_3239
            %"val_3335"<?,?> ⬅️ ::Concat(%"val_3332", %"val_3333", %"val_3334") {axis=0}
    4496 |  # node_view_62
            %"view_62"<FLOAT,[97,12,64]> ⬅️ ::Reshape(%"select_5", %"val_3335") {allowzero=1}
    4497 |  # node_transpose_76
            %"transpose_76"<FLOAT,[12,97,64]> ⬅️ ::Transpose(%"view_62") {perm=(1, 0, 2)}
    4498 |  # node_Constant_3240
            %"val_3336"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4499 |  # node_Constant_3241
            %"val_3337"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4500 |  # node_Constant_3242
            %"val_3338"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4501 |  # node_Constant_3243
            %"val_3339"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4502 |  # node_Constant_3244
            %"val_3340"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4503 |  # node_Concat_3245
            %"val_3341"<?,?> ⬅️ ::Concat(%"val_3337", %"val_3338", %"val_3339", %"val_3340") {axis=0}
    4504 |  # node_view_66
            %"view_66"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_74", %"val_3341") {allowzero=1}
    4505 |  # node_Constant_3246
            %"val_3342"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4506 |  # node_Constant_3247
            %"val_3343"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4507 |  # node_Constant_3248
            %"val_3344"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4508 |  # node_Constant_3249
            %"val_3345"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4509 |  # node_Constant_3250
            %"val_3346"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4510 |  # node_Concat_3251
            %"val_3347"<?,?> ⬅️ ::Concat(%"val_3343", %"val_3344", %"val_3345", %"val_3346") {axis=0}
    4511 |  # node_view_67
            %"view_67"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_75", %"val_3347") {allowzero=1}
    4512 |  # node_Constant_3252
            %"val_3348"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4513 |  # node_Constant_3253
            %"val_3349"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4514 |  # node_Constant_3254
            %"val_3350"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4515 |  # node_Constant_3255
            %"val_3351"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4516 |  # node_Constant_3256
            %"val_3352"<INT64,?> ⬅️ ::Constant() {value_ints=(64,)}
    4517 |  # node_Concat_3257
            %"val_3353"<?,?> ⬅️ ::Concat(%"val_3349", %"val_3350", %"val_3351", %"val_3352") {axis=0}
    4518 |  # node_view_68
            %"view_68"<FLOAT,[1,12,97,64]> ⬅️ ::Reshape(%"transpose_76", %"val_3353") {allowzero=1}
    4519 |  # node_Constant_3258
            %"val_3354"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4520 |  # node_Constant_3259
            %"val_3355"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4521 |  # node_Constant_3260
            %"val_3356"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4522 |  # node_Constant_3261
            %"val_3357"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4523 |  # node_Constant_3262
            %"val_3358"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4524 |  # node_Concat_3263
            %"val_3359"<?,?> ⬅️ ::Concat(%"val_3355", %"val_3356", %"val_3357", %"val_3358") {axis=0}
    4525 |  # node_view_69
            %"view_69"<FLOAT,[1,1,1,97]> ⬅️ ::Reshape(%"masked_fill_3", %"val_3359") {allowzero=1}
    4526 |  # node_Constant_3264
            %"val_3360"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4527 |  # node_Constant_3265
            %"val_3361"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4528 |  # node_Constant_3266
            %"val_3362"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4529 |  # node_Constant_3267
            %"val_3363"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4530 |  # node_Constant_3268
            %"val_3364"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4531 |  # node_Concat_3269
            %"val_3365"<?,?> ⬅️ ::Concat(%"val_3361", %"val_3362", %"val_3363", %"val_3364") {axis=0}
    4532 |  # node_expand_26
            %"expand_26"<FLOAT,[1,12,1,97]> ⬅️ ::Expand(%"view_69", %"val_3365")
    4533 |  # node_Constant_3270
            %"val_3366"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4534 |  # node_Constant_3271
            %"val_3367"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4535 |  # node_Constant_3272
            %"val_3368"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4536 |  # node_Constant_3273
            %"val_3369"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4537 |  # node_Concat_3274
            %"val_3370"<?,?> ⬅️ ::Concat(%"val_3367", %"val_3368", %"val_3369") {axis=0}
    4538 |  # node_view_70
            %"view_70"<FLOAT,[12,1,97]> ⬅️ ::Reshape(%"expand_26", %"val_3370") {allowzero=1}
    4539 |  # node_Constant_3275
            %"val_3371"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4540 |  # node_Constant_3276
            %"val_3372"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4541 |  # node_Constant_3277
            %"val_3373"<INT64,?> ⬅️ ::Constant() {value_ints=(12,)}
    4542 |  # node_Constant_3278
            %"val_3374"<INT64,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4543 |  # node_Constant_3279
            %"val_3375"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4544 |  # node_Concat_3280
            %"val_3376"<?,?> ⬅️ ::Concat(%"val_3372", %"val_3373", %"val_3374", %"val_3375") {axis=0}
    4545 |  # node_view_71
            %"view_71"<FLOAT,[1,12,1,97]> ⬅️ ::Reshape(%"view_70", %"val_3376") {allowzero=1}
    4546 |  # node_Shape_3281
            %"val_3377"<?,?> ⬅️ ::Shape(%"view_66") {start=0}
    4547 |  # node_Constant_3282
            %"val_3378"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4548 |  # node_Gather_3283
            %"val_3379"<?,?> ⬅️ ::Gather(%"val_3377", %"val_3378") {axis=0}
    4549 |  # node_CastLike_3284
            %"val_3380"<?,?> ⬅️ ::CastLike(%"val_3379", %"view_66")
    4550 |  # node_Constant_3285
            %"val_3381"<?,?> ⬅️ ::Constant() {value_float=1.0}
    4551 |  # node_CastLike_3286
            %"val_3382"<?,?> ⬅️ ::CastLike(%"val_3381", %"view_66")
    4552 |  # node_Sqrt_3287
            %"val_3383"<?,?> ⬅️ ::Sqrt(%"val_3380")
    4553 |  # node_Div_3288
            %"val_3384"<?,?> ⬅️ ::Div(%"val_3382", %"val_3383")
    4554 |  # node_CastLike_3289
            %"val_3385"<?,?> ⬅️ ::CastLike(%"val_3384", %"view_66")
    4555 |  # node_Shape_3290
            %"val_3386"<?,?> ⬅️ ::Shape(%"view_67") {start=0}
    4556 |  # node_Constant_3291
            %"val_3387"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4557 |  # node_Slice_3292
            %"val_3388"<?,?> ⬅️ ::Slice(%"val_3386", %"val_889", %"val_3387")
    4558 |  # node_Slice_3293
            %"val_3389"<?,?> ⬅️ ::Slice(%"val_3386", %"val_891", %"val_889")
    4559 |  # node_Constant_3294
            %"val_3390"<?,?> ⬅️ ::Constant() {value_ints=(-9223372036854775808,)}
    4560 |  # node_Slice_3295
            %"val_3391"<?,?> ⬅️ ::Slice(%"val_3386", %"val_3390", %"val_891")
    4561 |  # node_Constant_3296
            %"val_3392"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4562 |  # node_Concat_3297
            %"val_3393"<?,?> ⬅️ ::Concat(%"val_3392", %"val_3389", %"val_3388") {axis=0}
    4563 |  # node_Reshape_3298
            %"val_3394"<?,?> ⬅️ ::Reshape(%"view_67", %"val_3393") {allowzero=0}
    4564 |  # node_Transpose_3299
            %"val_3395"<?,?> ⬅️ ::Transpose(%"val_3394") {perm=(0, 2, 1)}
    4565 |  # node_Concat_3300
            %"val_3396"<?,?> ⬅️ ::Concat(%"val_3391", %"val_3388", %"val_3389") {axis=0}
    4566 |  # node_Reshape_3301
            %"val_3397"<?,?> ⬅️ ::Reshape(%"val_3395", %"val_3396") {allowzero=0}
    4567 |  # node_Sqrt_3302
            %"val_3398"<?,?> ⬅️ ::Sqrt(%"val_3385")
    4568 |  # node_Mul_3303
            %"val_3399"<?,?> ⬅️ ::Mul(%"view_66", %"val_3398")
    4569 |  # node_Sqrt_3304
            %"val_3400"<?,?> ⬅️ ::Sqrt(%"val_3385")
    4570 |  # node_Mul_3305
            %"val_3401"<?,?> ⬅️ ::Mul(%"val_3397", %"val_3400")
    4571 |  # node_MatMul_3306
            %"val_3402"<?,?> ⬅️ ::MatMul(%"val_3399", %"val_3401")
    4572 |  # node_Add_3307
            %"val_3403"<?,?> ⬅️ ::Add(%"val_3402", %"view_71")
    4573 |  # node_Softmax_3308
            %"val_3404"<?,?> ⬅️ ::Softmax(%"val_3403") {axis=-1}
    4574 |  # node_scaled_dot_product_attention_23
            %"scaled_dot_product_attention_23"<FLOAT,[1,12,97,64]> ⬅️ ::MatMul(%"val_3404", %"view_68")
    4575 |  # node_permute_2
            %"permute_2"<FLOAT,[97,1,12,64]> ⬅️ ::Transpose(%"scaled_dot_product_attention_23") {perm=(2, 0, 1, 3)}
    4576 |  # node_Constant_3309
            %"val_3405"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4577 |  # node_Constant_3310
            %"val_3406"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4578 |  # node_Constant_3311
            %"val_3407"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4579 |  # node_Concat_3312
            %"val_3408"<?,?> ⬅️ ::Concat(%"val_3406", %"val_3407") {axis=0}
    4580 |  # node_view_72
            %"view_72"<FLOAT,[97,768]> ⬅️ ::Reshape(%"permute_2", %"val_3408") {allowzero=1}
    4581 |  # node_linear_93
            %"linear_93"<FLOAT,[97,768]> ⬅️ ::Gemm(%"view_72", %"head.layers.1.self_attn.out_proj.weight"{...}, %"head.layers.1.self_attn.out_proj.bias"{...}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    4582 |  # node_Constant_3313
            %"val_3409"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4583 |  # node_Constant_3314
            %"val_3410"<INT64,?> ⬅️ ::Constant() {value_ints=(97,)}
    4584 |  # node_Constant_3315
            %"val_3411"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4585 |  # node_Constant_3316
            %"val_3412"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4586 |  # node_Concat_3317
            %"val_3413"<?,?> ⬅️ ::Concat(%"val_3410", %"val_3411", %"val_3412") {axis=0}
    4587 |  # node_view_73
            %"view_73"<FLOAT,[97,1,768]> ⬅️ ::Reshape(%"linear_93", %"val_3413") {allowzero=1}
    4588 |  # node_transpose_77
            %"transpose_77"<FLOAT,[1,97,768]> ⬅️ ::Transpose(%"view_73") {perm=(1, 0, 2)}
    4589 |  # node_clone_29
            %"clone_29"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"transpose_77")
    4590 |  # node_add_91
            %"add_91"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_90", %"clone_29")
    4591 |  # node_layer_norm_48
            %"layer_norm_48"<FLOAT,[1,97,768]>, %"val_3414"<?,?>, %"val_3415"<?,?> ⬅️ ::LayerNormalization(%"add_91", %"head.layers.1.norm2.weight"{...}, %"head.layers.1.norm2.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4592 |  # node_Transpose_3318
            %"val_3416"<?,?> ⬅️ ::Transpose(%"head.layers.1.linear1.weight"{...}) {perm=(1, 0)}
    4593 |  # node_MatMul_3319
            %"val_3417"<?,?> ⬅️ ::MatMul(%"layer_norm_48", %"val_3416")
    4594 |  # node_linear_94
            %"linear_94"<FLOAT,[1,97,3072]> ⬅️ ::Add(%"val_3417", %"head.layers.1.linear1.bias"{...})
    4595 |  # node_relu_1
            %"relu_1"<FLOAT,[1,97,3072]> ⬅️ ::Relu(%"linear_94")
    4596 |  # node_clone_30
            %"clone_30"<FLOAT,[1,97,3072]> ⬅️ ::Identity(%"relu_1")
    4597 |  # node_Transpose_3320
            %"val_3418"<?,?> ⬅️ ::Transpose(%"head.layers.1.linear2.weight"{...}) {perm=(1, 0)}
    4598 |  # node_MatMul_3321
            %"val_3419"<?,?> ⬅️ ::MatMul(%"clone_30", %"val_3418")
    4599 |  # node_linear_95
            %"linear_95"<FLOAT,[1,97,768]> ⬅️ ::Add(%"val_3419", %"head.layers.1.linear2.bias"{...})
    4600 |  # node_clone_31
            %"clone_31"<FLOAT,[1,97,768]> ⬅️ ::Identity(%"linear_95")
    4601 |  # node_add_92
            %"add_92"<FLOAT,[1,97,768]> ⬅️ ::Add(%"add_91", %"clone_31")
    4602 |  # node_CastLike_3322
            %"val_3420"<?,?> ⬅️ ::CastLike(%"val_6", %"marker_pos")
    4603 |  # node_clamp
            %"clamp"<INT64,[1,3]> ⬅️ ::Clip(%"marker_pos", %"val_3420")
    4604 |  # node_Cast_3323
            %"val_3421"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4605 |  # node_Constant_3324
            %"val_3422"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4606 |  # node_Reshape_3325
            %"val_3423"<?,?> ⬅️ ::Reshape(%"val_3421", %"val_3422") {allowzero=0}
    4607 |  # node_Cast_3326
            %"val_3424"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4608 |  # node_Constant_3327
            %"val_3425"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4609 |  # node_Reshape_3328
            %"val_3426"<?,?> ⬅️ ::Reshape(%"val_3424", %"val_3425") {allowzero=0}
    4610 |  # node_Cast_3329
            %"val_3427"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4611 |  # node_Constant_3330
            %"val_3428"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4612 |  # node_Reshape_3331
            %"val_3429"<?,?> ⬅️ ::Reshape(%"val_3427", %"val_3428") {allowzero=0}
    4613 |  # node_Constant_3332
            %"val_3430"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4614 |  # node_slice_159
            %"slice_159"<INT64,[1,3]> ⬅️ ::Slice(%"clamp", %"val_3423", %"val_3426", %"val_3429", %"val_3430")
    4615 |  # node_Cast_3333
            %"val_3431"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4616 |  # node_Constant_3334
            %"val_3432"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4617 |  # node_Reshape_3335
            %"val_3433"<?,?> ⬅️ ::Reshape(%"val_3431", %"val_3432") {allowzero=0}
    4618 |  # node_Cast_3336
            %"val_3434"<?,?> ⬅️ ::Cast(%"val_10") {to=7}
    4619 |  # node_Constant_3337
            %"val_3435"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4620 |  # node_Reshape_3338
            %"val_3436"<?,?> ⬅️ ::Reshape(%"val_3434", %"val_3435") {allowzero=0}
    4621 |  # node_Cast_3339
            %"val_3437"<?,?> ⬅️ ::Cast(%"val_51") {to=7}
    4622 |  # node_Constant_3340
            %"val_3438"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4623 |  # node_Reshape_3341
            %"val_3439"<?,?> ⬅️ ::Reshape(%"val_3437", %"val_3438") {allowzero=0}
    4624 |  # node_Constant_3342
            %"val_3440"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4625 |  # node_slice_160
            %"slice_160"<INT64,[1,3]> ⬅️ ::Slice(%"slice_159", %"val_3433", %"val_3436", %"val_3439", %"val_3440")
    4626 |  # node_unsqueeze_119
            %"unsqueeze_119"<INT64,[1,3,1]> ⬅️ ::Unsqueeze(%"slice_160", %"val_19")
    4627 |  # node_Constant_3343
            %"val_3441"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4628 |  # node_Constant_3344
            %"val_3442"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4629 |  # node_Constant_3345
            %"val_3443"<INT64,?> ⬅️ ::Constant() {value_ints=(1,)}
    4630 |  # node_Constant_3346
            %"val_3444"<INT64,?> ⬅️ ::Constant() {value_ints=(768,)}
    4631 |  # node_Concat_3347
            %"val_3445"<?,?> ⬅️ ::Concat(%"val_3442", %"val_3443", %"val_3444") {axis=0}
    4632 |  # node_expand_27
            %"expand_27"<INT64,[1,3,768]> ⬅️ ::Expand(%"unsqueeze_119", %"val_3445")
    4633 |  # node_Cast_3348
            %"val_3446"<?,?> ⬅️ ::Cast(%"expand_27") {to=7}
    4634 |  # node_gather
            %"gather"<FLOAT,[1,3,768]> ⬅️ ::GatherElements(%"add_92", %"val_3446") {axis=1}
    4635 |  # node_layer_norm_49
            %"layer_norm_49"<FLOAT,[1,3,768]>, %"val_3447"<?,?>, %"val_3448"<?,?> ⬅️ ::LayerNormalization(%"gather", %"scorer.0.weight"{...}, %"scorer.0.bias"{...}) {stash_type=1, epsilon=1e-05, axis=-1}
    4636 |  # node_Transpose_3349
            %"val_3449"<?,?> ⬅️ ::Transpose(%"scorer.1.weight"{...}) {perm=(1, 0)}
    4637 |  # node_MatMul_3350
            %"val_3450"<?,?> ⬅️ ::MatMul(%"layer_norm_49", %"val_3449")
    4638 |  # node_linear_96
            %"linear_96"<FLOAT,[1,3,768]> ⬅️ ::Add(%"val_3450", %"scorer.1.bias"{...})
    4639 |  # node_Constant_3351
            %"val_3451"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    4640 |  # node_Div_3352
            %"val_3452"<?,?> ⬅️ ::Div(%"linear_96", %"val_3451")
    4641 |  # node_Erf_3353
            %"val_3453"<?,?> ⬅️ ::Erf(%"val_3452")
    4642 |  # node_Constant_3354
            %"val_3454"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    4643 |  # node_Add_3355
            %"val_3455"<?,?> ⬅️ ::Add(%"val_3453", %"val_3454")
    4644 |  # node_Constant_3356
            %"val_3456"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    4645 |  # node_Mul_3357
            %"val_3457"<?,?> ⬅️ ::Mul(%"val_3456", %"val_3455")
    4646 |  # node_gelu_22
            %"gelu_22"<FLOAT,[1,3,768]> ⬅️ ::Mul(%"linear_96", %"val_3457")
    4647 |  # node_Transpose_3358
            %"val_3458"<?,?> ⬅️ ::Transpose(%"scorer.3.weight"{...}) {perm=(1, 0)}
    4648 |  # node_MatMul_3359
            %"val_3459"<?,?> ⬅️ ::MatMul(%"gelu_22", %"val_3458")
    4649 |  # node_linear_97
            %"linear_97"<FLOAT,[1,3,1]> ⬅️ ::Add(%"val_3459", %"scorer.3.bias"{[0.0258636474609375]})
    4650 |  # node_squeeze_2
            %"squeeze_2"<FLOAT,[1,3]> ⬅️ ::Squeeze(%"linear_97", %"val_889")
    4651 |  # node_bitwise_not_1
            %"bitwise_not_1"<BOOL,[1,3]> ⬅️ ::Not(%"marker_mask")
    4652 |  # node_Constant_3360
            %"val_3460"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(-10000., dtype=float32), name=None)}
    4653 |  # node_CastLike_3361
            %"val_3461"<?,?> ⬅️ ::CastLike(%"val_3460", %"squeeze_2")
    4654 |  # node_masked_fill_4
            %"logits"<FLOAT,[1,3]> ⬅️ ::Where(%"bitwise_not_1", %"val_3461", %"squeeze_2")
    4655 |  # node_detach
            %"detach"<FLOAT,[1,3]> ⬅️ ::Identity(%"logits")
    4656 |  # node_detach_1
            %"detach_1"<FLOAT,[1,3]> ⬅️ ::Identity(%"detach")
    4657 |  # node_detach_2
            %"detach_2"<FLOAT,[1,3]> ⬅️ ::Identity(%"detach_1")
    4658 |  # node_softmax
            %"softmax"<FLOAT,[1,3]> ⬅️ ::Softmax(%"detach_2") {axis=-1}
    4659 |  # node_convert_element_type_default
            %"convert_element_type_default"<INT64,[1,3]> ⬅️ ::Cast(%"marker_mask") {to=7}
    4660 |  # node_Constant_3362
            %"val_3462"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([-1]), name=None)}
    4661 |  # node_sum_1
            %"sum_1"<INT64,[1]> ⬅️ ::ReduceSum(%"convert_element_type_default", %"val_3462") {noop_with_empty_axes=0, keepdims=0}
    4662 |  # node_CastLike_3363
            %"val_3463"<?,?> ⬅️ ::CastLike(%"val_77", %"sum_1")
    4663 |  # node_clamp_1
            %"clamp_1"<INT64,[1]> ⬅️ ::Clip(%"sum_1", %"val_3463")
    4664 |  # node__to_copy_25
            %"_to_copy_25"<FLOAT,[1]> ⬅️ ::Cast(%"clamp_1") {to=1}
    4665 |  # node_Constant_3364
            %"val_3464"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.e-09, dtype=float32), name=None)}
    4666 |  # node_CastLike_3365
            %"val_3465"<?,?> ⬅️ ::CastLike(%"val_3464", %"softmax")
    4667 |  # node_clamp_min
            %"clamp_min"<FLOAT,[1,3]> ⬅️ ::Clip(%"softmax", %"val_3465")
    4668 |  # node_log
            %"log"<FLOAT,[1,3]> ⬅️ ::Log(%"clamp_min")
    4669 |  # node_mul_154
            %"mul_154"<FLOAT,[1,3]> ⬅️ ::Mul(%"softmax", %"log")
    4670 |  # node_Constant_3366
            %"val_3466"<?,?> ⬅️ ::Constant() {value=Tensor<INT64,[1]>(array([-1]), name=None)}
    4671 |  # node_sum_2
            %"sum_2"<FLOAT,[1]> ⬅️ ::ReduceSum(%"mul_154", %"val_3466") {noop_with_empty_axes=0, keepdims=0}
    4672 |  # node_neg_44
            %"neg_44"<FLOAT,[1]> ⬅️ ::Neg(%"sum_2")
    4673 |  # node_log_1
            %"log_1"<FLOAT,[1]> ⬅️ ::Log(%"_to_copy_25")
    4674 |  # node_div
            %"div"<FLOAT,[1]> ⬅️ ::Div(%"neg_44", %"log_1")
    4675 |  # node_topk__1
            %"getitem_110"<FLOAT,[1,2]>, %"topk__1"<INT64,[1,2]> ⬅️ ::TopK(%"softmax", %"val_19") {sorted=1, largest=1, axis=-1}
    4676 |  # node_Constant_3367
            %"val_3467"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4677 |  # node_Constant_3368
            %"val_3468"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4678 |  # node_Cast_3369
            %"val_3469"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4679 |  # node_Constant_3370
            %"val_3470"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4680 |  # node_Reshape_3371
            %"val_3471"<?,?> ⬅️ ::Reshape(%"val_3469", %"val_3470") {allowzero=0}
    4681 |  # node_Constant_3372
            %"val_3472"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4682 |  # node_slice_161
            %"slice_161"<FLOAT,[1,2]> ⬅️ ::Slice(%"getitem_110", %"val_3467", %"val_3468", %"val_3471", %"val_3472")
    4683 |  # node_select_6
            %"select_6"<FLOAT,[1]> ⬅️ ::Gather(%"slice_161", %"val_6") {axis=1}
    4684 |  # node_Constant_3373
            %"val_3473"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4685 |  # node_Constant_3374
            %"val_3474"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4686 |  # node_Cast_3375
            %"val_3475"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4687 |  # node_Constant_3376
            %"val_3476"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4688 |  # node_Reshape_3377
            %"val_3477"<?,?> ⬅️ ::Reshape(%"val_3475", %"val_3476") {allowzero=0}
    4689 |  # node_Constant_3378
            %"val_3478"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4690 |  # node_slice_162
            %"slice_162"<FLOAT,[1,2]> ⬅️ ::Slice(%"getitem_110", %"val_3473", %"val_3474", %"val_3477", %"val_3478")
    4691 |  # node_select_7
            %"select_7"<FLOAT,[1]> ⬅️ ::Gather(%"slice_162", %"val_6") {axis=1}
    4692 |  # node_Constant_3379
            %"val_3479"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4693 |  # node_Constant_3380
            %"val_3480"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4694 |  # node_Cast_3381
            %"val_3481"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4695 |  # node_Constant_3382
            %"val_3482"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4696 |  # node_Reshape_3383
            %"val_3483"<?,?> ⬅️ ::Reshape(%"val_3481", %"val_3482") {allowzero=0}
    4697 |  # node_Constant_3384
            %"val_3484"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4698 |  # node_slice_163
            %"slice_163"<FLOAT,[1,2]> ⬅️ ::Slice(%"getitem_110", %"val_3479", %"val_3480", %"val_3483", %"val_3484")
    4699 |  # node_select_8
            %"select_8"<FLOAT,[1]> ⬅️ ::Gather(%"slice_163", %"val_51") {axis=1}
    4700 |  # node_sub_2
            %"sub_2"<FLOAT,[1]> ⬅️ ::Sub(%"select_7", %"select_8")
    4701 |  # node_Constant_3385
            %"val_3485"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(255., dtype=float32), name=None)}
    4702 |  # node_div_1
            %"div_1"<FLOAT,[1]> ⬅️ ::Div(%"_to_copy_25", %"val_3485")
    4703 |  # node_Constant_3386
            %"val_3486"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4704 |  # node_Unsqueeze_3387
            %"val_3487"<?,?> ⬅️ ::Unsqueeze(%"select_6", %"val_3486")
    4705 |  # node_Constant_3388
            %"val_3488"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4706 |  # node_Unsqueeze_3389
            %"val_3489"<?,?> ⬅️ ::Unsqueeze(%"sub_2", %"val_3488")
    4707 |  # node_Constant_3390
            %"val_3490"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4708 |  # node_Unsqueeze_3391
            %"val_3491"<?,?> ⬅️ ::Unsqueeze(%"div", %"val_3490")
    4709 |  # node_Constant_3392
            %"val_3492"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4710 |  # node_Unsqueeze_3393
            %"val_3493"<?,?> ⬅️ ::Unsqueeze(%"div_1", %"val_3492")
    4711 |  # node_stack
            %"stack"<FLOAT,[1,4]> ⬅️ ::Concat(%"val_3487", %"val_3489", %"val_3491", %"val_3493") {axis=-1}
    4712 |  # node_Constant_3394
            %"val_3494"<?,?> ⬅️ ::Constant() {value_ints=(0,)}
    4713 |  # node_Constant_3395
            %"val_3495"<?,?> ⬅️ ::Constant() {value_ints=(9223372036854775807,)}
    4714 |  # node_Cast_3396
            %"val_3496"<?,?> ⬅️ ::Cast(%"val_6") {to=7}
    4715 |  # node_Constant_3397
            %"val_3497"<?,?> ⬅️ ::Constant() {value_ints=(-1,)}
    4716 |  # node_Reshape_3398
            %"val_3498"<?,?> ⬅️ ::Reshape(%"val_3496", %"val_3497") {allowzero=0}
    4717 |  # node_Constant_3399
            %"val_3499"<?,?> ⬅️ ::Constant() {value_ints=(1,)}
    4718 |  # node_slice_164
            %"slice_164"<FLOAT,[1,97,768]> ⬅️ ::Slice(%"add_92", %"val_3494", %"val_3495", %"val_3498", %"val_3499")
    4719 |  # node_select_9
            %"select_9"<FLOAT,[1,768]> ⬅️ ::Gather(%"slice_164", %"val_6") {axis=1}
    4720 |  # node_cat_66
            %"cat_66"<FLOAT,[1,772]> ⬅️ ::Concat(%"select_9", %"stack") {axis=-1}
    4721 |  # node_linear_98
            %"linear_98"<FLOAT,[1,256]> ⬅️ ::Gemm(%"cat_66", %"act_head.0.weight"{...}, %"act_head.0.bias"{...}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    4722 |  # node_Constant_3400
            %"val_3500"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1.4142135, dtype=float32), name=None)}
    4723 |  # node_Div_3401
            %"val_3501"<?,?> ⬅️ ::Div(%"linear_98", %"val_3500")
    4724 |  # node_Erf_3402
            %"val_3502"<?,?> ⬅️ ::Erf(%"val_3501")
    4725 |  # node_Constant_3403
            %"val_3503"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(1., dtype=float32), name=None)}
    4726 |  # node_Add_3404
            %"val_3504"<?,?> ⬅️ ::Add(%"val_3502", %"val_3503")
    4727 |  # node_Constant_3405
            %"val_3505"<?,?> ⬅️ ::Constant() {value=Tensor<FLOAT,[]>(array(0.5, dtype=float32), name=None)}
    4728 |  # node_Mul_3406
            %"val_3506"<?,?> ⬅️ ::Mul(%"val_3505", %"val_3504")
    4729 |  # node_gelu_23
            %"gelu_23"<FLOAT,[1,256]> ⬅️ ::Mul(%"linear_98", %"val_3506")
    4730 |  # node_linear_99
            %"act_logits"<FLOAT,[1,2]> ⬅️ ::Gemm(%"gelu_23", %"act_head.2.weight"{...}, %"act_head.2.bias"{[0.023529052734375, -0.0204925537109375]}) {beta=1.0, transB=1, alpha=1.0, transA=0}
    return %"logits"<FLOAT,[1,3]>, %"act_logits"<FLOAT,[1,2]>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib::aten_split(
    inputs=(
        %"self"<?,?>,
        %"split_size"<?,?>
    ),
    attributes={
        dim: INT = 0
    }
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"return_val"<?,?> ⬅️ ::SplitToSequence(%"self", %"split_size") {axis=@dim}
    return %"return_val"<?,?>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib::aten_getitem(
    inputs=(
        %"self"<?,?>,
        %"i"<?,?>
    ),
    outputs=(
        %"return_val"<?,?>
    ),
) {
    0 |  # n0
         %"return_val"<?,?> ⬅️ ::SequenceAt(%"self", %"i")
    return %"return_val"<?,?>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib.common::Rank(
    inputs=(
        %"input"<?,?>
    ),
    outputs=(
        %"return_val"<INT64,[]>
    ),
) {
    0 |  # n0
         %"tmp"<?,?> ⬅️ ::Shape(%"input")
    1 |  # n1
         %"return_val"<INT64,[]> ⬅️ ::Size(%"tmp")
    return %"return_val"<INT64,[]>
}

<
    opset_imports={'': 18},
>
def pkg.onnxscript.torch_lib.common::IsScalar(
    inputs=(
        %"input"<?,?>
    ),
    outputs=(
        %"return_val"<BOOL,[]>
    ),
) {
    0 |  # n0
         %"tmp"<?,?> ⬅️ ::Shape(%"input")
    1 |  # n1
         %"tmp_0"<?,?> ⬅️ ::Size(%"tmp")
    2 |  # n2
         %"tmp_1"<?,?> ⬅️ ::Constant() {value_int=0}
    3 |  # n3
         %"return_val"<BOOL,[]> ⬅️ ::Equal(%"tmp_0", %"tmp_1")
    return %"return_val"<BOOL,[]>
}
```

## Analysis

PyTorch ONNX Conversion Analysis

## Model Information

The model has 321908995 parameters and 131 buffers (non-trainable parameters).
Number of parameters per dtype:
```python
defaultdict(<class 'int'>, {torch.float32: 321908995})
```
Number of buffers per dtype:
```python
defaultdict(<class 'int'>, {torch.float32: 131})
```

Inputs:
- `input_ids`: `TensorMetadata(shape=torch.Size([1, 97]), dtype=torch.int64, requires_grad=False, stride=(97, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `attention_mask`: `TensorMetadata(shape=torch.Size([1, 97]), dtype=torch.int64, requires_grad=False, stride=(97, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `marker_pos`: `TensorMetadata(shape=torch.Size([1, 3]), dtype=torch.int64, requires_grad=False, stride=(3, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `marker_mask`: `TensorMetadata(shape=torch.Size([1, 3]), dtype=torch.bool, requires_grad=False, stride=(3, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `qtype`: `TensorMetadata(shape=torch.Size([1]), dtype=torch.int64, requires_grad=False, stride=(1,), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`

Outputs:
- `masked_fill_4`: `TensorMetadata(shape=torch.Size([1, 3]), dtype=torch.float32, requires_grad=False, stride=(3, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`
- `linear_99`: `TensorMetadata(shape=torch.Size([1, 2]), dtype=torch.float32, requires_grad=False, stride=(2, 1), memory_format=torch.contiguous_format, is_quantized=False, qparams={})`

The FX graph has 1528 nodes in total. Number of FX nodes per op:
- `placeholder`: 180
- `call_function`: 1347
- `output`: 1


Of the call_function nodes, the counts of operators used are:

- `aten.slice.Tensor`: 164
- `aten.mul.Tensor`: 155
- `aten.unsqueeze.default`: 120
- `<built-in function getitem>`: 111
- `aten.linear.default`: 100
- `aten.add.Tensor`: 93
- `aten.transpose.int`: 78
- `aten.view.default`: 68
- `aten.cat.default`: 67
- `aten.layer_norm.default`: 50
- `aten.neg.default`: 45
- `aten.clone.default`: 32
- `aten.expand.default`: 26
- `aten._to_copy.default`: 26
- `aten.scaled_dot_product_attention.default`: 24
- `aten.gelu.default`: 24
- `aten.matmul.default`: 22
- `aten.cos.default`: 22
- `aten.sin.default`: 22
- `aten.unbind.int`: 22
- `aten.split.Tensor`: 22
- `aten.select.int`: 10
- `aten.masked_fill.Scalar`: 5
- `aten.sub.Tensor`: 3
- `aten.permute.default`: 3
- `aten.squeeze.dim`: 3
- `aten.detach.default`: 3
- `aten.arange.default`: 2
- `aten.embedding.default`: 2
- `aten.bitwise_not.default`: 2
- `aten.zeros_like.default`: 2
- `aten.relu.default`: 2
- `aten.clamp.default`: 2
- `aten.sum.dim_IntList`: 2
- `aten.log.default`: 2
- `aten.div.Tensor`: 2
- `aten.abs.default`: 1
- `aten.le.Scalar`: 1
- `aten.logical_not.default`: 1
- `aten.gather.default`: 1
- `aten.softmax.int`: 1
- `prims.convert_element_type.default`: 1
- `aten.clamp_min.default`: 1
- `aten.topk.default`: 1
- `aten.stack.default`: 1

## ONNX Conversion Information

All operators in the model have registered ONNX decompositions.

## Decomposition comparison

Ops exist only in the ExportedProgram before decomposition: `['aten._assert_tensor_metadata.default', 'aten.chunk.default', 'aten.contiguous.default', 'aten.detach_.default', 'aten.dropout.default', 'aten.lift_fresh_copy.default', 'aten.masked_fill_.Scalar', 'aten.numpy_T.default', 'aten.reshape.default', 'aten.sym_size.int', 'aten.to.dtype', 'aten.to.dtype_layout', 'aten.unflatten.int', 'wrap_with_set_grad_enabled']`

Ops exist only in the ExportedProgram after decomposition: `['aten._to_copy.default', 'aten.clone.default', 'aten.cos.default', 'aten.matmul.default', 'aten.sin.default', 'aten.split.Tensor', 'prims.convert_element_type.default']`

